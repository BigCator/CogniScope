// Auto-generated. Do not edit!

// (in-package tag_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class tag {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.tag = null;
      this.weather = null;
      this.stamp = null;
      this.cnt_road_change = null;
      this.cnt_weather_change = null;
      this.rsv1 = null;
      this.rsv2 = null;
      this.rsv3 = null;
      this.rsv4 = null;
      this.rsv5 = null;
      this.rsv6 = null;
      this.rsv7 = null;
      this.rsv8 = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('tag')) {
        this.tag = initObj.tag
      }
      else {
        this.tag = '';
      }
      if (initObj.hasOwnProperty('weather')) {
        this.weather = initObj.weather
      }
      else {
        this.weather = '';
      }
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('cnt_road_change')) {
        this.cnt_road_change = initObj.cnt_road_change
      }
      else {
        this.cnt_road_change = 0;
      }
      if (initObj.hasOwnProperty('cnt_weather_change')) {
        this.cnt_weather_change = initObj.cnt_weather_change
      }
      else {
        this.cnt_weather_change = 0;
      }
      if (initObj.hasOwnProperty('rsv1')) {
        this.rsv1 = initObj.rsv1
      }
      else {
        this.rsv1 = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('rsv2')) {
        this.rsv2 = initObj.rsv2
      }
      else {
        this.rsv2 = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('rsv3')) {
        this.rsv3 = initObj.rsv3
      }
      else {
        this.rsv3 = '';
      }
      if (initObj.hasOwnProperty('rsv4')) {
        this.rsv4 = initObj.rsv4
      }
      else {
        this.rsv4 = '';
      }
      if (initObj.hasOwnProperty('rsv5')) {
        this.rsv5 = initObj.rsv5
      }
      else {
        this.rsv5 = 0.0;
      }
      if (initObj.hasOwnProperty('rsv6')) {
        this.rsv6 = initObj.rsv6
      }
      else {
        this.rsv6 = 0.0;
      }
      if (initObj.hasOwnProperty('rsv7')) {
        this.rsv7 = initObj.rsv7
      }
      else {
        this.rsv7 = 0;
      }
      if (initObj.hasOwnProperty('rsv8')) {
        this.rsv8 = initObj.rsv8
      }
      else {
        this.rsv8 = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type tag
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [tag]
    bufferOffset = _serializer.string(obj.tag, buffer, bufferOffset);
    // Serialize message field [weather]
    bufferOffset = _serializer.string(obj.weather, buffer, bufferOffset);
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [cnt_road_change]
    bufferOffset = _serializer.uint32(obj.cnt_road_change, buffer, bufferOffset);
    // Serialize message field [cnt_weather_change]
    bufferOffset = _serializer.uint32(obj.cnt_weather_change, buffer, bufferOffset);
    // Serialize message field [rsv1]
    bufferOffset = _serializer.time(obj.rsv1, buffer, bufferOffset);
    // Serialize message field [rsv2]
    bufferOffset = _serializer.time(obj.rsv2, buffer, bufferOffset);
    // Serialize message field [rsv3]
    bufferOffset = _serializer.string(obj.rsv3, buffer, bufferOffset);
    // Serialize message field [rsv4]
    bufferOffset = _serializer.string(obj.rsv4, buffer, bufferOffset);
    // Serialize message field [rsv5]
    bufferOffset = _serializer.float32(obj.rsv5, buffer, bufferOffset);
    // Serialize message field [rsv6]
    bufferOffset = _serializer.float32(obj.rsv6, buffer, bufferOffset);
    // Serialize message field [rsv7]
    bufferOffset = _serializer.int32(obj.rsv7, buffer, bufferOffset);
    // Serialize message field [rsv8]
    bufferOffset = _serializer.int32(obj.rsv8, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type tag
    let len;
    let data = new tag(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [tag]
    data.tag = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [weather]
    data.weather = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [cnt_road_change]
    data.cnt_road_change = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [cnt_weather_change]
    data.cnt_weather_change = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [rsv1]
    data.rsv1 = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [rsv2]
    data.rsv2 = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [rsv3]
    data.rsv3 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [rsv4]
    data.rsv4 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [rsv5]
    data.rsv5 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [rsv6]
    data.rsv6 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [rsv7]
    data.rsv7 = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [rsv8]
    data.rsv8 = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.tag.length;
    length += object.weather.length;
    length += object.rsv3.length;
    length += object.rsv4.length;
    return length + 64;
  }

  static datatype() {
    // Returns string type for a message object
    return 'tag_msgs/tag';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0e4879a5a8d53a6a9735d0ccbc1592b8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header      header
    string      tag
    string      weather
    time        stamp
    uint32      cnt_road_change
    uint32      cnt_weather_change
    time        rsv1
    time        rsv2
    string      rsv3
    string      rsv4
    float32     rsv5
    float32     rsv6
    int32       rsv7
    int32       rsv8
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new tag(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.tag !== undefined) {
      resolved.tag = msg.tag;
    }
    else {
      resolved.tag = ''
    }

    if (msg.weather !== undefined) {
      resolved.weather = msg.weather;
    }
    else {
      resolved.weather = ''
    }

    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.cnt_road_change !== undefined) {
      resolved.cnt_road_change = msg.cnt_road_change;
    }
    else {
      resolved.cnt_road_change = 0
    }

    if (msg.cnt_weather_change !== undefined) {
      resolved.cnt_weather_change = msg.cnt_weather_change;
    }
    else {
      resolved.cnt_weather_change = 0
    }

    if (msg.rsv1 !== undefined) {
      resolved.rsv1 = msg.rsv1;
    }
    else {
      resolved.rsv1 = {secs: 0, nsecs: 0}
    }

    if (msg.rsv2 !== undefined) {
      resolved.rsv2 = msg.rsv2;
    }
    else {
      resolved.rsv2 = {secs: 0, nsecs: 0}
    }

    if (msg.rsv3 !== undefined) {
      resolved.rsv3 = msg.rsv3;
    }
    else {
      resolved.rsv3 = ''
    }

    if (msg.rsv4 !== undefined) {
      resolved.rsv4 = msg.rsv4;
    }
    else {
      resolved.rsv4 = ''
    }

    if (msg.rsv5 !== undefined) {
      resolved.rsv5 = msg.rsv5;
    }
    else {
      resolved.rsv5 = 0.0
    }

    if (msg.rsv6 !== undefined) {
      resolved.rsv6 = msg.rsv6;
    }
    else {
      resolved.rsv6 = 0.0
    }

    if (msg.rsv7 !== undefined) {
      resolved.rsv7 = msg.rsv7;
    }
    else {
      resolved.rsv7 = 0
    }

    if (msg.rsv8 !== undefined) {
      resolved.rsv8 = msg.rsv8;
    }
    else {
      resolved.rsv8 = 0
    }

    return resolved;
    }
};

module.exports = tag;
