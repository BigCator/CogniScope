#!/bin/bash


source install/setup.bash

sleep 0.5

roslaunch pcd_output pcd_output.launch
