#!/bin/bash


source install/setup.bash

sleep 0.5

roslaunch pcd_show pcd_show.launch
