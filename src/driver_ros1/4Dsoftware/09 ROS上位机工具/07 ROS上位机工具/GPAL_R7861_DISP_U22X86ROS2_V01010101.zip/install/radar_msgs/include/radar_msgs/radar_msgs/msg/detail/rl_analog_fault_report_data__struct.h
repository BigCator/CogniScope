// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/RlAnalogFaultReportData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_ANALOG_FAULT_REPORT_DATA__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__RL_ANALOG_FAULT_REPORT_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/RlAnalogFaultReportData in the package radar_msgs.
typedef struct radar_msgs__msg__RlAnalogFaultReportData
{
  uint8_t faulttype;
  uint8_t reserved0;
  uint16_t reserved1;
  uint32_t faultsig;
  uint32_t reserved2;
} radar_msgs__msg__RlAnalogFaultReportData;

// Struct for a sequence of radar_msgs__msg__RlAnalogFaultReportData.
typedef struct radar_msgs__msg__RlAnalogFaultReportData__Sequence
{
  radar_msgs__msg__RlAnalogFaultReportData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__RlAnalogFaultReportData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__RL_ANALOG_FAULT_REPORT_DATA__STRUCT_H_
