// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonTxIntAnaSigRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_TX_INT_ANA_SIG_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_TX_INT_ANA_SIG_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_tx_int_ana_sig_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonTxIntAnaSigRep_timestamp
{
public:
  explicit Init_RlMonTxIntAnaSigRep_timestamp(::radar_msgs::msg::RlMonTxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonTxIntAnaSigRep timestamp(::radar_msgs::msg::RlMonTxIntAnaSigRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxIntAnaSigRep msg_;
};

class Init_RlMonTxIntAnaSigRep_phshiftdacqdeltamin
{
public:
  explicit Init_RlMonTxIntAnaSigRep_phshiftdacqdeltamin(::radar_msgs::msg::RlMonTxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxIntAnaSigRep_timestamp phshiftdacqdeltamin(::radar_msgs::msg::RlMonTxIntAnaSigRep::_phshiftdacqdeltamin_type arg)
  {
    msg_.phshiftdacqdeltamin = std::move(arg);
    return Init_RlMonTxIntAnaSigRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxIntAnaSigRep msg_;
};

class Init_RlMonTxIntAnaSigRep_phshiftdacideltamin
{
public:
  explicit Init_RlMonTxIntAnaSigRep_phshiftdacideltamin(::radar_msgs::msg::RlMonTxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxIntAnaSigRep_phshiftdacqdeltamin phshiftdacideltamin(::radar_msgs::msg::RlMonTxIntAnaSigRep::_phshiftdacideltamin_type arg)
  {
    msg_.phshiftdacideltamin = std::move(arg);
    return Init_RlMonTxIntAnaSigRep_phshiftdacqdeltamin(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxIntAnaSigRep msg_;
};

class Init_RlMonTxIntAnaSigRep_reserved0
{
public:
  explicit Init_RlMonTxIntAnaSigRep_reserved0(::radar_msgs::msg::RlMonTxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxIntAnaSigRep_phshiftdacideltamin reserved0(::radar_msgs::msg::RlMonTxIntAnaSigRep::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlMonTxIntAnaSigRep_phshiftdacideltamin(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxIntAnaSigRep msg_;
};

class Init_RlMonTxIntAnaSigRep_profindex
{
public:
  explicit Init_RlMonTxIntAnaSigRep_profindex(::radar_msgs::msg::RlMonTxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxIntAnaSigRep_reserved0 profindex(::radar_msgs::msg::RlMonTxIntAnaSigRep::_profindex_type arg)
  {
    msg_.profindex = std::move(arg);
    return Init_RlMonTxIntAnaSigRep_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxIntAnaSigRep msg_;
};

class Init_RlMonTxIntAnaSigRep_errorcode
{
public:
  explicit Init_RlMonTxIntAnaSigRep_errorcode(::radar_msgs::msg::RlMonTxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxIntAnaSigRep_profindex errorcode(::radar_msgs::msg::RlMonTxIntAnaSigRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonTxIntAnaSigRep_profindex(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxIntAnaSigRep msg_;
};

class Init_RlMonTxIntAnaSigRep_statusflags
{
public:
  Init_RlMonTxIntAnaSigRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonTxIntAnaSigRep_errorcode statusflags(::radar_msgs::msg::RlMonTxIntAnaSigRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonTxIntAnaSigRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxIntAnaSigRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonTxIntAnaSigRep>()
{
  return radar_msgs::msg::builder::Init_RlMonTxIntAnaSigRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_TX_INT_ANA_SIG_REP__BUILDER_HPP_
