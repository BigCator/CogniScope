// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/TrackingObj.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__TRACKING_OBJ__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__TRACKING_OBJ__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/tracking_obj__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_TrackingObj_reserved_d
{
public:
  explicit Init_TrackingObj_reserved_d(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::TrackingObj reserved_d(::radar_msgs::msg::TrackingObj::_reserved_d_type arg)
  {
    msg_.reserved_d = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_reserved_c
{
public:
  explicit Init_TrackingObj_reserved_c(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_reserved_d reserved_c(::radar_msgs::msg::TrackingObj::_reserved_c_type arg)
  {
    msg_.reserved_c = std::move(arg);
    return Init_TrackingObj_reserved_d(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_reserved_b
{
public:
  explicit Init_TrackingObj_reserved_b(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_reserved_c reserved_b(::radar_msgs::msg::TrackingObj::_reserved_b_type arg)
  {
    msg_.reserved_b = std::move(arg);
    return Init_TrackingObj_reserved_c(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_od_process_time
{
public:
  explicit Init_TrackingObj_od_process_time(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_reserved_b od_process_time(::radar_msgs::msg::TrackingObj::_od_process_time_type arg)
  {
    msg_.od_process_time = std::move(arg);
    return Init_TrackingObj_reserved_b(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_height
{
public:
  explicit Init_TrackingObj_height(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_od_process_time height(::radar_msgs::msg::TrackingObj::_height_type arg)
  {
    msg_.height = std::move(arg);
    return Init_TrackingObj_od_process_time(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_width
{
public:
  explicit Init_TrackingObj_width(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_height width(::radar_msgs::msg::TrackingObj::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_TrackingObj_height(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_length
{
public:
  explicit Init_TrackingObj_length(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_width length(::radar_msgs::msg::TrackingObj::_length_type arg)
  {
    msg_.length = std::move(arg);
    return Init_TrackingObj_width(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_obstacle_confidence
{
public:
  explicit Init_TrackingObj_obstacle_confidence(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_length obstacle_confidence(::radar_msgs::msg::TrackingObj::_obstacle_confidence_type arg)
  {
    msg_.obstacle_confidence = std::move(arg);
    return Init_TrackingObj_length(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_ground_confidence
{
public:
  explicit Init_TrackingObj_ground_confidence(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_obstacle_confidence ground_confidence(::radar_msgs::msg::TrackingObj::_ground_confidence_type arg)
  {
    msg_.ground_confidence = std::move(arg);
    return Init_TrackingObj_obstacle_confidence(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_signboard_confidence
{
public:
  explicit Init_TrackingObj_signboard_confidence(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_ground_confidence signboard_confidence(::radar_msgs::msg::TrackingObj::_signboard_confidence_type arg)
  {
    msg_.signboard_confidence = std::move(arg);
    return Init_TrackingObj_ground_confidence(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_truck_confidence
{
public:
  explicit Init_TrackingObj_truck_confidence(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_signboard_confidence truck_confidence(::radar_msgs::msg::TrackingObj::_truck_confidence_type arg)
  {
    msg_.truck_confidence = std::move(arg);
    return Init_TrackingObj_signboard_confidence(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_ped_confidence
{
public:
  explicit Init_TrackingObj_ped_confidence(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_truck_confidence ped_confidence(::radar_msgs::msg::TrackingObj::_ped_confidence_type arg)
  {
    msg_.ped_confidence = std::move(arg);
    return Init_TrackingObj_truck_confidence(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_bike_confidence
{
public:
  explicit Init_TrackingObj_bike_confidence(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_ped_confidence bike_confidence(::radar_msgs::msg::TrackingObj::_bike_confidence_type arg)
  {
    msg_.bike_confidence = std::move(arg);
    return Init_TrackingObj_ped_confidence(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_car_confidence
{
public:
  explicit Init_TrackingObj_car_confidence(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_bike_confidence car_confidence(::radar_msgs::msg::TrackingObj::_car_confidence_type arg)
  {
    msg_.car_confidence = std::move(arg);
    return Init_TrackingObj_bike_confidence(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_type
{
public:
  explicit Init_TrackingObj_type(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_car_confidence type(::radar_msgs::msg::TrackingObj::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_TrackingObj_car_confidence(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_orientation
{
public:
  explicit Init_TrackingObj_orientation(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_type orientation(::radar_msgs::msg::TrackingObj::_orientation_type arg)
  {
    msg_.orientation = std::move(arg);
    return Init_TrackingObj_type(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_v2ground_z
{
public:
  explicit Init_TrackingObj_v2ground_z(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_orientation v2ground_z(::radar_msgs::msg::TrackingObj::_v2ground_z_type arg)
  {
    msg_.v2ground_z = std::move(arg);
    return Init_TrackingObj_orientation(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_v2ground_y
{
public:
  explicit Init_TrackingObj_v2ground_y(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_v2ground_z v2ground_y(::radar_msgs::msg::TrackingObj::_v2ground_y_type arg)
  {
    msg_.v2ground_y = std::move(arg);
    return Init_TrackingObj_v2ground_z(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_v2ground_x
{
public:
  explicit Init_TrackingObj_v2ground_x(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_v2ground_y v2ground_x(::radar_msgs::msg::TrackingObj::_v2ground_x_type arg)
  {
    msg_.v2ground_x = std::move(arg);
    return Init_TrackingObj_v2ground_y(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_acceleration_z
{
public:
  explicit Init_TrackingObj_acceleration_z(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_v2ground_x acceleration_z(::radar_msgs::msg::TrackingObj::_acceleration_z_type arg)
  {
    msg_.acceleration_z = std::move(arg);
    return Init_TrackingObj_v2ground_x(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_acceleration_y
{
public:
  explicit Init_TrackingObj_acceleration_y(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_acceleration_z acceleration_y(::radar_msgs::msg::TrackingObj::_acceleration_y_type arg)
  {
    msg_.acceleration_y = std::move(arg);
    return Init_TrackingObj_acceleration_z(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_acceleration_x
{
public:
  explicit Init_TrackingObj_acceleration_x(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_acceleration_y acceleration_x(::radar_msgs::msg::TrackingObj::_acceleration_x_type arg)
  {
    msg_.acceleration_x = std::move(arg);
    return Init_TrackingObj_acceleration_y(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_velocity_z
{
public:
  explicit Init_TrackingObj_velocity_z(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_acceleration_x velocity_z(::radar_msgs::msg::TrackingObj::_velocity_z_type arg)
  {
    msg_.velocity_z = std::move(arg);
    return Init_TrackingObj_acceleration_x(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_velocity_y
{
public:
  explicit Init_TrackingObj_velocity_y(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_velocity_z velocity_y(::radar_msgs::msg::TrackingObj::_velocity_y_type arg)
  {
    msg_.velocity_y = std::move(arg);
    return Init_TrackingObj_velocity_z(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_velocity_x
{
public:
  explicit Init_TrackingObj_velocity_x(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_velocity_y velocity_x(::radar_msgs::msg::TrackingObj::_velocity_x_type arg)
  {
    msg_.velocity_x = std::move(arg);
    return Init_TrackingObj_velocity_y(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_position_z
{
public:
  explicit Init_TrackingObj_position_z(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_velocity_x position_z(::radar_msgs::msg::TrackingObj::_position_z_type arg)
  {
    msg_.position_z = std::move(arg);
    return Init_TrackingObj_velocity_x(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_position_y
{
public:
  explicit Init_TrackingObj_position_y(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_position_z position_y(::radar_msgs::msg::TrackingObj::_position_y_type arg)
  {
    msg_.position_y = std::move(arg);
    return Init_TrackingObj_position_z(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_position_x
{
public:
  explicit Init_TrackingObj_position_x(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_position_y position_x(::radar_msgs::msg::TrackingObj::_position_x_type arg)
  {
    msg_.position_x = std::move(arg);
    return Init_TrackingObj_position_y(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_existance_confidence
{
public:
  explicit Init_TrackingObj_existance_confidence(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_position_x existance_confidence(::radar_msgs::msg::TrackingObj::_existance_confidence_type arg)
  {
    msg_.existance_confidence = std::move(arg);
    return Init_TrackingObj_position_x(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_motion_state
{
public:
  explicit Init_TrackingObj_motion_state(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_existance_confidence motion_state(::radar_msgs::msg::TrackingObj::_motion_state_type arg)
  {
    msg_.motion_state = std::move(arg);
    return Init_TrackingObj_existance_confidence(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_measurement_status
{
public:
  explicit Init_TrackingObj_measurement_status(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_motion_state measurement_status(::radar_msgs::msg::TrackingObj::_measurement_status_type arg)
  {
    msg_.measurement_status = std::move(arg);
    return Init_TrackingObj_motion_state(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_age
{
public:
  explicit Init_TrackingObj_age(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_measurement_status age(::radar_msgs::msg::TrackingObj::_age_type arg)
  {
    msg_.age = std::move(arg);
    return Init_TrackingObj_measurement_status(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_object_id
{
public:
  explicit Init_TrackingObj_object_id(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_age object_id(::radar_msgs::msg::TrackingObj::_object_id_type arg)
  {
    msg_.object_id = std::move(arg);
    return Init_TrackingObj_age(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_objnum
{
public:
  explicit Init_TrackingObj_objnum(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_object_id objnum(::radar_msgs::msg::TrackingObj::_objnum_type arg)
  {
    msg_.objnum = std::move(arg);
    return Init_TrackingObj_object_id(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_frame_cnt
{
public:
  explicit Init_TrackingObj_frame_cnt(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_objnum frame_cnt(::radar_msgs::msg::TrackingObj::_frame_cnt_type arg)
  {
    msg_.frame_cnt = std::move(arg);
    return Init_TrackingObj_objnum(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_radar_id
{
public:
  explicit Init_TrackingObj_radar_id(::radar_msgs::msg::TrackingObj & msg)
  : msg_(msg)
  {}
  Init_TrackingObj_frame_cnt radar_id(::radar_msgs::msg::TrackingObj::_radar_id_type arg)
  {
    msg_.radar_id = std::move(arg);
    return Init_TrackingObj_frame_cnt(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

class Init_TrackingObj_header
{
public:
  Init_TrackingObj_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TrackingObj_radar_id header(::radar_msgs::msg::TrackingObj::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_TrackingObj_radar_id(msg_);
  }

private:
  ::radar_msgs::msg::TrackingObj msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::TrackingObj>()
{
  return radar_msgs::msg::builder::Init_TrackingObj_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__TRACKING_OBJ__BUILDER_HPP_
