// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RlMonTxPhShiftRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RlMonTxPhShiftRep __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RlMonTxPhShiftRep __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RlMonTxPhShiftRep_
{
  using Type = RlMonTxPhShiftRep_<ContainerAllocator>;

  explicit RlMonTxPhShiftRep_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      this->profindex = 0;
      this->reserved0 = 0;
      this->reserved1 = 0;
      this->phaseshiftermonval1 = 0;
      this->phaseshiftermonval2 = 0;
      this->phaseshiftermonval3 = 0;
      this->phaseshiftermonval4 = 0;
      this->txpsamplitudeval1 = 0;
      this->txpsamplitudeval2 = 0;
      this->txpsamplitudeval3 = 0;
      this->txpsamplitudeval4 = 0;
      this->txpsnoiseval1 = 0;
      this->txpsnoiseval2 = 0;
      this->txpsnoiseval3 = 0;
      this->txpsnoiseval4 = 0;
      this->timestamp = 0ul;
      this->reserved2 = 0ul;
      this->reserved3 = 0ul;
    }
  }

  explicit RlMonTxPhShiftRep_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      this->profindex = 0;
      this->reserved0 = 0;
      this->reserved1 = 0;
      this->phaseshiftermonval1 = 0;
      this->phaseshiftermonval2 = 0;
      this->phaseshiftermonval3 = 0;
      this->phaseshiftermonval4 = 0;
      this->txpsamplitudeval1 = 0;
      this->txpsamplitudeval2 = 0;
      this->txpsamplitudeval3 = 0;
      this->txpsamplitudeval4 = 0;
      this->txpsnoiseval1 = 0;
      this->txpsnoiseval2 = 0;
      this->txpsnoiseval3 = 0;
      this->txpsnoiseval4 = 0;
      this->timestamp = 0ul;
      this->reserved2 = 0ul;
      this->reserved3 = 0ul;
    }
  }

  // field types and members
  using _statusflags_type =
    uint16_t;
  _statusflags_type statusflags;
  using _errorcode_type =
    uint16_t;
  _errorcode_type errorcode;
  using _profindex_type =
    uint8_t;
  _profindex_type profindex;
  using _reserved0_type =
    uint8_t;
  _reserved0_type reserved0;
  using _reserved1_type =
    uint16_t;
  _reserved1_type reserved1;
  using _phaseshiftermonval1_type =
    uint16_t;
  _phaseshiftermonval1_type phaseshiftermonval1;
  using _phaseshiftermonval2_type =
    uint16_t;
  _phaseshiftermonval2_type phaseshiftermonval2;
  using _phaseshiftermonval3_type =
    uint16_t;
  _phaseshiftermonval3_type phaseshiftermonval3;
  using _phaseshiftermonval4_type =
    uint16_t;
  _phaseshiftermonval4_type phaseshiftermonval4;
  using _txpsamplitudeval1_type =
    int16_t;
  _txpsamplitudeval1_type txpsamplitudeval1;
  using _txpsamplitudeval2_type =
    int16_t;
  _txpsamplitudeval2_type txpsamplitudeval2;
  using _txpsamplitudeval3_type =
    int16_t;
  _txpsamplitudeval3_type txpsamplitudeval3;
  using _txpsamplitudeval4_type =
    int16_t;
  _txpsamplitudeval4_type txpsamplitudeval4;
  using _txpsnoiseval1_type =
    int8_t;
  _txpsnoiseval1_type txpsnoiseval1;
  using _txpsnoiseval2_type =
    int8_t;
  _txpsnoiseval2_type txpsnoiseval2;
  using _txpsnoiseval3_type =
    int8_t;
  _txpsnoiseval3_type txpsnoiseval3;
  using _txpsnoiseval4_type =
    int8_t;
  _txpsnoiseval4_type txpsnoiseval4;
  using _timestamp_type =
    uint32_t;
  _timestamp_type timestamp;
  using _reserved2_type =
    uint32_t;
  _reserved2_type reserved2;
  using _reserved3_type =
    uint32_t;
  _reserved3_type reserved3;

  // setters for named parameter idiom
  Type & set__statusflags(
    const uint16_t & _arg)
  {
    this->statusflags = _arg;
    return *this;
  }
  Type & set__errorcode(
    const uint16_t & _arg)
  {
    this->errorcode = _arg;
    return *this;
  }
  Type & set__profindex(
    const uint8_t & _arg)
  {
    this->profindex = _arg;
    return *this;
  }
  Type & set__reserved0(
    const uint8_t & _arg)
  {
    this->reserved0 = _arg;
    return *this;
  }
  Type & set__reserved1(
    const uint16_t & _arg)
  {
    this->reserved1 = _arg;
    return *this;
  }
  Type & set__phaseshiftermonval1(
    const uint16_t & _arg)
  {
    this->phaseshiftermonval1 = _arg;
    return *this;
  }
  Type & set__phaseshiftermonval2(
    const uint16_t & _arg)
  {
    this->phaseshiftermonval2 = _arg;
    return *this;
  }
  Type & set__phaseshiftermonval3(
    const uint16_t & _arg)
  {
    this->phaseshiftermonval3 = _arg;
    return *this;
  }
  Type & set__phaseshiftermonval4(
    const uint16_t & _arg)
  {
    this->phaseshiftermonval4 = _arg;
    return *this;
  }
  Type & set__txpsamplitudeval1(
    const int16_t & _arg)
  {
    this->txpsamplitudeval1 = _arg;
    return *this;
  }
  Type & set__txpsamplitudeval2(
    const int16_t & _arg)
  {
    this->txpsamplitudeval2 = _arg;
    return *this;
  }
  Type & set__txpsamplitudeval3(
    const int16_t & _arg)
  {
    this->txpsamplitudeval3 = _arg;
    return *this;
  }
  Type & set__txpsamplitudeval4(
    const int16_t & _arg)
  {
    this->txpsamplitudeval4 = _arg;
    return *this;
  }
  Type & set__txpsnoiseval1(
    const int8_t & _arg)
  {
    this->txpsnoiseval1 = _arg;
    return *this;
  }
  Type & set__txpsnoiseval2(
    const int8_t & _arg)
  {
    this->txpsnoiseval2 = _arg;
    return *this;
  }
  Type & set__txpsnoiseval3(
    const int8_t & _arg)
  {
    this->txpsnoiseval3 = _arg;
    return *this;
  }
  Type & set__txpsnoiseval4(
    const int8_t & _arg)
  {
    this->txpsnoiseval4 = _arg;
    return *this;
  }
  Type & set__timestamp(
    const uint32_t & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__reserved2(
    const uint32_t & _arg)
  {
    this->reserved2 = _arg;
    return *this;
  }
  Type & set__reserved3(
    const uint32_t & _arg)
  {
    this->reserved3 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RlMonTxPhShiftRep
    std::shared_ptr<radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RlMonTxPhShiftRep
    std::shared_ptr<radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RlMonTxPhShiftRep_ & other) const
  {
    if (this->statusflags != other.statusflags) {
      return false;
    }
    if (this->errorcode != other.errorcode) {
      return false;
    }
    if (this->profindex != other.profindex) {
      return false;
    }
    if (this->reserved0 != other.reserved0) {
      return false;
    }
    if (this->reserved1 != other.reserved1) {
      return false;
    }
    if (this->phaseshiftermonval1 != other.phaseshiftermonval1) {
      return false;
    }
    if (this->phaseshiftermonval2 != other.phaseshiftermonval2) {
      return false;
    }
    if (this->phaseshiftermonval3 != other.phaseshiftermonval3) {
      return false;
    }
    if (this->phaseshiftermonval4 != other.phaseshiftermonval4) {
      return false;
    }
    if (this->txpsamplitudeval1 != other.txpsamplitudeval1) {
      return false;
    }
    if (this->txpsamplitudeval2 != other.txpsamplitudeval2) {
      return false;
    }
    if (this->txpsamplitudeval3 != other.txpsamplitudeval3) {
      return false;
    }
    if (this->txpsamplitudeval4 != other.txpsamplitudeval4) {
      return false;
    }
    if (this->txpsnoiseval1 != other.txpsnoiseval1) {
      return false;
    }
    if (this->txpsnoiseval2 != other.txpsnoiseval2) {
      return false;
    }
    if (this->txpsnoiseval3 != other.txpsnoiseval3) {
      return false;
    }
    if (this->txpsnoiseval4 != other.txpsnoiseval4) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->reserved2 != other.reserved2) {
      return false;
    }
    if (this->reserved3 != other.reserved3) {
      return false;
    }
    return true;
  }
  bool operator!=(const RlMonTxPhShiftRep_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RlMonTxPhShiftRep_

// alias to use template instance with default allocator
using RlMonTxPhShiftRep =
  radar_msgs::msg::RlMonTxPhShiftRep_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__STRUCT_HPP_
