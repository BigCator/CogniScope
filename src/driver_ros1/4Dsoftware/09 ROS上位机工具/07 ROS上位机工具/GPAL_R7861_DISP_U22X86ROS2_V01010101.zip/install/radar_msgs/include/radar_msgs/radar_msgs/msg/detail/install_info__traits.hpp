// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/InstallInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/install_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const InstallInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: radar_id
  {
    out << "radar_id: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_id, out);
    out << ", ";
  }

  // member: frame_cnt
  {
    out << "frame_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_cnt, out);
    out << ", ";
  }

  // member: sensor_positioninvalid_flags
  {
    out << "sensor_positioninvalid_flags: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_positioninvalid_flags, out);
    out << ", ";
  }

  // member: sensor_xposition
  {
    out << "sensor_xposition: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_xposition, out);
    out << ", ";
  }

  // member: sensor_yposition
  {
    out << "sensor_yposition: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_yposition, out);
    out << ", ";
  }

  // member: sensor_zposition
  {
    out << "sensor_zposition: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_zposition, out);
    out << ", ";
  }

  // member: sensor_rollangle
  {
    out << "sensor_rollangle: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_rollangle, out);
    out << ", ";
  }

  // member: sensor_pitchangle
  {
    out << "sensor_pitchangle: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_pitchangle, out);
    out << ", ";
  }

  // member: sensor_yawangle
  {
    out << "sensor_yawangle: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_yawangle, out);
    out << ", ";
  }

  // member: azimuth_correction
  {
    out << "azimuth_correction: ";
    rosidl_generator_traits::value_to_yaml(msg.azimuth_correction, out);
    out << ", ";
  }

  // member: elevation_correction
  {
    out << "elevation_correction: ";
    rosidl_generator_traits::value_to_yaml(msg.elevation_correction, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const InstallInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: radar_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "radar_id: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_id, out);
    out << "\n";
  }

  // member: frame_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_cnt, out);
    out << "\n";
  }

  // member: sensor_positioninvalid_flags
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_positioninvalid_flags: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_positioninvalid_flags, out);
    out << "\n";
  }

  // member: sensor_xposition
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_xposition: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_xposition, out);
    out << "\n";
  }

  // member: sensor_yposition
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_yposition: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_yposition, out);
    out << "\n";
  }

  // member: sensor_zposition
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_zposition: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_zposition, out);
    out << "\n";
  }

  // member: sensor_rollangle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_rollangle: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_rollangle, out);
    out << "\n";
  }

  // member: sensor_pitchangle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_pitchangle: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_pitchangle, out);
    out << "\n";
  }

  // member: sensor_yawangle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_yawangle: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_yawangle, out);
    out << "\n";
  }

  // member: azimuth_correction
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "azimuth_correction: ";
    rosidl_generator_traits::value_to_yaml(msg.azimuth_correction, out);
    out << "\n";
  }

  // member: elevation_correction
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "elevation_correction: ";
    rosidl_generator_traits::value_to_yaml(msg.elevation_correction, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const InstallInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::InstallInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::InstallInfo & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::InstallInfo>()
{
  return "radar_msgs::msg::InstallInfo";
}

template<>
inline const char * name<radar_msgs::msg::InstallInfo>()
{
  return "radar_msgs/msg/InstallInfo";
}

template<>
struct has_fixed_size<radar_msgs::msg::InstallInfo>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<radar_msgs::msg::InstallInfo>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<radar_msgs::msg::InstallInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__TRAITS_HPP_
