// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/AlarmStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/AlarmStatus in the package radar_msgs.
typedef struct radar_msgs__msg__AlarmStatus
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  /// radar ID
  uint32_t radarid;
  /// frame cnt in radar
  uint32_t framecnt;
  /// number of alarm
  uint32_t alarmnum;
  uint16_t alarmcode01;
  uint16_t alarmcode02;
  uint16_t alarmcode03;
  uint16_t alarmcode04;
  uint16_t alarmcode05;
  uint16_t alarmcode06;
  uint16_t alarmcode07;
  uint16_t alarmcode08;
  uint16_t alarmcode09;
  uint16_t alarmcode10;
  uint16_t alarmcode11;
  uint16_t alarmcode12;
  uint16_t alarmcode13;
  uint16_t alarmcode14;
  uint16_t alarmcode15;
  uint16_t alarmcode16;
  uint16_t alarmcode17;
  uint16_t alarmcode18;
  uint16_t alarmcode19;
  uint16_t alarmcode20;
} radar_msgs__msg__AlarmStatus;

// Struct for a sequence of radar_msgs__msg__AlarmStatus.
typedef struct radar_msgs__msg__AlarmStatus__Sequence
{
  radar_msgs__msg__AlarmStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__AlarmStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__STRUCT_H_
