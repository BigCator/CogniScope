// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/ProcessStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__ProcessStatus __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__ProcessStatus __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ProcessStatus_
{
  using Type = ProcessStatus_<ContainerAllocator>;

  explicit ProcessStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radar_id = 0ul;
      this->frame_cnt = 0ul;
      this->capture_time = 0.0f;
      this->framelost_cnt = 0ul;
      this->adcerrcnt = 0ul;
      this->reserved_a = 0ul;
      this->reserved_b = 0ul;
      this->time1dfft = 0.0f;
      this->reserved_c = 0ul;
      this->reserved_d = 0ul;
      this->reserved_e = 0ul;
      this->reserved_f = 0ul;
      this->time2dfft = 0.0f;
      this->reserved_g = 0ul;
      this->reserved_h = 0ul;
      this->reserved_i = 0ul;
      this->reserved_j = 0ul;
      this->timerdmap = 0.0f;
      this->jam_status = 0ul;
      this->reserved_l = 0ul;
      this->reserved_m = 0ul;
      this->reserved_n = 0ul;
      this->timecfar = 0.0f;
      this->reserved_o = 0ul;
      this->reserved_p = 0ul;
      this->reserved_q = 0ul;
      this->reserved_r = 0ul;
      this->timedoa = 0.0f;
      this->reserved_s = 0ul;
      this->reserved_t = 0ul;
      this->reserved_u = 0ul;
      this->latency = 0.0f;
      this->timepcl = 0.0f;
      this->car_v_estimate = 0.0f;
      this->ground_k = 0.0f;
      this->ground_b = 0.0f;
      this->pcl_delay_time = 0.0f;
      this->timeod = 0.0f;
      this->odtimeoutcnt = 0ul;
      this->selfcalistatus = 0l;
      this->od_delay_time = 0.0f;
      this->car_v = 0.0f;
      this->car_yawrate = 0.0f;
      this->car_gear_state = 0ul;
    }
  }

  explicit ProcessStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radar_id = 0ul;
      this->frame_cnt = 0ul;
      this->capture_time = 0.0f;
      this->framelost_cnt = 0ul;
      this->adcerrcnt = 0ul;
      this->reserved_a = 0ul;
      this->reserved_b = 0ul;
      this->time1dfft = 0.0f;
      this->reserved_c = 0ul;
      this->reserved_d = 0ul;
      this->reserved_e = 0ul;
      this->reserved_f = 0ul;
      this->time2dfft = 0.0f;
      this->reserved_g = 0ul;
      this->reserved_h = 0ul;
      this->reserved_i = 0ul;
      this->reserved_j = 0ul;
      this->timerdmap = 0.0f;
      this->jam_status = 0ul;
      this->reserved_l = 0ul;
      this->reserved_m = 0ul;
      this->reserved_n = 0ul;
      this->timecfar = 0.0f;
      this->reserved_o = 0ul;
      this->reserved_p = 0ul;
      this->reserved_q = 0ul;
      this->reserved_r = 0ul;
      this->timedoa = 0.0f;
      this->reserved_s = 0ul;
      this->reserved_t = 0ul;
      this->reserved_u = 0ul;
      this->latency = 0.0f;
      this->timepcl = 0.0f;
      this->car_v_estimate = 0.0f;
      this->ground_k = 0.0f;
      this->ground_b = 0.0f;
      this->pcl_delay_time = 0.0f;
      this->timeod = 0.0f;
      this->odtimeoutcnt = 0ul;
      this->selfcalistatus = 0l;
      this->od_delay_time = 0.0f;
      this->car_v = 0.0f;
      this->car_yawrate = 0.0f;
      this->car_gear_state = 0ul;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _radar_id_type =
    uint32_t;
  _radar_id_type radar_id;
  using _frame_cnt_type =
    uint32_t;
  _frame_cnt_type frame_cnt;
  using _capture_time_type =
    float;
  _capture_time_type capture_time;
  using _framelost_cnt_type =
    uint32_t;
  _framelost_cnt_type framelost_cnt;
  using _adcerrcnt_type =
    uint32_t;
  _adcerrcnt_type adcerrcnt;
  using _reserved_a_type =
    uint32_t;
  _reserved_a_type reserved_a;
  using _reserved_b_type =
    uint32_t;
  _reserved_b_type reserved_b;
  using _time1dfft_type =
    float;
  _time1dfft_type time1dfft;
  using _reserved_c_type =
    uint32_t;
  _reserved_c_type reserved_c;
  using _reserved_d_type =
    uint32_t;
  _reserved_d_type reserved_d;
  using _reserved_e_type =
    uint32_t;
  _reserved_e_type reserved_e;
  using _reserved_f_type =
    uint32_t;
  _reserved_f_type reserved_f;
  using _time2dfft_type =
    float;
  _time2dfft_type time2dfft;
  using _reserved_g_type =
    uint32_t;
  _reserved_g_type reserved_g;
  using _reserved_h_type =
    uint32_t;
  _reserved_h_type reserved_h;
  using _reserved_i_type =
    uint32_t;
  _reserved_i_type reserved_i;
  using _reserved_j_type =
    uint32_t;
  _reserved_j_type reserved_j;
  using _timerdmap_type =
    float;
  _timerdmap_type timerdmap;
  using _jam_status_type =
    uint32_t;
  _jam_status_type jam_status;
  using _reserved_l_type =
    uint32_t;
  _reserved_l_type reserved_l;
  using _reserved_m_type =
    uint32_t;
  _reserved_m_type reserved_m;
  using _reserved_n_type =
    uint32_t;
  _reserved_n_type reserved_n;
  using _timecfar_type =
    float;
  _timecfar_type timecfar;
  using _reserved_o_type =
    uint32_t;
  _reserved_o_type reserved_o;
  using _reserved_p_type =
    uint32_t;
  _reserved_p_type reserved_p;
  using _reserved_q_type =
    uint32_t;
  _reserved_q_type reserved_q;
  using _reserved_r_type =
    uint32_t;
  _reserved_r_type reserved_r;
  using _timedoa_type =
    float;
  _timedoa_type timedoa;
  using _reserved_s_type =
    uint32_t;
  _reserved_s_type reserved_s;
  using _reserved_t_type =
    uint32_t;
  _reserved_t_type reserved_t;
  using _reserved_u_type =
    uint32_t;
  _reserved_u_type reserved_u;
  using _latency_type =
    float;
  _latency_type latency;
  using _timepcl_type =
    float;
  _timepcl_type timepcl;
  using _car_v_estimate_type =
    float;
  _car_v_estimate_type car_v_estimate;
  using _ground_k_type =
    float;
  _ground_k_type ground_k;
  using _ground_b_type =
    float;
  _ground_b_type ground_b;
  using _pcl_delay_time_type =
    float;
  _pcl_delay_time_type pcl_delay_time;
  using _timeod_type =
    float;
  _timeod_type timeod;
  using _odtimeoutcnt_type =
    uint32_t;
  _odtimeoutcnt_type odtimeoutcnt;
  using _selfcalistatus_type =
    int32_t;
  _selfcalistatus_type selfcalistatus;
  using _od_delay_time_type =
    float;
  _od_delay_time_type od_delay_time;
  using _car_v_type =
    float;
  _car_v_type car_v;
  using _car_yawrate_type =
    float;
  _car_yawrate_type car_yawrate;
  using _car_gear_state_type =
    uint32_t;
  _car_gear_state_type car_gear_state;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__radar_id(
    const uint32_t & _arg)
  {
    this->radar_id = _arg;
    return *this;
  }
  Type & set__frame_cnt(
    const uint32_t & _arg)
  {
    this->frame_cnt = _arg;
    return *this;
  }
  Type & set__capture_time(
    const float & _arg)
  {
    this->capture_time = _arg;
    return *this;
  }
  Type & set__framelost_cnt(
    const uint32_t & _arg)
  {
    this->framelost_cnt = _arg;
    return *this;
  }
  Type & set__adcerrcnt(
    const uint32_t & _arg)
  {
    this->adcerrcnt = _arg;
    return *this;
  }
  Type & set__reserved_a(
    const uint32_t & _arg)
  {
    this->reserved_a = _arg;
    return *this;
  }
  Type & set__reserved_b(
    const uint32_t & _arg)
  {
    this->reserved_b = _arg;
    return *this;
  }
  Type & set__time1dfft(
    const float & _arg)
  {
    this->time1dfft = _arg;
    return *this;
  }
  Type & set__reserved_c(
    const uint32_t & _arg)
  {
    this->reserved_c = _arg;
    return *this;
  }
  Type & set__reserved_d(
    const uint32_t & _arg)
  {
    this->reserved_d = _arg;
    return *this;
  }
  Type & set__reserved_e(
    const uint32_t & _arg)
  {
    this->reserved_e = _arg;
    return *this;
  }
  Type & set__reserved_f(
    const uint32_t & _arg)
  {
    this->reserved_f = _arg;
    return *this;
  }
  Type & set__time2dfft(
    const float & _arg)
  {
    this->time2dfft = _arg;
    return *this;
  }
  Type & set__reserved_g(
    const uint32_t & _arg)
  {
    this->reserved_g = _arg;
    return *this;
  }
  Type & set__reserved_h(
    const uint32_t & _arg)
  {
    this->reserved_h = _arg;
    return *this;
  }
  Type & set__reserved_i(
    const uint32_t & _arg)
  {
    this->reserved_i = _arg;
    return *this;
  }
  Type & set__reserved_j(
    const uint32_t & _arg)
  {
    this->reserved_j = _arg;
    return *this;
  }
  Type & set__timerdmap(
    const float & _arg)
  {
    this->timerdmap = _arg;
    return *this;
  }
  Type & set__jam_status(
    const uint32_t & _arg)
  {
    this->jam_status = _arg;
    return *this;
  }
  Type & set__reserved_l(
    const uint32_t & _arg)
  {
    this->reserved_l = _arg;
    return *this;
  }
  Type & set__reserved_m(
    const uint32_t & _arg)
  {
    this->reserved_m = _arg;
    return *this;
  }
  Type & set__reserved_n(
    const uint32_t & _arg)
  {
    this->reserved_n = _arg;
    return *this;
  }
  Type & set__timecfar(
    const float & _arg)
  {
    this->timecfar = _arg;
    return *this;
  }
  Type & set__reserved_o(
    const uint32_t & _arg)
  {
    this->reserved_o = _arg;
    return *this;
  }
  Type & set__reserved_p(
    const uint32_t & _arg)
  {
    this->reserved_p = _arg;
    return *this;
  }
  Type & set__reserved_q(
    const uint32_t & _arg)
  {
    this->reserved_q = _arg;
    return *this;
  }
  Type & set__reserved_r(
    const uint32_t & _arg)
  {
    this->reserved_r = _arg;
    return *this;
  }
  Type & set__timedoa(
    const float & _arg)
  {
    this->timedoa = _arg;
    return *this;
  }
  Type & set__reserved_s(
    const uint32_t & _arg)
  {
    this->reserved_s = _arg;
    return *this;
  }
  Type & set__reserved_t(
    const uint32_t & _arg)
  {
    this->reserved_t = _arg;
    return *this;
  }
  Type & set__reserved_u(
    const uint32_t & _arg)
  {
    this->reserved_u = _arg;
    return *this;
  }
  Type & set__latency(
    const float & _arg)
  {
    this->latency = _arg;
    return *this;
  }
  Type & set__timepcl(
    const float & _arg)
  {
    this->timepcl = _arg;
    return *this;
  }
  Type & set__car_v_estimate(
    const float & _arg)
  {
    this->car_v_estimate = _arg;
    return *this;
  }
  Type & set__ground_k(
    const float & _arg)
  {
    this->ground_k = _arg;
    return *this;
  }
  Type & set__ground_b(
    const float & _arg)
  {
    this->ground_b = _arg;
    return *this;
  }
  Type & set__pcl_delay_time(
    const float & _arg)
  {
    this->pcl_delay_time = _arg;
    return *this;
  }
  Type & set__timeod(
    const float & _arg)
  {
    this->timeod = _arg;
    return *this;
  }
  Type & set__odtimeoutcnt(
    const uint32_t & _arg)
  {
    this->odtimeoutcnt = _arg;
    return *this;
  }
  Type & set__selfcalistatus(
    const int32_t & _arg)
  {
    this->selfcalistatus = _arg;
    return *this;
  }
  Type & set__od_delay_time(
    const float & _arg)
  {
    this->od_delay_time = _arg;
    return *this;
  }
  Type & set__car_v(
    const float & _arg)
  {
    this->car_v = _arg;
    return *this;
  }
  Type & set__car_yawrate(
    const float & _arg)
  {
    this->car_yawrate = _arg;
    return *this;
  }
  Type & set__car_gear_state(
    const uint32_t & _arg)
  {
    this->car_gear_state = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::ProcessStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::ProcessStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::ProcessStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::ProcessStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::ProcessStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::ProcessStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::ProcessStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::ProcessStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::ProcessStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::ProcessStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__ProcessStatus
    std::shared_ptr<radar_msgs::msg::ProcessStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__ProcessStatus
    std::shared_ptr<radar_msgs::msg::ProcessStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ProcessStatus_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->radar_id != other.radar_id) {
      return false;
    }
    if (this->frame_cnt != other.frame_cnt) {
      return false;
    }
    if (this->capture_time != other.capture_time) {
      return false;
    }
    if (this->framelost_cnt != other.framelost_cnt) {
      return false;
    }
    if (this->adcerrcnt != other.adcerrcnt) {
      return false;
    }
    if (this->reserved_a != other.reserved_a) {
      return false;
    }
    if (this->reserved_b != other.reserved_b) {
      return false;
    }
    if (this->time1dfft != other.time1dfft) {
      return false;
    }
    if (this->reserved_c != other.reserved_c) {
      return false;
    }
    if (this->reserved_d != other.reserved_d) {
      return false;
    }
    if (this->reserved_e != other.reserved_e) {
      return false;
    }
    if (this->reserved_f != other.reserved_f) {
      return false;
    }
    if (this->time2dfft != other.time2dfft) {
      return false;
    }
    if (this->reserved_g != other.reserved_g) {
      return false;
    }
    if (this->reserved_h != other.reserved_h) {
      return false;
    }
    if (this->reserved_i != other.reserved_i) {
      return false;
    }
    if (this->reserved_j != other.reserved_j) {
      return false;
    }
    if (this->timerdmap != other.timerdmap) {
      return false;
    }
    if (this->jam_status != other.jam_status) {
      return false;
    }
    if (this->reserved_l != other.reserved_l) {
      return false;
    }
    if (this->reserved_m != other.reserved_m) {
      return false;
    }
    if (this->reserved_n != other.reserved_n) {
      return false;
    }
    if (this->timecfar != other.timecfar) {
      return false;
    }
    if (this->reserved_o != other.reserved_o) {
      return false;
    }
    if (this->reserved_p != other.reserved_p) {
      return false;
    }
    if (this->reserved_q != other.reserved_q) {
      return false;
    }
    if (this->reserved_r != other.reserved_r) {
      return false;
    }
    if (this->timedoa != other.timedoa) {
      return false;
    }
    if (this->reserved_s != other.reserved_s) {
      return false;
    }
    if (this->reserved_t != other.reserved_t) {
      return false;
    }
    if (this->reserved_u != other.reserved_u) {
      return false;
    }
    if (this->latency != other.latency) {
      return false;
    }
    if (this->timepcl != other.timepcl) {
      return false;
    }
    if (this->car_v_estimate != other.car_v_estimate) {
      return false;
    }
    if (this->ground_k != other.ground_k) {
      return false;
    }
    if (this->ground_b != other.ground_b) {
      return false;
    }
    if (this->pcl_delay_time != other.pcl_delay_time) {
      return false;
    }
    if (this->timeod != other.timeod) {
      return false;
    }
    if (this->odtimeoutcnt != other.odtimeoutcnt) {
      return false;
    }
    if (this->selfcalistatus != other.selfcalistatus) {
      return false;
    }
    if (this->od_delay_time != other.od_delay_time) {
      return false;
    }
    if (this->car_v != other.car_v) {
      return false;
    }
    if (this->car_yawrate != other.car_yawrate) {
      return false;
    }
    if (this->car_gear_state != other.car_gear_state) {
      return false;
    }
    return true;
  }
  bool operator!=(const ProcessStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ProcessStatus_

// alias to use template instance with default allocator
using ProcessStatus =
  radar_msgs::msg::ProcessStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__STRUCT_HPP_
