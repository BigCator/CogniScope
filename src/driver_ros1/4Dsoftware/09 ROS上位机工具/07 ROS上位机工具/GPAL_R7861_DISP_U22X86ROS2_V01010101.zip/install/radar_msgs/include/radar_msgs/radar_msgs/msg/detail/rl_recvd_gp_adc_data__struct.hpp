// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RlRecvdGpAdcData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_RECVD_GP_ADC_DATA__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_RECVD_GP_ADC_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'sensor'
#include "radar_msgs/msg/detail/rl_gp_adc_data__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RlRecvdGpAdcData __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RlRecvdGpAdcData __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RlRecvdGpAdcData_
{
  using Type = RlRecvdGpAdcData_<ContainerAllocator>;

  explicit RlRecvdGpAdcData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor.fill(radar_msgs::msg::RlGpAdcData_<ContainerAllocator>{_init});
      std::fill<typename std::array<uint16_t, 4>::iterator, uint16_t>(this->reserved0.begin(), this->reserved0.end(), 0);
      std::fill<typename std::array<uint32_t, 7>::iterator, uint32_t>(this->reserved1.begin(), this->reserved1.end(), 0ul);
    }
  }

  explicit RlRecvdGpAdcData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : sensor(_alloc),
    reserved0(_alloc),
    reserved1(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor.fill(radar_msgs::msg::RlGpAdcData_<ContainerAllocator>{_alloc, _init});
      std::fill<typename std::array<uint16_t, 4>::iterator, uint16_t>(this->reserved0.begin(), this->reserved0.end(), 0);
      std::fill<typename std::array<uint32_t, 7>::iterator, uint32_t>(this->reserved1.begin(), this->reserved1.end(), 0ul);
    }
  }

  // field types and members
  using _sensor_type =
    std::array<radar_msgs::msg::RlGpAdcData_<ContainerAllocator>, 6>;
  _sensor_type sensor;
  using _reserved0_type =
    std::array<uint16_t, 4>;
  _reserved0_type reserved0;
  using _reserved1_type =
    std::array<uint32_t, 7>;
  _reserved1_type reserved1;

  // setters for named parameter idiom
  Type & set__sensor(
    const std::array<radar_msgs::msg::RlGpAdcData_<ContainerAllocator>, 6> & _arg)
  {
    this->sensor = _arg;
    return *this;
  }
  Type & set__reserved0(
    const std::array<uint16_t, 4> & _arg)
  {
    this->reserved0 = _arg;
    return *this;
  }
  Type & set__reserved1(
    const std::array<uint32_t, 7> & _arg)
  {
    this->reserved1 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RlRecvdGpAdcData
    std::shared_ptr<radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RlRecvdGpAdcData
    std::shared_ptr<radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RlRecvdGpAdcData_ & other) const
  {
    if (this->sensor != other.sensor) {
      return false;
    }
    if (this->reserved0 != other.reserved0) {
      return false;
    }
    if (this->reserved1 != other.reserved1) {
      return false;
    }
    return true;
  }
  bool operator!=(const RlRecvdGpAdcData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RlRecvdGpAdcData_

// alias to use template instance with default allocator
using RlRecvdGpAdcData =
  radar_msgs::msg::RlRecvdGpAdcData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_RECVD_GP_ADC_DATA__STRUCT_HPP_
