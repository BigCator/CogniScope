// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from radar_msgs:msg/RadarTarget.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "radar_msgs/msg/detail/radar_target__rosidl_typesupport_introspection_c.h"
#include "radar_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "radar_msgs/msg/detail/radar_target__functions.h"
#include "radar_msgs/msg/detail/radar_target__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `x`
// Member `y`
// Member `z`
// Member `v`
// Member `azimuth`
// Member `elevation`
// Member `snr`
// Member `power`
// Member `valid_flg`
// Member `existance_probability`
// Member `motion_state`
// Member `detection_class`
// Member `reset_cnt`
// Member `od_timeout_cnt`
// Member `reserved_a`
// Member `reserved_b`
// Member `reserved_c`
// Member `reserved_d`
// Member `reserved_e`
// Member `reserved_f`
// Member `reserved_g`
// Member `reserved_h`
// Member `reserved_i`
// Member `reserved_j`
// Member `reserved_k`
// Member `reserved_l`
// Member `reserved_m`
// Member `reserved_n`
// Member `reserved_o`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  radar_msgs__msg__RadarTarget__init(message_memory);
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_fini_function(void * message_memory)
{
  radar_msgs__msg__RadarTarget__fini(message_memory);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__x(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__x(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__x(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__x(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__x(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__x(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__x(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__x(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__y(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__y(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__y(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__y(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__y(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__y(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__y(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__y(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__z(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__z(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__z(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__z(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__z(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__z(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__z(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__z(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__v(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__v(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__v(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__v(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__v(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__v(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__v(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__v(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__azimuth(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__azimuth(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__azimuth(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__azimuth(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__azimuth(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__azimuth(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__azimuth(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__azimuth(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__elevation(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__elevation(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__elevation(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__elevation(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__elevation(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__elevation(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__elevation(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__elevation(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__snr(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__snr(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__snr(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__snr(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__snr(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__snr(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__snr(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__snr(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__power(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__power(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__power(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__power(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__power(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__power(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__power(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__power(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__valid_flg(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__valid_flg(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__valid_flg(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__valid_flg(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__valid_flg(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__valid_flg(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__valid_flg(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__valid_flg(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__existance_probability(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__existance_probability(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__existance_probability(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__existance_probability(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__existance_probability(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__existance_probability(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__existance_probability(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__existance_probability(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__motion_state(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__motion_state(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__motion_state(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__motion_state(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__motion_state(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__motion_state(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__motion_state(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__motion_state(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__detection_class(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__detection_class(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__detection_class(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__detection_class(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__detection_class(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__detection_class(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__detection_class(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__detection_class(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reset_cnt(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reset_cnt(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reset_cnt(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reset_cnt(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reset_cnt(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reset_cnt(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reset_cnt(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reset_cnt(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__od_timeout_cnt(
  const void * untyped_member)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__od_timeout_cnt(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__od_timeout_cnt(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__od_timeout_cnt(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int16_t * item =
    ((const int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__od_timeout_cnt(untyped_member, index));
  int16_t * value =
    (int16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__od_timeout_cnt(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int16_t * item =
    ((int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__od_timeout_cnt(untyped_member, index));
  const int16_t * value =
    (const int16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__od_timeout_cnt(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  rosidl_runtime_c__int16__Sequence__fini(member);
  return rosidl_runtime_c__int16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_a(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_a(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_a(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_a(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_a(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_a(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_a(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_a(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_b(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_b(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_b(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_b(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_b(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_b(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_b(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_b(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_c(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_c(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_c(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_c(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_c(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_c(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_c(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_c(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_d(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_d(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_d(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_d(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_d(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_d(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_d(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_d(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_e(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_e(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_e(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_e(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_e(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_e(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_e(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_e(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_f(
  const void * untyped_member)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_f(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_f(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_f(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int16_t * item =
    ((const int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_f(untyped_member, index));
  int16_t * value =
    (int16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_f(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int16_t * item =
    ((int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_f(untyped_member, index));
  const int16_t * value =
    (const int16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_f(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  rosidl_runtime_c__int16__Sequence__fini(member);
  return rosidl_runtime_c__int16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_g(
  const void * untyped_member)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_g(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_g(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_g(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int16_t * item =
    ((const int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_g(untyped_member, index));
  int16_t * value =
    (int16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_g(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int16_t * item =
    ((int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_g(untyped_member, index));
  const int16_t * value =
    (const int16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_g(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  rosidl_runtime_c__int16__Sequence__fini(member);
  return rosidl_runtime_c__int16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_h(
  const void * untyped_member)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_h(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_h(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_h(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int16_t * item =
    ((const int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_h(untyped_member, index));
  int16_t * value =
    (int16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_h(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int16_t * item =
    ((int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_h(untyped_member, index));
  const int16_t * value =
    (const int16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_h(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  rosidl_runtime_c__int16__Sequence__fini(member);
  return rosidl_runtime_c__int16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_i(
  const void * untyped_member)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_i(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_i(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_i(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int16_t * item =
    ((const int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_i(untyped_member, index));
  int16_t * value =
    (int16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_i(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int16_t * item =
    ((int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_i(untyped_member, index));
  const int16_t * value =
    (const int16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_i(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  rosidl_runtime_c__int16__Sequence__fini(member);
  return rosidl_runtime_c__int16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_j(
  const void * untyped_member)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_j(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int16__Sequence * member =
    (const rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_j(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_j(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int16_t * item =
    ((const int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_j(untyped_member, index));
  int16_t * value =
    (int16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_j(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int16_t * item =
    ((int16_t *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_j(untyped_member, index));
  const int16_t * value =
    (const int16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_j(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int16__Sequence * member =
    (rosidl_runtime_c__int16__Sequence *)(untyped_member);
  rosidl_runtime_c__int16__Sequence__fini(member);
  return rosidl_runtime_c__int16__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_k(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_k(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_k(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_k(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_k(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_k(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_k(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_k(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_l(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_l(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_l(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_l(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_l(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_l(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_l(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_l(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_m(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_m(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_m(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_m(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_m(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_m(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_m(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_m(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_n(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_n(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_n(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_n(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_n(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_n(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_n(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_n(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_o(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_o(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_o(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_o(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_o(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_o(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_o(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_o(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_message_member_array[35] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "radar_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, radar_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "frame_cnt",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, frame_cnt),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "target_num",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, target_num),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "polar_state",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, polar_state),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, x),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__x,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__x,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__x,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__x,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__x,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__x  // resize(index) function pointer
  },
  {
    "y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, y),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__y,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__y,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__y,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__y,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__y,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__y  // resize(index) function pointer
  },
  {
    "z",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, z),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__z,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__z,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__z,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__z,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__z,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__z  // resize(index) function pointer
  },
  {
    "v",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, v),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__v,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__v,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__v,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__v,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__v,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__v  // resize(index) function pointer
  },
  {
    "azimuth",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, azimuth),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__azimuth,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__azimuth,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__azimuth,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__azimuth,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__azimuth,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__azimuth  // resize(index) function pointer
  },
  {
    "elevation",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, elevation),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__elevation,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__elevation,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__elevation,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__elevation,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__elevation,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__elevation  // resize(index) function pointer
  },
  {
    "snr",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, snr),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__snr,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__snr,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__snr,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__snr,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__snr,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__snr  // resize(index) function pointer
  },
  {
    "power",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, power),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__power,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__power,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__power,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__power,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__power,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__power  // resize(index) function pointer
  },
  {
    "valid_flg",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, valid_flg),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__valid_flg,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__valid_flg,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__valid_flg,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__valid_flg,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__valid_flg,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__valid_flg  // resize(index) function pointer
  },
  {
    "existance_probability",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, existance_probability),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__existance_probability,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__existance_probability,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__existance_probability,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__existance_probability,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__existance_probability,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__existance_probability  // resize(index) function pointer
  },
  {
    "motion_state",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, motion_state),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__motion_state,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__motion_state,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__motion_state,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__motion_state,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__motion_state,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__motion_state  // resize(index) function pointer
  },
  {
    "detection_class",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, detection_class),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__detection_class,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__detection_class,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__detection_class,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__detection_class,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__detection_class,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__detection_class  // resize(index) function pointer
  },
  {
    "reset_cnt",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reset_cnt),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reset_cnt,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reset_cnt,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reset_cnt,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reset_cnt,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reset_cnt,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reset_cnt  // resize(index) function pointer
  },
  {
    "od_timeout_cnt",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, od_timeout_cnt),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__od_timeout_cnt,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__od_timeout_cnt,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__od_timeout_cnt,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__od_timeout_cnt,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__od_timeout_cnt,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__od_timeout_cnt  // resize(index) function pointer
  },
  {
    "reserved_a",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_a),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_a,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_a,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_a,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_a,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_a,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_a  // resize(index) function pointer
  },
  {
    "reserved_b",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_b),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_b,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_b,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_b,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_b,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_b,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_b  // resize(index) function pointer
  },
  {
    "reserved_c",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_c),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_c,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_c,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_c,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_c,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_c,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_c  // resize(index) function pointer
  },
  {
    "reserved_d",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_d),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_d,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_d,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_d,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_d,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_d,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_d  // resize(index) function pointer
  },
  {
    "reserved_e",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_e),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_e,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_e,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_e,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_e,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_e,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_e  // resize(index) function pointer
  },
  {
    "reserved_f",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_f),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_f,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_f,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_f,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_f,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_f,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_f  // resize(index) function pointer
  },
  {
    "reserved_g",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_g),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_g,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_g,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_g,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_g,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_g,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_g  // resize(index) function pointer
  },
  {
    "reserved_h",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_h),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_h,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_h,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_h,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_h,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_h,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_h  // resize(index) function pointer
  },
  {
    "reserved_i",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_i),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_i,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_i,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_i,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_i,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_i,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_i  // resize(index) function pointer
  },
  {
    "reserved_j",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_j),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_j,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_j,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_j,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_j,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_j,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_j  // resize(index) function pointer
  },
  {
    "reserved_k",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_k),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_k,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_k,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_k,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_k,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_k,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_k  // resize(index) function pointer
  },
  {
    "reserved_l",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_l),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_l,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_l,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_l,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_l,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_l,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_l  // resize(index) function pointer
  },
  {
    "reserved_m",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_m),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_m,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_m,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_m,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_m,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_m,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_m  // resize(index) function pointer
  },
  {
    "reserved_n",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_n),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_n,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_n,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_n,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_n,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_n,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_n  // resize(index) function pointer
  },
  {
    "reserved_o",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RadarTarget, reserved_o),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__size_function__RadarTarget__reserved_o,  // size() function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_const_function__RadarTarget__reserved_o,  // get_const(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__get_function__RadarTarget__reserved_o,  // get(index) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__fetch_function__RadarTarget__reserved_o,  // fetch(index, &value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__assign_function__RadarTarget__reserved_o,  // assign(index, value) function pointer
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__resize_function__RadarTarget__reserved_o  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_message_members = {
  "radar_msgs__msg",  // message namespace
  "RadarTarget",  // message name
  35,  // number of fields
  sizeof(radar_msgs__msg__RadarTarget),
  radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_message_member_array,  // message members
  radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_init_function,  // function to initialize message memory (memory has to be allocated)
  radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_message_type_support_handle = {
  0,
  &radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_radar_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RadarTarget)() {
  radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_message_type_support_handle.typesupport_identifier) {
    radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &radar_msgs__msg__RadarTarget__rosidl_typesupport_introspection_c__RadarTarget_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
