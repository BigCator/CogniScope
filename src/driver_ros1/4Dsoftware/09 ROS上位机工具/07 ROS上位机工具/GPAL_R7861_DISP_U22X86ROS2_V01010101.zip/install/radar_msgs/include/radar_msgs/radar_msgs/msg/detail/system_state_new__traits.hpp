// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/SystemStateNew.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_NEW__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_NEW__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/system_state_new__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SystemStateNew & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: project_code_num
  {
    if (msg.project_code_num.size() == 0) {
      out << "project_code_num: []";
    } else {
      out << "project_code_num: [";
      size_t pending_items = msg.project_code_num.size();
      for (auto item : msg.project_code_num) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: product_year
  {
    out << "product_year: ";
    rosidl_generator_traits::value_to_yaml(msg.product_year, out);
    out << ", ";
  }

  // member: product_month
  {
    out << "product_month: ";
    rosidl_generator_traits::value_to_yaml(msg.product_month, out);
    out << ", ";
  }

  // member: product_day
  {
    out << "product_day: ";
    rosidl_generator_traits::value_to_yaml(msg.product_day, out);
    out << ", ";
  }

  // member: porduct_code
  {
    if (msg.porduct_code.size() == 0) {
      out << "porduct_code: []";
    } else {
      out << "porduct_code: [";
      size_t pending_items = msg.porduct_code.size();
      for (auto item : msg.porduct_code) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: serial_num
  {
    if (msg.serial_num.size() == 0) {
      out << "serial_num: []";
    } else {
      out << "serial_num: [";
      size_t pending_items = msg.serial_num.size();
      for (auto item : msg.serial_num) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: rfhw_code
  {
    if (msg.rfhw_code.size() == 0) {
      out << "rfhw_code: []";
    } else {
      out << "rfhw_code: [";
      size_t pending_items = msg.rfhw_code.size();
      for (auto item : msg.rfhw_code) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: rfhw_version
  {
    out << "rfhw_version: ";
    rosidl_generator_traits::value_to_yaml(msg.rfhw_version, out);
    out << ", ";
  }

  // member: dsphw_code
  {
    if (msg.dsphw_code.size() == 0) {
      out << "dsphw_code: []";
    } else {
      out << "dsphw_code: [";
      size_t pending_items = msg.dsphw_code.size();
      for (auto item : msg.dsphw_code) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: dsphw_version
  {
    out << "dsphw_version: ";
    rosidl_generator_traits::value_to_yaml(msg.dsphw_version, out);
    out << ", ";
  }

  // member: calibrate_code
  {
    if (msg.calibrate_code.size() == 0) {
      out << "calibrate_code: []";
    } else {
      out << "calibrate_code: [";
      size_t pending_items = msg.calibrate_code.size();
      for (auto item : msg.calibrate_code) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: os_version
  {
    if (msg.os_version.size() == 0) {
      out << "os_version: []";
    } else {
      out << "os_version: [";
      size_t pending_items = msg.os_version.size();
      for (auto item : msg.os_version) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: sw_version
  {
    if (msg.sw_version.size() == 0) {
      out << "sw_version: []";
    } else {
      out << "sw_version: [";
      size_t pending_items = msg.sw_version.size();
      for (auto item : msg.sw_version) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: algo_version
  {
    if (msg.algo_version.size() == 0) {
      out << "algo_version: []";
    } else {
      out << "algo_version: [";
      size_t pending_items = msg.algo_version.size();
      for (auto item : msg.algo_version) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: waveform_version
  {
    if (msg.waveform_version.size() == 0) {
      out << "waveform_version: []";
    } else {
      out << "waveform_version: [";
      size_t pending_items = msg.waveform_version.size();
      for (auto item : msg.waveform_version) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: a72_0_loading
  {
    out << "a72_0_loading: ";
    rosidl_generator_traits::value_to_yaml(msg.a72_0_loading, out);
    out << ", ";
  }

  // member: a72_1_loading
  {
    out << "a72_1_loading: ";
    rosidl_generator_traits::value_to_yaml(msg.a72_1_loading, out);
    out << ", ";
  }

  // member: a72_0_freq
  {
    out << "a72_0_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.a72_0_freq, out);
    out << ", ";
  }

  // member: a72_1_freq
  {
    out << "a72_1_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.a72_1_freq, out);
    out << ", ";
  }

  // member: mcu_0_freq
  {
    out << "mcu_0_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.mcu_0_freq, out);
    out << ", ";
  }

  // member: mcu_1_freq
  {
    out << "mcu_1_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.mcu_1_freq, out);
    out << ", ";
  }

  // member: mcu_2_freq
  {
    out << "mcu_2_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.mcu_2_freq, out);
    out << ", ";
  }

  // member: mcu_3_freq
  {
    out << "mcu_3_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.mcu_3_freq, out);
    out << ", ";
  }

  // member: lp_mcu_0_freq
  {
    out << "lp_mcu_0_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.lp_mcu_0_freq, out);
    out << ", ";
  }

  // member: lp_mcu_1_freq
  {
    out << "lp_mcu_1_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.lp_mcu_1_freq, out);
    out << ", ";
  }

  // member: c7x_mma_freq
  {
    out << "c7x_mma_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.c7x_mma_freq, out);
    out << ", ";
  }

  // member: c66x_0_freq
  {
    out << "c66x_0_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.c66x_0_freq, out);
    out << ", ";
  }

  // member: c66x_1_freq
  {
    out << "c66x_1_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.c66x_1_freq, out);
    out << ", ";
  }

  // member: c7x_1_freq
  {
    out << "c7x_1_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.c7x_1_freq, out);
    out << ", ";
  }

  // member: reboot_cnt
  {
    out << "reboot_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.reboot_cnt, out);
    out << ", ";
  }

  // member: memory_loading
  {
    out << "memory_loading: ";
    rosidl_generator_traits::value_to_yaml(msg.memory_loading, out);
    out << ", ";
  }

  // member: junction_temp
  {
    out << "junction_temp: ";
    rosidl_generator_traits::value_to_yaml(msg.junction_temp, out);
    out << ", ";
  }

  // member: low_power_mode_enable
  {
    out << "low_power_mode_enable: ";
    rosidl_generator_traits::value_to_yaml(msg.low_power_mode_enable, out);
    out << ", ";
  }

  // member: error_code
  {
    out << "error_code: ";
    rosidl_generator_traits::value_to_yaml(msg.error_code, out);
    out << ", ";
  }

  // member: blockage_detection
  {
    out << "blockage_detection: ";
    rosidl_generator_traits::value_to_yaml(msg.blockage_detection, out);
    out << ", ";
  }

  // member: radar_mode
  {
    out << "radar_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_mode, out);
    out << ", ";
  }

  // member: udpsend_enpnt
  {
    out << "udpsend_enpnt: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_enpnt, out);
    out << ", ";
  }

  // member: udpsend_entrk
  {
    out << "udpsend_entrk: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_entrk, out);
    out << ", ";
  }

  // member: udpsend_enrdmap
  {
    out << "udpsend_enrdmap: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_enrdmap, out);
    out << ", ";
  }

  // member: udpsend_encfar
  {
    out << "udpsend_encfar: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_encfar, out);
    out << ", ";
  }

  // member: udpsend_enadc
  {
    out << "udpsend_enadc: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_enadc, out);
    out << ", ";
  }

  // member: udpsend_enfft1d
  {
    out << "udpsend_enfft1d: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_enfft1d, out);
    out << ", ";
  }

  // member: udpsend_enfft2d
  {
    out << "udpsend_enfft2d: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_enfft2d, out);
    out << ", ";
  }

  // member: udpsend_endoa
  {
    out << "udpsend_endoa: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_endoa, out);
    out << ", ";
  }

  // member: radar_txfreq
  {
    out << "radar_txfreq: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_txfreq, out);
    out << ", ";
  }

  // member: frame_triggerdelay
  {
    out << "frame_triggerdelay: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_triggerdelay, out);
    out << ", ";
  }

  // member: sync_enable
  {
    out << "sync_enable: ";
    rosidl_generator_traits::value_to_yaml(msg.sync_enable, out);
    out << ", ";
  }

  // member: sync_radarnum
  {
    out << "sync_radarnum: ";
    rosidl_generator_traits::value_to_yaml(msg.sync_radarnum, out);
    out << ", ";
  }

  // member: antiinterface_enable
  {
    out << "antiinterface_enable: ";
    rosidl_generator_traits::value_to_yaml(msg.antiinterface_enable, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SystemStateNew & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: project_code_num
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.project_code_num.size() == 0) {
      out << "project_code_num: []\n";
    } else {
      out << "project_code_num:\n";
      for (auto item : msg.project_code_num) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: product_year
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "product_year: ";
    rosidl_generator_traits::value_to_yaml(msg.product_year, out);
    out << "\n";
  }

  // member: product_month
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "product_month: ";
    rosidl_generator_traits::value_to_yaml(msg.product_month, out);
    out << "\n";
  }

  // member: product_day
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "product_day: ";
    rosidl_generator_traits::value_to_yaml(msg.product_day, out);
    out << "\n";
  }

  // member: porduct_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.porduct_code.size() == 0) {
      out << "porduct_code: []\n";
    } else {
      out << "porduct_code:\n";
      for (auto item : msg.porduct_code) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: serial_num
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.serial_num.size() == 0) {
      out << "serial_num: []\n";
    } else {
      out << "serial_num:\n";
      for (auto item : msg.serial_num) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: rfhw_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.rfhw_code.size() == 0) {
      out << "rfhw_code: []\n";
    } else {
      out << "rfhw_code:\n";
      for (auto item : msg.rfhw_code) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: rfhw_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rfhw_version: ";
    rosidl_generator_traits::value_to_yaml(msg.rfhw_version, out);
    out << "\n";
  }

  // member: dsphw_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.dsphw_code.size() == 0) {
      out << "dsphw_code: []\n";
    } else {
      out << "dsphw_code:\n";
      for (auto item : msg.dsphw_code) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: dsphw_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dsphw_version: ";
    rosidl_generator_traits::value_to_yaml(msg.dsphw_version, out);
    out << "\n";
  }

  // member: calibrate_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.calibrate_code.size() == 0) {
      out << "calibrate_code: []\n";
    } else {
      out << "calibrate_code:\n";
      for (auto item : msg.calibrate_code) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: os_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.os_version.size() == 0) {
      out << "os_version: []\n";
    } else {
      out << "os_version:\n";
      for (auto item : msg.os_version) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: sw_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.sw_version.size() == 0) {
      out << "sw_version: []\n";
    } else {
      out << "sw_version:\n";
      for (auto item : msg.sw_version) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: algo_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.algo_version.size() == 0) {
      out << "algo_version: []\n";
    } else {
      out << "algo_version:\n";
      for (auto item : msg.algo_version) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: waveform_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.waveform_version.size() == 0) {
      out << "waveform_version: []\n";
    } else {
      out << "waveform_version:\n";
      for (auto item : msg.waveform_version) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: a72_0_loading
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "a72_0_loading: ";
    rosidl_generator_traits::value_to_yaml(msg.a72_0_loading, out);
    out << "\n";
  }

  // member: a72_1_loading
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "a72_1_loading: ";
    rosidl_generator_traits::value_to_yaml(msg.a72_1_loading, out);
    out << "\n";
  }

  // member: a72_0_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "a72_0_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.a72_0_freq, out);
    out << "\n";
  }

  // member: a72_1_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "a72_1_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.a72_1_freq, out);
    out << "\n";
  }

  // member: mcu_0_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mcu_0_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.mcu_0_freq, out);
    out << "\n";
  }

  // member: mcu_1_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mcu_1_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.mcu_1_freq, out);
    out << "\n";
  }

  // member: mcu_2_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mcu_2_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.mcu_2_freq, out);
    out << "\n";
  }

  // member: mcu_3_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mcu_3_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.mcu_3_freq, out);
    out << "\n";
  }

  // member: lp_mcu_0_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lp_mcu_0_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.lp_mcu_0_freq, out);
    out << "\n";
  }

  // member: lp_mcu_1_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lp_mcu_1_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.lp_mcu_1_freq, out);
    out << "\n";
  }

  // member: c7x_mma_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "c7x_mma_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.c7x_mma_freq, out);
    out << "\n";
  }

  // member: c66x_0_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "c66x_0_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.c66x_0_freq, out);
    out << "\n";
  }

  // member: c66x_1_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "c66x_1_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.c66x_1_freq, out);
    out << "\n";
  }

  // member: c7x_1_freq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "c7x_1_freq: ";
    rosidl_generator_traits::value_to_yaml(msg.c7x_1_freq, out);
    out << "\n";
  }

  // member: reboot_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reboot_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.reboot_cnt, out);
    out << "\n";
  }

  // member: memory_loading
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "memory_loading: ";
    rosidl_generator_traits::value_to_yaml(msg.memory_loading, out);
    out << "\n";
  }

  // member: junction_temp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "junction_temp: ";
    rosidl_generator_traits::value_to_yaml(msg.junction_temp, out);
    out << "\n";
  }

  // member: low_power_mode_enable
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "low_power_mode_enable: ";
    rosidl_generator_traits::value_to_yaml(msg.low_power_mode_enable, out);
    out << "\n";
  }

  // member: error_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "error_code: ";
    rosidl_generator_traits::value_to_yaml(msg.error_code, out);
    out << "\n";
  }

  // member: blockage_detection
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "blockage_detection: ";
    rosidl_generator_traits::value_to_yaml(msg.blockage_detection, out);
    out << "\n";
  }

  // member: radar_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "radar_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_mode, out);
    out << "\n";
  }

  // member: udpsend_enpnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udpsend_enpnt: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_enpnt, out);
    out << "\n";
  }

  // member: udpsend_entrk
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udpsend_entrk: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_entrk, out);
    out << "\n";
  }

  // member: udpsend_enrdmap
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udpsend_enrdmap: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_enrdmap, out);
    out << "\n";
  }

  // member: udpsend_encfar
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udpsend_encfar: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_encfar, out);
    out << "\n";
  }

  // member: udpsend_enadc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udpsend_enadc: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_enadc, out);
    out << "\n";
  }

  // member: udpsend_enfft1d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udpsend_enfft1d: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_enfft1d, out);
    out << "\n";
  }

  // member: udpsend_enfft2d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udpsend_enfft2d: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_enfft2d, out);
    out << "\n";
  }

  // member: udpsend_endoa
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udpsend_endoa: ";
    rosidl_generator_traits::value_to_yaml(msg.udpsend_endoa, out);
    out << "\n";
  }

  // member: radar_txfreq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "radar_txfreq: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_txfreq, out);
    out << "\n";
  }

  // member: frame_triggerdelay
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_triggerdelay: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_triggerdelay, out);
    out << "\n";
  }

  // member: sync_enable
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sync_enable: ";
    rosidl_generator_traits::value_to_yaml(msg.sync_enable, out);
    out << "\n";
  }

  // member: sync_radarnum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sync_radarnum: ";
    rosidl_generator_traits::value_to_yaml(msg.sync_radarnum, out);
    out << "\n";
  }

  // member: antiinterface_enable
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "antiinterface_enable: ";
    rosidl_generator_traits::value_to_yaml(msg.antiinterface_enable, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SystemStateNew & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::SystemStateNew & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::SystemStateNew & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::SystemStateNew>()
{
  return "radar_msgs::msg::SystemStateNew";
}

template<>
inline const char * name<radar_msgs::msg::SystemStateNew>()
{
  return "radar_msgs/msg/SystemStateNew";
}

template<>
struct has_fixed_size<radar_msgs::msg::SystemStateNew>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<radar_msgs::msg::SystemStateNew>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<radar_msgs::msg::SystemStateNew>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_NEW__TRAITS_HPP_
