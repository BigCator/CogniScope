// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/RlMonTxPhShiftRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/rl_mon_tx_ph_shift_rep__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const RlMonTxPhShiftRep & msg,
  std::ostream & out)
{
  out << "{";
  // member: statusflags
  {
    out << "statusflags: ";
    rosidl_generator_traits::value_to_yaml(msg.statusflags, out);
    out << ", ";
  }

  // member: errorcode
  {
    out << "errorcode: ";
    rosidl_generator_traits::value_to_yaml(msg.errorcode, out);
    out << ", ";
  }

  // member: profindex
  {
    out << "profindex: ";
    rosidl_generator_traits::value_to_yaml(msg.profindex, out);
    out << ", ";
  }

  // member: reserved0
  {
    out << "reserved0: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved0, out);
    out << ", ";
  }

  // member: reserved1
  {
    out << "reserved1: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved1, out);
    out << ", ";
  }

  // member: phaseshiftermonval1
  {
    out << "phaseshiftermonval1: ";
    rosidl_generator_traits::value_to_yaml(msg.phaseshiftermonval1, out);
    out << ", ";
  }

  // member: phaseshiftermonval2
  {
    out << "phaseshiftermonval2: ";
    rosidl_generator_traits::value_to_yaml(msg.phaseshiftermonval2, out);
    out << ", ";
  }

  // member: phaseshiftermonval3
  {
    out << "phaseshiftermonval3: ";
    rosidl_generator_traits::value_to_yaml(msg.phaseshiftermonval3, out);
    out << ", ";
  }

  // member: phaseshiftermonval4
  {
    out << "phaseshiftermonval4: ";
    rosidl_generator_traits::value_to_yaml(msg.phaseshiftermonval4, out);
    out << ", ";
  }

  // member: txpsamplitudeval1
  {
    out << "txpsamplitudeval1: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsamplitudeval1, out);
    out << ", ";
  }

  // member: txpsamplitudeval2
  {
    out << "txpsamplitudeval2: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsamplitudeval2, out);
    out << ", ";
  }

  // member: txpsamplitudeval3
  {
    out << "txpsamplitudeval3: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsamplitudeval3, out);
    out << ", ";
  }

  // member: txpsamplitudeval4
  {
    out << "txpsamplitudeval4: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsamplitudeval4, out);
    out << ", ";
  }

  // member: txpsnoiseval1
  {
    out << "txpsnoiseval1: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsnoiseval1, out);
    out << ", ";
  }

  // member: txpsnoiseval2
  {
    out << "txpsnoiseval2: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsnoiseval2, out);
    out << ", ";
  }

  // member: txpsnoiseval3
  {
    out << "txpsnoiseval3: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsnoiseval3, out);
    out << ", ";
  }

  // member: txpsnoiseval4
  {
    out << "txpsnoiseval4: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsnoiseval4, out);
    out << ", ";
  }

  // member: timestamp
  {
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << ", ";
  }

  // member: reserved2
  {
    out << "reserved2: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved2, out);
    out << ", ";
  }

  // member: reserved3
  {
    out << "reserved3: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved3, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RlMonTxPhShiftRep & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: statusflags
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "statusflags: ";
    rosidl_generator_traits::value_to_yaml(msg.statusflags, out);
    out << "\n";
  }

  // member: errorcode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "errorcode: ";
    rosidl_generator_traits::value_to_yaml(msg.errorcode, out);
    out << "\n";
  }

  // member: profindex
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "profindex: ";
    rosidl_generator_traits::value_to_yaml(msg.profindex, out);
    out << "\n";
  }

  // member: reserved0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved0: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved0, out);
    out << "\n";
  }

  // member: reserved1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved1: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved1, out);
    out << "\n";
  }

  // member: phaseshiftermonval1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "phaseshiftermonval1: ";
    rosidl_generator_traits::value_to_yaml(msg.phaseshiftermonval1, out);
    out << "\n";
  }

  // member: phaseshiftermonval2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "phaseshiftermonval2: ";
    rosidl_generator_traits::value_to_yaml(msg.phaseshiftermonval2, out);
    out << "\n";
  }

  // member: phaseshiftermonval3
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "phaseshiftermonval3: ";
    rosidl_generator_traits::value_to_yaml(msg.phaseshiftermonval3, out);
    out << "\n";
  }

  // member: phaseshiftermonval4
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "phaseshiftermonval4: ";
    rosidl_generator_traits::value_to_yaml(msg.phaseshiftermonval4, out);
    out << "\n";
  }

  // member: txpsamplitudeval1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "txpsamplitudeval1: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsamplitudeval1, out);
    out << "\n";
  }

  // member: txpsamplitudeval2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "txpsamplitudeval2: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsamplitudeval2, out);
    out << "\n";
  }

  // member: txpsamplitudeval3
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "txpsamplitudeval3: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsamplitudeval3, out);
    out << "\n";
  }

  // member: txpsamplitudeval4
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "txpsamplitudeval4: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsamplitudeval4, out);
    out << "\n";
  }

  // member: txpsnoiseval1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "txpsnoiseval1: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsnoiseval1, out);
    out << "\n";
  }

  // member: txpsnoiseval2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "txpsnoiseval2: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsnoiseval2, out);
    out << "\n";
  }

  // member: txpsnoiseval3
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "txpsnoiseval3: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsnoiseval3, out);
    out << "\n";
  }

  // member: txpsnoiseval4
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "txpsnoiseval4: ";
    rosidl_generator_traits::value_to_yaml(msg.txpsnoiseval4, out);
    out << "\n";
  }

  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << "\n";
  }

  // member: reserved2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved2: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved2, out);
    out << "\n";
  }

  // member: reserved3
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved3: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved3, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RlMonTxPhShiftRep & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::RlMonTxPhShiftRep & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::RlMonTxPhShiftRep & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::RlMonTxPhShiftRep>()
{
  return "radar_msgs::msg::RlMonTxPhShiftRep";
}

template<>
inline const char * name<radar_msgs::msg::RlMonTxPhShiftRep>()
{
  return "radar_msgs/msg/RlMonTxPhShiftRep";
}

template<>
struct has_fixed_size<radar_msgs::msg::RlMonTxPhShiftRep>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<radar_msgs::msg::RlMonTxPhShiftRep>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<radar_msgs::msg::RlMonTxPhShiftRep>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__TRAITS_HPP_
