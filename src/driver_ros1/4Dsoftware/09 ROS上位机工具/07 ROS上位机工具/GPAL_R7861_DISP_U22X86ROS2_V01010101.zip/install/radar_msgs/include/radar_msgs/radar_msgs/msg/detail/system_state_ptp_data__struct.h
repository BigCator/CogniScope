// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/SystemStatePtpData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_PTP_DATA__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_PTP_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/SystemStatePtpData in the package radar_msgs.
typedef struct radar_msgs__msg__SystemStatePtpData
{
  uint32_t reserved;
  uint32_t ptp_counter_flg;
  uint32_t pulse_count;
  uint32_t ptp_sec_counter;
  uint32_t ptp_nsec;
  uint64_t ptp_follow_sec;
  uint64_t ptp_sec_counter_all;
} radar_msgs__msg__SystemStatePtpData;

// Struct for a sequence of radar_msgs__msg__SystemStatePtpData.
typedef struct radar_msgs__msg__SystemStatePtpData__Sequence
{
  radar_msgs__msg__SystemStatePtpData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__SystemStatePtpData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_PTP_DATA__STRUCT_H_
