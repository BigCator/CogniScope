// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/RlMonTxPhShiftRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/RlMonTxPhShiftRep in the package radar_msgs.
typedef struct radar_msgs__msg__RlMonTxPhShiftRep
{
  uint16_t statusflags;
  uint16_t errorcode;
  uint8_t profindex;
  uint8_t reserved0;
  uint16_t reserved1;
  uint16_t phaseshiftermonval1;
  uint16_t phaseshiftermonval2;
  uint16_t phaseshiftermonval3;
  uint16_t phaseshiftermonval4;
  int16_t txpsamplitudeval1;
  int16_t txpsamplitudeval2;
  int16_t txpsamplitudeval3;
  int16_t txpsamplitudeval4;
  int8_t txpsnoiseval1;
  int8_t txpsnoiseval2;
  int8_t txpsnoiseval3;
  int8_t txpsnoiseval4;
  uint32_t timestamp;
  uint32_t reserved2;
  uint32_t reserved3;
} radar_msgs__msg__RlMonTxPhShiftRep;

// Struct for a sequence of radar_msgs__msg__RlMonTxPhShiftRep.
typedef struct radar_msgs__msg__RlMonTxPhShiftRep__Sequence
{
  radar_msgs__msg__RlMonTxPhShiftRep * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__RlMonTxPhShiftRep__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__STRUCT_H_
