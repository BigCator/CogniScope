// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/SystemState.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/system_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `temp`
#include "radar_msgs/msg/detail/system_state_temp__functions.h"
// Member `load`
#include "radar_msgs/msg/detail/system_stats_load__functions.h"
// Member `primary_heap`
#include "radar_msgs/msg/detail/system_statsheap__functions.h"
// Member `heap_arr`
#include "radar_msgs/msg/detail/system_statsheap_arr__functions.h"
// Member `ptp_data`
#include "radar_msgs/msg/detail/system_state_ptp_data__functions.h"

bool
radar_msgs__msg__SystemState__init(radar_msgs__msg__SystemState * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__SystemState__fini(msg);
    return false;
  }
  // temp
  for (size_t i = 0; i < 5; ++i) {
    if (!radar_msgs__msg__SystemStateTemp__init(&msg->temp[i])) {
      radar_msgs__msg__SystemState__fini(msg);
      return false;
    }
  }
  // voltage
  // freq
  // load
  for (size_t i = 0; i < 10; ++i) {
    if (!radar_msgs__msg__SystemStatsLoad__init(&msg->load[i])) {
      radar_msgs__msg__SystemState__fini(msg);
      return false;
    }
  }
  // primary_heap
  for (size_t i = 0; i < 4; ++i) {
    if (!radar_msgs__msg__SystemStatsheap__init(&msg->primary_heap[i])) {
      radar_msgs__msg__SystemState__fini(msg);
      return false;
    }
  }
  // heap_arr
  for (size_t i = 0; i < 9; ++i) {
    if (!radar_msgs__msg__SystemStatsheapArr__init(&msg->heap_arr[i])) {
      radar_msgs__msg__SystemState__fini(msg);
      return false;
    }
  }
  // ptp_data
  if (!radar_msgs__msg__SystemStatePtpData__init(&msg->ptp_data)) {
    radar_msgs__msg__SystemState__fini(msg);
    return false;
  }
  return true;
}

void
radar_msgs__msg__SystemState__fini(radar_msgs__msg__SystemState * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // temp
  for (size_t i = 0; i < 5; ++i) {
    radar_msgs__msg__SystemStateTemp__fini(&msg->temp[i]);
  }
  // voltage
  // freq
  // load
  for (size_t i = 0; i < 10; ++i) {
    radar_msgs__msg__SystemStatsLoad__fini(&msg->load[i]);
  }
  // primary_heap
  for (size_t i = 0; i < 4; ++i) {
    radar_msgs__msg__SystemStatsheap__fini(&msg->primary_heap[i]);
  }
  // heap_arr
  for (size_t i = 0; i < 9; ++i) {
    radar_msgs__msg__SystemStatsheapArr__fini(&msg->heap_arr[i]);
  }
  // ptp_data
  radar_msgs__msg__SystemStatePtpData__fini(&msg->ptp_data);
}

bool
radar_msgs__msg__SystemState__are_equal(const radar_msgs__msg__SystemState * lhs, const radar_msgs__msg__SystemState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // temp
  for (size_t i = 0; i < 5; ++i) {
    if (!radar_msgs__msg__SystemStateTemp__are_equal(
        &(lhs->temp[i]), &(rhs->temp[i])))
    {
      return false;
    }
  }
  // voltage
  for (size_t i = 0; i < 5; ++i) {
    if (lhs->voltage[i] != rhs->voltage[i]) {
      return false;
    }
  }
  // freq
  for (size_t i = 0; i < 10; ++i) {
    if (lhs->freq[i] != rhs->freq[i]) {
      return false;
    }
  }
  // load
  for (size_t i = 0; i < 10; ++i) {
    if (!radar_msgs__msg__SystemStatsLoad__are_equal(
        &(lhs->load[i]), &(rhs->load[i])))
    {
      return false;
    }
  }
  // primary_heap
  for (size_t i = 0; i < 4; ++i) {
    if (!radar_msgs__msg__SystemStatsheap__are_equal(
        &(lhs->primary_heap[i]), &(rhs->primary_heap[i])))
    {
      return false;
    }
  }
  // heap_arr
  for (size_t i = 0; i < 9; ++i) {
    if (!radar_msgs__msg__SystemStatsheapArr__are_equal(
        &(lhs->heap_arr[i]), &(rhs->heap_arr[i])))
    {
      return false;
    }
  }
  // ptp_data
  if (!radar_msgs__msg__SystemStatePtpData__are_equal(
      &(lhs->ptp_data), &(rhs->ptp_data)))
  {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__SystemState__copy(
  const radar_msgs__msg__SystemState * input,
  radar_msgs__msg__SystemState * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // temp
  for (size_t i = 0; i < 5; ++i) {
    if (!radar_msgs__msg__SystemStateTemp__copy(
        &(input->temp[i]), &(output->temp[i])))
    {
      return false;
    }
  }
  // voltage
  for (size_t i = 0; i < 5; ++i) {
    output->voltage[i] = input->voltage[i];
  }
  // freq
  for (size_t i = 0; i < 10; ++i) {
    output->freq[i] = input->freq[i];
  }
  // load
  for (size_t i = 0; i < 10; ++i) {
    if (!radar_msgs__msg__SystemStatsLoad__copy(
        &(input->load[i]), &(output->load[i])))
    {
      return false;
    }
  }
  // primary_heap
  for (size_t i = 0; i < 4; ++i) {
    if (!radar_msgs__msg__SystemStatsheap__copy(
        &(input->primary_heap[i]), &(output->primary_heap[i])))
    {
      return false;
    }
  }
  // heap_arr
  for (size_t i = 0; i < 9; ++i) {
    if (!radar_msgs__msg__SystemStatsheapArr__copy(
        &(input->heap_arr[i]), &(output->heap_arr[i])))
    {
      return false;
    }
  }
  // ptp_data
  if (!radar_msgs__msg__SystemStatePtpData__copy(
      &(input->ptp_data), &(output->ptp_data)))
  {
    return false;
  }
  return true;
}

radar_msgs__msg__SystemState *
radar_msgs__msg__SystemState__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemState * msg = (radar_msgs__msg__SystemState *)allocator.allocate(sizeof(radar_msgs__msg__SystemState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__SystemState));
  bool success = radar_msgs__msg__SystemState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__SystemState__destroy(radar_msgs__msg__SystemState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__SystemState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__SystemState__Sequence__init(radar_msgs__msg__SystemState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemState * data = NULL;

  if (size) {
    data = (radar_msgs__msg__SystemState *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__SystemState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__SystemState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__SystemState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__SystemState__Sequence__fini(radar_msgs__msg__SystemState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__SystemState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__SystemState__Sequence *
radar_msgs__msg__SystemState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemState__Sequence * array = (radar_msgs__msg__SystemState__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__SystemState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__SystemState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__SystemState__Sequence__destroy(radar_msgs__msg__SystemState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__SystemState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__SystemState__Sequence__are_equal(const radar_msgs__msg__SystemState__Sequence * lhs, const radar_msgs__msg__SystemState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__SystemState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__SystemState__Sequence__copy(
  const radar_msgs__msg__SystemState__Sequence * input,
  radar_msgs__msg__SystemState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__SystemState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__SystemState * data =
      (radar_msgs__msg__SystemState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__SystemState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__SystemState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__SystemState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
