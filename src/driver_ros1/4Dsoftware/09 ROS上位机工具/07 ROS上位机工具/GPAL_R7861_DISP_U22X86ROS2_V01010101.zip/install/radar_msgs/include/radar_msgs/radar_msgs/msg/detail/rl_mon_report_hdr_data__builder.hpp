// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonReportHdrData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_REPORT_HDR_DATA__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_REPORT_HDR_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_report_hdr_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonReportHdrData_reserved1
{
public:
  explicit Init_RlMonReportHdrData_reserved1(::radar_msgs::msg::RlMonReportHdrData & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonReportHdrData reserved1(::radar_msgs::msg::RlMonReportHdrData::_reserved1_type arg)
  {
    msg_.reserved1 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonReportHdrData msg_;
};

class Init_RlMonReportHdrData_reserved0
{
public:
  explicit Init_RlMonReportHdrData_reserved0(::radar_msgs::msg::RlMonReportHdrData & msg)
  : msg_(msg)
  {}
  Init_RlMonReportHdrData_reserved1 reserved0(::radar_msgs::msg::RlMonReportHdrData::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlMonReportHdrData_reserved1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonReportHdrData msg_;
};

class Init_RlMonReportHdrData_avgtemp
{
public:
  explicit Init_RlMonReportHdrData_avgtemp(::radar_msgs::msg::RlMonReportHdrData & msg)
  : msg_(msg)
  {}
  Init_RlMonReportHdrData_reserved0 avgtemp(::radar_msgs::msg::RlMonReportHdrData::_avgtemp_type arg)
  {
    msg_.avgtemp = std::move(arg);
    return Init_RlMonReportHdrData_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonReportHdrData msg_;
};

class Init_RlMonReportHdrData_ftticount
{
public:
  Init_RlMonReportHdrData_ftticount()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonReportHdrData_avgtemp ftticount(::radar_msgs::msg::RlMonReportHdrData::_ftticount_type arg)
  {
    msg_.ftticount = std::move(arg);
    return Init_RlMonReportHdrData_avgtemp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonReportHdrData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonReportHdrData>()
{
  return radar_msgs::msg::builder::Init_RlMonReportHdrData_ftticount();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_REPORT_HDR_DATA__BUILDER_HPP_
