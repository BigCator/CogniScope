// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonTxPowRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_TX_POW_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_TX_POW_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_tx_pow_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonTxPowRep_timestamp
{
public:
  explicit Init_RlMonTxPowRep_timestamp(::radar_msgs::msg::RlMonTxPowRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonTxPowRep timestamp(::radar_msgs::msg::RlMonTxPowRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPowRep msg_;
};

class Init_RlMonTxPowRep_reserved2
{
public:
  explicit Init_RlMonTxPowRep_reserved2(::radar_msgs::msg::RlMonTxPowRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPowRep_timestamp reserved2(::radar_msgs::msg::RlMonTxPowRep::_reserved2_type arg)
  {
    msg_.reserved2 = std::move(arg);
    return Init_RlMonTxPowRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPowRep msg_;
};

class Init_RlMonTxPowRep_txpowval
{
public:
  explicit Init_RlMonTxPowRep_txpowval(::radar_msgs::msg::RlMonTxPowRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPowRep_reserved2 txpowval(::radar_msgs::msg::RlMonTxPowRep::_txpowval_type arg)
  {
    msg_.txpowval = std::move(arg);
    return Init_RlMonTxPowRep_reserved2(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPowRep msg_;
};

class Init_RlMonTxPowRep_reserved1
{
public:
  explicit Init_RlMonTxPowRep_reserved1(::radar_msgs::msg::RlMonTxPowRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPowRep_txpowval reserved1(::radar_msgs::msg::RlMonTxPowRep::_reserved1_type arg)
  {
    msg_.reserved1 = std::move(arg);
    return Init_RlMonTxPowRep_txpowval(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPowRep msg_;
};

class Init_RlMonTxPowRep_reserved0
{
public:
  explicit Init_RlMonTxPowRep_reserved0(::radar_msgs::msg::RlMonTxPowRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPowRep_reserved1 reserved0(::radar_msgs::msg::RlMonTxPowRep::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlMonTxPowRep_reserved1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPowRep msg_;
};

class Init_RlMonTxPowRep_profindex
{
public:
  explicit Init_RlMonTxPowRep_profindex(::radar_msgs::msg::RlMonTxPowRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPowRep_reserved0 profindex(::radar_msgs::msg::RlMonTxPowRep::_profindex_type arg)
  {
    msg_.profindex = std::move(arg);
    return Init_RlMonTxPowRep_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPowRep msg_;
};

class Init_RlMonTxPowRep_errorcode
{
public:
  explicit Init_RlMonTxPowRep_errorcode(::radar_msgs::msg::RlMonTxPowRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPowRep_profindex errorcode(::radar_msgs::msg::RlMonTxPowRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonTxPowRep_profindex(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPowRep msg_;
};

class Init_RlMonTxPowRep_statusflags
{
public:
  Init_RlMonTxPowRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonTxPowRep_errorcode statusflags(::radar_msgs::msg::RlMonTxPowRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonTxPowRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPowRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonTxPowRep>()
{
  return radar_msgs::msg::builder::Init_RlMonTxPowRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_TX_POW_REP__BUILDER_HPP_
