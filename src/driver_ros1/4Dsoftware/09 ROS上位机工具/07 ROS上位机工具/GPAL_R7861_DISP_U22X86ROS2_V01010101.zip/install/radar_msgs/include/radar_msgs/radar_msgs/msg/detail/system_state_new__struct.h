// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/SystemStateNew.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_NEW__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_NEW__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/SystemStateNew in the package radar_msgs.
typedef struct radar_msgs__msg__SystemStateNew
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  /// project number
  uint8_t project_code_num[20];
  /// manufacture date: year since 2000
  uint16_t product_year;
  /// manufacture date: month
  uint16_t product_month;
  /// manufacture date: day
  uint16_t product_day;
  uint8_t porduct_code[20];
  uint8_t serial_num[40];
  uint8_t rfhw_code[40];
  uint16_t rfhw_version;
  uint8_t dsphw_code[40];
  uint16_t dsphw_version;
  uint8_t calibrate_code[20];
  uint8_t os_version[20];
  uint8_t sw_version[20];
  uint8_t algo_version[20];
  uint8_t waveform_version[20];
  uint16_t a72_0_loading;
  uint16_t a72_1_loading;
  uint32_t a72_0_freq;
  uint32_t a72_1_freq;
  uint32_t mcu_0_freq;
  uint32_t mcu_1_freq;
  uint32_t mcu_2_freq;
  uint32_t mcu_3_freq;
  uint32_t lp_mcu_0_freq;
  uint32_t lp_mcu_1_freq;
  uint32_t c7x_mma_freq;
  uint32_t c66x_0_freq;
  uint32_t c66x_1_freq;
  uint32_t c7x_1_freq;
  uint16_t reboot_cnt;
  uint16_t memory_loading;
  uint32_t junction_temp;
  uint16_t low_power_mode_enable;
  uint16_t error_code;
  uint16_t blockage_detection;
  uint16_t radar_mode;
  uint16_t udpsend_enpnt;
  uint16_t udpsend_entrk;
  uint16_t udpsend_enrdmap;
  uint16_t udpsend_encfar;
  uint16_t udpsend_enadc;
  uint16_t udpsend_enfft1d;
  uint16_t udpsend_enfft2d;
  uint16_t udpsend_endoa;
  uint16_t radar_txfreq;
  uint16_t frame_triggerdelay;
  uint16_t sync_enable;
  uint16_t sync_radarnum;
  uint16_t antiinterface_enable;
} radar_msgs__msg__SystemStateNew;

// Struct for a sequence of radar_msgs__msg__SystemStateNew.
typedef struct radar_msgs__msg__SystemStateNew__Sequence
{
  radar_msgs__msg__SystemStateNew * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__SystemStateNew__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_NEW__STRUCT_H_
