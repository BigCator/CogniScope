// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/SystemStateTemp.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_TEMP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_TEMP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/system_state_temp__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_SystemStateTemp_max_temp
{
public:
  explicit Init_SystemStateTemp_max_temp(::radar_msgs::msg::SystemStateTemp & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::SystemStateTemp max_temp(::radar_msgs::msg::SystemStateTemp::_max_temp_type arg)
  {
    msg_.max_temp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::SystemStateTemp msg_;
};

class Init_SystemStateTemp_min_temp
{
public:
  Init_SystemStateTemp_min_temp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SystemStateTemp_max_temp min_temp(::radar_msgs::msg::SystemStateTemp::_min_temp_type arg)
  {
    msg_.min_temp = std::move(arg);
    return Init_SystemStateTemp_max_temp(msg_);
  }

private:
  ::radar_msgs::msg::SystemStateTemp msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::SystemStateTemp>()
{
  return radar_msgs::msg::builder::Init_SystemStateTemp_min_temp();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_TEMP__BUILDER_HPP_
