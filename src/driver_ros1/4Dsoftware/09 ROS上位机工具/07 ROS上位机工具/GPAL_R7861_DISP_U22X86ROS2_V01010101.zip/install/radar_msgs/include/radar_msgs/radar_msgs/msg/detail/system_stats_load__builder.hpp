// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/SystemStatsLoad.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATS_LOAD__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATS_LOAD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/system_stats_load__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_SystemStatsLoad_load_value
{
public:
  Init_SystemStatsLoad_load_value()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::radar_msgs::msg::SystemStatsLoad load_value(::radar_msgs::msg::SystemStatsLoad::_load_value_type arg)
  {
    msg_.load_value = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::SystemStatsLoad msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::SystemStatsLoad>()
{
  return radar_msgs::msg::builder::Init_SystemStatsLoad_load_value();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATS_LOAD__BUILDER_HPP_
