// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/AlarmStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/alarm_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_AlarmStatus_alarmcode20
{
public:
  explicit Init_AlarmStatus_alarmcode20(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::AlarmStatus alarmcode20(::radar_msgs::msg::AlarmStatus::_alarmcode20_type arg)
  {
    msg_.alarmcode20 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode19
{
public:
  explicit Init_AlarmStatus_alarmcode19(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode20 alarmcode19(::radar_msgs::msg::AlarmStatus::_alarmcode19_type arg)
  {
    msg_.alarmcode19 = std::move(arg);
    return Init_AlarmStatus_alarmcode20(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode18
{
public:
  explicit Init_AlarmStatus_alarmcode18(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode19 alarmcode18(::radar_msgs::msg::AlarmStatus::_alarmcode18_type arg)
  {
    msg_.alarmcode18 = std::move(arg);
    return Init_AlarmStatus_alarmcode19(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode17
{
public:
  explicit Init_AlarmStatus_alarmcode17(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode18 alarmcode17(::radar_msgs::msg::AlarmStatus::_alarmcode17_type arg)
  {
    msg_.alarmcode17 = std::move(arg);
    return Init_AlarmStatus_alarmcode18(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode16
{
public:
  explicit Init_AlarmStatus_alarmcode16(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode17 alarmcode16(::radar_msgs::msg::AlarmStatus::_alarmcode16_type arg)
  {
    msg_.alarmcode16 = std::move(arg);
    return Init_AlarmStatus_alarmcode17(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode15
{
public:
  explicit Init_AlarmStatus_alarmcode15(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode16 alarmcode15(::radar_msgs::msg::AlarmStatus::_alarmcode15_type arg)
  {
    msg_.alarmcode15 = std::move(arg);
    return Init_AlarmStatus_alarmcode16(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode14
{
public:
  explicit Init_AlarmStatus_alarmcode14(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode15 alarmcode14(::radar_msgs::msg::AlarmStatus::_alarmcode14_type arg)
  {
    msg_.alarmcode14 = std::move(arg);
    return Init_AlarmStatus_alarmcode15(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode13
{
public:
  explicit Init_AlarmStatus_alarmcode13(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode14 alarmcode13(::radar_msgs::msg::AlarmStatus::_alarmcode13_type arg)
  {
    msg_.alarmcode13 = std::move(arg);
    return Init_AlarmStatus_alarmcode14(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode12
{
public:
  explicit Init_AlarmStatus_alarmcode12(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode13 alarmcode12(::radar_msgs::msg::AlarmStatus::_alarmcode12_type arg)
  {
    msg_.alarmcode12 = std::move(arg);
    return Init_AlarmStatus_alarmcode13(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode11
{
public:
  explicit Init_AlarmStatus_alarmcode11(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode12 alarmcode11(::radar_msgs::msg::AlarmStatus::_alarmcode11_type arg)
  {
    msg_.alarmcode11 = std::move(arg);
    return Init_AlarmStatus_alarmcode12(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode10
{
public:
  explicit Init_AlarmStatus_alarmcode10(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode11 alarmcode10(::radar_msgs::msg::AlarmStatus::_alarmcode10_type arg)
  {
    msg_.alarmcode10 = std::move(arg);
    return Init_AlarmStatus_alarmcode11(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode09
{
public:
  explicit Init_AlarmStatus_alarmcode09(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode10 alarmcode09(::radar_msgs::msg::AlarmStatus::_alarmcode09_type arg)
  {
    msg_.alarmcode09 = std::move(arg);
    return Init_AlarmStatus_alarmcode10(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode08
{
public:
  explicit Init_AlarmStatus_alarmcode08(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode09 alarmcode08(::radar_msgs::msg::AlarmStatus::_alarmcode08_type arg)
  {
    msg_.alarmcode08 = std::move(arg);
    return Init_AlarmStatus_alarmcode09(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode07
{
public:
  explicit Init_AlarmStatus_alarmcode07(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode08 alarmcode07(::radar_msgs::msg::AlarmStatus::_alarmcode07_type arg)
  {
    msg_.alarmcode07 = std::move(arg);
    return Init_AlarmStatus_alarmcode08(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode06
{
public:
  explicit Init_AlarmStatus_alarmcode06(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode07 alarmcode06(::radar_msgs::msg::AlarmStatus::_alarmcode06_type arg)
  {
    msg_.alarmcode06 = std::move(arg);
    return Init_AlarmStatus_alarmcode07(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode05
{
public:
  explicit Init_AlarmStatus_alarmcode05(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode06 alarmcode05(::radar_msgs::msg::AlarmStatus::_alarmcode05_type arg)
  {
    msg_.alarmcode05 = std::move(arg);
    return Init_AlarmStatus_alarmcode06(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode04
{
public:
  explicit Init_AlarmStatus_alarmcode04(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode05 alarmcode04(::radar_msgs::msg::AlarmStatus::_alarmcode04_type arg)
  {
    msg_.alarmcode04 = std::move(arg);
    return Init_AlarmStatus_alarmcode05(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode03
{
public:
  explicit Init_AlarmStatus_alarmcode03(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode04 alarmcode03(::radar_msgs::msg::AlarmStatus::_alarmcode03_type arg)
  {
    msg_.alarmcode03 = std::move(arg);
    return Init_AlarmStatus_alarmcode04(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode02
{
public:
  explicit Init_AlarmStatus_alarmcode02(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode03 alarmcode02(::radar_msgs::msg::AlarmStatus::_alarmcode02_type arg)
  {
    msg_.alarmcode02 = std::move(arg);
    return Init_AlarmStatus_alarmcode03(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmcode01
{
public:
  explicit Init_AlarmStatus_alarmcode01(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode02 alarmcode01(::radar_msgs::msg::AlarmStatus::_alarmcode01_type arg)
  {
    msg_.alarmcode01 = std::move(arg);
    return Init_AlarmStatus_alarmcode02(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_alarmnum
{
public:
  explicit Init_AlarmStatus_alarmnum(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmcode01 alarmnum(::radar_msgs::msg::AlarmStatus::_alarmnum_type arg)
  {
    msg_.alarmnum = std::move(arg);
    return Init_AlarmStatus_alarmcode01(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_framecnt
{
public:
  explicit Init_AlarmStatus_framecnt(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_alarmnum framecnt(::radar_msgs::msg::AlarmStatus::_framecnt_type arg)
  {
    msg_.framecnt = std::move(arg);
    return Init_AlarmStatus_alarmnum(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_radarid
{
public:
  explicit Init_AlarmStatus_radarid(::radar_msgs::msg::AlarmStatus & msg)
  : msg_(msg)
  {}
  Init_AlarmStatus_framecnt radarid(::radar_msgs::msg::AlarmStatus::_radarid_type arg)
  {
    msg_.radarid = std::move(arg);
    return Init_AlarmStatus_framecnt(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

class Init_AlarmStatus_header
{
public:
  Init_AlarmStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AlarmStatus_radarid header(::radar_msgs::msg::AlarmStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_AlarmStatus_radarid(msg_);
  }

private:
  ::radar_msgs::msg::AlarmStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::AlarmStatus>()
{
  return radar_msgs::msg::builder::Init_AlarmStatus_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__BUILDER_HPP_
