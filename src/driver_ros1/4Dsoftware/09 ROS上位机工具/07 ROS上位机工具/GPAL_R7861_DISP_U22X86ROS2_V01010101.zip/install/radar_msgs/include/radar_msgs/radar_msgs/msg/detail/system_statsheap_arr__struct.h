// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/SystemStatsheapArr.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATSHEAP_ARR__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATSHEAP_ARR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'heap'
#include "radar_msgs/msg/detail/system_statsheap__struct.h"

/// Struct defined in msg/SystemStatsheapArr in the package radar_msgs.
/**
  * Header header           # Includes measurement timestamp and coordinate frame.
 */
typedef struct radar_msgs__msg__SystemStatsheapArr
{
  radar_msgs__msg__SystemStatsheap heap[2];
} radar_msgs__msg__SystemStatsheapArr;

// Struct for a sequence of radar_msgs__msg__SystemStatsheapArr.
typedef struct radar_msgs__msg__SystemStatsheapArr__Sequence
{
  radar_msgs__msg__SystemStatsheapArr * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__SystemStatsheapArr__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATSHEAP_ARR__STRUCT_H_
