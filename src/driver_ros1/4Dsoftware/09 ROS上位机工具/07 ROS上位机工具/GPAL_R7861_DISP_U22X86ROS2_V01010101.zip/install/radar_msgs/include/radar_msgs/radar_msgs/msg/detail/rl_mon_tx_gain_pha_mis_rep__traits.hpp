// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/RlMonTxGainPhaMisRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/rl_mon_tx_gain_pha_mis_rep__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const RlMonTxGainPhaMisRep & msg,
  std::ostream & out)
{
  out << "{";
  // member: statusflags
  {
    out << "statusflags: ";
    rosidl_generator_traits::value_to_yaml(msg.statusflags, out);
    out << ", ";
  }

  // member: errorcode
  {
    out << "errorcode: ";
    rosidl_generator_traits::value_to_yaml(msg.errorcode, out);
    out << ", ";
  }

  // member: profindex
  {
    out << "profindex: ";
    rosidl_generator_traits::value_to_yaml(msg.profindex, out);
    out << ", ";
  }

  // member: noisepower00
  {
    out << "noisepower00: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower00, out);
    out << ", ";
  }

  // member: noisepower01
  {
    out << "noisepower01: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower01, out);
    out << ", ";
  }

  // member: noisepower02
  {
    out << "noisepower02: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower02, out);
    out << ", ";
  }

  // member: txgainval
  {
    if (msg.txgainval.size() == 0) {
      out << "txgainval: []";
    } else {
      out << "txgainval: [";
      size_t pending_items = msg.txgainval.size();
      for (auto item : msg.txgainval) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: txphaval
  {
    if (msg.txphaval.size() == 0) {
      out << "txphaval: []";
    } else {
      out << "txphaval: [";
      size_t pending_items = msg.txphaval.size();
      for (auto item : msg.txphaval) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: noisepower10
  {
    out << "noisepower10: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower10, out);
    out << ", ";
  }

  // member: noisepower11
  {
    out << "noisepower11: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower11, out);
    out << ", ";
  }

  // member: noisepower12
  {
    out << "noisepower12: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower12, out);
    out << ", ";
  }

  // member: noisepower20
  {
    out << "noisepower20: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower20, out);
    out << ", ";
  }

  // member: noisepower21
  {
    out << "noisepower21: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower21, out);
    out << ", ";
  }

  // member: noisepower22
  {
    out << "noisepower22: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower22, out);
    out << ", ";
  }

  // member: reserved0
  {
    out << "reserved0: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved0, out);
    out << ", ";
  }

  // member: reserved1
  {
    out << "reserved1: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved1, out);
    out << ", ";
  }

  // member: timestamp
  {
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RlMonTxGainPhaMisRep & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: statusflags
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "statusflags: ";
    rosidl_generator_traits::value_to_yaml(msg.statusflags, out);
    out << "\n";
  }

  // member: errorcode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "errorcode: ";
    rosidl_generator_traits::value_to_yaml(msg.errorcode, out);
    out << "\n";
  }

  // member: profindex
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "profindex: ";
    rosidl_generator_traits::value_to_yaml(msg.profindex, out);
    out << "\n";
  }

  // member: noisepower00
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "noisepower00: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower00, out);
    out << "\n";
  }

  // member: noisepower01
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "noisepower01: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower01, out);
    out << "\n";
  }

  // member: noisepower02
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "noisepower02: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower02, out);
    out << "\n";
  }

  // member: txgainval
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.txgainval.size() == 0) {
      out << "txgainval: []\n";
    } else {
      out << "txgainval:\n";
      for (auto item : msg.txgainval) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: txphaval
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.txphaval.size() == 0) {
      out << "txphaval: []\n";
    } else {
      out << "txphaval:\n";
      for (auto item : msg.txphaval) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: noisepower10
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "noisepower10: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower10, out);
    out << "\n";
  }

  // member: noisepower11
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "noisepower11: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower11, out);
    out << "\n";
  }

  // member: noisepower12
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "noisepower12: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower12, out);
    out << "\n";
  }

  // member: noisepower20
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "noisepower20: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower20, out);
    out << "\n";
  }

  // member: noisepower21
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "noisepower21: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower21, out);
    out << "\n";
  }

  // member: noisepower22
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "noisepower22: ";
    rosidl_generator_traits::value_to_yaml(msg.noisepower22, out);
    out << "\n";
  }

  // member: reserved0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved0: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved0, out);
    out << "\n";
  }

  // member: reserved1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved1: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved1, out);
    out << "\n";
  }

  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RlMonTxGainPhaMisRep & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::RlMonTxGainPhaMisRep & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::RlMonTxGainPhaMisRep>()
{
  return "radar_msgs::msg::RlMonTxGainPhaMisRep";
}

template<>
inline const char * name<radar_msgs::msg::RlMonTxGainPhaMisRep>()
{
  return "radar_msgs/msg/RlMonTxGainPhaMisRep";
}

template<>
struct has_fixed_size<radar_msgs::msg::RlMonTxGainPhaMisRep>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<radar_msgs::msg::RlMonTxGainPhaMisRep>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<radar_msgs::msg::RlMonTxGainPhaMisRep>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__TRAITS_HPP_
