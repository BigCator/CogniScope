// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/SystemInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__SystemInfo __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__SystemInfo __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SystemInfo_
{
  using Type = SystemInfo_<ContainerAllocator>;

  explicit SystemInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<uint8_t, 16>::iterator, uint8_t>(this->product_code.begin(), this->product_code.end(), 0);
      std::fill<typename std::array<uint8_t, 16>::iterator, uint8_t>(this->product_version.begin(), this->product_version.end(), 0);
      std::fill<typename std::array<uint8_t, 12>::iterator, uint8_t>(this->compile_date.begin(), this->compile_date.end(), 0);
      std::fill<typename std::array<uint8_t, 16>::iterator, uint8_t>(this->compile_time.begin(), this->compile_time.end(), 0);
      std::fill<typename std::array<uint8_t, 32>::iterator, uint8_t>(this->reserve.begin(), this->reserve.end(), 0);
    }
  }

  explicit SystemInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    product_code(_alloc),
    product_version(_alloc),
    compile_date(_alloc),
    compile_time(_alloc),
    reserve(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<uint8_t, 16>::iterator, uint8_t>(this->product_code.begin(), this->product_code.end(), 0);
      std::fill<typename std::array<uint8_t, 16>::iterator, uint8_t>(this->product_version.begin(), this->product_version.end(), 0);
      std::fill<typename std::array<uint8_t, 12>::iterator, uint8_t>(this->compile_date.begin(), this->compile_date.end(), 0);
      std::fill<typename std::array<uint8_t, 16>::iterator, uint8_t>(this->compile_time.begin(), this->compile_time.end(), 0);
      std::fill<typename std::array<uint8_t, 32>::iterator, uint8_t>(this->reserve.begin(), this->reserve.end(), 0);
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _product_code_type =
    std::array<uint8_t, 16>;
  _product_code_type product_code;
  using _product_version_type =
    std::array<uint8_t, 16>;
  _product_version_type product_version;
  using _compile_date_type =
    std::array<uint8_t, 12>;
  _compile_date_type compile_date;
  using _compile_time_type =
    std::array<uint8_t, 16>;
  _compile_time_type compile_time;
  using _reserve_type =
    std::array<uint8_t, 32>;
  _reserve_type reserve;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__product_code(
    const std::array<uint8_t, 16> & _arg)
  {
    this->product_code = _arg;
    return *this;
  }
  Type & set__product_version(
    const std::array<uint8_t, 16> & _arg)
  {
    this->product_version = _arg;
    return *this;
  }
  Type & set__compile_date(
    const std::array<uint8_t, 12> & _arg)
  {
    this->compile_date = _arg;
    return *this;
  }
  Type & set__compile_time(
    const std::array<uint8_t, 16> & _arg)
  {
    this->compile_time = _arg;
    return *this;
  }
  Type & set__reserve(
    const std::array<uint8_t, 32> & _arg)
  {
    this->reserve = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::SystemInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::SystemInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::SystemInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::SystemInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::SystemInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::SystemInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::SystemInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::SystemInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::SystemInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::SystemInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__SystemInfo
    std::shared_ptr<radar_msgs::msg::SystemInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__SystemInfo
    std::shared_ptr<radar_msgs::msg::SystemInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SystemInfo_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->product_code != other.product_code) {
      return false;
    }
    if (this->product_version != other.product_version) {
      return false;
    }
    if (this->compile_date != other.compile_date) {
      return false;
    }
    if (this->compile_time != other.compile_time) {
      return false;
    }
    if (this->reserve != other.reserve) {
      return false;
    }
    return true;
  }
  bool operator!=(const SystemInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SystemInfo_

// alias to use template instance with default allocator
using SystemInfo =
  radar_msgs::msg::SystemInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_HPP_
