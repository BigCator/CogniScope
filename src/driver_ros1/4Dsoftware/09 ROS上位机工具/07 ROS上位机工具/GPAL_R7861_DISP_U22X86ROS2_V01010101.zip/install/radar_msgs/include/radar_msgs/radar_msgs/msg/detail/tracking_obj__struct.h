﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/TrackingObj.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__TRACKING_OBJ__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__TRACKING_OBJ__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'object_id'
// Member 'age'
// Member 'measurement_status'
// Member 'motion_state'
// Member 'existance_confidence'
// Member 'position_x'
// Member 'position_y'
// Member 'position_z'
// Member 'velocity_x'
// Member 'velocity_y'
// Member 'velocity_z'
// Member 'acceleration_x'
// Member 'acceleration_y'
// Member 'acceleration_z'
// Member 'v2ground_x'
// Member 'v2ground_y'
// Member 'v2ground_z'
// Member 'orientation'
// Member 'type'
// Member 'car_confidence'
// Member 'bike_confidence'
// Member 'ped_confidence'
// Member 'truck_confidence'
// Member 'signboard_confidence'
// Member 'ground_confidence'
// Member 'obstacle_confidence'
// Member 'length'
// Member 'width'
// Member 'height'
// Member 'od_process_time'
// Member 'reserved_b'
// Member 'reserved_c'
// Member 'reserved_d'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/TrackingObj in the package radar_msgs.
typedef struct radar_msgs__msg__TrackingObj
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  /// radar ID
  uint32_t radar_id;
  /// frame cnt in radar
  uint32_t frame_cnt;
  /// object number of this frame
  uint32_t objnum;
  /// object ID
  rosidl_runtime_c__uint32__Sequence object_id;
  /// total frames from the object occurs
  rosidl_runtime_c__uint16__Sequence age;
  /// track status (0: measured; 1: new; 2: predicted)
  rosidl_runtime_c__uint8__Sequence measurement_status;
  /// movement state ( 0: static; 1: dynamic)
  rosidl_runtime_c__uint8__Sequence motion_state;
  /// existance confidence
  rosidl_runtime_c__uint8__Sequence existance_confidence;
  /// x value of central point
  rosidl_runtime_c__float__Sequence position_x;
  /// y value of central point
  rosidl_runtime_c__float__Sequence position_y;
  /// z value of central point
  rosidl_runtime_c__float__Sequence position_z;
  /// relative velocity of x orientation
  rosidl_runtime_c__float__Sequence velocity_x;
  /// relative velocity of y orientation
  rosidl_runtime_c__float__Sequence velocity_y;
  /// relative velocity of z orientation
  rosidl_runtime_c__float__Sequence velocity_z;
  /// relative acceleration of x orientation
  rosidl_runtime_c__float__Sequence acceleration_x;
  /// relative acceleration of y orientation
  rosidl_runtime_c__float__Sequence acceleration_y;
  /// relative acceleration of z orientation
  rosidl_runtime_c__float__Sequence acceleration_z;
  /// velocity towards ground of x orientation
  rosidl_runtime_c__float__Sequence v2ground_x;
  /// velocity towards ground of y orientation
  rosidl_runtime_c__float__Sequence v2ground_y;
  /// velocity towards ground of z orientation
  rosidl_runtime_c__float__Sequence v2ground_z;
  /// yaw rate
  rosidl_runtime_c__float__Sequence orientation;
  /// object type (（0: car 小型汽车; 1: bike 两轮车; 2: pedestrian 行人; 3: truck 大车; 4: signboard 高空物; 5: ground 地面; 6: obstacle 静态障碍物)
  rosidl_runtime_c__uint8__Sequence type;
  /// car confidence
  rosidl_runtime_c__uint8__Sequence car_confidence;
  /// bike confidence
  rosidl_runtime_c__uint8__Sequence bike_confidence;
  /// pedestrian confidence
  rosidl_runtime_c__uint8__Sequence ped_confidence;
  /// truck confidence
  rosidl_runtime_c__uint8__Sequence truck_confidence;
  /// signboard confidence
  rosidl_runtime_c__uint8__Sequence signboard_confidence;
  /// ground confidence
  rosidl_runtime_c__uint8__Sequence ground_confidence;
  /// obstacle confidence
  rosidl_runtime_c__uint8__Sequence obstacle_confidence;
  /// length
  rosidl_runtime_c__float__Sequence length;
  /// width
  rosidl_runtime_c__float__Sequence width;
  /// height
  rosidl_runtime_c__float__Sequence height;
  /// duration of od process (us)
  rosidl_runtime_c__float__Sequence od_process_time;
  /// Reserved_B
  rosidl_runtime_c__float__Sequence reserved_b;
  /// Reserved_C
  rosidl_runtime_c__float__Sequence reserved_c;
  /// Reserved_D
  rosidl_runtime_c__float__Sequence reserved_d;
} radar_msgs__msg__TrackingObj;

// Struct for a sequence of radar_msgs__msg__TrackingObj.
typedef struct radar_msgs__msg__TrackingObj__Sequence
{
  radar_msgs__msg__TrackingObj * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__TrackingObj__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__TRACKING_OBJ__STRUCT_H_
