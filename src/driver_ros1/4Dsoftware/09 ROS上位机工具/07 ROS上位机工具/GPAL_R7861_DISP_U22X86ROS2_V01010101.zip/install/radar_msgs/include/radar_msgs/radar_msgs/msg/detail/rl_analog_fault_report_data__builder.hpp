// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlAnalogFaultReportData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_ANALOG_FAULT_REPORT_DATA__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_ANALOG_FAULT_REPORT_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_analog_fault_report_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlAnalogFaultReportData_reserved2
{
public:
  explicit Init_RlAnalogFaultReportData_reserved2(::radar_msgs::msg::RlAnalogFaultReportData & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlAnalogFaultReportData reserved2(::radar_msgs::msg::RlAnalogFaultReportData::_reserved2_type arg)
  {
    msg_.reserved2 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlAnalogFaultReportData msg_;
};

class Init_RlAnalogFaultReportData_faultsig
{
public:
  explicit Init_RlAnalogFaultReportData_faultsig(::radar_msgs::msg::RlAnalogFaultReportData & msg)
  : msg_(msg)
  {}
  Init_RlAnalogFaultReportData_reserved2 faultsig(::radar_msgs::msg::RlAnalogFaultReportData::_faultsig_type arg)
  {
    msg_.faultsig = std::move(arg);
    return Init_RlAnalogFaultReportData_reserved2(msg_);
  }

private:
  ::radar_msgs::msg::RlAnalogFaultReportData msg_;
};

class Init_RlAnalogFaultReportData_reserved1
{
public:
  explicit Init_RlAnalogFaultReportData_reserved1(::radar_msgs::msg::RlAnalogFaultReportData & msg)
  : msg_(msg)
  {}
  Init_RlAnalogFaultReportData_faultsig reserved1(::radar_msgs::msg::RlAnalogFaultReportData::_reserved1_type arg)
  {
    msg_.reserved1 = std::move(arg);
    return Init_RlAnalogFaultReportData_faultsig(msg_);
  }

private:
  ::radar_msgs::msg::RlAnalogFaultReportData msg_;
};

class Init_RlAnalogFaultReportData_reserved0
{
public:
  explicit Init_RlAnalogFaultReportData_reserved0(::radar_msgs::msg::RlAnalogFaultReportData & msg)
  : msg_(msg)
  {}
  Init_RlAnalogFaultReportData_reserved1 reserved0(::radar_msgs::msg::RlAnalogFaultReportData::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlAnalogFaultReportData_reserved1(msg_);
  }

private:
  ::radar_msgs::msg::RlAnalogFaultReportData msg_;
};

class Init_RlAnalogFaultReportData_faulttype
{
public:
  Init_RlAnalogFaultReportData_faulttype()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlAnalogFaultReportData_reserved0 faulttype(::radar_msgs::msg::RlAnalogFaultReportData::_faulttype_type arg)
  {
    msg_.faulttype = std::move(arg);
    return Init_RlAnalogFaultReportData_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlAnalogFaultReportData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlAnalogFaultReportData>()
{
  return radar_msgs::msg::builder::Init_RlAnalogFaultReportData_faulttype();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_ANALOG_FAULT_REPORT_DATA__BUILDER_HPP_
