// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/RlMonTxIntAnaSigRep.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/rl_mon_tx_int_ana_sig_rep__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
radar_msgs__msg__RlMonTxIntAnaSigRep__init(radar_msgs__msg__RlMonTxIntAnaSigRep * msg)
{
  if (!msg) {
    return false;
  }
  // statusflags
  // errorcode
  // profindex
  // reserved0
  // phshiftdacideltamin
  // phshiftdacqdeltamin
  // timestamp
  return true;
}

void
radar_msgs__msg__RlMonTxIntAnaSigRep__fini(radar_msgs__msg__RlMonTxIntAnaSigRep * msg)
{
  if (!msg) {
    return;
  }
  // statusflags
  // errorcode
  // profindex
  // reserved0
  // phshiftdacideltamin
  // phshiftdacqdeltamin
  // timestamp
}

bool
radar_msgs__msg__RlMonTxIntAnaSigRep__are_equal(const radar_msgs__msg__RlMonTxIntAnaSigRep * lhs, const radar_msgs__msg__RlMonTxIntAnaSigRep * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // statusflags
  if (lhs->statusflags != rhs->statusflags) {
    return false;
  }
  // errorcode
  if (lhs->errorcode != rhs->errorcode) {
    return false;
  }
  // profindex
  if (lhs->profindex != rhs->profindex) {
    return false;
  }
  // reserved0
  if (lhs->reserved0 != rhs->reserved0) {
    return false;
  }
  // phshiftdacideltamin
  if (lhs->phshiftdacideltamin != rhs->phshiftdacideltamin) {
    return false;
  }
  // phshiftdacqdeltamin
  if (lhs->phshiftdacqdeltamin != rhs->phshiftdacqdeltamin) {
    return false;
  }
  // timestamp
  if (lhs->timestamp != rhs->timestamp) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__RlMonTxIntAnaSigRep__copy(
  const radar_msgs__msg__RlMonTxIntAnaSigRep * input,
  radar_msgs__msg__RlMonTxIntAnaSigRep * output)
{
  if (!input || !output) {
    return false;
  }
  // statusflags
  output->statusflags = input->statusflags;
  // errorcode
  output->errorcode = input->errorcode;
  // profindex
  output->profindex = input->profindex;
  // reserved0
  output->reserved0 = input->reserved0;
  // phshiftdacideltamin
  output->phshiftdacideltamin = input->phshiftdacideltamin;
  // phshiftdacqdeltamin
  output->phshiftdacqdeltamin = input->phshiftdacqdeltamin;
  // timestamp
  output->timestamp = input->timestamp;
  return true;
}

radar_msgs__msg__RlMonTxIntAnaSigRep *
radar_msgs__msg__RlMonTxIntAnaSigRep__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RlMonTxIntAnaSigRep * msg = (radar_msgs__msg__RlMonTxIntAnaSigRep *)allocator.allocate(sizeof(radar_msgs__msg__RlMonTxIntAnaSigRep), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__RlMonTxIntAnaSigRep));
  bool success = radar_msgs__msg__RlMonTxIntAnaSigRep__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__RlMonTxIntAnaSigRep__destroy(radar_msgs__msg__RlMonTxIntAnaSigRep * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__RlMonTxIntAnaSigRep__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence__init(radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RlMonTxIntAnaSigRep * data = NULL;

  if (size) {
    data = (radar_msgs__msg__RlMonTxIntAnaSigRep *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__RlMonTxIntAnaSigRep), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__RlMonTxIntAnaSigRep__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__RlMonTxIntAnaSigRep__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence__fini(radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__RlMonTxIntAnaSigRep__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence *
radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence * array = (radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence__destroy(radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence__are_equal(const radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence * lhs, const radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__RlMonTxIntAnaSigRep__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence__copy(
  const radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence * input,
  radar_msgs__msg__RlMonTxIntAnaSigRep__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__RlMonTxIntAnaSigRep);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__RlMonTxIntAnaSigRep * data =
      (radar_msgs__msg__RlMonTxIntAnaSigRep *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__RlMonTxIntAnaSigRep__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__RlMonTxIntAnaSigRep__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__RlMonTxIntAnaSigRep__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
