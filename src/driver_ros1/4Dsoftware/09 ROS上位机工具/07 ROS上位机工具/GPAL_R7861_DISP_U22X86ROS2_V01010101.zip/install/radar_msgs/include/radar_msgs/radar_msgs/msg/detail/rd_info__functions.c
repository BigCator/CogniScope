// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/RdInfo.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/rd_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
radar_msgs__msg__RdInfo__init(radar_msgs__msg__RdInfo * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__RdInfo__fini(msg);
    return false;
  }
  // frameid
  // cfarcount
  // targetnum
  // resetcnt
  // objnum
  // carspeed
  // caryawrate
  // gearstate
  // odtimeoutcnt
  // comprotv_i
  // comprotv_ii
  // framelostcnt
  // beforeadcerrcnt
  // afteradcerrcnt
  // udpframelostcnt
  // udpfreq
  // timesyncstatus
  // velestimate
  // gndk
  // gndb
  // pcl_time
  // od_time
  // rdframelostcnt
  // jamstatusprofile0
  // jamstatusprofile1
  // latency
  return true;
}

void
radar_msgs__msg__RdInfo__fini(radar_msgs__msg__RdInfo * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // frameid
  // cfarcount
  // targetnum
  // resetcnt
  // objnum
  // carspeed
  // caryawrate
  // gearstate
  // odtimeoutcnt
  // comprotv_i
  // comprotv_ii
  // framelostcnt
  // beforeadcerrcnt
  // afteradcerrcnt
  // udpframelostcnt
  // udpfreq
  // timesyncstatus
  // velestimate
  // gndk
  // gndb
  // pcl_time
  // od_time
  // rdframelostcnt
  // jamstatusprofile0
  // jamstatusprofile1
  // latency
}

bool
radar_msgs__msg__RdInfo__are_equal(const radar_msgs__msg__RdInfo * lhs, const radar_msgs__msg__RdInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // frameid
  if (lhs->frameid != rhs->frameid) {
    return false;
  }
  // cfarcount
  if (lhs->cfarcount != rhs->cfarcount) {
    return false;
  }
  // targetnum
  if (lhs->targetnum != rhs->targetnum) {
    return false;
  }
  // resetcnt
  if (lhs->resetcnt != rhs->resetcnt) {
    return false;
  }
  // objnum
  if (lhs->objnum != rhs->objnum) {
    return false;
  }
  // carspeed
  if (lhs->carspeed != rhs->carspeed) {
    return false;
  }
  // caryawrate
  if (lhs->caryawrate != rhs->caryawrate) {
    return false;
  }
  // gearstate
  if (lhs->gearstate != rhs->gearstate) {
    return false;
  }
  // odtimeoutcnt
  if (lhs->odtimeoutcnt != rhs->odtimeoutcnt) {
    return false;
  }
  // comprotv_i
  if (lhs->comprotv_i != rhs->comprotv_i) {
    return false;
  }
  // comprotv_ii
  if (lhs->comprotv_ii != rhs->comprotv_ii) {
    return false;
  }
  // framelostcnt
  if (lhs->framelostcnt != rhs->framelostcnt) {
    return false;
  }
  // beforeadcerrcnt
  if (lhs->beforeadcerrcnt != rhs->beforeadcerrcnt) {
    return false;
  }
  // afteradcerrcnt
  if (lhs->afteradcerrcnt != rhs->afteradcerrcnt) {
    return false;
  }
  // udpframelostcnt
  if (lhs->udpframelostcnt != rhs->udpframelostcnt) {
    return false;
  }
  // udpfreq
  if (lhs->udpfreq != rhs->udpfreq) {
    return false;
  }
  // timesyncstatus
  if (lhs->timesyncstatus != rhs->timesyncstatus) {
    return false;
  }
  // velestimate
  if (lhs->velestimate != rhs->velestimate) {
    return false;
  }
  // gndk
  if (lhs->gndk != rhs->gndk) {
    return false;
  }
  // gndb
  if (lhs->gndb != rhs->gndb) {
    return false;
  }
  // pcl_time
  if (lhs->pcl_time != rhs->pcl_time) {
    return false;
  }
  // od_time
  if (lhs->od_time != rhs->od_time) {
    return false;
  }
  // rdframelostcnt
  if (lhs->rdframelostcnt != rhs->rdframelostcnt) {
    return false;
  }
  // jamstatusprofile0
  if (lhs->jamstatusprofile0 != rhs->jamstatusprofile0) {
    return false;
  }
  // jamstatusprofile1
  if (lhs->jamstatusprofile1 != rhs->jamstatusprofile1) {
    return false;
  }
  // latency
  if (lhs->latency != rhs->latency) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__RdInfo__copy(
  const radar_msgs__msg__RdInfo * input,
  radar_msgs__msg__RdInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // frameid
  output->frameid = input->frameid;
  // cfarcount
  output->cfarcount = input->cfarcount;
  // targetnum
  output->targetnum = input->targetnum;
  // resetcnt
  output->resetcnt = input->resetcnt;
  // objnum
  output->objnum = input->objnum;
  // carspeed
  output->carspeed = input->carspeed;
  // caryawrate
  output->caryawrate = input->caryawrate;
  // gearstate
  output->gearstate = input->gearstate;
  // odtimeoutcnt
  output->odtimeoutcnt = input->odtimeoutcnt;
  // comprotv_i
  output->comprotv_i = input->comprotv_i;
  // comprotv_ii
  output->comprotv_ii = input->comprotv_ii;
  // framelostcnt
  output->framelostcnt = input->framelostcnt;
  // beforeadcerrcnt
  output->beforeadcerrcnt = input->beforeadcerrcnt;
  // afteradcerrcnt
  output->afteradcerrcnt = input->afteradcerrcnt;
  // udpframelostcnt
  output->udpframelostcnt = input->udpframelostcnt;
  // udpfreq
  output->udpfreq = input->udpfreq;
  // timesyncstatus
  output->timesyncstatus = input->timesyncstatus;
  // velestimate
  output->velestimate = input->velestimate;
  // gndk
  output->gndk = input->gndk;
  // gndb
  output->gndb = input->gndb;
  // pcl_time
  output->pcl_time = input->pcl_time;
  // od_time
  output->od_time = input->od_time;
  // rdframelostcnt
  output->rdframelostcnt = input->rdframelostcnt;
  // jamstatusprofile0
  output->jamstatusprofile0 = input->jamstatusprofile0;
  // jamstatusprofile1
  output->jamstatusprofile1 = input->jamstatusprofile1;
  // latency
  output->latency = input->latency;
  return true;
}

radar_msgs__msg__RdInfo *
radar_msgs__msg__RdInfo__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RdInfo * msg = (radar_msgs__msg__RdInfo *)allocator.allocate(sizeof(radar_msgs__msg__RdInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__RdInfo));
  bool success = radar_msgs__msg__RdInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__RdInfo__destroy(radar_msgs__msg__RdInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__RdInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__RdInfo__Sequence__init(radar_msgs__msg__RdInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RdInfo * data = NULL;

  if (size) {
    data = (radar_msgs__msg__RdInfo *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__RdInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__RdInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__RdInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__RdInfo__Sequence__fini(radar_msgs__msg__RdInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__RdInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__RdInfo__Sequence *
radar_msgs__msg__RdInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RdInfo__Sequence * array = (radar_msgs__msg__RdInfo__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__RdInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__RdInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__RdInfo__Sequence__destroy(radar_msgs__msg__RdInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__RdInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__RdInfo__Sequence__are_equal(const radar_msgs__msg__RdInfo__Sequence * lhs, const radar_msgs__msg__RdInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__RdInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__RdInfo__Sequence__copy(
  const radar_msgs__msg__RdInfo__Sequence * input,
  radar_msgs__msg__RdInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__RdInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__RdInfo * data =
      (radar_msgs__msg__RdInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__RdInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__RdInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__RdInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
