// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/UdpPacket.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/udp_packet__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
radar_msgs__msg__UdpPacket__init(radar_msgs__msg__UdpPacket * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__UdpPacket__fini(msg);
    return false;
  }
  // data
  // datalen
  return true;
}

void
radar_msgs__msg__UdpPacket__fini(radar_msgs__msg__UdpPacket * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // data
  // datalen
}

bool
radar_msgs__msg__UdpPacket__are_equal(const radar_msgs__msg__UdpPacket * lhs, const radar_msgs__msg__UdpPacket * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // data
  for (size_t i = 0; i < 1600; ++i) {
    if (lhs->data[i] != rhs->data[i]) {
      return false;
    }
  }
  // datalen
  if (lhs->datalen != rhs->datalen) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__UdpPacket__copy(
  const radar_msgs__msg__UdpPacket * input,
  radar_msgs__msg__UdpPacket * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // data
  for (size_t i = 0; i < 1600; ++i) {
    output->data[i] = input->data[i];
  }
  // datalen
  output->datalen = input->datalen;
  return true;
}

radar_msgs__msg__UdpPacket *
radar_msgs__msg__UdpPacket__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__UdpPacket * msg = (radar_msgs__msg__UdpPacket *)allocator.allocate(sizeof(radar_msgs__msg__UdpPacket), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__UdpPacket));
  bool success = radar_msgs__msg__UdpPacket__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__UdpPacket__destroy(radar_msgs__msg__UdpPacket * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__UdpPacket__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__UdpPacket__Sequence__init(radar_msgs__msg__UdpPacket__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__UdpPacket * data = NULL;

  if (size) {
    data = (radar_msgs__msg__UdpPacket *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__UdpPacket), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__UdpPacket__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__UdpPacket__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__UdpPacket__Sequence__fini(radar_msgs__msg__UdpPacket__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__UdpPacket__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__UdpPacket__Sequence *
radar_msgs__msg__UdpPacket__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__UdpPacket__Sequence * array = (radar_msgs__msg__UdpPacket__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__UdpPacket__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__UdpPacket__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__UdpPacket__Sequence__destroy(radar_msgs__msg__UdpPacket__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__UdpPacket__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__UdpPacket__Sequence__are_equal(const radar_msgs__msg__UdpPacket__Sequence * lhs, const radar_msgs__msg__UdpPacket__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__UdpPacket__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__UdpPacket__Sequence__copy(
  const radar_msgs__msg__UdpPacket__Sequence * input,
  radar_msgs__msg__UdpPacket__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__UdpPacket);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__UdpPacket * data =
      (radar_msgs__msg__UdpPacket *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__UdpPacket__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__UdpPacket__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__UdpPacket__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
