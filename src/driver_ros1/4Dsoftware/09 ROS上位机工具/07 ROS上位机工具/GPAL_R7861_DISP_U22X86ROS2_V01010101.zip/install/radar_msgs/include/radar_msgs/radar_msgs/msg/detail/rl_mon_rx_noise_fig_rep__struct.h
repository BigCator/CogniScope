// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/RlMonRxNoiseFigRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_RX_NOISE_FIG_REP__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_RX_NOISE_FIG_REP__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/RlMonRxNoiseFigRep in the package radar_msgs.
typedef struct radar_msgs__msg__RlMonRxNoiseFigRep
{
  uint16_t statusflags;
  uint16_t errorcode;
  uint8_t profindex;
  uint8_t reserved0;
  uint16_t reserved1;
  uint16_t rxnoisefigval[12];
  uint32_t reserved2;
  uint32_t reserved3;
  uint32_t reserved4;
  uint32_t timestamp;
} radar_msgs__msg__RlMonRxNoiseFigRep;

// Struct for a sequence of radar_msgs__msg__RlMonRxNoiseFigRep.
typedef struct radar_msgs__msg__RlMonRxNoiseFigRep__Sequence
{
  radar_msgs__msg__RlMonRxNoiseFigRep * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__RlMonRxNoiseFigRep__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_RX_NOISE_FIG_REP__STRUCT_H_
