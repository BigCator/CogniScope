// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonTxGainPhaMisRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_tx_gain_pha_mis_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonTxGainPhaMisRep_timestamp
{
public:
  explicit Init_RlMonTxGainPhaMisRep_timestamp(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonTxGainPhaMisRep timestamp(::radar_msgs::msg::RlMonTxGainPhaMisRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_reserved1
{
public:
  explicit Init_RlMonTxGainPhaMisRep_reserved1(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_timestamp reserved1(::radar_msgs::msg::RlMonTxGainPhaMisRep::_reserved1_type arg)
  {
    msg_.reserved1 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_reserved0
{
public:
  explicit Init_RlMonTxGainPhaMisRep_reserved0(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_reserved1 reserved0(::radar_msgs::msg::RlMonTxGainPhaMisRep::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_reserved1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_noisepower22
{
public:
  explicit Init_RlMonTxGainPhaMisRep_noisepower22(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_reserved0 noisepower22(::radar_msgs::msg::RlMonTxGainPhaMisRep::_noisepower22_type arg)
  {
    msg_.noisepower22 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_noisepower21
{
public:
  explicit Init_RlMonTxGainPhaMisRep_noisepower21(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_noisepower22 noisepower21(::radar_msgs::msg::RlMonTxGainPhaMisRep::_noisepower21_type arg)
  {
    msg_.noisepower21 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_noisepower22(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_noisepower20
{
public:
  explicit Init_RlMonTxGainPhaMisRep_noisepower20(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_noisepower21 noisepower20(::radar_msgs::msg::RlMonTxGainPhaMisRep::_noisepower20_type arg)
  {
    msg_.noisepower20 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_noisepower21(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_noisepower12
{
public:
  explicit Init_RlMonTxGainPhaMisRep_noisepower12(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_noisepower20 noisepower12(::radar_msgs::msg::RlMonTxGainPhaMisRep::_noisepower12_type arg)
  {
    msg_.noisepower12 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_noisepower20(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_noisepower11
{
public:
  explicit Init_RlMonTxGainPhaMisRep_noisepower11(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_noisepower12 noisepower11(::radar_msgs::msg::RlMonTxGainPhaMisRep::_noisepower11_type arg)
  {
    msg_.noisepower11 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_noisepower12(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_noisepower10
{
public:
  explicit Init_RlMonTxGainPhaMisRep_noisepower10(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_noisepower11 noisepower10(::radar_msgs::msg::RlMonTxGainPhaMisRep::_noisepower10_type arg)
  {
    msg_.noisepower10 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_noisepower11(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_txphaval
{
public:
  explicit Init_RlMonTxGainPhaMisRep_txphaval(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_noisepower10 txphaval(::radar_msgs::msg::RlMonTxGainPhaMisRep::_txphaval_type arg)
  {
    msg_.txphaval = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_noisepower10(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_txgainval
{
public:
  explicit Init_RlMonTxGainPhaMisRep_txgainval(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_txphaval txgainval(::radar_msgs::msg::RlMonTxGainPhaMisRep::_txgainval_type arg)
  {
    msg_.txgainval = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_txphaval(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_noisepower02
{
public:
  explicit Init_RlMonTxGainPhaMisRep_noisepower02(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_txgainval noisepower02(::radar_msgs::msg::RlMonTxGainPhaMisRep::_noisepower02_type arg)
  {
    msg_.noisepower02 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_txgainval(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_noisepower01
{
public:
  explicit Init_RlMonTxGainPhaMisRep_noisepower01(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_noisepower02 noisepower01(::radar_msgs::msg::RlMonTxGainPhaMisRep::_noisepower01_type arg)
  {
    msg_.noisepower01 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_noisepower02(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_noisepower00
{
public:
  explicit Init_RlMonTxGainPhaMisRep_noisepower00(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_noisepower01 noisepower00(::radar_msgs::msg::RlMonTxGainPhaMisRep::_noisepower00_type arg)
  {
    msg_.noisepower00 = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_noisepower01(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_profindex
{
public:
  explicit Init_RlMonTxGainPhaMisRep_profindex(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_noisepower00 profindex(::radar_msgs::msg::RlMonTxGainPhaMisRep::_profindex_type arg)
  {
    msg_.profindex = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_noisepower00(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_errorcode
{
public:
  explicit Init_RlMonTxGainPhaMisRep_errorcode(::radar_msgs::msg::RlMonTxGainPhaMisRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxGainPhaMisRep_profindex errorcode(::radar_msgs::msg::RlMonTxGainPhaMisRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_profindex(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

class Init_RlMonTxGainPhaMisRep_statusflags
{
public:
  Init_RlMonTxGainPhaMisRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonTxGainPhaMisRep_errorcode statusflags(::radar_msgs::msg::RlMonTxGainPhaMisRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonTxGainPhaMisRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxGainPhaMisRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonTxGainPhaMisRep>()
{
  return radar_msgs::msg::builder::Init_RlMonTxGainPhaMisRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__BUILDER_HPP_
