// generated from rosidl_generator_c/resource/idl.h.em
// with input from radar_msgs:msg/InstallInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__INSTALL_INFO_H_
#define RADAR_MSGS__MSG__INSTALL_INFO_H_

#include "radar_msgs/msg/detail/install_info__struct.h"
#include "radar_msgs/msg/detail/install_info__functions.h"
#include "radar_msgs/msg/detail/install_info__type_support.h"

#endif  // RADAR_MSGS__MSG__INSTALL_INFO_H_
