// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/SystemStateTemp.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/system_state_temp__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
radar_msgs__msg__SystemStateTemp__init(radar_msgs__msg__SystemStateTemp * msg)
{
  if (!msg) {
    return false;
  }
  // min_temp
  // max_temp
  return true;
}

void
radar_msgs__msg__SystemStateTemp__fini(radar_msgs__msg__SystemStateTemp * msg)
{
  if (!msg) {
    return;
  }
  // min_temp
  // max_temp
}

bool
radar_msgs__msg__SystemStateTemp__are_equal(const radar_msgs__msg__SystemStateTemp * lhs, const radar_msgs__msg__SystemStateTemp * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // min_temp
  if (lhs->min_temp != rhs->min_temp) {
    return false;
  }
  // max_temp
  if (lhs->max_temp != rhs->max_temp) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__SystemStateTemp__copy(
  const radar_msgs__msg__SystemStateTemp * input,
  radar_msgs__msg__SystemStateTemp * output)
{
  if (!input || !output) {
    return false;
  }
  // min_temp
  output->min_temp = input->min_temp;
  // max_temp
  output->max_temp = input->max_temp;
  return true;
}

radar_msgs__msg__SystemStateTemp *
radar_msgs__msg__SystemStateTemp__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemStateTemp * msg = (radar_msgs__msg__SystemStateTemp *)allocator.allocate(sizeof(radar_msgs__msg__SystemStateTemp), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__SystemStateTemp));
  bool success = radar_msgs__msg__SystemStateTemp__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__SystemStateTemp__destroy(radar_msgs__msg__SystemStateTemp * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__SystemStateTemp__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__SystemStateTemp__Sequence__init(radar_msgs__msg__SystemStateTemp__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemStateTemp * data = NULL;

  if (size) {
    data = (radar_msgs__msg__SystemStateTemp *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__SystemStateTemp), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__SystemStateTemp__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__SystemStateTemp__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__SystemStateTemp__Sequence__fini(radar_msgs__msg__SystemStateTemp__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__SystemStateTemp__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__SystemStateTemp__Sequence *
radar_msgs__msg__SystemStateTemp__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemStateTemp__Sequence * array = (radar_msgs__msg__SystemStateTemp__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__SystemStateTemp__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__SystemStateTemp__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__SystemStateTemp__Sequence__destroy(radar_msgs__msg__SystemStateTemp__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__SystemStateTemp__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__SystemStateTemp__Sequence__are_equal(const radar_msgs__msg__SystemStateTemp__Sequence * lhs, const radar_msgs__msg__SystemStateTemp__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__SystemStateTemp__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__SystemStateTemp__Sequence__copy(
  const radar_msgs__msg__SystemStateTemp__Sequence * input,
  radar_msgs__msg__SystemStateTemp__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__SystemStateTemp);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__SystemStateTemp * data =
      (radar_msgs__msg__SystemStateTemp *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__SystemStateTemp__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__SystemStateTemp__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__SystemStateTemp__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
