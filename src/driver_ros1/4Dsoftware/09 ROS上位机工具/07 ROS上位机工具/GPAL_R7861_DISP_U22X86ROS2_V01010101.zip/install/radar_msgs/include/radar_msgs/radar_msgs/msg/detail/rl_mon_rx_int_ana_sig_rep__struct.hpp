// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RlMonRxIntAnaSigRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_RX_INT_ANA_SIG_REP__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_RX_INT_ANA_SIG_REP__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RlMonRxIntAnaSigRep __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RlMonRxIntAnaSigRep __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RlMonRxIntAnaSigRep_
{
  using Type = RlMonRxIntAnaSigRep_<ContainerAllocator>;

  explicit RlMonRxIntAnaSigRep_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      this->profindex = 0;
      this->reserved0 = 0;
      this->reserved1 = 0;
      this->timestamp = 0ul;
    }
  }

  explicit RlMonRxIntAnaSigRep_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      this->profindex = 0;
      this->reserved0 = 0;
      this->reserved1 = 0;
      this->timestamp = 0ul;
    }
  }

  // field types and members
  using _statusflags_type =
    uint16_t;
  _statusflags_type statusflags;
  using _errorcode_type =
    uint16_t;
  _errorcode_type errorcode;
  using _profindex_type =
    uint8_t;
  _profindex_type profindex;
  using _reserved0_type =
    uint8_t;
  _reserved0_type reserved0;
  using _reserved1_type =
    uint16_t;
  _reserved1_type reserved1;
  using _timestamp_type =
    uint32_t;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__statusflags(
    const uint16_t & _arg)
  {
    this->statusflags = _arg;
    return *this;
  }
  Type & set__errorcode(
    const uint16_t & _arg)
  {
    this->errorcode = _arg;
    return *this;
  }
  Type & set__profindex(
    const uint8_t & _arg)
  {
    this->profindex = _arg;
    return *this;
  }
  Type & set__reserved0(
    const uint8_t & _arg)
  {
    this->reserved0 = _arg;
    return *this;
  }
  Type & set__reserved1(
    const uint16_t & _arg)
  {
    this->reserved1 = _arg;
    return *this;
  }
  Type & set__timestamp(
    const uint32_t & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RlMonRxIntAnaSigRep
    std::shared_ptr<radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RlMonRxIntAnaSigRep
    std::shared_ptr<radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RlMonRxIntAnaSigRep_ & other) const
  {
    if (this->statusflags != other.statusflags) {
      return false;
    }
    if (this->errorcode != other.errorcode) {
      return false;
    }
    if (this->profindex != other.profindex) {
      return false;
    }
    if (this->reserved0 != other.reserved0) {
      return false;
    }
    if (this->reserved1 != other.reserved1) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const RlMonRxIntAnaSigRep_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RlMonRxIntAnaSigRep_

// alias to use template instance with default allocator
using RlMonRxIntAnaSigRep =
  radar_msgs::msg::RlMonRxIntAnaSigRep_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_RX_INT_ANA_SIG_REP__STRUCT_HPP_
