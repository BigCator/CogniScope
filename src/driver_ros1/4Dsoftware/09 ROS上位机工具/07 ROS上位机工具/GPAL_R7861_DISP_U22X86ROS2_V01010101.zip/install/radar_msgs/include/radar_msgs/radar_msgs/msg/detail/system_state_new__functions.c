// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/SystemStateNew.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/system_state_new__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
radar_msgs__msg__SystemStateNew__init(radar_msgs__msg__SystemStateNew * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__SystemStateNew__fini(msg);
    return false;
  }
  // project_code_num
  // product_year
  // product_month
  // product_day
  // porduct_code
  // serial_num
  // rfhw_code
  // rfhw_version
  // dsphw_code
  // dsphw_version
  // calibrate_code
  // os_version
  // sw_version
  // algo_version
  // waveform_version
  // a72_0_loading
  // a72_1_loading
  // a72_0_freq
  // a72_1_freq
  // mcu_0_freq
  // mcu_1_freq
  // mcu_2_freq
  // mcu_3_freq
  // lp_mcu_0_freq
  // lp_mcu_1_freq
  // c7x_mma_freq
  // c66x_0_freq
  // c66x_1_freq
  // c7x_1_freq
  // reboot_cnt
  // memory_loading
  // junction_temp
  // low_power_mode_enable
  // error_code
  // blockage_detection
  // radar_mode
  // udpsend_enpnt
  // udpsend_entrk
  // udpsend_enrdmap
  // udpsend_encfar
  // udpsend_enadc
  // udpsend_enfft1d
  // udpsend_enfft2d
  // udpsend_endoa
  // radar_txfreq
  // frame_triggerdelay
  // sync_enable
  // sync_radarnum
  // antiinterface_enable
  return true;
}

void
radar_msgs__msg__SystemStateNew__fini(radar_msgs__msg__SystemStateNew * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // project_code_num
  // product_year
  // product_month
  // product_day
  // porduct_code
  // serial_num
  // rfhw_code
  // rfhw_version
  // dsphw_code
  // dsphw_version
  // calibrate_code
  // os_version
  // sw_version
  // algo_version
  // waveform_version
  // a72_0_loading
  // a72_1_loading
  // a72_0_freq
  // a72_1_freq
  // mcu_0_freq
  // mcu_1_freq
  // mcu_2_freq
  // mcu_3_freq
  // lp_mcu_0_freq
  // lp_mcu_1_freq
  // c7x_mma_freq
  // c66x_0_freq
  // c66x_1_freq
  // c7x_1_freq
  // reboot_cnt
  // memory_loading
  // junction_temp
  // low_power_mode_enable
  // error_code
  // blockage_detection
  // radar_mode
  // udpsend_enpnt
  // udpsend_entrk
  // udpsend_enrdmap
  // udpsend_encfar
  // udpsend_enadc
  // udpsend_enfft1d
  // udpsend_enfft2d
  // udpsend_endoa
  // radar_txfreq
  // frame_triggerdelay
  // sync_enable
  // sync_radarnum
  // antiinterface_enable
}

bool
radar_msgs__msg__SystemStateNew__are_equal(const radar_msgs__msg__SystemStateNew * lhs, const radar_msgs__msg__SystemStateNew * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // project_code_num
  for (size_t i = 0; i < 20; ++i) {
    if (lhs->project_code_num[i] != rhs->project_code_num[i]) {
      return false;
    }
  }
  // product_year
  if (lhs->product_year != rhs->product_year) {
    return false;
  }
  // product_month
  if (lhs->product_month != rhs->product_month) {
    return false;
  }
  // product_day
  if (lhs->product_day != rhs->product_day) {
    return false;
  }
  // porduct_code
  for (size_t i = 0; i < 20; ++i) {
    if (lhs->porduct_code[i] != rhs->porduct_code[i]) {
      return false;
    }
  }
  // serial_num
  for (size_t i = 0; i < 40; ++i) {
    if (lhs->serial_num[i] != rhs->serial_num[i]) {
      return false;
    }
  }
  // rfhw_code
  for (size_t i = 0; i < 40; ++i) {
    if (lhs->rfhw_code[i] != rhs->rfhw_code[i]) {
      return false;
    }
  }
  // rfhw_version
  if (lhs->rfhw_version != rhs->rfhw_version) {
    return false;
  }
  // dsphw_code
  for (size_t i = 0; i < 40; ++i) {
    if (lhs->dsphw_code[i] != rhs->dsphw_code[i]) {
      return false;
    }
  }
  // dsphw_version
  if (lhs->dsphw_version != rhs->dsphw_version) {
    return false;
  }
  // calibrate_code
  for (size_t i = 0; i < 20; ++i) {
    if (lhs->calibrate_code[i] != rhs->calibrate_code[i]) {
      return false;
    }
  }
  // os_version
  for (size_t i = 0; i < 20; ++i) {
    if (lhs->os_version[i] != rhs->os_version[i]) {
      return false;
    }
  }
  // sw_version
  for (size_t i = 0; i < 20; ++i) {
    if (lhs->sw_version[i] != rhs->sw_version[i]) {
      return false;
    }
  }
  // algo_version
  for (size_t i = 0; i < 20; ++i) {
    if (lhs->algo_version[i] != rhs->algo_version[i]) {
      return false;
    }
  }
  // waveform_version
  for (size_t i = 0; i < 20; ++i) {
    if (lhs->waveform_version[i] != rhs->waveform_version[i]) {
      return false;
    }
  }
  // a72_0_loading
  if (lhs->a72_0_loading != rhs->a72_0_loading) {
    return false;
  }
  // a72_1_loading
  if (lhs->a72_1_loading != rhs->a72_1_loading) {
    return false;
  }
  // a72_0_freq
  if (lhs->a72_0_freq != rhs->a72_0_freq) {
    return false;
  }
  // a72_1_freq
  if (lhs->a72_1_freq != rhs->a72_1_freq) {
    return false;
  }
  // mcu_0_freq
  if (lhs->mcu_0_freq != rhs->mcu_0_freq) {
    return false;
  }
  // mcu_1_freq
  if (lhs->mcu_1_freq != rhs->mcu_1_freq) {
    return false;
  }
  // mcu_2_freq
  if (lhs->mcu_2_freq != rhs->mcu_2_freq) {
    return false;
  }
  // mcu_3_freq
  if (lhs->mcu_3_freq != rhs->mcu_3_freq) {
    return false;
  }
  // lp_mcu_0_freq
  if (lhs->lp_mcu_0_freq != rhs->lp_mcu_0_freq) {
    return false;
  }
  // lp_mcu_1_freq
  if (lhs->lp_mcu_1_freq != rhs->lp_mcu_1_freq) {
    return false;
  }
  // c7x_mma_freq
  if (lhs->c7x_mma_freq != rhs->c7x_mma_freq) {
    return false;
  }
  // c66x_0_freq
  if (lhs->c66x_0_freq != rhs->c66x_0_freq) {
    return false;
  }
  // c66x_1_freq
  if (lhs->c66x_1_freq != rhs->c66x_1_freq) {
    return false;
  }
  // c7x_1_freq
  if (lhs->c7x_1_freq != rhs->c7x_1_freq) {
    return false;
  }
  // reboot_cnt
  if (lhs->reboot_cnt != rhs->reboot_cnt) {
    return false;
  }
  // memory_loading
  if (lhs->memory_loading != rhs->memory_loading) {
    return false;
  }
  // junction_temp
  if (lhs->junction_temp != rhs->junction_temp) {
    return false;
  }
  // low_power_mode_enable
  if (lhs->low_power_mode_enable != rhs->low_power_mode_enable) {
    return false;
  }
  // error_code
  if (lhs->error_code != rhs->error_code) {
    return false;
  }
  // blockage_detection
  if (lhs->blockage_detection != rhs->blockage_detection) {
    return false;
  }
  // radar_mode
  if (lhs->radar_mode != rhs->radar_mode) {
    return false;
  }
  // udpsend_enpnt
  if (lhs->udpsend_enpnt != rhs->udpsend_enpnt) {
    return false;
  }
  // udpsend_entrk
  if (lhs->udpsend_entrk != rhs->udpsend_entrk) {
    return false;
  }
  // udpsend_enrdmap
  if (lhs->udpsend_enrdmap != rhs->udpsend_enrdmap) {
    return false;
  }
  // udpsend_encfar
  if (lhs->udpsend_encfar != rhs->udpsend_encfar) {
    return false;
  }
  // udpsend_enadc
  if (lhs->udpsend_enadc != rhs->udpsend_enadc) {
    return false;
  }
  // udpsend_enfft1d
  if (lhs->udpsend_enfft1d != rhs->udpsend_enfft1d) {
    return false;
  }
  // udpsend_enfft2d
  if (lhs->udpsend_enfft2d != rhs->udpsend_enfft2d) {
    return false;
  }
  // udpsend_endoa
  if (lhs->udpsend_endoa != rhs->udpsend_endoa) {
    return false;
  }
  // radar_txfreq
  if (lhs->radar_txfreq != rhs->radar_txfreq) {
    return false;
  }
  // frame_triggerdelay
  if (lhs->frame_triggerdelay != rhs->frame_triggerdelay) {
    return false;
  }
  // sync_enable
  if (lhs->sync_enable != rhs->sync_enable) {
    return false;
  }
  // sync_radarnum
  if (lhs->sync_radarnum != rhs->sync_radarnum) {
    return false;
  }
  // antiinterface_enable
  if (lhs->antiinterface_enable != rhs->antiinterface_enable) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__SystemStateNew__copy(
  const radar_msgs__msg__SystemStateNew * input,
  radar_msgs__msg__SystemStateNew * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // project_code_num
  for (size_t i = 0; i < 20; ++i) {
    output->project_code_num[i] = input->project_code_num[i];
  }
  // product_year
  output->product_year = input->product_year;
  // product_month
  output->product_month = input->product_month;
  // product_day
  output->product_day = input->product_day;
  // porduct_code
  for (size_t i = 0; i < 20; ++i) {
    output->porduct_code[i] = input->porduct_code[i];
  }
  // serial_num
  for (size_t i = 0; i < 40; ++i) {
    output->serial_num[i] = input->serial_num[i];
  }
  // rfhw_code
  for (size_t i = 0; i < 40; ++i) {
    output->rfhw_code[i] = input->rfhw_code[i];
  }
  // rfhw_version
  output->rfhw_version = input->rfhw_version;
  // dsphw_code
  for (size_t i = 0; i < 40; ++i) {
    output->dsphw_code[i] = input->dsphw_code[i];
  }
  // dsphw_version
  output->dsphw_version = input->dsphw_version;
  // calibrate_code
  for (size_t i = 0; i < 20; ++i) {
    output->calibrate_code[i] = input->calibrate_code[i];
  }
  // os_version
  for (size_t i = 0; i < 20; ++i) {
    output->os_version[i] = input->os_version[i];
  }
  // sw_version
  for (size_t i = 0; i < 20; ++i) {
    output->sw_version[i] = input->sw_version[i];
  }
  // algo_version
  for (size_t i = 0; i < 20; ++i) {
    output->algo_version[i] = input->algo_version[i];
  }
  // waveform_version
  for (size_t i = 0; i < 20; ++i) {
    output->waveform_version[i] = input->waveform_version[i];
  }
  // a72_0_loading
  output->a72_0_loading = input->a72_0_loading;
  // a72_1_loading
  output->a72_1_loading = input->a72_1_loading;
  // a72_0_freq
  output->a72_0_freq = input->a72_0_freq;
  // a72_1_freq
  output->a72_1_freq = input->a72_1_freq;
  // mcu_0_freq
  output->mcu_0_freq = input->mcu_0_freq;
  // mcu_1_freq
  output->mcu_1_freq = input->mcu_1_freq;
  // mcu_2_freq
  output->mcu_2_freq = input->mcu_2_freq;
  // mcu_3_freq
  output->mcu_3_freq = input->mcu_3_freq;
  // lp_mcu_0_freq
  output->lp_mcu_0_freq = input->lp_mcu_0_freq;
  // lp_mcu_1_freq
  output->lp_mcu_1_freq = input->lp_mcu_1_freq;
  // c7x_mma_freq
  output->c7x_mma_freq = input->c7x_mma_freq;
  // c66x_0_freq
  output->c66x_0_freq = input->c66x_0_freq;
  // c66x_1_freq
  output->c66x_1_freq = input->c66x_1_freq;
  // c7x_1_freq
  output->c7x_1_freq = input->c7x_1_freq;
  // reboot_cnt
  output->reboot_cnt = input->reboot_cnt;
  // memory_loading
  output->memory_loading = input->memory_loading;
  // junction_temp
  output->junction_temp = input->junction_temp;
  // low_power_mode_enable
  output->low_power_mode_enable = input->low_power_mode_enable;
  // error_code
  output->error_code = input->error_code;
  // blockage_detection
  output->blockage_detection = input->blockage_detection;
  // radar_mode
  output->radar_mode = input->radar_mode;
  // udpsend_enpnt
  output->udpsend_enpnt = input->udpsend_enpnt;
  // udpsend_entrk
  output->udpsend_entrk = input->udpsend_entrk;
  // udpsend_enrdmap
  output->udpsend_enrdmap = input->udpsend_enrdmap;
  // udpsend_encfar
  output->udpsend_encfar = input->udpsend_encfar;
  // udpsend_enadc
  output->udpsend_enadc = input->udpsend_enadc;
  // udpsend_enfft1d
  output->udpsend_enfft1d = input->udpsend_enfft1d;
  // udpsend_enfft2d
  output->udpsend_enfft2d = input->udpsend_enfft2d;
  // udpsend_endoa
  output->udpsend_endoa = input->udpsend_endoa;
  // radar_txfreq
  output->radar_txfreq = input->radar_txfreq;
  // frame_triggerdelay
  output->frame_triggerdelay = input->frame_triggerdelay;
  // sync_enable
  output->sync_enable = input->sync_enable;
  // sync_radarnum
  output->sync_radarnum = input->sync_radarnum;
  // antiinterface_enable
  output->antiinterface_enable = input->antiinterface_enable;
  return true;
}

radar_msgs__msg__SystemStateNew *
radar_msgs__msg__SystemStateNew__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemStateNew * msg = (radar_msgs__msg__SystemStateNew *)allocator.allocate(sizeof(radar_msgs__msg__SystemStateNew), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__SystemStateNew));
  bool success = radar_msgs__msg__SystemStateNew__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__SystemStateNew__destroy(radar_msgs__msg__SystemStateNew * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__SystemStateNew__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__SystemStateNew__Sequence__init(radar_msgs__msg__SystemStateNew__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemStateNew * data = NULL;

  if (size) {
    data = (radar_msgs__msg__SystemStateNew *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__SystemStateNew), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__SystemStateNew__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__SystemStateNew__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__SystemStateNew__Sequence__fini(radar_msgs__msg__SystemStateNew__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__SystemStateNew__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__SystemStateNew__Sequence *
radar_msgs__msg__SystemStateNew__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemStateNew__Sequence * array = (radar_msgs__msg__SystemStateNew__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__SystemStateNew__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__SystemStateNew__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__SystemStateNew__Sequence__destroy(radar_msgs__msg__SystemStateNew__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__SystemStateNew__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__SystemStateNew__Sequence__are_equal(const radar_msgs__msg__SystemStateNew__Sequence * lhs, const radar_msgs__msg__SystemStateNew__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__SystemStateNew__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__SystemStateNew__Sequence__copy(
  const radar_msgs__msg__SystemStateNew__Sequence * input,
  radar_msgs__msg__SystemStateNew__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__SystemStateNew);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__SystemStateNew * data =
      (radar_msgs__msg__SystemStateNew *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__SystemStateNew__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__SystemStateNew__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__SystemStateNew__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
