// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/RlMonRxIntAnaSigRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_RX_INT_ANA_SIG_REP__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_RX_INT_ANA_SIG_REP__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/rl_mon_rx_int_ana_sig_rep__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const RlMonRxIntAnaSigRep & msg,
  std::ostream & out)
{
  out << "{";
  // member: statusflags
  {
    out << "statusflags: ";
    rosidl_generator_traits::value_to_yaml(msg.statusflags, out);
    out << ", ";
  }

  // member: errorcode
  {
    out << "errorcode: ";
    rosidl_generator_traits::value_to_yaml(msg.errorcode, out);
    out << ", ";
  }

  // member: profindex
  {
    out << "profindex: ";
    rosidl_generator_traits::value_to_yaml(msg.profindex, out);
    out << ", ";
  }

  // member: reserved0
  {
    out << "reserved0: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved0, out);
    out << ", ";
  }

  // member: reserved1
  {
    out << "reserved1: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved1, out);
    out << ", ";
  }

  // member: timestamp
  {
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RlMonRxIntAnaSigRep & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: statusflags
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "statusflags: ";
    rosidl_generator_traits::value_to_yaml(msg.statusflags, out);
    out << "\n";
  }

  // member: errorcode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "errorcode: ";
    rosidl_generator_traits::value_to_yaml(msg.errorcode, out);
    out << "\n";
  }

  // member: profindex
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "profindex: ";
    rosidl_generator_traits::value_to_yaml(msg.profindex, out);
    out << "\n";
  }

  // member: reserved0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved0: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved0, out);
    out << "\n";
  }

  // member: reserved1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved1: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved1, out);
    out << "\n";
  }

  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RlMonRxIntAnaSigRep & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::RlMonRxIntAnaSigRep & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::RlMonRxIntAnaSigRep & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::RlMonRxIntAnaSigRep>()
{
  return "radar_msgs::msg::RlMonRxIntAnaSigRep";
}

template<>
inline const char * name<radar_msgs::msg::RlMonRxIntAnaSigRep>()
{
  return "radar_msgs/msg/RlMonRxIntAnaSigRep";
}

template<>
struct has_fixed_size<radar_msgs::msg::RlMonRxIntAnaSigRep>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<radar_msgs::msg::RlMonRxIntAnaSigRep>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<radar_msgs::msg::RlMonRxIntAnaSigRep>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_RX_INT_ANA_SIG_REP__TRAITS_HPP_
