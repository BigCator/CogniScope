// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/SystemStateWoPtp.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_WO_PTP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_WO_PTP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/system_state_wo_ptp__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_SystemStateWoPtp_heap_arr
{
public:
  explicit Init_SystemStateWoPtp_heap_arr(::radar_msgs::msg::SystemStateWoPtp & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::SystemStateWoPtp heap_arr(::radar_msgs::msg::SystemStateWoPtp::_heap_arr_type arg)
  {
    msg_.heap_arr = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::SystemStateWoPtp msg_;
};

class Init_SystemStateWoPtp_primary_heap
{
public:
  explicit Init_SystemStateWoPtp_primary_heap(::radar_msgs::msg::SystemStateWoPtp & msg)
  : msg_(msg)
  {}
  Init_SystemStateWoPtp_heap_arr primary_heap(::radar_msgs::msg::SystemStateWoPtp::_primary_heap_type arg)
  {
    msg_.primary_heap = std::move(arg);
    return Init_SystemStateWoPtp_heap_arr(msg_);
  }

private:
  ::radar_msgs::msg::SystemStateWoPtp msg_;
};

class Init_SystemStateWoPtp_load
{
public:
  explicit Init_SystemStateWoPtp_load(::radar_msgs::msg::SystemStateWoPtp & msg)
  : msg_(msg)
  {}
  Init_SystemStateWoPtp_primary_heap load(::radar_msgs::msg::SystemStateWoPtp::_load_type arg)
  {
    msg_.load = std::move(arg);
    return Init_SystemStateWoPtp_primary_heap(msg_);
  }

private:
  ::radar_msgs::msg::SystemStateWoPtp msg_;
};

class Init_SystemStateWoPtp_freq
{
public:
  explicit Init_SystemStateWoPtp_freq(::radar_msgs::msg::SystemStateWoPtp & msg)
  : msg_(msg)
  {}
  Init_SystemStateWoPtp_load freq(::radar_msgs::msg::SystemStateWoPtp::_freq_type arg)
  {
    msg_.freq = std::move(arg);
    return Init_SystemStateWoPtp_load(msg_);
  }

private:
  ::radar_msgs::msg::SystemStateWoPtp msg_;
};

class Init_SystemStateWoPtp_voltage
{
public:
  explicit Init_SystemStateWoPtp_voltage(::radar_msgs::msg::SystemStateWoPtp & msg)
  : msg_(msg)
  {}
  Init_SystemStateWoPtp_freq voltage(::radar_msgs::msg::SystemStateWoPtp::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return Init_SystemStateWoPtp_freq(msg_);
  }

private:
  ::radar_msgs::msg::SystemStateWoPtp msg_;
};

class Init_SystemStateWoPtp_temp
{
public:
  explicit Init_SystemStateWoPtp_temp(::radar_msgs::msg::SystemStateWoPtp & msg)
  : msg_(msg)
  {}
  Init_SystemStateWoPtp_voltage temp(::radar_msgs::msg::SystemStateWoPtp::_temp_type arg)
  {
    msg_.temp = std::move(arg);
    return Init_SystemStateWoPtp_voltage(msg_);
  }

private:
  ::radar_msgs::msg::SystemStateWoPtp msg_;
};

class Init_SystemStateWoPtp_header
{
public:
  Init_SystemStateWoPtp_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SystemStateWoPtp_temp header(::radar_msgs::msg::SystemStateWoPtp::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SystemStateWoPtp_temp(msg_);
  }

private:
  ::radar_msgs::msg::SystemStateWoPtp msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::SystemStateWoPtp>()
{
  return radar_msgs::msg::builder::Init_SystemStateWoPtp_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_WO_PTP__BUILDER_HPP_
