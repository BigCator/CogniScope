// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/RadarFeature.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RADAR_FEATURE__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__RADAR_FEATURE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'd'
// Member 'v'
// Member 'azimuth'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/RadarFeature in the package radar_msgs.
typedef struct radar_msgs__msg__RadarFeature
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  /// targets Num
  uint32_t target_num;
  /// distance
  rosidl_runtime_c__float__Sequence d;
  /// target velocity
  rosidl_runtime_c__float__Sequence v;
  /// target azimuth
  rosidl_runtime_c__float__Sequence azimuth;
} radar_msgs__msg__RadarFeature;

// Struct for a sequence of radar_msgs__msg__RadarFeature.
typedef struct radar_msgs__msg__RadarFeature__Sequence
{
  radar_msgs__msg__RadarFeature * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__RadarFeature__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__RADAR_FEATURE__STRUCT_H_
