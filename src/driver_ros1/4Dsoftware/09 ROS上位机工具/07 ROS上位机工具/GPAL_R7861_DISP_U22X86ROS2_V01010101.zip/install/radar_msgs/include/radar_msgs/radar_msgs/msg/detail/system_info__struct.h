// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/SystemInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/SystemInfo in the package radar_msgs.
typedef struct radar_msgs__msg__SystemInfo
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  /// product_code
  uint8_t product_code[16];
  /// productVersion
  uint8_t product_version[16];
  /// compileDate
  uint8_t compile_date[12];
  /// compileTime
  uint8_t compile_time[16];
  /// reserve
  uint8_t reserve[32];
} radar_msgs__msg__SystemInfo;

// Struct for a sequence of radar_msgs__msg__SystemInfo.
typedef struct radar_msgs__msg__SystemInfo__Sequence
{
  radar_msgs__msg__SystemInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__SystemInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_H_
