// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/RlRecvdGpAdcData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_RECVD_GP_ADC_DATA__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__RL_RECVD_GP_ADC_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'sensor'
#include "radar_msgs/msg/detail/rl_gp_adc_data__struct.h"

/// Struct defined in msg/RlRecvdGpAdcData in the package radar_msgs.
typedef struct radar_msgs__msg__RlRecvdGpAdcData
{
  radar_msgs__msg__RlGpAdcData sensor[6];
  uint16_t reserved0[4];
  uint32_t reserved1[7];
} radar_msgs__msg__RlRecvdGpAdcData;

// Struct for a sequence of radar_msgs__msg__RlRecvdGpAdcData.
typedef struct radar_msgs__msg__RlRecvdGpAdcData__Sequence
{
  radar_msgs__msg__RlRecvdGpAdcData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__RlRecvdGpAdcData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__RL_RECVD_GP_ADC_DATA__STRUCT_H_
