// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonRxNoiseFigRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_RX_NOISE_FIG_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_RX_NOISE_FIG_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_rx_noise_fig_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonRxNoiseFigRep_timestamp
{
public:
  explicit Init_RlMonRxNoiseFigRep_timestamp(::radar_msgs::msg::RlMonRxNoiseFigRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonRxNoiseFigRep timestamp(::radar_msgs::msg::RlMonRxNoiseFigRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxNoiseFigRep msg_;
};

class Init_RlMonRxNoiseFigRep_reserved4
{
public:
  explicit Init_RlMonRxNoiseFigRep_reserved4(::radar_msgs::msg::RlMonRxNoiseFigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxNoiseFigRep_timestamp reserved4(::radar_msgs::msg::RlMonRxNoiseFigRep::_reserved4_type arg)
  {
    msg_.reserved4 = std::move(arg);
    return Init_RlMonRxNoiseFigRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxNoiseFigRep msg_;
};

class Init_RlMonRxNoiseFigRep_reserved3
{
public:
  explicit Init_RlMonRxNoiseFigRep_reserved3(::radar_msgs::msg::RlMonRxNoiseFigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxNoiseFigRep_reserved4 reserved3(::radar_msgs::msg::RlMonRxNoiseFigRep::_reserved3_type arg)
  {
    msg_.reserved3 = std::move(arg);
    return Init_RlMonRxNoiseFigRep_reserved4(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxNoiseFigRep msg_;
};

class Init_RlMonRxNoiseFigRep_reserved2
{
public:
  explicit Init_RlMonRxNoiseFigRep_reserved2(::radar_msgs::msg::RlMonRxNoiseFigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxNoiseFigRep_reserved3 reserved2(::radar_msgs::msg::RlMonRxNoiseFigRep::_reserved2_type arg)
  {
    msg_.reserved2 = std::move(arg);
    return Init_RlMonRxNoiseFigRep_reserved3(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxNoiseFigRep msg_;
};

class Init_RlMonRxNoiseFigRep_rxnoisefigval
{
public:
  explicit Init_RlMonRxNoiseFigRep_rxnoisefigval(::radar_msgs::msg::RlMonRxNoiseFigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxNoiseFigRep_reserved2 rxnoisefigval(::radar_msgs::msg::RlMonRxNoiseFigRep::_rxnoisefigval_type arg)
  {
    msg_.rxnoisefigval = std::move(arg);
    return Init_RlMonRxNoiseFigRep_reserved2(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxNoiseFigRep msg_;
};

class Init_RlMonRxNoiseFigRep_reserved1
{
public:
  explicit Init_RlMonRxNoiseFigRep_reserved1(::radar_msgs::msg::RlMonRxNoiseFigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxNoiseFigRep_rxnoisefigval reserved1(::radar_msgs::msg::RlMonRxNoiseFigRep::_reserved1_type arg)
  {
    msg_.reserved1 = std::move(arg);
    return Init_RlMonRxNoiseFigRep_rxnoisefigval(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxNoiseFigRep msg_;
};

class Init_RlMonRxNoiseFigRep_reserved0
{
public:
  explicit Init_RlMonRxNoiseFigRep_reserved0(::radar_msgs::msg::RlMonRxNoiseFigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxNoiseFigRep_reserved1 reserved0(::radar_msgs::msg::RlMonRxNoiseFigRep::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlMonRxNoiseFigRep_reserved1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxNoiseFigRep msg_;
};

class Init_RlMonRxNoiseFigRep_profindex
{
public:
  explicit Init_RlMonRxNoiseFigRep_profindex(::radar_msgs::msg::RlMonRxNoiseFigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxNoiseFigRep_reserved0 profindex(::radar_msgs::msg::RlMonRxNoiseFigRep::_profindex_type arg)
  {
    msg_.profindex = std::move(arg);
    return Init_RlMonRxNoiseFigRep_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxNoiseFigRep msg_;
};

class Init_RlMonRxNoiseFigRep_errorcode
{
public:
  explicit Init_RlMonRxNoiseFigRep_errorcode(::radar_msgs::msg::RlMonRxNoiseFigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxNoiseFigRep_profindex errorcode(::radar_msgs::msg::RlMonRxNoiseFigRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonRxNoiseFigRep_profindex(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxNoiseFigRep msg_;
};

class Init_RlMonRxNoiseFigRep_statusflags
{
public:
  Init_RlMonRxNoiseFigRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonRxNoiseFigRep_errorcode statusflags(::radar_msgs::msg::RlMonRxNoiseFigRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonRxNoiseFigRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxNoiseFigRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonRxNoiseFigRep>()
{
  return radar_msgs::msg::builder::Init_RlMonRxNoiseFigRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_RX_NOISE_FIG_REP__BUILDER_HPP_
