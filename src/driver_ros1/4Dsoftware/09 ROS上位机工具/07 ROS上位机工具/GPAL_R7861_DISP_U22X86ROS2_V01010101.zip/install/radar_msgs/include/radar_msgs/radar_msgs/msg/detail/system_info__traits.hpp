// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/SystemInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_INFO__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/system_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SystemInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: product_code
  {
    if (msg.product_code.size() == 0) {
      out << "product_code: []";
    } else {
      out << "product_code: [";
      size_t pending_items = msg.product_code.size();
      for (auto item : msg.product_code) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: product_version
  {
    if (msg.product_version.size() == 0) {
      out << "product_version: []";
    } else {
      out << "product_version: [";
      size_t pending_items = msg.product_version.size();
      for (auto item : msg.product_version) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: compile_date
  {
    if (msg.compile_date.size() == 0) {
      out << "compile_date: []";
    } else {
      out << "compile_date: [";
      size_t pending_items = msg.compile_date.size();
      for (auto item : msg.compile_date) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: compile_time
  {
    if (msg.compile_time.size() == 0) {
      out << "compile_time: []";
    } else {
      out << "compile_time: [";
      size_t pending_items = msg.compile_time.size();
      for (auto item : msg.compile_time) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserve
  {
    if (msg.reserve.size() == 0) {
      out << "reserve: []";
    } else {
      out << "reserve: [";
      size_t pending_items = msg.reserve.size();
      for (auto item : msg.reserve) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SystemInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: product_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.product_code.size() == 0) {
      out << "product_code: []\n";
    } else {
      out << "product_code:\n";
      for (auto item : msg.product_code) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: product_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.product_version.size() == 0) {
      out << "product_version: []\n";
    } else {
      out << "product_version:\n";
      for (auto item : msg.product_version) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: compile_date
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.compile_date.size() == 0) {
      out << "compile_date: []\n";
    } else {
      out << "compile_date:\n";
      for (auto item : msg.compile_date) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: compile_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.compile_time.size() == 0) {
      out << "compile_time: []\n";
    } else {
      out << "compile_time:\n";
      for (auto item : msg.compile_time) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserve
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserve.size() == 0) {
      out << "reserve: []\n";
    } else {
      out << "reserve:\n";
      for (auto item : msg.reserve) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SystemInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::SystemInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::SystemInfo & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::SystemInfo>()
{
  return "radar_msgs::msg::SystemInfo";
}

template<>
inline const char * name<radar_msgs::msg::SystemInfo>()
{
  return "radar_msgs/msg/SystemInfo";
}

template<>
struct has_fixed_size<radar_msgs::msg::SystemInfo>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<radar_msgs::msg::SystemInfo>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<radar_msgs::msg::SystemInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_INFO__TRAITS_HPP_
