// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlRecvdGpAdcData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_RECVD_GP_ADC_DATA__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_RECVD_GP_ADC_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_recvd_gp_adc_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlRecvdGpAdcData_reserved1
{
public:
  explicit Init_RlRecvdGpAdcData_reserved1(::radar_msgs::msg::RlRecvdGpAdcData & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlRecvdGpAdcData reserved1(::radar_msgs::msg::RlRecvdGpAdcData::_reserved1_type arg)
  {
    msg_.reserved1 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlRecvdGpAdcData msg_;
};

class Init_RlRecvdGpAdcData_reserved0
{
public:
  explicit Init_RlRecvdGpAdcData_reserved0(::radar_msgs::msg::RlRecvdGpAdcData & msg)
  : msg_(msg)
  {}
  Init_RlRecvdGpAdcData_reserved1 reserved0(::radar_msgs::msg::RlRecvdGpAdcData::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlRecvdGpAdcData_reserved1(msg_);
  }

private:
  ::radar_msgs::msg::RlRecvdGpAdcData msg_;
};

class Init_RlRecvdGpAdcData_sensor
{
public:
  Init_RlRecvdGpAdcData_sensor()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlRecvdGpAdcData_reserved0 sensor(::radar_msgs::msg::RlRecvdGpAdcData::_sensor_type arg)
  {
    msg_.sensor = std::move(arg);
    return Init_RlRecvdGpAdcData_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlRecvdGpAdcData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlRecvdGpAdcData>()
{
  return radar_msgs::msg::builder::Init_RlRecvdGpAdcData_sensor();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_RECVD_GP_ADC_DATA__BUILDER_HPP_
