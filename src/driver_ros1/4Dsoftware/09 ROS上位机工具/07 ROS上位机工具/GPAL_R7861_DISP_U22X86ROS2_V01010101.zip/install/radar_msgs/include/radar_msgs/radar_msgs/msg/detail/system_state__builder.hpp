// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/SystemState.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/system_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_SystemState_ptp_data
{
public:
  explicit Init_SystemState_ptp_data(::radar_msgs::msg::SystemState & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::SystemState ptp_data(::radar_msgs::msg::SystemState::_ptp_data_type arg)
  {
    msg_.ptp_data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::SystemState msg_;
};

class Init_SystemState_heap_arr
{
public:
  explicit Init_SystemState_heap_arr(::radar_msgs::msg::SystemState & msg)
  : msg_(msg)
  {}
  Init_SystemState_ptp_data heap_arr(::radar_msgs::msg::SystemState::_heap_arr_type arg)
  {
    msg_.heap_arr = std::move(arg);
    return Init_SystemState_ptp_data(msg_);
  }

private:
  ::radar_msgs::msg::SystemState msg_;
};

class Init_SystemState_primary_heap
{
public:
  explicit Init_SystemState_primary_heap(::radar_msgs::msg::SystemState & msg)
  : msg_(msg)
  {}
  Init_SystemState_heap_arr primary_heap(::radar_msgs::msg::SystemState::_primary_heap_type arg)
  {
    msg_.primary_heap = std::move(arg);
    return Init_SystemState_heap_arr(msg_);
  }

private:
  ::radar_msgs::msg::SystemState msg_;
};

class Init_SystemState_load
{
public:
  explicit Init_SystemState_load(::radar_msgs::msg::SystemState & msg)
  : msg_(msg)
  {}
  Init_SystemState_primary_heap load(::radar_msgs::msg::SystemState::_load_type arg)
  {
    msg_.load = std::move(arg);
    return Init_SystemState_primary_heap(msg_);
  }

private:
  ::radar_msgs::msg::SystemState msg_;
};

class Init_SystemState_freq
{
public:
  explicit Init_SystemState_freq(::radar_msgs::msg::SystemState & msg)
  : msg_(msg)
  {}
  Init_SystemState_load freq(::radar_msgs::msg::SystemState::_freq_type arg)
  {
    msg_.freq = std::move(arg);
    return Init_SystemState_load(msg_);
  }

private:
  ::radar_msgs::msg::SystemState msg_;
};

class Init_SystemState_voltage
{
public:
  explicit Init_SystemState_voltage(::radar_msgs::msg::SystemState & msg)
  : msg_(msg)
  {}
  Init_SystemState_freq voltage(::radar_msgs::msg::SystemState::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return Init_SystemState_freq(msg_);
  }

private:
  ::radar_msgs::msg::SystemState msg_;
};

class Init_SystemState_temp
{
public:
  explicit Init_SystemState_temp(::radar_msgs::msg::SystemState & msg)
  : msg_(msg)
  {}
  Init_SystemState_voltage temp(::radar_msgs::msg::SystemState::_temp_type arg)
  {
    msg_.temp = std::move(arg);
    return Init_SystemState_voltage(msg_);
  }

private:
  ::radar_msgs::msg::SystemState msg_;
};

class Init_SystemState_header
{
public:
  Init_SystemState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SystemState_temp header(::radar_msgs::msg::SystemState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SystemState_temp(msg_);
  }

private:
  ::radar_msgs::msg::SystemState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::SystemState>()
{
  return radar_msgs::msg::builder::Init_SystemState_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE__BUILDER_HPP_
