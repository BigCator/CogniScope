// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/SystemStatePtpData.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/system_state_ptp_data__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
radar_msgs__msg__SystemStatePtpData__init(radar_msgs__msg__SystemStatePtpData * msg)
{
  if (!msg) {
    return false;
  }
  // reserved
  // ptp_counter_flg
  // pulse_count
  // ptp_sec_counter
  // ptp_nsec
  // ptp_follow_sec
  // ptp_sec_counter_all
  return true;
}

void
radar_msgs__msg__SystemStatePtpData__fini(radar_msgs__msg__SystemStatePtpData * msg)
{
  if (!msg) {
    return;
  }
  // reserved
  // ptp_counter_flg
  // pulse_count
  // ptp_sec_counter
  // ptp_nsec
  // ptp_follow_sec
  // ptp_sec_counter_all
}

bool
radar_msgs__msg__SystemStatePtpData__are_equal(const radar_msgs__msg__SystemStatePtpData * lhs, const radar_msgs__msg__SystemStatePtpData * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // reserved
  if (lhs->reserved != rhs->reserved) {
    return false;
  }
  // ptp_counter_flg
  if (lhs->ptp_counter_flg != rhs->ptp_counter_flg) {
    return false;
  }
  // pulse_count
  if (lhs->pulse_count != rhs->pulse_count) {
    return false;
  }
  // ptp_sec_counter
  if (lhs->ptp_sec_counter != rhs->ptp_sec_counter) {
    return false;
  }
  // ptp_nsec
  if (lhs->ptp_nsec != rhs->ptp_nsec) {
    return false;
  }
  // ptp_follow_sec
  if (lhs->ptp_follow_sec != rhs->ptp_follow_sec) {
    return false;
  }
  // ptp_sec_counter_all
  if (lhs->ptp_sec_counter_all != rhs->ptp_sec_counter_all) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__SystemStatePtpData__copy(
  const radar_msgs__msg__SystemStatePtpData * input,
  radar_msgs__msg__SystemStatePtpData * output)
{
  if (!input || !output) {
    return false;
  }
  // reserved
  output->reserved = input->reserved;
  // ptp_counter_flg
  output->ptp_counter_flg = input->ptp_counter_flg;
  // pulse_count
  output->pulse_count = input->pulse_count;
  // ptp_sec_counter
  output->ptp_sec_counter = input->ptp_sec_counter;
  // ptp_nsec
  output->ptp_nsec = input->ptp_nsec;
  // ptp_follow_sec
  output->ptp_follow_sec = input->ptp_follow_sec;
  // ptp_sec_counter_all
  output->ptp_sec_counter_all = input->ptp_sec_counter_all;
  return true;
}

radar_msgs__msg__SystemStatePtpData *
radar_msgs__msg__SystemStatePtpData__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemStatePtpData * msg = (radar_msgs__msg__SystemStatePtpData *)allocator.allocate(sizeof(radar_msgs__msg__SystemStatePtpData), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__SystemStatePtpData));
  bool success = radar_msgs__msg__SystemStatePtpData__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__SystemStatePtpData__destroy(radar_msgs__msg__SystemStatePtpData * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__SystemStatePtpData__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__SystemStatePtpData__Sequence__init(radar_msgs__msg__SystemStatePtpData__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemStatePtpData * data = NULL;

  if (size) {
    data = (radar_msgs__msg__SystemStatePtpData *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__SystemStatePtpData), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__SystemStatePtpData__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__SystemStatePtpData__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__SystemStatePtpData__Sequence__fini(radar_msgs__msg__SystemStatePtpData__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__SystemStatePtpData__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__SystemStatePtpData__Sequence *
radar_msgs__msg__SystemStatePtpData__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__SystemStatePtpData__Sequence * array = (radar_msgs__msg__SystemStatePtpData__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__SystemStatePtpData__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__SystemStatePtpData__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__SystemStatePtpData__Sequence__destroy(radar_msgs__msg__SystemStatePtpData__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__SystemStatePtpData__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__SystemStatePtpData__Sequence__are_equal(const radar_msgs__msg__SystemStatePtpData__Sequence * lhs, const radar_msgs__msg__SystemStatePtpData__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__SystemStatePtpData__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__SystemStatePtpData__Sequence__copy(
  const radar_msgs__msg__SystemStatePtpData__Sequence * input,
  radar_msgs__msg__SystemStatePtpData__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__SystemStatePtpData);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__SystemStatePtpData * data =
      (radar_msgs__msg__SystemStatePtpData *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__SystemStatePtpData__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__SystemStatePtpData__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__SystemStatePtpData__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
