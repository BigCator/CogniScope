// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/SystemStatePtpData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_PTP_DATA__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_PTP_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/system_state_ptp_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_SystemStatePtpData_ptp_sec_counter_all
{
public:
  explicit Init_SystemStatePtpData_ptp_sec_counter_all(::radar_msgs::msg::SystemStatePtpData & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::SystemStatePtpData ptp_sec_counter_all(::radar_msgs::msg::SystemStatePtpData::_ptp_sec_counter_all_type arg)
  {
    msg_.ptp_sec_counter_all = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::SystemStatePtpData msg_;
};

class Init_SystemStatePtpData_ptp_follow_sec
{
public:
  explicit Init_SystemStatePtpData_ptp_follow_sec(::radar_msgs::msg::SystemStatePtpData & msg)
  : msg_(msg)
  {}
  Init_SystemStatePtpData_ptp_sec_counter_all ptp_follow_sec(::radar_msgs::msg::SystemStatePtpData::_ptp_follow_sec_type arg)
  {
    msg_.ptp_follow_sec = std::move(arg);
    return Init_SystemStatePtpData_ptp_sec_counter_all(msg_);
  }

private:
  ::radar_msgs::msg::SystemStatePtpData msg_;
};

class Init_SystemStatePtpData_ptp_nsec
{
public:
  explicit Init_SystemStatePtpData_ptp_nsec(::radar_msgs::msg::SystemStatePtpData & msg)
  : msg_(msg)
  {}
  Init_SystemStatePtpData_ptp_follow_sec ptp_nsec(::radar_msgs::msg::SystemStatePtpData::_ptp_nsec_type arg)
  {
    msg_.ptp_nsec = std::move(arg);
    return Init_SystemStatePtpData_ptp_follow_sec(msg_);
  }

private:
  ::radar_msgs::msg::SystemStatePtpData msg_;
};

class Init_SystemStatePtpData_ptp_sec_counter
{
public:
  explicit Init_SystemStatePtpData_ptp_sec_counter(::radar_msgs::msg::SystemStatePtpData & msg)
  : msg_(msg)
  {}
  Init_SystemStatePtpData_ptp_nsec ptp_sec_counter(::radar_msgs::msg::SystemStatePtpData::_ptp_sec_counter_type arg)
  {
    msg_.ptp_sec_counter = std::move(arg);
    return Init_SystemStatePtpData_ptp_nsec(msg_);
  }

private:
  ::radar_msgs::msg::SystemStatePtpData msg_;
};

class Init_SystemStatePtpData_pulse_count
{
public:
  explicit Init_SystemStatePtpData_pulse_count(::radar_msgs::msg::SystemStatePtpData & msg)
  : msg_(msg)
  {}
  Init_SystemStatePtpData_ptp_sec_counter pulse_count(::radar_msgs::msg::SystemStatePtpData::_pulse_count_type arg)
  {
    msg_.pulse_count = std::move(arg);
    return Init_SystemStatePtpData_ptp_sec_counter(msg_);
  }

private:
  ::radar_msgs::msg::SystemStatePtpData msg_;
};

class Init_SystemStatePtpData_ptp_counter_flg
{
public:
  explicit Init_SystemStatePtpData_ptp_counter_flg(::radar_msgs::msg::SystemStatePtpData & msg)
  : msg_(msg)
  {}
  Init_SystemStatePtpData_pulse_count ptp_counter_flg(::radar_msgs::msg::SystemStatePtpData::_ptp_counter_flg_type arg)
  {
    msg_.ptp_counter_flg = std::move(arg);
    return Init_SystemStatePtpData_pulse_count(msg_);
  }

private:
  ::radar_msgs::msg::SystemStatePtpData msg_;
};

class Init_SystemStatePtpData_reserved
{
public:
  Init_SystemStatePtpData_reserved()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SystemStatePtpData_ptp_counter_flg reserved(::radar_msgs::msg::SystemStatePtpData::_reserved_type arg)
  {
    msg_.reserved = std::move(arg);
    return Init_SystemStatePtpData_ptp_counter_flg(msg_);
  }

private:
  ::radar_msgs::msg::SystemStatePtpData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::SystemStatePtpData>()
{
  return radar_msgs::msg::builder::Init_SystemStatePtpData_reserved();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_PTP_DATA__BUILDER_HPP_
