// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonTxPhShiftRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_tx_ph_shift_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonTxPhShiftRep_reserved3
{
public:
  explicit Init_RlMonTxPhShiftRep_reserved3(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonTxPhShiftRep reserved3(::radar_msgs::msg::RlMonTxPhShiftRep::_reserved3_type arg)
  {
    msg_.reserved3 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_reserved2
{
public:
  explicit Init_RlMonTxPhShiftRep_reserved2(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_reserved3 reserved2(::radar_msgs::msg::RlMonTxPhShiftRep::_reserved2_type arg)
  {
    msg_.reserved2 = std::move(arg);
    return Init_RlMonTxPhShiftRep_reserved3(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_timestamp
{
public:
  explicit Init_RlMonTxPhShiftRep_timestamp(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_reserved2 timestamp(::radar_msgs::msg::RlMonTxPhShiftRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_RlMonTxPhShiftRep_reserved2(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_txpsnoiseval4
{
public:
  explicit Init_RlMonTxPhShiftRep_txpsnoiseval4(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_timestamp txpsnoiseval4(::radar_msgs::msg::RlMonTxPhShiftRep::_txpsnoiseval4_type arg)
  {
    msg_.txpsnoiseval4 = std::move(arg);
    return Init_RlMonTxPhShiftRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_txpsnoiseval3
{
public:
  explicit Init_RlMonTxPhShiftRep_txpsnoiseval3(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_txpsnoiseval4 txpsnoiseval3(::radar_msgs::msg::RlMonTxPhShiftRep::_txpsnoiseval3_type arg)
  {
    msg_.txpsnoiseval3 = std::move(arg);
    return Init_RlMonTxPhShiftRep_txpsnoiseval4(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_txpsnoiseval2
{
public:
  explicit Init_RlMonTxPhShiftRep_txpsnoiseval2(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_txpsnoiseval3 txpsnoiseval2(::radar_msgs::msg::RlMonTxPhShiftRep::_txpsnoiseval2_type arg)
  {
    msg_.txpsnoiseval2 = std::move(arg);
    return Init_RlMonTxPhShiftRep_txpsnoiseval3(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_txpsnoiseval1
{
public:
  explicit Init_RlMonTxPhShiftRep_txpsnoiseval1(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_txpsnoiseval2 txpsnoiseval1(::radar_msgs::msg::RlMonTxPhShiftRep::_txpsnoiseval1_type arg)
  {
    msg_.txpsnoiseval1 = std::move(arg);
    return Init_RlMonTxPhShiftRep_txpsnoiseval2(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_txpsamplitudeval4
{
public:
  explicit Init_RlMonTxPhShiftRep_txpsamplitudeval4(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_txpsnoiseval1 txpsamplitudeval4(::radar_msgs::msg::RlMonTxPhShiftRep::_txpsamplitudeval4_type arg)
  {
    msg_.txpsamplitudeval4 = std::move(arg);
    return Init_RlMonTxPhShiftRep_txpsnoiseval1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_txpsamplitudeval3
{
public:
  explicit Init_RlMonTxPhShiftRep_txpsamplitudeval3(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_txpsamplitudeval4 txpsamplitudeval3(::radar_msgs::msg::RlMonTxPhShiftRep::_txpsamplitudeval3_type arg)
  {
    msg_.txpsamplitudeval3 = std::move(arg);
    return Init_RlMonTxPhShiftRep_txpsamplitudeval4(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_txpsamplitudeval2
{
public:
  explicit Init_RlMonTxPhShiftRep_txpsamplitudeval2(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_txpsamplitudeval3 txpsamplitudeval2(::radar_msgs::msg::RlMonTxPhShiftRep::_txpsamplitudeval2_type arg)
  {
    msg_.txpsamplitudeval2 = std::move(arg);
    return Init_RlMonTxPhShiftRep_txpsamplitudeval3(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_txpsamplitudeval1
{
public:
  explicit Init_RlMonTxPhShiftRep_txpsamplitudeval1(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_txpsamplitudeval2 txpsamplitudeval1(::radar_msgs::msg::RlMonTxPhShiftRep::_txpsamplitudeval1_type arg)
  {
    msg_.txpsamplitudeval1 = std::move(arg);
    return Init_RlMonTxPhShiftRep_txpsamplitudeval2(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_phaseshiftermonval4
{
public:
  explicit Init_RlMonTxPhShiftRep_phaseshiftermonval4(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_txpsamplitudeval1 phaseshiftermonval4(::radar_msgs::msg::RlMonTxPhShiftRep::_phaseshiftermonval4_type arg)
  {
    msg_.phaseshiftermonval4 = std::move(arg);
    return Init_RlMonTxPhShiftRep_txpsamplitudeval1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_phaseshiftermonval3
{
public:
  explicit Init_RlMonTxPhShiftRep_phaseshiftermonval3(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_phaseshiftermonval4 phaseshiftermonval3(::radar_msgs::msg::RlMonTxPhShiftRep::_phaseshiftermonval3_type arg)
  {
    msg_.phaseshiftermonval3 = std::move(arg);
    return Init_RlMonTxPhShiftRep_phaseshiftermonval4(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_phaseshiftermonval2
{
public:
  explicit Init_RlMonTxPhShiftRep_phaseshiftermonval2(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_phaseshiftermonval3 phaseshiftermonval2(::radar_msgs::msg::RlMonTxPhShiftRep::_phaseshiftermonval2_type arg)
  {
    msg_.phaseshiftermonval2 = std::move(arg);
    return Init_RlMonTxPhShiftRep_phaseshiftermonval3(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_phaseshiftermonval1
{
public:
  explicit Init_RlMonTxPhShiftRep_phaseshiftermonval1(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_phaseshiftermonval2 phaseshiftermonval1(::radar_msgs::msg::RlMonTxPhShiftRep::_phaseshiftermonval1_type arg)
  {
    msg_.phaseshiftermonval1 = std::move(arg);
    return Init_RlMonTxPhShiftRep_phaseshiftermonval2(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_reserved1
{
public:
  explicit Init_RlMonTxPhShiftRep_reserved1(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_phaseshiftermonval1 reserved1(::radar_msgs::msg::RlMonTxPhShiftRep::_reserved1_type arg)
  {
    msg_.reserved1 = std::move(arg);
    return Init_RlMonTxPhShiftRep_phaseshiftermonval1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_reserved0
{
public:
  explicit Init_RlMonTxPhShiftRep_reserved0(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_reserved1 reserved0(::radar_msgs::msg::RlMonTxPhShiftRep::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlMonTxPhShiftRep_reserved1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_profindex
{
public:
  explicit Init_RlMonTxPhShiftRep_profindex(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_reserved0 profindex(::radar_msgs::msg::RlMonTxPhShiftRep::_profindex_type arg)
  {
    msg_.profindex = std::move(arg);
    return Init_RlMonTxPhShiftRep_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_errorcode
{
public:
  explicit Init_RlMonTxPhShiftRep_errorcode(::radar_msgs::msg::RlMonTxPhShiftRep & msg)
  : msg_(msg)
  {}
  Init_RlMonTxPhShiftRep_profindex errorcode(::radar_msgs::msg::RlMonTxPhShiftRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonTxPhShiftRep_profindex(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

class Init_RlMonTxPhShiftRep_statusflags
{
public:
  Init_RlMonTxPhShiftRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonTxPhShiftRep_errorcode statusflags(::radar_msgs::msg::RlMonTxPhShiftRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonTxPhShiftRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonTxPhShiftRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonTxPhShiftRep>()
{
  return radar_msgs::msg::builder::Init_RlMonTxPhShiftRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_TX_PH_SHIFT_REP__BUILDER_HPP_
