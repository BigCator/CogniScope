// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from radar_msgs:msg/SystemState.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "radar_msgs/msg/detail/system_state__rosidl_typesupport_introspection_c.h"
#include "radar_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "radar_msgs/msg/detail/system_state__functions.h"
#include "radar_msgs/msg/detail/system_state__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `temp`
#include "radar_msgs/msg/system_state_temp.h"
// Member `temp`
#include "radar_msgs/msg/detail/system_state_temp__rosidl_typesupport_introspection_c.h"
// Member `load`
#include "radar_msgs/msg/system_stats_load.h"
// Member `load`
#include "radar_msgs/msg/detail/system_stats_load__rosidl_typesupport_introspection_c.h"
// Member `primary_heap`
#include "radar_msgs/msg/system_statsheap.h"
// Member `primary_heap`
#include "radar_msgs/msg/detail/system_statsheap__rosidl_typesupport_introspection_c.h"
// Member `heap_arr`
#include "radar_msgs/msg/system_statsheap_arr.h"
// Member `heap_arr`
#include "radar_msgs/msg/detail/system_statsheap_arr__rosidl_typesupport_introspection_c.h"
// Member `ptp_data`
#include "radar_msgs/msg/system_state_ptp_data.h"
// Member `ptp_data`
#include "radar_msgs/msg/detail/system_state_ptp_data__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  radar_msgs__msg__SystemState__init(message_memory);
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_fini_function(void * message_memory)
{
  radar_msgs__msg__SystemState__fini(message_memory);
}

size_t radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__temp(
  const void * untyped_member)
{
  (void)untyped_member;
  return 5;
}

const void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__temp(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__SystemStateTemp * member =
    (const radar_msgs__msg__SystemStateTemp *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__temp(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__SystemStateTemp * member =
    (radar_msgs__msg__SystemStateTemp *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__temp(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__SystemStateTemp * item =
    ((const radar_msgs__msg__SystemStateTemp *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__temp(untyped_member, index));
  radar_msgs__msg__SystemStateTemp * value =
    (radar_msgs__msg__SystemStateTemp *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__temp(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__SystemStateTemp * item =
    ((radar_msgs__msg__SystemStateTemp *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__temp(untyped_member, index));
  const radar_msgs__msg__SystemStateTemp * value =
    (const radar_msgs__msg__SystemStateTemp *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__voltage(
  const void * untyped_member)
{
  (void)untyped_member;
  return 5;
}

const void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__voltage(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__voltage(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__voltage(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__voltage(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__voltage(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__voltage(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__freq(
  const void * untyped_member)
{
  (void)untyped_member;
  return 10;
}

const void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__freq(
  const void * untyped_member, size_t index)
{
  const uint32_t * member =
    (const uint32_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__freq(
  void * untyped_member, size_t index)
{
  uint32_t * member =
    (uint32_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__freq(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint32_t * item =
    ((const uint32_t *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__freq(untyped_member, index));
  uint32_t * value =
    (uint32_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__freq(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint32_t * item =
    ((uint32_t *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__freq(untyped_member, index));
  const uint32_t * value =
    (const uint32_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__load(
  const void * untyped_member)
{
  (void)untyped_member;
  return 10;
}

const void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__load(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__SystemStatsLoad * member =
    (const radar_msgs__msg__SystemStatsLoad *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__load(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__SystemStatsLoad * member =
    (radar_msgs__msg__SystemStatsLoad *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__load(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__SystemStatsLoad * item =
    ((const radar_msgs__msg__SystemStatsLoad *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__load(untyped_member, index));
  radar_msgs__msg__SystemStatsLoad * value =
    (radar_msgs__msg__SystemStatsLoad *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__load(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__SystemStatsLoad * item =
    ((radar_msgs__msg__SystemStatsLoad *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__load(untyped_member, index));
  const radar_msgs__msg__SystemStatsLoad * value =
    (const radar_msgs__msg__SystemStatsLoad *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__primary_heap(
  const void * untyped_member)
{
  (void)untyped_member;
  return 4;
}

const void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__primary_heap(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__SystemStatsheap * member =
    (const radar_msgs__msg__SystemStatsheap *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__primary_heap(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__SystemStatsheap * member =
    (radar_msgs__msg__SystemStatsheap *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__primary_heap(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__SystemStatsheap * item =
    ((const radar_msgs__msg__SystemStatsheap *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__primary_heap(untyped_member, index));
  radar_msgs__msg__SystemStatsheap * value =
    (radar_msgs__msg__SystemStatsheap *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__primary_heap(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__SystemStatsheap * item =
    ((radar_msgs__msg__SystemStatsheap *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__primary_heap(untyped_member, index));
  const radar_msgs__msg__SystemStatsheap * value =
    (const radar_msgs__msg__SystemStatsheap *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__heap_arr(
  const void * untyped_member)
{
  (void)untyped_member;
  return 9;
}

const void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__heap_arr(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__SystemStatsheapArr * member =
    (const radar_msgs__msg__SystemStatsheapArr *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__heap_arr(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__SystemStatsheapArr * member =
    (radar_msgs__msg__SystemStatsheapArr *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__heap_arr(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__SystemStatsheapArr * item =
    ((const radar_msgs__msg__SystemStatsheapArr *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__heap_arr(untyped_member, index));
  radar_msgs__msg__SystemStatsheapArr * value =
    (radar_msgs__msg__SystemStatsheapArr *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__heap_arr(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__SystemStatsheapArr * item =
    ((radar_msgs__msg__SystemStatsheapArr *)
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__heap_arr(untyped_member, index));
  const radar_msgs__msg__SystemStatsheapArr * value =
    (const radar_msgs__msg__SystemStatsheapArr *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_member_array[8] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemState, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "temp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    5,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemState, temp),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__temp,  // size() function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__temp,  // get_const(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__temp,  // get(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__temp,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__temp,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "voltage",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    5,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemState, voltage),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__voltage,  // size() function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__voltage,  // get_const(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__voltage,  // get(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__voltage,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__voltage,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    10,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemState, freq),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__freq,  // size() function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__freq,  // get_const(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__freq,  // get(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__freq,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__freq,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "load",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    10,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemState, load),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__load,  // size() function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__load,  // get_const(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__load,  // get(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__load,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__load,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "primary_heap",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    4,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemState, primary_heap),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__primary_heap,  // size() function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__primary_heap,  // get_const(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__primary_heap,  // get(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__primary_heap,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__primary_heap,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "heap_arr",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    9,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemState, heap_arr),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__size_function__SystemState__heap_arr,  // size() function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_const_function__SystemState__heap_arr,  // get_const(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__get_function__SystemState__heap_arr,  // get(index) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__fetch_function__SystemState__heap_arr,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__assign_function__SystemState__heap_arr,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "ptp_data",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemState, ptp_data),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_members = {
  "radar_msgs__msg",  // message namespace
  "SystemState",  // message name
  8,  // number of fields
  sizeof(radar_msgs__msg__SystemState),
  radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_member_array,  // message members
  radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_init_function,  // function to initialize message memory (memory has to be allocated)
  radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_type_support_handle = {
  0,
  &radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_radar_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, SystemState)() {
  radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, SystemStateTemp)();
  radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, SystemStatsLoad)();
  radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_member_array[5].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, SystemStatsheap)();
  radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_member_array[6].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, SystemStatsheapArr)();
  radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_member_array[7].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, SystemStatePtpData)();
  if (!radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_type_support_handle.typesupport_identifier) {
    radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &radar_msgs__msg__SystemState__rosidl_typesupport_introspection_c__SystemState_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
