// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/PointCnt.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__POINT_CNT__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__POINT_CNT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__PointCnt __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__PointCnt __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct PointCnt_
{
  using Type = PointCnt_<ContainerAllocator>;

  explicit PointCnt_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->frame_id = 0ul;
      this->cfar_count = 0ul;
      this->target_num = 0ul;
      this->resetcnt = 0;
      this->objnum = 0ul;
      this->od_process_time = 0.0f;
      this->carspeed = 0.0f;
      this->caryawrate = 0.0f;
      this->odtimeoutcnt = 0;
      this->comprotv_i = 0;
      this->comprotv_ii = 0;
      this->framelostcnt = 0;
      this->beforeadcerrcnt = 0;
      this->afteradcerrcnt = 0;
      this->udprramelostcnt = 0ul;
    }
  }

  explicit PointCnt_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->frame_id = 0ul;
      this->cfar_count = 0ul;
      this->target_num = 0ul;
      this->resetcnt = 0;
      this->objnum = 0ul;
      this->od_process_time = 0.0f;
      this->carspeed = 0.0f;
      this->caryawrate = 0.0f;
      this->odtimeoutcnt = 0;
      this->comprotv_i = 0;
      this->comprotv_ii = 0;
      this->framelostcnt = 0;
      this->beforeadcerrcnt = 0;
      this->afteradcerrcnt = 0;
      this->udprramelostcnt = 0ul;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _frame_id_type =
    uint32_t;
  _frame_id_type frame_id;
  using _cfar_count_type =
    uint32_t;
  _cfar_count_type cfar_count;
  using _target_num_type =
    uint32_t;
  _target_num_type target_num;
  using _resetcnt_type =
    int16_t;
  _resetcnt_type resetcnt;
  using _objnum_type =
    uint32_t;
  _objnum_type objnum;
  using _od_process_time_type =
    float;
  _od_process_time_type od_process_time;
  using _carspeed_type =
    float;
  _carspeed_type carspeed;
  using _caryawrate_type =
    float;
  _caryawrate_type caryawrate;
  using _odtimeoutcnt_type =
    int16_t;
  _odtimeoutcnt_type odtimeoutcnt;
  using _comprotv_i_type =
    uint16_t;
  _comprotv_i_type comprotv_i;
  using _comprotv_ii_type =
    uint16_t;
  _comprotv_ii_type comprotv_ii;
  using _framelostcnt_type =
    uint16_t;
  _framelostcnt_type framelostcnt;
  using _beforeadcerrcnt_type =
    uint16_t;
  _beforeadcerrcnt_type beforeadcerrcnt;
  using _afteradcerrcnt_type =
    uint16_t;
  _afteradcerrcnt_type afteradcerrcnt;
  using _udprramelostcnt_type =
    uint32_t;
  _udprramelostcnt_type udprramelostcnt;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__frame_id(
    const uint32_t & _arg)
  {
    this->frame_id = _arg;
    return *this;
  }
  Type & set__cfar_count(
    const uint32_t & _arg)
  {
    this->cfar_count = _arg;
    return *this;
  }
  Type & set__target_num(
    const uint32_t & _arg)
  {
    this->target_num = _arg;
    return *this;
  }
  Type & set__resetcnt(
    const int16_t & _arg)
  {
    this->resetcnt = _arg;
    return *this;
  }
  Type & set__objnum(
    const uint32_t & _arg)
  {
    this->objnum = _arg;
    return *this;
  }
  Type & set__od_process_time(
    const float & _arg)
  {
    this->od_process_time = _arg;
    return *this;
  }
  Type & set__carspeed(
    const float & _arg)
  {
    this->carspeed = _arg;
    return *this;
  }
  Type & set__caryawrate(
    const float & _arg)
  {
    this->caryawrate = _arg;
    return *this;
  }
  Type & set__odtimeoutcnt(
    const int16_t & _arg)
  {
    this->odtimeoutcnt = _arg;
    return *this;
  }
  Type & set__comprotv_i(
    const uint16_t & _arg)
  {
    this->comprotv_i = _arg;
    return *this;
  }
  Type & set__comprotv_ii(
    const uint16_t & _arg)
  {
    this->comprotv_ii = _arg;
    return *this;
  }
  Type & set__framelostcnt(
    const uint16_t & _arg)
  {
    this->framelostcnt = _arg;
    return *this;
  }
  Type & set__beforeadcerrcnt(
    const uint16_t & _arg)
  {
    this->beforeadcerrcnt = _arg;
    return *this;
  }
  Type & set__afteradcerrcnt(
    const uint16_t & _arg)
  {
    this->afteradcerrcnt = _arg;
    return *this;
  }
  Type & set__udprramelostcnt(
    const uint32_t & _arg)
  {
    this->udprramelostcnt = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::PointCnt_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::PointCnt_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::PointCnt_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::PointCnt_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::PointCnt_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::PointCnt_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::PointCnt_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::PointCnt_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::PointCnt_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::PointCnt_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__PointCnt
    std::shared_ptr<radar_msgs::msg::PointCnt_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__PointCnt
    std::shared_ptr<radar_msgs::msg::PointCnt_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PointCnt_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->frame_id != other.frame_id) {
      return false;
    }
    if (this->cfar_count != other.cfar_count) {
      return false;
    }
    if (this->target_num != other.target_num) {
      return false;
    }
    if (this->resetcnt != other.resetcnt) {
      return false;
    }
    if (this->objnum != other.objnum) {
      return false;
    }
    if (this->od_process_time != other.od_process_time) {
      return false;
    }
    if (this->carspeed != other.carspeed) {
      return false;
    }
    if (this->caryawrate != other.caryawrate) {
      return false;
    }
    if (this->odtimeoutcnt != other.odtimeoutcnt) {
      return false;
    }
    if (this->comprotv_i != other.comprotv_i) {
      return false;
    }
    if (this->comprotv_ii != other.comprotv_ii) {
      return false;
    }
    if (this->framelostcnt != other.framelostcnt) {
      return false;
    }
    if (this->beforeadcerrcnt != other.beforeadcerrcnt) {
      return false;
    }
    if (this->afteradcerrcnt != other.afteradcerrcnt) {
      return false;
    }
    if (this->udprramelostcnt != other.udprramelostcnt) {
      return false;
    }
    return true;
  }
  bool operator!=(const PointCnt_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PointCnt_

// alias to use template instance with default allocator
using PointCnt =
  radar_msgs::msg::PointCnt_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__POINT_CNT__STRUCT_HPP_
