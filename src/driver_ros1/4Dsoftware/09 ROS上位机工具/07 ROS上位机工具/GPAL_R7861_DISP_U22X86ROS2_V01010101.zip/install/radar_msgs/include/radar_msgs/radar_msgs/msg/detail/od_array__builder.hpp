// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/OdArray.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OD_ARRAY__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__OD_ARRAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/od_array__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_OdArray_odarray
{
public:
  explicit Init_OdArray_odarray(::radar_msgs::msg::OdArray & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::OdArray odarray(::radar_msgs::msg::OdArray::_odarray_type arg)
  {
    msg_.odarray = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::OdArray msg_;
};

class Init_OdArray_objnum
{
public:
  explicit Init_OdArray_objnum(::radar_msgs::msg::OdArray & msg)
  : msg_(msg)
  {}
  Init_OdArray_odarray objnum(::radar_msgs::msg::OdArray::_objnum_type arg)
  {
    msg_.objnum = std::move(arg);
    return Init_OdArray_odarray(msg_);
  }

private:
  ::radar_msgs::msg::OdArray msg_;
};

class Init_OdArray_frame_cnt
{
public:
  explicit Init_OdArray_frame_cnt(::radar_msgs::msg::OdArray & msg)
  : msg_(msg)
  {}
  Init_OdArray_objnum frame_cnt(::radar_msgs::msg::OdArray::_frame_cnt_type arg)
  {
    msg_.frame_cnt = std::move(arg);
    return Init_OdArray_objnum(msg_);
  }

private:
  ::radar_msgs::msg::OdArray msg_;
};

class Init_OdArray_radar_id
{
public:
  explicit Init_OdArray_radar_id(::radar_msgs::msg::OdArray & msg)
  : msg_(msg)
  {}
  Init_OdArray_frame_cnt radar_id(::radar_msgs::msg::OdArray::_radar_id_type arg)
  {
    msg_.radar_id = std::move(arg);
    return Init_OdArray_frame_cnt(msg_);
  }

private:
  ::radar_msgs::msg::OdArray msg_;
};

class Init_OdArray_header
{
public:
  Init_OdArray_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_OdArray_radar_id header(::radar_msgs::msg::OdArray::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_OdArray_radar_id(msg_);
  }

private:
  ::radar_msgs::msg::OdArray msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::OdArray>()
{
  return radar_msgs::msg::builder::Init_OdArray_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__OD_ARRAY__BUILDER_HPP_
