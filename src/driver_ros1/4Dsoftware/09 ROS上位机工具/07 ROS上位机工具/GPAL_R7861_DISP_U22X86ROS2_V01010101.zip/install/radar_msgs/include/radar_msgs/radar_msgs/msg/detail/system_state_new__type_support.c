// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from radar_msgs:msg/SystemStateNew.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "radar_msgs/msg/detail/system_state_new__rosidl_typesupport_introspection_c.h"
#include "radar_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "radar_msgs/msg/detail/system_state_new__functions.h"
#include "radar_msgs/msg/detail/system_state_new__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  radar_msgs__msg__SystemStateNew__init(message_memory);
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_fini_function(void * message_memory)
{
  radar_msgs__msg__SystemStateNew__fini(message_memory);
}

size_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__project_code_num(
  const void * untyped_member)
{
  (void)untyped_member;
  return 20;
}

const void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__project_code_num(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__project_code_num(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__project_code_num(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__project_code_num(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__project_code_num(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__project_code_num(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__porduct_code(
  const void * untyped_member)
{
  (void)untyped_member;
  return 20;
}

const void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__porduct_code(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__porduct_code(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__porduct_code(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__porduct_code(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__porduct_code(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__porduct_code(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__serial_num(
  const void * untyped_member)
{
  (void)untyped_member;
  return 40;
}

const void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__serial_num(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__serial_num(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__serial_num(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__serial_num(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__serial_num(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__serial_num(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__rfhw_code(
  const void * untyped_member)
{
  (void)untyped_member;
  return 40;
}

const void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__rfhw_code(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__rfhw_code(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__rfhw_code(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__rfhw_code(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__rfhw_code(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__rfhw_code(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__dsphw_code(
  const void * untyped_member)
{
  (void)untyped_member;
  return 40;
}

const void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__dsphw_code(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__dsphw_code(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__dsphw_code(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__dsphw_code(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__dsphw_code(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__dsphw_code(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__calibrate_code(
  const void * untyped_member)
{
  (void)untyped_member;
  return 20;
}

const void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__calibrate_code(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__calibrate_code(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__calibrate_code(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__calibrate_code(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__calibrate_code(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__calibrate_code(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__os_version(
  const void * untyped_member)
{
  (void)untyped_member;
  return 20;
}

const void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__os_version(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__os_version(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__os_version(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__os_version(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__os_version(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__os_version(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__sw_version(
  const void * untyped_member)
{
  (void)untyped_member;
  return 20;
}

const void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__sw_version(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__sw_version(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__sw_version(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__sw_version(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__sw_version(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__sw_version(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__algo_version(
  const void * untyped_member)
{
  (void)untyped_member;
  return 20;
}

const void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__algo_version(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__algo_version(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__algo_version(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__algo_version(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__algo_version(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__algo_version(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__waveform_version(
  const void * untyped_member)
{
  (void)untyped_member;
  return 20;
}

const void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__waveform_version(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__waveform_version(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__waveform_version(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__waveform_version(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__waveform_version(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__waveform_version(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_message_member_array[50] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "project_code_num",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    20,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, project_code_num),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__project_code_num,  // size() function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__project_code_num,  // get_const(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__project_code_num,  // get(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__project_code_num,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__project_code_num,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "product_year",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, product_year),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "product_month",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, product_month),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "product_day",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, product_day),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "porduct_code",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    20,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, porduct_code),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__porduct_code,  // size() function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__porduct_code,  // get_const(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__porduct_code,  // get(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__porduct_code,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__porduct_code,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "serial_num",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    40,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, serial_num),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__serial_num,  // size() function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__serial_num,  // get_const(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__serial_num,  // get(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__serial_num,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__serial_num,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "rfhw_code",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    40,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, rfhw_code),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__rfhw_code,  // size() function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__rfhw_code,  // get_const(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__rfhw_code,  // get(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__rfhw_code,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__rfhw_code,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "rfhw_version",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, rfhw_version),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "dsphw_code",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    40,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, dsphw_code),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__dsphw_code,  // size() function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__dsphw_code,  // get_const(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__dsphw_code,  // get(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__dsphw_code,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__dsphw_code,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "dsphw_version",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, dsphw_version),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "calibrate_code",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    20,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, calibrate_code),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__calibrate_code,  // size() function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__calibrate_code,  // get_const(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__calibrate_code,  // get(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__calibrate_code,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__calibrate_code,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "os_version",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    20,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, os_version),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__os_version,  // size() function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__os_version,  // get_const(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__os_version,  // get(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__os_version,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__os_version,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "sw_version",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    20,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, sw_version),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__sw_version,  // size() function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__sw_version,  // get_const(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__sw_version,  // get(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__sw_version,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__sw_version,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "algo_version",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    20,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, algo_version),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__algo_version,  // size() function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__algo_version,  // get_const(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__algo_version,  // get(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__algo_version,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__algo_version,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "waveform_version",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    20,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, waveform_version),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__size_function__SystemStateNew__waveform_version,  // size() function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_const_function__SystemStateNew__waveform_version,  // get_const(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__get_function__SystemStateNew__waveform_version,  // get(index) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__fetch_function__SystemStateNew__waveform_version,  // fetch(index, &value) function pointer
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__assign_function__SystemStateNew__waveform_version,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "a72_0_loading",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, a72_0_loading),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "a72_1_loading",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, a72_1_loading),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "a72_0_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, a72_0_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "a72_1_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, a72_1_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "mcu_0_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, mcu_0_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "mcu_1_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, mcu_1_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "mcu_2_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, mcu_2_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "mcu_3_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, mcu_3_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "lp_mcu_0_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, lp_mcu_0_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "lp_mcu_1_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, lp_mcu_1_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "c7x_mma_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, c7x_mma_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "c66x_0_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, c66x_0_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "c66x_1_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, c66x_1_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "c7x_1_freq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, c7x_1_freq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reboot_cnt",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, reboot_cnt),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "memory_loading",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, memory_loading),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "junction_temp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, junction_temp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "low_power_mode_enable",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, low_power_mode_enable),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "error_code",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, error_code),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "blockage_detection",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, blockage_detection),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "radar_mode",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, radar_mode),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "udpsend_enpnt",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, udpsend_enpnt),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "udpsend_entrk",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, udpsend_entrk),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "udpsend_enrdmap",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, udpsend_enrdmap),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "udpsend_encfar",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, udpsend_encfar),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "udpsend_enadc",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, udpsend_enadc),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "udpsend_enfft1d",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, udpsend_enfft1d),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "udpsend_enfft2d",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, udpsend_enfft2d),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "udpsend_endoa",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, udpsend_endoa),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "radar_txfreq",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, radar_txfreq),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "frame_triggerdelay",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, frame_triggerdelay),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "sync_enable",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, sync_enable),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "sync_radarnum",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, sync_radarnum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "antiinterface_enable",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__SystemStateNew, antiinterface_enable),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_message_members = {
  "radar_msgs__msg",  // message namespace
  "SystemStateNew",  // message name
  50,  // number of fields
  sizeof(radar_msgs__msg__SystemStateNew),
  radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_message_member_array,  // message members
  radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_init_function,  // function to initialize message memory (memory has to be allocated)
  radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_message_type_support_handle = {
  0,
  &radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_radar_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, SystemStateNew)() {
  radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_message_type_support_handle.typesupport_identifier) {
    radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &radar_msgs__msg__SystemStateNew__rosidl_typesupport_introspection_c__SystemStateNew_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
