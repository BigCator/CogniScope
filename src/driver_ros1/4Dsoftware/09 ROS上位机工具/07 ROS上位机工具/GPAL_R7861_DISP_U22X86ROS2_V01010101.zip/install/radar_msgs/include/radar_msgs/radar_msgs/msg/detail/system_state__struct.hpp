// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/SystemState.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'temp'
#include "radar_msgs/msg/detail/system_state_temp__struct.hpp"
// Member 'load'
#include "radar_msgs/msg/detail/system_stats_load__struct.hpp"
// Member 'primary_heap'
#include "radar_msgs/msg/detail/system_statsheap__struct.hpp"
// Member 'heap_arr'
#include "radar_msgs/msg/detail/system_statsheap_arr__struct.hpp"
// Member 'ptp_data'
#include "radar_msgs/msg/detail/system_state_ptp_data__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__SystemState __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__SystemState __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SystemState_
{
  using Type = SystemState_<ContainerAllocator>;

  explicit SystemState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    ptp_data(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->temp.fill(radar_msgs::msg::SystemStateTemp_<ContainerAllocator>{_init});
      std::fill<typename std::array<float, 5>::iterator, float>(this->voltage.begin(), this->voltage.end(), 0.0f);
      std::fill<typename std::array<uint32_t, 10>::iterator, uint32_t>(this->freq.begin(), this->freq.end(), 0ul);
      this->load.fill(radar_msgs::msg::SystemStatsLoad_<ContainerAllocator>{_init});
      this->primary_heap.fill(radar_msgs::msg::SystemStatsheap_<ContainerAllocator>{_init});
      this->heap_arr.fill(radar_msgs::msg::SystemStatsheapArr_<ContainerAllocator>{_init});
    }
  }

  explicit SystemState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    temp(_alloc),
    voltage(_alloc),
    freq(_alloc),
    load(_alloc),
    primary_heap(_alloc),
    heap_arr(_alloc),
    ptp_data(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->temp.fill(radar_msgs::msg::SystemStateTemp_<ContainerAllocator>{_alloc, _init});
      std::fill<typename std::array<float, 5>::iterator, float>(this->voltage.begin(), this->voltage.end(), 0.0f);
      std::fill<typename std::array<uint32_t, 10>::iterator, uint32_t>(this->freq.begin(), this->freq.end(), 0ul);
      this->load.fill(radar_msgs::msg::SystemStatsLoad_<ContainerAllocator>{_alloc, _init});
      this->primary_heap.fill(radar_msgs::msg::SystemStatsheap_<ContainerAllocator>{_alloc, _init});
      this->heap_arr.fill(radar_msgs::msg::SystemStatsheapArr_<ContainerAllocator>{_alloc, _init});
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _temp_type =
    std::array<radar_msgs::msg::SystemStateTemp_<ContainerAllocator>, 5>;
  _temp_type temp;
  using _voltage_type =
    std::array<float, 5>;
  _voltage_type voltage;
  using _freq_type =
    std::array<uint32_t, 10>;
  _freq_type freq;
  using _load_type =
    std::array<radar_msgs::msg::SystemStatsLoad_<ContainerAllocator>, 10>;
  _load_type load;
  using _primary_heap_type =
    std::array<radar_msgs::msg::SystemStatsheap_<ContainerAllocator>, 4>;
  _primary_heap_type primary_heap;
  using _heap_arr_type =
    std::array<radar_msgs::msg::SystemStatsheapArr_<ContainerAllocator>, 9>;
  _heap_arr_type heap_arr;
  using _ptp_data_type =
    radar_msgs::msg::SystemStatePtpData_<ContainerAllocator>;
  _ptp_data_type ptp_data;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__temp(
    const std::array<radar_msgs::msg::SystemStateTemp_<ContainerAllocator>, 5> & _arg)
  {
    this->temp = _arg;
    return *this;
  }
  Type & set__voltage(
    const std::array<float, 5> & _arg)
  {
    this->voltage = _arg;
    return *this;
  }
  Type & set__freq(
    const std::array<uint32_t, 10> & _arg)
  {
    this->freq = _arg;
    return *this;
  }
  Type & set__load(
    const std::array<radar_msgs::msg::SystemStatsLoad_<ContainerAllocator>, 10> & _arg)
  {
    this->load = _arg;
    return *this;
  }
  Type & set__primary_heap(
    const std::array<radar_msgs::msg::SystemStatsheap_<ContainerAllocator>, 4> & _arg)
  {
    this->primary_heap = _arg;
    return *this;
  }
  Type & set__heap_arr(
    const std::array<radar_msgs::msg::SystemStatsheapArr_<ContainerAllocator>, 9> & _arg)
  {
    this->heap_arr = _arg;
    return *this;
  }
  Type & set__ptp_data(
    const radar_msgs::msg::SystemStatePtpData_<ContainerAllocator> & _arg)
  {
    this->ptp_data = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::SystemState_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::SystemState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::SystemState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::SystemState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::SystemState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::SystemState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::SystemState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::SystemState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::SystemState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::SystemState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__SystemState
    std::shared_ptr<radar_msgs::msg::SystemState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__SystemState
    std::shared_ptr<radar_msgs::msg::SystemState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SystemState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->temp != other.temp) {
      return false;
    }
    if (this->voltage != other.voltage) {
      return false;
    }
    if (this->freq != other.freq) {
      return false;
    }
    if (this->load != other.load) {
      return false;
    }
    if (this->primary_heap != other.primary_heap) {
      return false;
    }
    if (this->heap_arr != other.heap_arr) {
      return false;
    }
    if (this->ptp_data != other.ptp_data) {
      return false;
    }
    return true;
  }
  bool operator!=(const SystemState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SystemState_

// alias to use template instance with default allocator
using SystemState =
  radar_msgs::msg::SystemState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE__STRUCT_HPP_
