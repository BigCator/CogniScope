// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/TrackingObj.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/tracking_obj__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `object_id`
// Member `age`
// Member `measurement_status`
// Member `motion_state`
// Member `existance_confidence`
// Member `position_x`
// Member `position_y`
// Member `position_z`
// Member `velocity_x`
// Member `velocity_y`
// Member `velocity_z`
// Member `acceleration_x`
// Member `acceleration_y`
// Member `acceleration_z`
// Member `v2ground_x`
// Member `v2ground_y`
// Member `v2ground_z`
// Member `orientation`
// Member `type`
// Member `car_confidence`
// Member `bike_confidence`
// Member `ped_confidence`
// Member `truck_confidence`
// Member `signboard_confidence`
// Member `ground_confidence`
// Member `obstacle_confidence`
// Member `length`
// Member `width`
// Member `height`
// Member `od_process_time`
// Member `reserved_b`
// Member `reserved_c`
// Member `reserved_d`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
radar_msgs__msg__TrackingObj__init(radar_msgs__msg__TrackingObj * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // radar_id
  // frame_cnt
  // objnum
  // object_id
  if (!rosidl_runtime_c__uint32__Sequence__init(&msg->object_id, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // age
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->age, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // measurement_status
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->measurement_status, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // motion_state
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->motion_state, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // existance_confidence
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->existance_confidence, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // position_x
  if (!rosidl_runtime_c__float__Sequence__init(&msg->position_x, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // position_y
  if (!rosidl_runtime_c__float__Sequence__init(&msg->position_y, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // position_z
  if (!rosidl_runtime_c__float__Sequence__init(&msg->position_z, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // velocity_x
  if (!rosidl_runtime_c__float__Sequence__init(&msg->velocity_x, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // velocity_y
  if (!rosidl_runtime_c__float__Sequence__init(&msg->velocity_y, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // velocity_z
  if (!rosidl_runtime_c__float__Sequence__init(&msg->velocity_z, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // acceleration_x
  if (!rosidl_runtime_c__float__Sequence__init(&msg->acceleration_x, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // acceleration_y
  if (!rosidl_runtime_c__float__Sequence__init(&msg->acceleration_y, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // acceleration_z
  if (!rosidl_runtime_c__float__Sequence__init(&msg->acceleration_z, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // v2ground_x
  if (!rosidl_runtime_c__float__Sequence__init(&msg->v2ground_x, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // v2ground_y
  if (!rosidl_runtime_c__float__Sequence__init(&msg->v2ground_y, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // v2ground_z
  if (!rosidl_runtime_c__float__Sequence__init(&msg->v2ground_z, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // orientation
  if (!rosidl_runtime_c__float__Sequence__init(&msg->orientation, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // type
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->type, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // car_confidence
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->car_confidence, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // bike_confidence
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->bike_confidence, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // ped_confidence
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->ped_confidence, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // truck_confidence
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->truck_confidence, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // signboard_confidence
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->signboard_confidence, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // ground_confidence
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->ground_confidence, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // obstacle_confidence
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->obstacle_confidence, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // length
  if (!rosidl_runtime_c__float__Sequence__init(&msg->length, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // width
  if (!rosidl_runtime_c__float__Sequence__init(&msg->width, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // height
  if (!rosidl_runtime_c__float__Sequence__init(&msg->height, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // od_process_time
  if (!rosidl_runtime_c__float__Sequence__init(&msg->od_process_time, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // reserved_b
  if (!rosidl_runtime_c__float__Sequence__init(&msg->reserved_b, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // reserved_c
  if (!rosidl_runtime_c__float__Sequence__init(&msg->reserved_c, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  // reserved_d
  if (!rosidl_runtime_c__float__Sequence__init(&msg->reserved_d, 0)) {
    radar_msgs__msg__TrackingObj__fini(msg);
    return false;
  }
  return true;
}

void
radar_msgs__msg__TrackingObj__fini(radar_msgs__msg__TrackingObj * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // radar_id
  // frame_cnt
  // objnum
  // object_id
  rosidl_runtime_c__uint32__Sequence__fini(&msg->object_id);
  // age
  rosidl_runtime_c__uint16__Sequence__fini(&msg->age);
  // measurement_status
  rosidl_runtime_c__uint8__Sequence__fini(&msg->measurement_status);
  // motion_state
  rosidl_runtime_c__uint8__Sequence__fini(&msg->motion_state);
  // existance_confidence
  rosidl_runtime_c__uint8__Sequence__fini(&msg->existance_confidence);
  // position_x
  rosidl_runtime_c__float__Sequence__fini(&msg->position_x);
  // position_y
  rosidl_runtime_c__float__Sequence__fini(&msg->position_y);
  // position_z
  rosidl_runtime_c__float__Sequence__fini(&msg->position_z);
  // velocity_x
  rosidl_runtime_c__float__Sequence__fini(&msg->velocity_x);
  // velocity_y
  rosidl_runtime_c__float__Sequence__fini(&msg->velocity_y);
  // velocity_z
  rosidl_runtime_c__float__Sequence__fini(&msg->velocity_z);
  // acceleration_x
  rosidl_runtime_c__float__Sequence__fini(&msg->acceleration_x);
  // acceleration_y
  rosidl_runtime_c__float__Sequence__fini(&msg->acceleration_y);
  // acceleration_z
  rosidl_runtime_c__float__Sequence__fini(&msg->acceleration_z);
  // v2ground_x
  rosidl_runtime_c__float__Sequence__fini(&msg->v2ground_x);
  // v2ground_y
  rosidl_runtime_c__float__Sequence__fini(&msg->v2ground_y);
  // v2ground_z
  rosidl_runtime_c__float__Sequence__fini(&msg->v2ground_z);
  // orientation
  rosidl_runtime_c__float__Sequence__fini(&msg->orientation);
  // type
  rosidl_runtime_c__uint8__Sequence__fini(&msg->type);
  // car_confidence
  rosidl_runtime_c__uint8__Sequence__fini(&msg->car_confidence);
  // bike_confidence
  rosidl_runtime_c__uint8__Sequence__fini(&msg->bike_confidence);
  // ped_confidence
  rosidl_runtime_c__uint8__Sequence__fini(&msg->ped_confidence);
  // truck_confidence
  rosidl_runtime_c__uint8__Sequence__fini(&msg->truck_confidence);
  // signboard_confidence
  rosidl_runtime_c__uint8__Sequence__fini(&msg->signboard_confidence);
  // ground_confidence
  rosidl_runtime_c__uint8__Sequence__fini(&msg->ground_confidence);
  // obstacle_confidence
  rosidl_runtime_c__uint8__Sequence__fini(&msg->obstacle_confidence);
  // length
  rosidl_runtime_c__float__Sequence__fini(&msg->length);
  // width
  rosidl_runtime_c__float__Sequence__fini(&msg->width);
  // height
  rosidl_runtime_c__float__Sequence__fini(&msg->height);
  // od_process_time
  rosidl_runtime_c__float__Sequence__fini(&msg->od_process_time);
  // reserved_b
  rosidl_runtime_c__float__Sequence__fini(&msg->reserved_b);
  // reserved_c
  rosidl_runtime_c__float__Sequence__fini(&msg->reserved_c);
  // reserved_d
  rosidl_runtime_c__float__Sequence__fini(&msg->reserved_d);
}

bool
radar_msgs__msg__TrackingObj__are_equal(const radar_msgs__msg__TrackingObj * lhs, const radar_msgs__msg__TrackingObj * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // radar_id
  if (lhs->radar_id != rhs->radar_id) {
    return false;
  }
  // frame_cnt
  if (lhs->frame_cnt != rhs->frame_cnt) {
    return false;
  }
  // objnum
  if (lhs->objnum != rhs->objnum) {
    return false;
  }
  // object_id
  if (!rosidl_runtime_c__uint32__Sequence__are_equal(
      &(lhs->object_id), &(rhs->object_id)))
  {
    return false;
  }
  // age
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->age), &(rhs->age)))
  {
    return false;
  }
  // measurement_status
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->measurement_status), &(rhs->measurement_status)))
  {
    return false;
  }
  // motion_state
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->motion_state), &(rhs->motion_state)))
  {
    return false;
  }
  // existance_confidence
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->existance_confidence), &(rhs->existance_confidence)))
  {
    return false;
  }
  // position_x
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->position_x), &(rhs->position_x)))
  {
    return false;
  }
  // position_y
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->position_y), &(rhs->position_y)))
  {
    return false;
  }
  // position_z
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->position_z), &(rhs->position_z)))
  {
    return false;
  }
  // velocity_x
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->velocity_x), &(rhs->velocity_x)))
  {
    return false;
  }
  // velocity_y
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->velocity_y), &(rhs->velocity_y)))
  {
    return false;
  }
  // velocity_z
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->velocity_z), &(rhs->velocity_z)))
  {
    return false;
  }
  // acceleration_x
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->acceleration_x), &(rhs->acceleration_x)))
  {
    return false;
  }
  // acceleration_y
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->acceleration_y), &(rhs->acceleration_y)))
  {
    return false;
  }
  // acceleration_z
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->acceleration_z), &(rhs->acceleration_z)))
  {
    return false;
  }
  // v2ground_x
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->v2ground_x), &(rhs->v2ground_x)))
  {
    return false;
  }
  // v2ground_y
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->v2ground_y), &(rhs->v2ground_y)))
  {
    return false;
  }
  // v2ground_z
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->v2ground_z), &(rhs->v2ground_z)))
  {
    return false;
  }
  // orientation
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->orientation), &(rhs->orientation)))
  {
    return false;
  }
  // type
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->type), &(rhs->type)))
  {
    return false;
  }
  // car_confidence
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->car_confidence), &(rhs->car_confidence)))
  {
    return false;
  }
  // bike_confidence
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->bike_confidence), &(rhs->bike_confidence)))
  {
    return false;
  }
  // ped_confidence
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->ped_confidence), &(rhs->ped_confidence)))
  {
    return false;
  }
  // truck_confidence
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->truck_confidence), &(rhs->truck_confidence)))
  {
    return false;
  }
  // signboard_confidence
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->signboard_confidence), &(rhs->signboard_confidence)))
  {
    return false;
  }
  // ground_confidence
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->ground_confidence), &(rhs->ground_confidence)))
  {
    return false;
  }
  // obstacle_confidence
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->obstacle_confidence), &(rhs->obstacle_confidence)))
  {
    return false;
  }
  // length
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->length), &(rhs->length)))
  {
    return false;
  }
  // width
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->width), &(rhs->width)))
  {
    return false;
  }
  // height
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->height), &(rhs->height)))
  {
    return false;
  }
  // od_process_time
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->od_process_time), &(rhs->od_process_time)))
  {
    return false;
  }
  // reserved_b
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->reserved_b), &(rhs->reserved_b)))
  {
    return false;
  }
  // reserved_c
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->reserved_c), &(rhs->reserved_c)))
  {
    return false;
  }
  // reserved_d
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->reserved_d), &(rhs->reserved_d)))
  {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__TrackingObj__copy(
  const radar_msgs__msg__TrackingObj * input,
  radar_msgs__msg__TrackingObj * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // radar_id
  output->radar_id = input->radar_id;
  // frame_cnt
  output->frame_cnt = input->frame_cnt;
  // objnum
  output->objnum = input->objnum;
  // object_id
  if (!rosidl_runtime_c__uint32__Sequence__copy(
      &(input->object_id), &(output->object_id)))
  {
    return false;
  }
  // age
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->age), &(output->age)))
  {
    return false;
  }
  // measurement_status
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->measurement_status), &(output->measurement_status)))
  {
    return false;
  }
  // motion_state
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->motion_state), &(output->motion_state)))
  {
    return false;
  }
  // existance_confidence
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->existance_confidence), &(output->existance_confidence)))
  {
    return false;
  }
  // position_x
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->position_x), &(output->position_x)))
  {
    return false;
  }
  // position_y
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->position_y), &(output->position_y)))
  {
    return false;
  }
  // position_z
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->position_z), &(output->position_z)))
  {
    return false;
  }
  // velocity_x
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->velocity_x), &(output->velocity_x)))
  {
    return false;
  }
  // velocity_y
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->velocity_y), &(output->velocity_y)))
  {
    return false;
  }
  // velocity_z
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->velocity_z), &(output->velocity_z)))
  {
    return false;
  }
  // acceleration_x
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->acceleration_x), &(output->acceleration_x)))
  {
    return false;
  }
  // acceleration_y
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->acceleration_y), &(output->acceleration_y)))
  {
    return false;
  }
  // acceleration_z
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->acceleration_z), &(output->acceleration_z)))
  {
    return false;
  }
  // v2ground_x
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->v2ground_x), &(output->v2ground_x)))
  {
    return false;
  }
  // v2ground_y
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->v2ground_y), &(output->v2ground_y)))
  {
    return false;
  }
  // v2ground_z
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->v2ground_z), &(output->v2ground_z)))
  {
    return false;
  }
  // orientation
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->orientation), &(output->orientation)))
  {
    return false;
  }
  // type
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->type), &(output->type)))
  {
    return false;
  }
  // car_confidence
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->car_confidence), &(output->car_confidence)))
  {
    return false;
  }
  // bike_confidence
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->bike_confidence), &(output->bike_confidence)))
  {
    return false;
  }
  // ped_confidence
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->ped_confidence), &(output->ped_confidence)))
  {
    return false;
  }
  // truck_confidence
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->truck_confidence), &(output->truck_confidence)))
  {
    return false;
  }
  // signboard_confidence
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->signboard_confidence), &(output->signboard_confidence)))
  {
    return false;
  }
  // ground_confidence
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->ground_confidence), &(output->ground_confidence)))
  {
    return false;
  }
  // obstacle_confidence
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->obstacle_confidence), &(output->obstacle_confidence)))
  {
    return false;
  }
  // length
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->length), &(output->length)))
  {
    return false;
  }
  // width
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->width), &(output->width)))
  {
    return false;
  }
  // height
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->height), &(output->height)))
  {
    return false;
  }
  // od_process_time
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->od_process_time), &(output->od_process_time)))
  {
    return false;
  }
  // reserved_b
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->reserved_b), &(output->reserved_b)))
  {
    return false;
  }
  // reserved_c
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->reserved_c), &(output->reserved_c)))
  {
    return false;
  }
  // reserved_d
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->reserved_d), &(output->reserved_d)))
  {
    return false;
  }
  return true;
}

radar_msgs__msg__TrackingObj *
radar_msgs__msg__TrackingObj__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__TrackingObj * msg = (radar_msgs__msg__TrackingObj *)allocator.allocate(sizeof(radar_msgs__msg__TrackingObj), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__TrackingObj));
  bool success = radar_msgs__msg__TrackingObj__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__TrackingObj__destroy(radar_msgs__msg__TrackingObj * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__TrackingObj__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__TrackingObj__Sequence__init(radar_msgs__msg__TrackingObj__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__TrackingObj * data = NULL;

  if (size) {
    data = (radar_msgs__msg__TrackingObj *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__TrackingObj), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__TrackingObj__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__TrackingObj__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__TrackingObj__Sequence__fini(radar_msgs__msg__TrackingObj__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__TrackingObj__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__TrackingObj__Sequence *
radar_msgs__msg__TrackingObj__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__TrackingObj__Sequence * array = (radar_msgs__msg__TrackingObj__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__TrackingObj__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__TrackingObj__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__TrackingObj__Sequence__destroy(radar_msgs__msg__TrackingObj__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__TrackingObj__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__TrackingObj__Sequence__are_equal(const radar_msgs__msg__TrackingObj__Sequence * lhs, const radar_msgs__msg__TrackingObj__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__TrackingObj__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__TrackingObj__Sequence__copy(
  const radar_msgs__msg__TrackingObj__Sequence * input,
  radar_msgs__msg__TrackingObj__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__TrackingObj);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__TrackingObj * data =
      (radar_msgs__msg__TrackingObj *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__TrackingObj__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__TrackingObj__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__TrackingObj__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
