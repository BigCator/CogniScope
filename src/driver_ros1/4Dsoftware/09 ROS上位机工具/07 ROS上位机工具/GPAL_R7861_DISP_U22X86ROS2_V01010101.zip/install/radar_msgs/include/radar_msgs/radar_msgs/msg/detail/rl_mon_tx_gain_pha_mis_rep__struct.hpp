// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RlMonTxGainPhaMisRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RlMonTxGainPhaMisRep __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RlMonTxGainPhaMisRep __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RlMonTxGainPhaMisRep_
{
  using Type = RlMonTxGainPhaMisRep_<ContainerAllocator>;

  explicit RlMonTxGainPhaMisRep_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      this->profindex = 0;
      this->noisepower00 = 0;
      this->noisepower01 = 0;
      this->noisepower02 = 0;
      std::fill<typename std::array<int16_t, 9>::iterator, int16_t>(this->txgainval.begin(), this->txgainval.end(), 0);
      std::fill<typename std::array<uint16_t, 9>::iterator, uint16_t>(this->txphaval.begin(), this->txphaval.end(), 0);
      this->noisepower10 = 0;
      this->noisepower11 = 0;
      this->noisepower12 = 0;
      this->noisepower20 = 0;
      this->noisepower21 = 0;
      this->noisepower22 = 0;
      this->reserved0 = 0;
      this->reserved1 = 0;
      this->timestamp = 0ul;
    }
  }

  explicit RlMonTxGainPhaMisRep_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : txgainval(_alloc),
    txphaval(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      this->profindex = 0;
      this->noisepower00 = 0;
      this->noisepower01 = 0;
      this->noisepower02 = 0;
      std::fill<typename std::array<int16_t, 9>::iterator, int16_t>(this->txgainval.begin(), this->txgainval.end(), 0);
      std::fill<typename std::array<uint16_t, 9>::iterator, uint16_t>(this->txphaval.begin(), this->txphaval.end(), 0);
      this->noisepower10 = 0;
      this->noisepower11 = 0;
      this->noisepower12 = 0;
      this->noisepower20 = 0;
      this->noisepower21 = 0;
      this->noisepower22 = 0;
      this->reserved0 = 0;
      this->reserved1 = 0;
      this->timestamp = 0ul;
    }
  }

  // field types and members
  using _statusflags_type =
    uint16_t;
  _statusflags_type statusflags;
  using _errorcode_type =
    uint16_t;
  _errorcode_type errorcode;
  using _profindex_type =
    uint8_t;
  _profindex_type profindex;
  using _noisepower00_type =
    uint8_t;
  _noisepower00_type noisepower00;
  using _noisepower01_type =
    uint8_t;
  _noisepower01_type noisepower01;
  using _noisepower02_type =
    uint8_t;
  _noisepower02_type noisepower02;
  using _txgainval_type =
    std::array<int16_t, 9>;
  _txgainval_type txgainval;
  using _txphaval_type =
    std::array<uint16_t, 9>;
  _txphaval_type txphaval;
  using _noisepower10_type =
    uint8_t;
  _noisepower10_type noisepower10;
  using _noisepower11_type =
    uint8_t;
  _noisepower11_type noisepower11;
  using _noisepower12_type =
    uint8_t;
  _noisepower12_type noisepower12;
  using _noisepower20_type =
    uint8_t;
  _noisepower20_type noisepower20;
  using _noisepower21_type =
    uint8_t;
  _noisepower21_type noisepower21;
  using _noisepower22_type =
    uint8_t;
  _noisepower22_type noisepower22;
  using _reserved0_type =
    uint8_t;
  _reserved0_type reserved0;
  using _reserved1_type =
    uint8_t;
  _reserved1_type reserved1;
  using _timestamp_type =
    uint32_t;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__statusflags(
    const uint16_t & _arg)
  {
    this->statusflags = _arg;
    return *this;
  }
  Type & set__errorcode(
    const uint16_t & _arg)
  {
    this->errorcode = _arg;
    return *this;
  }
  Type & set__profindex(
    const uint8_t & _arg)
  {
    this->profindex = _arg;
    return *this;
  }
  Type & set__noisepower00(
    const uint8_t & _arg)
  {
    this->noisepower00 = _arg;
    return *this;
  }
  Type & set__noisepower01(
    const uint8_t & _arg)
  {
    this->noisepower01 = _arg;
    return *this;
  }
  Type & set__noisepower02(
    const uint8_t & _arg)
  {
    this->noisepower02 = _arg;
    return *this;
  }
  Type & set__txgainval(
    const std::array<int16_t, 9> & _arg)
  {
    this->txgainval = _arg;
    return *this;
  }
  Type & set__txphaval(
    const std::array<uint16_t, 9> & _arg)
  {
    this->txphaval = _arg;
    return *this;
  }
  Type & set__noisepower10(
    const uint8_t & _arg)
  {
    this->noisepower10 = _arg;
    return *this;
  }
  Type & set__noisepower11(
    const uint8_t & _arg)
  {
    this->noisepower11 = _arg;
    return *this;
  }
  Type & set__noisepower12(
    const uint8_t & _arg)
  {
    this->noisepower12 = _arg;
    return *this;
  }
  Type & set__noisepower20(
    const uint8_t & _arg)
  {
    this->noisepower20 = _arg;
    return *this;
  }
  Type & set__noisepower21(
    const uint8_t & _arg)
  {
    this->noisepower21 = _arg;
    return *this;
  }
  Type & set__noisepower22(
    const uint8_t & _arg)
  {
    this->noisepower22 = _arg;
    return *this;
  }
  Type & set__reserved0(
    const uint8_t & _arg)
  {
    this->reserved0 = _arg;
    return *this;
  }
  Type & set__reserved1(
    const uint8_t & _arg)
  {
    this->reserved1 = _arg;
    return *this;
  }
  Type & set__timestamp(
    const uint32_t & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RlMonTxGainPhaMisRep
    std::shared_ptr<radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RlMonTxGainPhaMisRep
    std::shared_ptr<radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RlMonTxGainPhaMisRep_ & other) const
  {
    if (this->statusflags != other.statusflags) {
      return false;
    }
    if (this->errorcode != other.errorcode) {
      return false;
    }
    if (this->profindex != other.profindex) {
      return false;
    }
    if (this->noisepower00 != other.noisepower00) {
      return false;
    }
    if (this->noisepower01 != other.noisepower01) {
      return false;
    }
    if (this->noisepower02 != other.noisepower02) {
      return false;
    }
    if (this->txgainval != other.txgainval) {
      return false;
    }
    if (this->txphaval != other.txphaval) {
      return false;
    }
    if (this->noisepower10 != other.noisepower10) {
      return false;
    }
    if (this->noisepower11 != other.noisepower11) {
      return false;
    }
    if (this->noisepower12 != other.noisepower12) {
      return false;
    }
    if (this->noisepower20 != other.noisepower20) {
      return false;
    }
    if (this->noisepower21 != other.noisepower21) {
      return false;
    }
    if (this->noisepower22 != other.noisepower22) {
      return false;
    }
    if (this->reserved0 != other.reserved0) {
      return false;
    }
    if (this->reserved1 != other.reserved1) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const RlMonTxGainPhaMisRep_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RlMonTxGainPhaMisRep_

// alias to use template instance with default allocator
using RlMonTxGainPhaMisRep =
  radar_msgs::msg::RlMonTxGainPhaMisRep_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__STRUCT_HPP_
