// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/RlMonTxGainPhaMisRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/RlMonTxGainPhaMisRep in the package radar_msgs.
typedef struct radar_msgs__msg__RlMonTxGainPhaMisRep
{
  uint16_t statusflags;
  uint16_t errorcode;
  uint8_t profindex;
  uint8_t noisepower00;
  uint8_t noisepower01;
  uint8_t noisepower02;
  int16_t txgainval[9];
  uint16_t txphaval[9];
  uint8_t noisepower10;
  uint8_t noisepower11;
  uint8_t noisepower12;
  uint8_t noisepower20;
  uint8_t noisepower21;
  uint8_t noisepower22;
  uint8_t reserved0;
  uint8_t reserved1;
  uint32_t timestamp;
} radar_msgs__msg__RlMonTxGainPhaMisRep;

// Struct for a sequence of radar_msgs__msg__RlMonTxGainPhaMisRep.
typedef struct radar_msgs__msg__RlMonTxGainPhaMisRep__Sequence
{
  radar_msgs__msg__RlMonTxGainPhaMisRep * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__RlMonTxGainPhaMisRep__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_TX_GAIN_PHA_MIS_REP__STRUCT_H_
