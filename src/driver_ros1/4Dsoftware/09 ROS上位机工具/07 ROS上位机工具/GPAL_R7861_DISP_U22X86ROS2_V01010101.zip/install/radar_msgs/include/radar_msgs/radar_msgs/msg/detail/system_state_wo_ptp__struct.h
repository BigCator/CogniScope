// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/SystemStateWoPtp.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_WO_PTP__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_WO_PTP__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'temp'
#include "radar_msgs/msg/detail/system_state_temp__struct.h"
// Member 'load'
#include "radar_msgs/msg/detail/system_stats_load__struct.h"
// Member 'primary_heap'
#include "radar_msgs/msg/detail/system_statsheap__struct.h"
// Member 'heap_arr'
#include "radar_msgs/msg/detail/system_statsheap_arr__struct.h"

/// Struct defined in msg/SystemStateWoPtp in the package radar_msgs.
typedef struct radar_msgs__msg__SystemStateWoPtp
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  radar_msgs__msg__SystemStateTemp temp[5];
  float voltage[5];
  uint32_t freq[10];
  radar_msgs__msg__SystemStatsLoad load[10];
  radar_msgs__msg__SystemStatsheap primary_heap[4];
  radar_msgs__msg__SystemStatsheapArr heap_arr[9];
} radar_msgs__msg__SystemStateWoPtp;

// Struct for a sequence of radar_msgs__msg__SystemStateWoPtp.
typedef struct radar_msgs__msg__SystemStateWoPtp__Sequence
{
  radar_msgs__msg__SystemStateWoPtp * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__SystemStateWoPtp__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_WO_PTP__STRUCT_H_
