// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/SystemStateNew.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_NEW__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_NEW__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__SystemStateNew __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__SystemStateNew __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SystemStateNew_
{
  using Type = SystemStateNew_<ContainerAllocator>;

  explicit SystemStateNew_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->project_code_num.begin(), this->project_code_num.end(), 0);
      this->product_year = 0;
      this->product_month = 0;
      this->product_day = 0;
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->porduct_code.begin(), this->porduct_code.end(), 0);
      std::fill<typename std::array<uint8_t, 40>::iterator, uint8_t>(this->serial_num.begin(), this->serial_num.end(), 0);
      std::fill<typename std::array<uint8_t, 40>::iterator, uint8_t>(this->rfhw_code.begin(), this->rfhw_code.end(), 0);
      this->rfhw_version = 0;
      std::fill<typename std::array<uint8_t, 40>::iterator, uint8_t>(this->dsphw_code.begin(), this->dsphw_code.end(), 0);
      this->dsphw_version = 0;
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->calibrate_code.begin(), this->calibrate_code.end(), 0);
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->os_version.begin(), this->os_version.end(), 0);
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->sw_version.begin(), this->sw_version.end(), 0);
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->algo_version.begin(), this->algo_version.end(), 0);
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->waveform_version.begin(), this->waveform_version.end(), 0);
      this->a72_0_loading = 0;
      this->a72_1_loading = 0;
      this->a72_0_freq = 0ul;
      this->a72_1_freq = 0ul;
      this->mcu_0_freq = 0ul;
      this->mcu_1_freq = 0ul;
      this->mcu_2_freq = 0ul;
      this->mcu_3_freq = 0ul;
      this->lp_mcu_0_freq = 0ul;
      this->lp_mcu_1_freq = 0ul;
      this->c7x_mma_freq = 0ul;
      this->c66x_0_freq = 0ul;
      this->c66x_1_freq = 0ul;
      this->c7x_1_freq = 0ul;
      this->reboot_cnt = 0;
      this->memory_loading = 0;
      this->junction_temp = 0ul;
      this->low_power_mode_enable = 0;
      this->error_code = 0;
      this->blockage_detection = 0;
      this->radar_mode = 0;
      this->udpsend_enpnt = 0;
      this->udpsend_entrk = 0;
      this->udpsend_enrdmap = 0;
      this->udpsend_encfar = 0;
      this->udpsend_enadc = 0;
      this->udpsend_enfft1d = 0;
      this->udpsend_enfft2d = 0;
      this->udpsend_endoa = 0;
      this->radar_txfreq = 0;
      this->frame_triggerdelay = 0;
      this->sync_enable = 0;
      this->sync_radarnum = 0;
      this->antiinterface_enable = 0;
    }
  }

  explicit SystemStateNew_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    project_code_num(_alloc),
    porduct_code(_alloc),
    serial_num(_alloc),
    rfhw_code(_alloc),
    dsphw_code(_alloc),
    calibrate_code(_alloc),
    os_version(_alloc),
    sw_version(_alloc),
    algo_version(_alloc),
    waveform_version(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->project_code_num.begin(), this->project_code_num.end(), 0);
      this->product_year = 0;
      this->product_month = 0;
      this->product_day = 0;
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->porduct_code.begin(), this->porduct_code.end(), 0);
      std::fill<typename std::array<uint8_t, 40>::iterator, uint8_t>(this->serial_num.begin(), this->serial_num.end(), 0);
      std::fill<typename std::array<uint8_t, 40>::iterator, uint8_t>(this->rfhw_code.begin(), this->rfhw_code.end(), 0);
      this->rfhw_version = 0;
      std::fill<typename std::array<uint8_t, 40>::iterator, uint8_t>(this->dsphw_code.begin(), this->dsphw_code.end(), 0);
      this->dsphw_version = 0;
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->calibrate_code.begin(), this->calibrate_code.end(), 0);
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->os_version.begin(), this->os_version.end(), 0);
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->sw_version.begin(), this->sw_version.end(), 0);
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->algo_version.begin(), this->algo_version.end(), 0);
      std::fill<typename std::array<uint8_t, 20>::iterator, uint8_t>(this->waveform_version.begin(), this->waveform_version.end(), 0);
      this->a72_0_loading = 0;
      this->a72_1_loading = 0;
      this->a72_0_freq = 0ul;
      this->a72_1_freq = 0ul;
      this->mcu_0_freq = 0ul;
      this->mcu_1_freq = 0ul;
      this->mcu_2_freq = 0ul;
      this->mcu_3_freq = 0ul;
      this->lp_mcu_0_freq = 0ul;
      this->lp_mcu_1_freq = 0ul;
      this->c7x_mma_freq = 0ul;
      this->c66x_0_freq = 0ul;
      this->c66x_1_freq = 0ul;
      this->c7x_1_freq = 0ul;
      this->reboot_cnt = 0;
      this->memory_loading = 0;
      this->junction_temp = 0ul;
      this->low_power_mode_enable = 0;
      this->error_code = 0;
      this->blockage_detection = 0;
      this->radar_mode = 0;
      this->udpsend_enpnt = 0;
      this->udpsend_entrk = 0;
      this->udpsend_enrdmap = 0;
      this->udpsend_encfar = 0;
      this->udpsend_enadc = 0;
      this->udpsend_enfft1d = 0;
      this->udpsend_enfft2d = 0;
      this->udpsend_endoa = 0;
      this->radar_txfreq = 0;
      this->frame_triggerdelay = 0;
      this->sync_enable = 0;
      this->sync_radarnum = 0;
      this->antiinterface_enable = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _project_code_num_type =
    std::array<uint8_t, 20>;
  _project_code_num_type project_code_num;
  using _product_year_type =
    uint16_t;
  _product_year_type product_year;
  using _product_month_type =
    uint16_t;
  _product_month_type product_month;
  using _product_day_type =
    uint16_t;
  _product_day_type product_day;
  using _porduct_code_type =
    std::array<uint8_t, 20>;
  _porduct_code_type porduct_code;
  using _serial_num_type =
    std::array<uint8_t, 40>;
  _serial_num_type serial_num;
  using _rfhw_code_type =
    std::array<uint8_t, 40>;
  _rfhw_code_type rfhw_code;
  using _rfhw_version_type =
    uint16_t;
  _rfhw_version_type rfhw_version;
  using _dsphw_code_type =
    std::array<uint8_t, 40>;
  _dsphw_code_type dsphw_code;
  using _dsphw_version_type =
    uint16_t;
  _dsphw_version_type dsphw_version;
  using _calibrate_code_type =
    std::array<uint8_t, 20>;
  _calibrate_code_type calibrate_code;
  using _os_version_type =
    std::array<uint8_t, 20>;
  _os_version_type os_version;
  using _sw_version_type =
    std::array<uint8_t, 20>;
  _sw_version_type sw_version;
  using _algo_version_type =
    std::array<uint8_t, 20>;
  _algo_version_type algo_version;
  using _waveform_version_type =
    std::array<uint8_t, 20>;
  _waveform_version_type waveform_version;
  using _a72_0_loading_type =
    uint16_t;
  _a72_0_loading_type a72_0_loading;
  using _a72_1_loading_type =
    uint16_t;
  _a72_1_loading_type a72_1_loading;
  using _a72_0_freq_type =
    uint32_t;
  _a72_0_freq_type a72_0_freq;
  using _a72_1_freq_type =
    uint32_t;
  _a72_1_freq_type a72_1_freq;
  using _mcu_0_freq_type =
    uint32_t;
  _mcu_0_freq_type mcu_0_freq;
  using _mcu_1_freq_type =
    uint32_t;
  _mcu_1_freq_type mcu_1_freq;
  using _mcu_2_freq_type =
    uint32_t;
  _mcu_2_freq_type mcu_2_freq;
  using _mcu_3_freq_type =
    uint32_t;
  _mcu_3_freq_type mcu_3_freq;
  using _lp_mcu_0_freq_type =
    uint32_t;
  _lp_mcu_0_freq_type lp_mcu_0_freq;
  using _lp_mcu_1_freq_type =
    uint32_t;
  _lp_mcu_1_freq_type lp_mcu_1_freq;
  using _c7x_mma_freq_type =
    uint32_t;
  _c7x_mma_freq_type c7x_mma_freq;
  using _c66x_0_freq_type =
    uint32_t;
  _c66x_0_freq_type c66x_0_freq;
  using _c66x_1_freq_type =
    uint32_t;
  _c66x_1_freq_type c66x_1_freq;
  using _c7x_1_freq_type =
    uint32_t;
  _c7x_1_freq_type c7x_1_freq;
  using _reboot_cnt_type =
    uint16_t;
  _reboot_cnt_type reboot_cnt;
  using _memory_loading_type =
    uint16_t;
  _memory_loading_type memory_loading;
  using _junction_temp_type =
    uint32_t;
  _junction_temp_type junction_temp;
  using _low_power_mode_enable_type =
    uint16_t;
  _low_power_mode_enable_type low_power_mode_enable;
  using _error_code_type =
    uint16_t;
  _error_code_type error_code;
  using _blockage_detection_type =
    uint16_t;
  _blockage_detection_type blockage_detection;
  using _radar_mode_type =
    uint16_t;
  _radar_mode_type radar_mode;
  using _udpsend_enpnt_type =
    uint16_t;
  _udpsend_enpnt_type udpsend_enpnt;
  using _udpsend_entrk_type =
    uint16_t;
  _udpsend_entrk_type udpsend_entrk;
  using _udpsend_enrdmap_type =
    uint16_t;
  _udpsend_enrdmap_type udpsend_enrdmap;
  using _udpsend_encfar_type =
    uint16_t;
  _udpsend_encfar_type udpsend_encfar;
  using _udpsend_enadc_type =
    uint16_t;
  _udpsend_enadc_type udpsend_enadc;
  using _udpsend_enfft1d_type =
    uint16_t;
  _udpsend_enfft1d_type udpsend_enfft1d;
  using _udpsend_enfft2d_type =
    uint16_t;
  _udpsend_enfft2d_type udpsend_enfft2d;
  using _udpsend_endoa_type =
    uint16_t;
  _udpsend_endoa_type udpsend_endoa;
  using _radar_txfreq_type =
    uint16_t;
  _radar_txfreq_type radar_txfreq;
  using _frame_triggerdelay_type =
    uint16_t;
  _frame_triggerdelay_type frame_triggerdelay;
  using _sync_enable_type =
    uint16_t;
  _sync_enable_type sync_enable;
  using _sync_radarnum_type =
    uint16_t;
  _sync_radarnum_type sync_radarnum;
  using _antiinterface_enable_type =
    uint16_t;
  _antiinterface_enable_type antiinterface_enable;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__project_code_num(
    const std::array<uint8_t, 20> & _arg)
  {
    this->project_code_num = _arg;
    return *this;
  }
  Type & set__product_year(
    const uint16_t & _arg)
  {
    this->product_year = _arg;
    return *this;
  }
  Type & set__product_month(
    const uint16_t & _arg)
  {
    this->product_month = _arg;
    return *this;
  }
  Type & set__product_day(
    const uint16_t & _arg)
  {
    this->product_day = _arg;
    return *this;
  }
  Type & set__porduct_code(
    const std::array<uint8_t, 20> & _arg)
  {
    this->porduct_code = _arg;
    return *this;
  }
  Type & set__serial_num(
    const std::array<uint8_t, 40> & _arg)
  {
    this->serial_num = _arg;
    return *this;
  }
  Type & set__rfhw_code(
    const std::array<uint8_t, 40> & _arg)
  {
    this->rfhw_code = _arg;
    return *this;
  }
  Type & set__rfhw_version(
    const uint16_t & _arg)
  {
    this->rfhw_version = _arg;
    return *this;
  }
  Type & set__dsphw_code(
    const std::array<uint8_t, 40> & _arg)
  {
    this->dsphw_code = _arg;
    return *this;
  }
  Type & set__dsphw_version(
    const uint16_t & _arg)
  {
    this->dsphw_version = _arg;
    return *this;
  }
  Type & set__calibrate_code(
    const std::array<uint8_t, 20> & _arg)
  {
    this->calibrate_code = _arg;
    return *this;
  }
  Type & set__os_version(
    const std::array<uint8_t, 20> & _arg)
  {
    this->os_version = _arg;
    return *this;
  }
  Type & set__sw_version(
    const std::array<uint8_t, 20> & _arg)
  {
    this->sw_version = _arg;
    return *this;
  }
  Type & set__algo_version(
    const std::array<uint8_t, 20> & _arg)
  {
    this->algo_version = _arg;
    return *this;
  }
  Type & set__waveform_version(
    const std::array<uint8_t, 20> & _arg)
  {
    this->waveform_version = _arg;
    return *this;
  }
  Type & set__a72_0_loading(
    const uint16_t & _arg)
  {
    this->a72_0_loading = _arg;
    return *this;
  }
  Type & set__a72_1_loading(
    const uint16_t & _arg)
  {
    this->a72_1_loading = _arg;
    return *this;
  }
  Type & set__a72_0_freq(
    const uint32_t & _arg)
  {
    this->a72_0_freq = _arg;
    return *this;
  }
  Type & set__a72_1_freq(
    const uint32_t & _arg)
  {
    this->a72_1_freq = _arg;
    return *this;
  }
  Type & set__mcu_0_freq(
    const uint32_t & _arg)
  {
    this->mcu_0_freq = _arg;
    return *this;
  }
  Type & set__mcu_1_freq(
    const uint32_t & _arg)
  {
    this->mcu_1_freq = _arg;
    return *this;
  }
  Type & set__mcu_2_freq(
    const uint32_t & _arg)
  {
    this->mcu_2_freq = _arg;
    return *this;
  }
  Type & set__mcu_3_freq(
    const uint32_t & _arg)
  {
    this->mcu_3_freq = _arg;
    return *this;
  }
  Type & set__lp_mcu_0_freq(
    const uint32_t & _arg)
  {
    this->lp_mcu_0_freq = _arg;
    return *this;
  }
  Type & set__lp_mcu_1_freq(
    const uint32_t & _arg)
  {
    this->lp_mcu_1_freq = _arg;
    return *this;
  }
  Type & set__c7x_mma_freq(
    const uint32_t & _arg)
  {
    this->c7x_mma_freq = _arg;
    return *this;
  }
  Type & set__c66x_0_freq(
    const uint32_t & _arg)
  {
    this->c66x_0_freq = _arg;
    return *this;
  }
  Type & set__c66x_1_freq(
    const uint32_t & _arg)
  {
    this->c66x_1_freq = _arg;
    return *this;
  }
  Type & set__c7x_1_freq(
    const uint32_t & _arg)
  {
    this->c7x_1_freq = _arg;
    return *this;
  }
  Type & set__reboot_cnt(
    const uint16_t & _arg)
  {
    this->reboot_cnt = _arg;
    return *this;
  }
  Type & set__memory_loading(
    const uint16_t & _arg)
  {
    this->memory_loading = _arg;
    return *this;
  }
  Type & set__junction_temp(
    const uint32_t & _arg)
  {
    this->junction_temp = _arg;
    return *this;
  }
  Type & set__low_power_mode_enable(
    const uint16_t & _arg)
  {
    this->low_power_mode_enable = _arg;
    return *this;
  }
  Type & set__error_code(
    const uint16_t & _arg)
  {
    this->error_code = _arg;
    return *this;
  }
  Type & set__blockage_detection(
    const uint16_t & _arg)
  {
    this->blockage_detection = _arg;
    return *this;
  }
  Type & set__radar_mode(
    const uint16_t & _arg)
  {
    this->radar_mode = _arg;
    return *this;
  }
  Type & set__udpsend_enpnt(
    const uint16_t & _arg)
  {
    this->udpsend_enpnt = _arg;
    return *this;
  }
  Type & set__udpsend_entrk(
    const uint16_t & _arg)
  {
    this->udpsend_entrk = _arg;
    return *this;
  }
  Type & set__udpsend_enrdmap(
    const uint16_t & _arg)
  {
    this->udpsend_enrdmap = _arg;
    return *this;
  }
  Type & set__udpsend_encfar(
    const uint16_t & _arg)
  {
    this->udpsend_encfar = _arg;
    return *this;
  }
  Type & set__udpsend_enadc(
    const uint16_t & _arg)
  {
    this->udpsend_enadc = _arg;
    return *this;
  }
  Type & set__udpsend_enfft1d(
    const uint16_t & _arg)
  {
    this->udpsend_enfft1d = _arg;
    return *this;
  }
  Type & set__udpsend_enfft2d(
    const uint16_t & _arg)
  {
    this->udpsend_enfft2d = _arg;
    return *this;
  }
  Type & set__udpsend_endoa(
    const uint16_t & _arg)
  {
    this->udpsend_endoa = _arg;
    return *this;
  }
  Type & set__radar_txfreq(
    const uint16_t & _arg)
  {
    this->radar_txfreq = _arg;
    return *this;
  }
  Type & set__frame_triggerdelay(
    const uint16_t & _arg)
  {
    this->frame_triggerdelay = _arg;
    return *this;
  }
  Type & set__sync_enable(
    const uint16_t & _arg)
  {
    this->sync_enable = _arg;
    return *this;
  }
  Type & set__sync_radarnum(
    const uint16_t & _arg)
  {
    this->sync_radarnum = _arg;
    return *this;
  }
  Type & set__antiinterface_enable(
    const uint16_t & _arg)
  {
    this->antiinterface_enable = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::SystemStateNew_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::SystemStateNew_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::SystemStateNew_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::SystemStateNew_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::SystemStateNew_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::SystemStateNew_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::SystemStateNew_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::SystemStateNew_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::SystemStateNew_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::SystemStateNew_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__SystemStateNew
    std::shared_ptr<radar_msgs::msg::SystemStateNew_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__SystemStateNew
    std::shared_ptr<radar_msgs::msg::SystemStateNew_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SystemStateNew_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->project_code_num != other.project_code_num) {
      return false;
    }
    if (this->product_year != other.product_year) {
      return false;
    }
    if (this->product_month != other.product_month) {
      return false;
    }
    if (this->product_day != other.product_day) {
      return false;
    }
    if (this->porduct_code != other.porduct_code) {
      return false;
    }
    if (this->serial_num != other.serial_num) {
      return false;
    }
    if (this->rfhw_code != other.rfhw_code) {
      return false;
    }
    if (this->rfhw_version != other.rfhw_version) {
      return false;
    }
    if (this->dsphw_code != other.dsphw_code) {
      return false;
    }
    if (this->dsphw_version != other.dsphw_version) {
      return false;
    }
    if (this->calibrate_code != other.calibrate_code) {
      return false;
    }
    if (this->os_version != other.os_version) {
      return false;
    }
    if (this->sw_version != other.sw_version) {
      return false;
    }
    if (this->algo_version != other.algo_version) {
      return false;
    }
    if (this->waveform_version != other.waveform_version) {
      return false;
    }
    if (this->a72_0_loading != other.a72_0_loading) {
      return false;
    }
    if (this->a72_1_loading != other.a72_1_loading) {
      return false;
    }
    if (this->a72_0_freq != other.a72_0_freq) {
      return false;
    }
    if (this->a72_1_freq != other.a72_1_freq) {
      return false;
    }
    if (this->mcu_0_freq != other.mcu_0_freq) {
      return false;
    }
    if (this->mcu_1_freq != other.mcu_1_freq) {
      return false;
    }
    if (this->mcu_2_freq != other.mcu_2_freq) {
      return false;
    }
    if (this->mcu_3_freq != other.mcu_3_freq) {
      return false;
    }
    if (this->lp_mcu_0_freq != other.lp_mcu_0_freq) {
      return false;
    }
    if (this->lp_mcu_1_freq != other.lp_mcu_1_freq) {
      return false;
    }
    if (this->c7x_mma_freq != other.c7x_mma_freq) {
      return false;
    }
    if (this->c66x_0_freq != other.c66x_0_freq) {
      return false;
    }
    if (this->c66x_1_freq != other.c66x_1_freq) {
      return false;
    }
    if (this->c7x_1_freq != other.c7x_1_freq) {
      return false;
    }
    if (this->reboot_cnt != other.reboot_cnt) {
      return false;
    }
    if (this->memory_loading != other.memory_loading) {
      return false;
    }
    if (this->junction_temp != other.junction_temp) {
      return false;
    }
    if (this->low_power_mode_enable != other.low_power_mode_enable) {
      return false;
    }
    if (this->error_code != other.error_code) {
      return false;
    }
    if (this->blockage_detection != other.blockage_detection) {
      return false;
    }
    if (this->radar_mode != other.radar_mode) {
      return false;
    }
    if (this->udpsend_enpnt != other.udpsend_enpnt) {
      return false;
    }
    if (this->udpsend_entrk != other.udpsend_entrk) {
      return false;
    }
    if (this->udpsend_enrdmap != other.udpsend_enrdmap) {
      return false;
    }
    if (this->udpsend_encfar != other.udpsend_encfar) {
      return false;
    }
    if (this->udpsend_enadc != other.udpsend_enadc) {
      return false;
    }
    if (this->udpsend_enfft1d != other.udpsend_enfft1d) {
      return false;
    }
    if (this->udpsend_enfft2d != other.udpsend_enfft2d) {
      return false;
    }
    if (this->udpsend_endoa != other.udpsend_endoa) {
      return false;
    }
    if (this->radar_txfreq != other.radar_txfreq) {
      return false;
    }
    if (this->frame_triggerdelay != other.frame_triggerdelay) {
      return false;
    }
    if (this->sync_enable != other.sync_enable) {
      return false;
    }
    if (this->sync_radarnum != other.sync_radarnum) {
      return false;
    }
    if (this->antiinterface_enable != other.antiinterface_enable) {
      return false;
    }
    return true;
  }
  bool operator!=(const SystemStateNew_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SystemStateNew_

// alias to use template instance with default allocator
using SystemStateNew =
  radar_msgs::msg::SystemStateNew_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_NEW__STRUCT_HPP_
