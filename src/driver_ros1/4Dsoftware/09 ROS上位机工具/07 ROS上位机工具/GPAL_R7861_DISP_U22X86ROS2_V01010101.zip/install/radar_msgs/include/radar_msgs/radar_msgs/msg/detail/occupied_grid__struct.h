// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/OccupiedGrid.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'grid_x'
// Member 'grid_y'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/OccupiedGrid in the package radar_msgs.
typedef struct radar_msgs__msg__OccupiedGrid
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  /// radar ID
  uint32_t radar_id;
  /// frame cnt in radar
  uint32_t frame_cnt;
  /// number of grid
  uint32_t occupied_num;
  /// length of grid along x axis
  float grid_x_length;
  /// length of grid along y axis
  float grid_y_length;
  /// Position x of grid, unit: m
  rosidl_runtime_c__float__Sequence grid_x;
  /// Position y of grid, unit: m
  rosidl_runtime_c__float__Sequence grid_y;
  float reserved_a;
  float reserved_b;
  float reserved_c;
} radar_msgs__msg__OccupiedGrid;

// Struct for a sequence of radar_msgs__msg__OccupiedGrid.
typedef struct radar_msgs__msg__OccupiedGrid__Sequence
{
  radar_msgs__msg__OccupiedGrid * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__OccupiedGrid__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__STRUCT_H_
