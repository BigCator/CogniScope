// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/OccupiedGrid.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/occupied_grid__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `grid_x`
// Member `grid_y`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
radar_msgs__msg__OccupiedGrid__init(radar_msgs__msg__OccupiedGrid * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__OccupiedGrid__fini(msg);
    return false;
  }
  // radar_id
  // frame_cnt
  // occupied_num
  // grid_x_length
  // grid_y_length
  // grid_x
  if (!rosidl_runtime_c__float__Sequence__init(&msg->grid_x, 0)) {
    radar_msgs__msg__OccupiedGrid__fini(msg);
    return false;
  }
  // grid_y
  if (!rosidl_runtime_c__float__Sequence__init(&msg->grid_y, 0)) {
    radar_msgs__msg__OccupiedGrid__fini(msg);
    return false;
  }
  // reserved_a
  // reserved_b
  // reserved_c
  return true;
}

void
radar_msgs__msg__OccupiedGrid__fini(radar_msgs__msg__OccupiedGrid * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // radar_id
  // frame_cnt
  // occupied_num
  // grid_x_length
  // grid_y_length
  // grid_x
  rosidl_runtime_c__float__Sequence__fini(&msg->grid_x);
  // grid_y
  rosidl_runtime_c__float__Sequence__fini(&msg->grid_y);
  // reserved_a
  // reserved_b
  // reserved_c
}

bool
radar_msgs__msg__OccupiedGrid__are_equal(const radar_msgs__msg__OccupiedGrid * lhs, const radar_msgs__msg__OccupiedGrid * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // radar_id
  if (lhs->radar_id != rhs->radar_id) {
    return false;
  }
  // frame_cnt
  if (lhs->frame_cnt != rhs->frame_cnt) {
    return false;
  }
  // occupied_num
  if (lhs->occupied_num != rhs->occupied_num) {
    return false;
  }
  // grid_x_length
  if (lhs->grid_x_length != rhs->grid_x_length) {
    return false;
  }
  // grid_y_length
  if (lhs->grid_y_length != rhs->grid_y_length) {
    return false;
  }
  // grid_x
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->grid_x), &(rhs->grid_x)))
  {
    return false;
  }
  // grid_y
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->grid_y), &(rhs->grid_y)))
  {
    return false;
  }
  // reserved_a
  if (lhs->reserved_a != rhs->reserved_a) {
    return false;
  }
  // reserved_b
  if (lhs->reserved_b != rhs->reserved_b) {
    return false;
  }
  // reserved_c
  if (lhs->reserved_c != rhs->reserved_c) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__OccupiedGrid__copy(
  const radar_msgs__msg__OccupiedGrid * input,
  radar_msgs__msg__OccupiedGrid * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // radar_id
  output->radar_id = input->radar_id;
  // frame_cnt
  output->frame_cnt = input->frame_cnt;
  // occupied_num
  output->occupied_num = input->occupied_num;
  // grid_x_length
  output->grid_x_length = input->grid_x_length;
  // grid_y_length
  output->grid_y_length = input->grid_y_length;
  // grid_x
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->grid_x), &(output->grid_x)))
  {
    return false;
  }
  // grid_y
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->grid_y), &(output->grid_y)))
  {
    return false;
  }
  // reserved_a
  output->reserved_a = input->reserved_a;
  // reserved_b
  output->reserved_b = input->reserved_b;
  // reserved_c
  output->reserved_c = input->reserved_c;
  return true;
}

radar_msgs__msg__OccupiedGrid *
radar_msgs__msg__OccupiedGrid__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__OccupiedGrid * msg = (radar_msgs__msg__OccupiedGrid *)allocator.allocate(sizeof(radar_msgs__msg__OccupiedGrid), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__OccupiedGrid));
  bool success = radar_msgs__msg__OccupiedGrid__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__OccupiedGrid__destroy(radar_msgs__msg__OccupiedGrid * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__OccupiedGrid__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__OccupiedGrid__Sequence__init(radar_msgs__msg__OccupiedGrid__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__OccupiedGrid * data = NULL;

  if (size) {
    data = (radar_msgs__msg__OccupiedGrid *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__OccupiedGrid), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__OccupiedGrid__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__OccupiedGrid__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__OccupiedGrid__Sequence__fini(radar_msgs__msg__OccupiedGrid__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__OccupiedGrid__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__OccupiedGrid__Sequence *
radar_msgs__msg__OccupiedGrid__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__OccupiedGrid__Sequence * array = (radar_msgs__msg__OccupiedGrid__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__OccupiedGrid__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__OccupiedGrid__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__OccupiedGrid__Sequence__destroy(radar_msgs__msg__OccupiedGrid__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__OccupiedGrid__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__OccupiedGrid__Sequence__are_equal(const radar_msgs__msg__OccupiedGrid__Sequence * lhs, const radar_msgs__msg__OccupiedGrid__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__OccupiedGrid__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__OccupiedGrid__Sequence__copy(
  const radar_msgs__msg__OccupiedGrid__Sequence * input,
  radar_msgs__msg__OccupiedGrid__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__OccupiedGrid);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__OccupiedGrid * data =
      (radar_msgs__msg__OccupiedGrid *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__OccupiedGrid__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__OccupiedGrid__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__OccupiedGrid__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
