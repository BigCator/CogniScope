// generated from rosidl_generator_c/resource/idl.h.em
// with input from radar_msgs:msg/SystemStatsLoad.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__SYSTEM_STATS_LOAD_H_
#define RADAR_MSGS__MSG__SYSTEM_STATS_LOAD_H_

#include "radar_msgs/msg/detail/system_stats_load__struct.h"
#include "radar_msgs/msg/detail/system_stats_load__functions.h"
#include "radar_msgs/msg/detail/system_stats_load__type_support.h"

#endif  // RADAR_MSGS__MSG__SYSTEM_STATS_LOAD_H_
