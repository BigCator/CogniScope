// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from radar_msgs:msg/RlRecvdGpAdcData.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "radar_msgs/msg/detail/rl_recvd_gp_adc_data__rosidl_typesupport_introspection_c.h"
#include "radar_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "radar_msgs/msg/detail/rl_recvd_gp_adc_data__functions.h"
#include "radar_msgs/msg/detail/rl_recvd_gp_adc_data__struct.h"


// Include directives for member types
// Member `sensor`
#include "radar_msgs/msg/rl_gp_adc_data.h"
// Member `sensor`
#include "radar_msgs/msg/detail/rl_gp_adc_data__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  radar_msgs__msg__RlRecvdGpAdcData__init(message_memory);
}

void radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_fini_function(void * message_memory)
{
  radar_msgs__msg__RlRecvdGpAdcData__fini(message_memory);
}

size_t radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__size_function__RlRecvdGpAdcData__sensor(
  const void * untyped_member)
{
  (void)untyped_member;
  return 6;
}

const void * radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_const_function__RlRecvdGpAdcData__sensor(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlGpAdcData * member =
    (const radar_msgs__msg__RlGpAdcData *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_function__RlRecvdGpAdcData__sensor(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlGpAdcData * member =
    (radar_msgs__msg__RlGpAdcData *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__fetch_function__RlRecvdGpAdcData__sensor(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlGpAdcData * item =
    ((const radar_msgs__msg__RlGpAdcData *)
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_const_function__RlRecvdGpAdcData__sensor(untyped_member, index));
  radar_msgs__msg__RlGpAdcData * value =
    (radar_msgs__msg__RlGpAdcData *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__assign_function__RlRecvdGpAdcData__sensor(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlGpAdcData * item =
    ((radar_msgs__msg__RlGpAdcData *)
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_function__RlRecvdGpAdcData__sensor(untyped_member, index));
  const radar_msgs__msg__RlGpAdcData * value =
    (const radar_msgs__msg__RlGpAdcData *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__size_function__RlRecvdGpAdcData__reserved0(
  const void * untyped_member)
{
  (void)untyped_member;
  return 4;
}

const void * radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_const_function__RlRecvdGpAdcData__reserved0(
  const void * untyped_member, size_t index)
{
  const uint16_t * member =
    (const uint16_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_function__RlRecvdGpAdcData__reserved0(
  void * untyped_member, size_t index)
{
  uint16_t * member =
    (uint16_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__fetch_function__RlRecvdGpAdcData__reserved0(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_const_function__RlRecvdGpAdcData__reserved0(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__assign_function__RlRecvdGpAdcData__reserved0(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_function__RlRecvdGpAdcData__reserved0(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__size_function__RlRecvdGpAdcData__reserved1(
  const void * untyped_member)
{
  (void)untyped_member;
  return 7;
}

const void * radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_const_function__RlRecvdGpAdcData__reserved1(
  const void * untyped_member, size_t index)
{
  const uint32_t * member =
    (const uint32_t *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_function__RlRecvdGpAdcData__reserved1(
  void * untyped_member, size_t index)
{
  uint32_t * member =
    (uint32_t *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__fetch_function__RlRecvdGpAdcData__reserved1(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint32_t * item =
    ((const uint32_t *)
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_const_function__RlRecvdGpAdcData__reserved1(untyped_member, index));
  uint32_t * value =
    (uint32_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__assign_function__RlRecvdGpAdcData__reserved1(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint32_t * item =
    ((uint32_t *)
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_function__RlRecvdGpAdcData__reserved1(untyped_member, index));
  const uint32_t * value =
    (const uint32_t *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_message_member_array[3] = {
  {
    "sensor",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    6,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RlRecvdGpAdcData, sensor),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__size_function__RlRecvdGpAdcData__sensor,  // size() function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_const_function__RlRecvdGpAdcData__sensor,  // get_const(index) function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_function__RlRecvdGpAdcData__sensor,  // get(index) function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__fetch_function__RlRecvdGpAdcData__sensor,  // fetch(index, &value) function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__assign_function__RlRecvdGpAdcData__sensor,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reserved0",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    4,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RlRecvdGpAdcData, reserved0),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__size_function__RlRecvdGpAdcData__reserved0,  // size() function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_const_function__RlRecvdGpAdcData__reserved0,  // get_const(index) function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_function__RlRecvdGpAdcData__reserved0,  // get(index) function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__fetch_function__RlRecvdGpAdcData__reserved0,  // fetch(index, &value) function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__assign_function__RlRecvdGpAdcData__reserved0,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reserved1",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    7,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RlRecvdGpAdcData, reserved1),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__size_function__RlRecvdGpAdcData__reserved1,  // size() function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_const_function__RlRecvdGpAdcData__reserved1,  // get_const(index) function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__get_function__RlRecvdGpAdcData__reserved1,  // get(index) function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__fetch_function__RlRecvdGpAdcData__reserved1,  // fetch(index, &value) function pointer
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__assign_function__RlRecvdGpAdcData__reserved1,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_message_members = {
  "radar_msgs__msg",  // message namespace
  "RlRecvdGpAdcData",  // message name
  3,  // number of fields
  sizeof(radar_msgs__msg__RlRecvdGpAdcData),
  radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_message_member_array,  // message members
  radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_init_function,  // function to initialize message memory (memory has to be allocated)
  radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_message_type_support_handle = {
  0,
  &radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_radar_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlRecvdGpAdcData)() {
  radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlGpAdcData)();
  if (!radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_message_type_support_handle.typesupport_identifier) {
    radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &radar_msgs__msg__RlRecvdGpAdcData__rosidl_typesupport_introspection_c__RlRecvdGpAdcData_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
