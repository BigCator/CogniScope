// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/SystemStateTemp.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_TEMP__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_TEMP__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/system_state_temp__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SystemStateTemp & msg,
  std::ostream & out)
{
  out << "{";
  // member: min_temp
  {
    out << "min_temp: ";
    rosidl_generator_traits::value_to_yaml(msg.min_temp, out);
    out << ", ";
  }

  // member: max_temp
  {
    out << "max_temp: ";
    rosidl_generator_traits::value_to_yaml(msg.max_temp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SystemStateTemp & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: min_temp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "min_temp: ";
    rosidl_generator_traits::value_to_yaml(msg.min_temp, out);
    out << "\n";
  }

  // member: max_temp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "max_temp: ";
    rosidl_generator_traits::value_to_yaml(msg.max_temp, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SystemStateTemp & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::SystemStateTemp & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::SystemStateTemp & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::SystemStateTemp>()
{
  return "radar_msgs::msg::SystemStateTemp";
}

template<>
inline const char * name<radar_msgs::msg::SystemStateTemp>()
{
  return "radar_msgs/msg/SystemStateTemp";
}

template<>
struct has_fixed_size<radar_msgs::msg::SystemStateTemp>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<radar_msgs::msg::SystemStateTemp>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<radar_msgs::msg::SystemStateTemp>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__SYSTEM_STATE_TEMP__TRAITS_HPP_
