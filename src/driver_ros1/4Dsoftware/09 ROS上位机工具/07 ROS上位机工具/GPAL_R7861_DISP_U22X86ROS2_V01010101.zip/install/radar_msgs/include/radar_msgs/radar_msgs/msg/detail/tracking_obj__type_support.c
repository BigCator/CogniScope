// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from radar_msgs:msg/TrackingObj.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "radar_msgs/msg/detail/tracking_obj__rosidl_typesupport_introspection_c.h"
#include "radar_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "radar_msgs/msg/detail/tracking_obj__functions.h"
#include "radar_msgs/msg/detail/tracking_obj__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `object_id`
// Member `age`
// Member `measurement_status`
// Member `motion_state`
// Member `existance_confidence`
// Member `position_x`
// Member `position_y`
// Member `position_z`
// Member `velocity_x`
// Member `velocity_y`
// Member `velocity_z`
// Member `acceleration_x`
// Member `acceleration_y`
// Member `acceleration_z`
// Member `v2ground_x`
// Member `v2ground_y`
// Member `v2ground_z`
// Member `orientation`
// Member `type`
// Member `car_confidence`
// Member `bike_confidence`
// Member `ped_confidence`
// Member `truck_confidence`
// Member `signboard_confidence`
// Member `ground_confidence`
// Member `obstacle_confidence`
// Member `length`
// Member `width`
// Member `height`
// Member `od_process_time`
// Member `reserved_b`
// Member `reserved_c`
// Member `reserved_d`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  radar_msgs__msg__TrackingObj__init(message_memory);
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_fini_function(void * message_memory)
{
  radar_msgs__msg__TrackingObj__fini(message_memory);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__object_id(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__object_id(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__object_id(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__object_id(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint32_t * item =
    ((const uint32_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__object_id(untyped_member, index));
  uint32_t * value =
    (uint32_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__object_id(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint32_t * item =
    ((uint32_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__object_id(untyped_member, index));
  const uint32_t * value =
    (const uint32_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__object_id(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  rosidl_runtime_c__uint32__Sequence__fini(member);
  return rosidl_runtime_c__uint32__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__age(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__age(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__age(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__age(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__age(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__age(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__age(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__age(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__measurement_status(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__measurement_status(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__measurement_status(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__measurement_status(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__measurement_status(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__measurement_status(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__measurement_status(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__measurement_status(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__motion_state(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__motion_state(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__motion_state(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__motion_state(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__motion_state(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__motion_state(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__motion_state(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__motion_state(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__existance_confidence(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__existance_confidence(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__existance_confidence(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__existance_confidence(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__existance_confidence(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__existance_confidence(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__existance_confidence(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__existance_confidence(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__position_x(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__position_x(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__position_x(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__position_x(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__position_x(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__position_x(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__position_x(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__position_x(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__position_y(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__position_y(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__position_y(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__position_y(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__position_y(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__position_y(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__position_y(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__position_y(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__position_z(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__position_z(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__position_z(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__position_z(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__position_z(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__position_z(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__position_z(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__position_z(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__velocity_x(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__velocity_x(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__velocity_x(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__velocity_x(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__velocity_x(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__velocity_x(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__velocity_x(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__velocity_x(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__velocity_y(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__velocity_y(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__velocity_y(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__velocity_y(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__velocity_y(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__velocity_y(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__velocity_y(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__velocity_y(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__velocity_z(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__velocity_z(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__velocity_z(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__velocity_z(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__velocity_z(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__velocity_z(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__velocity_z(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__velocity_z(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__acceleration_x(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__acceleration_x(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__acceleration_x(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__acceleration_x(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__acceleration_x(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__acceleration_x(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__acceleration_x(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__acceleration_x(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__acceleration_y(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__acceleration_y(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__acceleration_y(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__acceleration_y(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__acceleration_y(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__acceleration_y(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__acceleration_y(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__acceleration_y(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__acceleration_z(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__acceleration_z(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__acceleration_z(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__acceleration_z(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__acceleration_z(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__acceleration_z(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__acceleration_z(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__acceleration_z(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__v2ground_x(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__v2ground_x(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__v2ground_x(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__v2ground_x(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__v2ground_x(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__v2ground_x(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__v2ground_x(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__v2ground_x(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__v2ground_y(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__v2ground_y(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__v2ground_y(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__v2ground_y(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__v2ground_y(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__v2ground_y(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__v2ground_y(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__v2ground_y(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__v2ground_z(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__v2ground_z(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__v2ground_z(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__v2ground_z(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__v2ground_z(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__v2ground_z(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__v2ground_z(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__v2ground_z(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__orientation(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__orientation(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__orientation(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__orientation(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__orientation(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__orientation(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__orientation(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__orientation(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__type(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__type(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__type(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__type(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__type(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__type(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__type(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__type(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__car_confidence(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__car_confidence(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__car_confidence(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__car_confidence(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__car_confidence(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__car_confidence(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__car_confidence(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__car_confidence(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__bike_confidence(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__bike_confidence(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__bike_confidence(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__bike_confidence(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__bike_confidence(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__bike_confidence(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__bike_confidence(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__bike_confidence(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__ped_confidence(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__ped_confidence(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__ped_confidence(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__ped_confidence(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__ped_confidence(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__ped_confidence(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__ped_confidence(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__ped_confidence(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__truck_confidence(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__truck_confidence(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__truck_confidence(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__truck_confidence(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__truck_confidence(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__truck_confidence(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__truck_confidence(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__truck_confidence(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__signboard_confidence(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__signboard_confidence(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__signboard_confidence(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__signboard_confidence(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__signboard_confidence(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__signboard_confidence(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__signboard_confidence(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__signboard_confidence(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__ground_confidence(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__ground_confidence(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__ground_confidence(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__ground_confidence(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__ground_confidence(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__ground_confidence(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__ground_confidence(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__ground_confidence(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__obstacle_confidence(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__obstacle_confidence(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__obstacle_confidence(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__obstacle_confidence(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__obstacle_confidence(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__obstacle_confidence(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__obstacle_confidence(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__obstacle_confidence(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__length(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__length(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__length(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__length(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__length(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__length(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__length(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__length(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__width(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__width(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__width(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__width(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__width(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__width(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__width(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__width(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__height(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__height(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__height(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__height(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__height(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__height(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__height(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__height(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__od_process_time(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__od_process_time(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__od_process_time(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__od_process_time(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__od_process_time(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__od_process_time(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__od_process_time(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__od_process_time(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__reserved_b(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__reserved_b(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__reserved_b(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__reserved_b(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__reserved_b(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__reserved_b(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__reserved_b(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__reserved_b(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__reserved_c(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__reserved_c(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__reserved_c(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__reserved_c(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__reserved_c(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__reserved_c(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__reserved_c(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__reserved_c(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__reserved_d(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__reserved_d(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__reserved_d(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__reserved_d(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__reserved_d(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__reserved_d(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__reserved_d(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__reserved_d(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_message_member_array[37] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "radar_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, radar_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "frame_cnt",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, frame_cnt),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "objnum",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, objnum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "object_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, object_id),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__object_id,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__object_id,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__object_id,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__object_id,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__object_id,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__object_id  // resize(index) function pointer
  },
  {
    "age",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, age),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__age,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__age,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__age,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__age,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__age,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__age  // resize(index) function pointer
  },
  {
    "measurement_status",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, measurement_status),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__measurement_status,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__measurement_status,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__measurement_status,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__measurement_status,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__measurement_status,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__measurement_status  // resize(index) function pointer
  },
  {
    "motion_state",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, motion_state),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__motion_state,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__motion_state,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__motion_state,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__motion_state,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__motion_state,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__motion_state  // resize(index) function pointer
  },
  {
    "existance_confidence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, existance_confidence),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__existance_confidence,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__existance_confidence,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__existance_confidence,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__existance_confidence,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__existance_confidence,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__existance_confidence  // resize(index) function pointer
  },
  {
    "position_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, position_x),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__position_x,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__position_x,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__position_x,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__position_x,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__position_x,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__position_x  // resize(index) function pointer
  },
  {
    "position_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, position_y),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__position_y,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__position_y,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__position_y,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__position_y,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__position_y,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__position_y  // resize(index) function pointer
  },
  {
    "position_z",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, position_z),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__position_z,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__position_z,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__position_z,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__position_z,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__position_z,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__position_z  // resize(index) function pointer
  },
  {
    "velocity_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, velocity_x),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__velocity_x,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__velocity_x,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__velocity_x,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__velocity_x,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__velocity_x,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__velocity_x  // resize(index) function pointer
  },
  {
    "velocity_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, velocity_y),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__velocity_y,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__velocity_y,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__velocity_y,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__velocity_y,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__velocity_y,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__velocity_y  // resize(index) function pointer
  },
  {
    "velocity_z",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, velocity_z),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__velocity_z,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__velocity_z,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__velocity_z,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__velocity_z,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__velocity_z,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__velocity_z  // resize(index) function pointer
  },
  {
    "acceleration_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, acceleration_x),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__acceleration_x,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__acceleration_x,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__acceleration_x,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__acceleration_x,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__acceleration_x,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__acceleration_x  // resize(index) function pointer
  },
  {
    "acceleration_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, acceleration_y),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__acceleration_y,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__acceleration_y,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__acceleration_y,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__acceleration_y,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__acceleration_y,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__acceleration_y  // resize(index) function pointer
  },
  {
    "acceleration_z",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, acceleration_z),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__acceleration_z,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__acceleration_z,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__acceleration_z,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__acceleration_z,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__acceleration_z,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__acceleration_z  // resize(index) function pointer
  },
  {
    "v2ground_x",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, v2ground_x),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__v2ground_x,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__v2ground_x,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__v2ground_x,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__v2ground_x,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__v2ground_x,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__v2ground_x  // resize(index) function pointer
  },
  {
    "v2ground_y",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, v2ground_y),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__v2ground_y,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__v2ground_y,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__v2ground_y,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__v2ground_y,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__v2ground_y,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__v2ground_y  // resize(index) function pointer
  },
  {
    "v2ground_z",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, v2ground_z),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__v2ground_z,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__v2ground_z,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__v2ground_z,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__v2ground_z,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__v2ground_z,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__v2ground_z  // resize(index) function pointer
  },
  {
    "orientation",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, orientation),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__orientation,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__orientation,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__orientation,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__orientation,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__orientation,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__orientation  // resize(index) function pointer
  },
  {
    "type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, type),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__type,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__type,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__type,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__type,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__type,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__type  // resize(index) function pointer
  },
  {
    "car_confidence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, car_confidence),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__car_confidence,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__car_confidence,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__car_confidence,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__car_confidence,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__car_confidence,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__car_confidence  // resize(index) function pointer
  },
  {
    "bike_confidence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, bike_confidence),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__bike_confidence,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__bike_confidence,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__bike_confidence,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__bike_confidence,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__bike_confidence,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__bike_confidence  // resize(index) function pointer
  },
  {
    "ped_confidence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, ped_confidence),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__ped_confidence,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__ped_confidence,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__ped_confidence,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__ped_confidence,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__ped_confidence,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__ped_confidence  // resize(index) function pointer
  },
  {
    "truck_confidence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, truck_confidence),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__truck_confidence,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__truck_confidence,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__truck_confidence,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__truck_confidence,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__truck_confidence,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__truck_confidence  // resize(index) function pointer
  },
  {
    "signboard_confidence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, signboard_confidence),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__signboard_confidence,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__signboard_confidence,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__signboard_confidence,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__signboard_confidence,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__signboard_confidence,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__signboard_confidence  // resize(index) function pointer
  },
  {
    "ground_confidence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, ground_confidence),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__ground_confidence,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__ground_confidence,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__ground_confidence,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__ground_confidence,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__ground_confidence,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__ground_confidence  // resize(index) function pointer
  },
  {
    "obstacle_confidence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, obstacle_confidence),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__obstacle_confidence,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__obstacle_confidence,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__obstacle_confidence,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__obstacle_confidence,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__obstacle_confidence,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__obstacle_confidence  // resize(index) function pointer
  },
  {
    "length",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, length),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__length,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__length,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__length,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__length,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__length,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__length  // resize(index) function pointer
  },
  {
    "width",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, width),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__width,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__width,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__width,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__width,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__width,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__width  // resize(index) function pointer
  },
  {
    "height",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, height),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__height,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__height,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__height,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__height,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__height,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__height  // resize(index) function pointer
  },
  {
    "od_process_time",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, od_process_time),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__od_process_time,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__od_process_time,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__od_process_time,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__od_process_time,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__od_process_time,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__od_process_time  // resize(index) function pointer
  },
  {
    "reserved_b",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, reserved_b),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__reserved_b,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__reserved_b,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__reserved_b,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__reserved_b,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__reserved_b,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__reserved_b  // resize(index) function pointer
  },
  {
    "reserved_c",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, reserved_c),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__reserved_c,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__reserved_c,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__reserved_c,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__reserved_c,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__reserved_c,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__reserved_c  // resize(index) function pointer
  },
  {
    "reserved_d",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__TrackingObj, reserved_d),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__size_function__TrackingObj__reserved_d,  // size() function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_const_function__TrackingObj__reserved_d,  // get_const(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__get_function__TrackingObj__reserved_d,  // get(index) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__fetch_function__TrackingObj__reserved_d,  // fetch(index, &value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__assign_function__TrackingObj__reserved_d,  // assign(index, value) function pointer
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__resize_function__TrackingObj__reserved_d  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_message_members = {
  "radar_msgs__msg",  // message namespace
  "TrackingObj",  // message name
  37,  // number of fields
  sizeof(radar_msgs__msg__TrackingObj),
  radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_message_member_array,  // message members
  radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_init_function,  // function to initialize message memory (memory has to be allocated)
  radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_message_type_support_handle = {
  0,
  &radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_radar_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, TrackingObj)() {
  radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_message_type_support_handle.typesupport_identifier) {
    radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &radar_msgs__msg__TrackingObj__rosidl_typesupport_introspection_c__TrackingObj_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
