// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/PointCnt.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__POINT_CNT__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__POINT_CNT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/point_cnt__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_PointCnt_udprramelostcnt
{
public:
  explicit Init_PointCnt_udprramelostcnt(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::PointCnt udprramelostcnt(::radar_msgs::msg::PointCnt::_udprramelostcnt_type arg)
  {
    msg_.udprramelostcnt = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_afteradcerrcnt
{
public:
  explicit Init_PointCnt_afteradcerrcnt(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_udprramelostcnt afteradcerrcnt(::radar_msgs::msg::PointCnt::_afteradcerrcnt_type arg)
  {
    msg_.afteradcerrcnt = std::move(arg);
    return Init_PointCnt_udprramelostcnt(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_beforeadcerrcnt
{
public:
  explicit Init_PointCnt_beforeadcerrcnt(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_afteradcerrcnt beforeadcerrcnt(::radar_msgs::msg::PointCnt::_beforeadcerrcnt_type arg)
  {
    msg_.beforeadcerrcnt = std::move(arg);
    return Init_PointCnt_afteradcerrcnt(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_framelostcnt
{
public:
  explicit Init_PointCnt_framelostcnt(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_beforeadcerrcnt framelostcnt(::radar_msgs::msg::PointCnt::_framelostcnt_type arg)
  {
    msg_.framelostcnt = std::move(arg);
    return Init_PointCnt_beforeadcerrcnt(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_comprotv_ii
{
public:
  explicit Init_PointCnt_comprotv_ii(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_framelostcnt comprotv_ii(::radar_msgs::msg::PointCnt::_comprotv_ii_type arg)
  {
    msg_.comprotv_ii = std::move(arg);
    return Init_PointCnt_framelostcnt(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_comprotv_i
{
public:
  explicit Init_PointCnt_comprotv_i(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_comprotv_ii comprotv_i(::radar_msgs::msg::PointCnt::_comprotv_i_type arg)
  {
    msg_.comprotv_i = std::move(arg);
    return Init_PointCnt_comprotv_ii(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_odtimeoutcnt
{
public:
  explicit Init_PointCnt_odtimeoutcnt(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_comprotv_i odtimeoutcnt(::radar_msgs::msg::PointCnt::_odtimeoutcnt_type arg)
  {
    msg_.odtimeoutcnt = std::move(arg);
    return Init_PointCnt_comprotv_i(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_caryawrate
{
public:
  explicit Init_PointCnt_caryawrate(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_odtimeoutcnt caryawrate(::radar_msgs::msg::PointCnt::_caryawrate_type arg)
  {
    msg_.caryawrate = std::move(arg);
    return Init_PointCnt_odtimeoutcnt(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_carspeed
{
public:
  explicit Init_PointCnt_carspeed(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_caryawrate carspeed(::radar_msgs::msg::PointCnt::_carspeed_type arg)
  {
    msg_.carspeed = std::move(arg);
    return Init_PointCnt_caryawrate(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_od_process_time
{
public:
  explicit Init_PointCnt_od_process_time(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_carspeed od_process_time(::radar_msgs::msg::PointCnt::_od_process_time_type arg)
  {
    msg_.od_process_time = std::move(arg);
    return Init_PointCnt_carspeed(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_objnum
{
public:
  explicit Init_PointCnt_objnum(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_od_process_time objnum(::radar_msgs::msg::PointCnt::_objnum_type arg)
  {
    msg_.objnum = std::move(arg);
    return Init_PointCnt_od_process_time(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_resetcnt
{
public:
  explicit Init_PointCnt_resetcnt(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_objnum resetcnt(::radar_msgs::msg::PointCnt::_resetcnt_type arg)
  {
    msg_.resetcnt = std::move(arg);
    return Init_PointCnt_objnum(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_target_num
{
public:
  explicit Init_PointCnt_target_num(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_resetcnt target_num(::radar_msgs::msg::PointCnt::_target_num_type arg)
  {
    msg_.target_num = std::move(arg);
    return Init_PointCnt_resetcnt(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_cfar_count
{
public:
  explicit Init_PointCnt_cfar_count(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_target_num cfar_count(::radar_msgs::msg::PointCnt::_cfar_count_type arg)
  {
    msg_.cfar_count = std::move(arg);
    return Init_PointCnt_target_num(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_frame_id
{
public:
  explicit Init_PointCnt_frame_id(::radar_msgs::msg::PointCnt & msg)
  : msg_(msg)
  {}
  Init_PointCnt_cfar_count frame_id(::radar_msgs::msg::PointCnt::_frame_id_type arg)
  {
    msg_.frame_id = std::move(arg);
    return Init_PointCnt_cfar_count(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

class Init_PointCnt_header
{
public:
  Init_PointCnt_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PointCnt_frame_id header(::radar_msgs::msg::PointCnt::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_PointCnt_frame_id(msg_);
  }

private:
  ::radar_msgs::msg::PointCnt msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::PointCnt>()
{
  return radar_msgs::msg::builder::Init_PointCnt_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__POINT_CNT__BUILDER_HPP_
