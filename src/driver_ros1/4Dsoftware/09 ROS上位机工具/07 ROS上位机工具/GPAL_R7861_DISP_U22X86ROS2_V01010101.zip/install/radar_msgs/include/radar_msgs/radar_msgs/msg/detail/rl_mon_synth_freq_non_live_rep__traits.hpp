// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/RlMonSynthFreqNonLiveRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_SYNTH_FREQ_NON_LIVE_REP__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_SYNTH_FREQ_NON_LIVE_REP__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/rl_mon_synth_freq_non_live_rep__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const RlMonSynthFreqNonLiveRep & msg,
  std::ostream & out)
{
  out << "{";
  // member: statusflags
  {
    out << "statusflags: ";
    rosidl_generator_traits::value_to_yaml(msg.statusflags, out);
    out << ", ";
  }

  // member: errorcode
  {
    out << "errorcode: ";
    rosidl_generator_traits::value_to_yaml(msg.errorcode, out);
    out << ", ";
  }

  // member: profindex0
  {
    out << "profindex0: ";
    rosidl_generator_traits::value_to_yaml(msg.profindex0, out);
    out << ", ";
  }

  // member: reserved0
  {
    out << "reserved0: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved0, out);
    out << ", ";
  }

  // member: reserved1
  {
    out << "reserved1: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved1, out);
    out << ", ";
  }

  // member: maxfreqerval0
  {
    out << "maxfreqerval0: ";
    rosidl_generator_traits::value_to_yaml(msg.maxfreqerval0, out);
    out << ", ";
  }

  // member: freqfailcnt0
  {
    out << "freqfailcnt0: ";
    rosidl_generator_traits::value_to_yaml(msg.freqfailcnt0, out);
    out << ", ";
  }

  // member: maxfreqfailtime0
  {
    out << "maxfreqfailtime0: ";
    rosidl_generator_traits::value_to_yaml(msg.maxfreqfailtime0, out);
    out << ", ";
  }

  // member: reserved2
  {
    out << "reserved2: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved2, out);
    out << ", ";
  }

  // member: profindex1
  {
    out << "profindex1: ";
    rosidl_generator_traits::value_to_yaml(msg.profindex1, out);
    out << ", ";
  }

  // member: reserved3
  {
    out << "reserved3: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved3, out);
    out << ", ";
  }

  // member: reserved4
  {
    out << "reserved4: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved4, out);
    out << ", ";
  }

  // member: maxfreqerval1
  {
    out << "maxfreqerval1: ";
    rosidl_generator_traits::value_to_yaml(msg.maxfreqerval1, out);
    out << ", ";
  }

  // member: freqfailcnt1
  {
    out << "freqfailcnt1: ";
    rosidl_generator_traits::value_to_yaml(msg.freqfailcnt1, out);
    out << ", ";
  }

  // member: maxfreqfailtime1
  {
    out << "maxfreqfailtime1: ";
    rosidl_generator_traits::value_to_yaml(msg.maxfreqfailtime1, out);
    out << ", ";
  }

  // member: reserved5
  {
    out << "reserved5: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved5, out);
    out << ", ";
  }

  // member: timestamp
  {
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RlMonSynthFreqNonLiveRep & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: statusflags
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "statusflags: ";
    rosidl_generator_traits::value_to_yaml(msg.statusflags, out);
    out << "\n";
  }

  // member: errorcode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "errorcode: ";
    rosidl_generator_traits::value_to_yaml(msg.errorcode, out);
    out << "\n";
  }

  // member: profindex0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "profindex0: ";
    rosidl_generator_traits::value_to_yaml(msg.profindex0, out);
    out << "\n";
  }

  // member: reserved0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved0: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved0, out);
    out << "\n";
  }

  // member: reserved1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved1: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved1, out);
    out << "\n";
  }

  // member: maxfreqerval0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "maxfreqerval0: ";
    rosidl_generator_traits::value_to_yaml(msg.maxfreqerval0, out);
    out << "\n";
  }

  // member: freqfailcnt0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "freqfailcnt0: ";
    rosidl_generator_traits::value_to_yaml(msg.freqfailcnt0, out);
    out << "\n";
  }

  // member: maxfreqfailtime0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "maxfreqfailtime0: ";
    rosidl_generator_traits::value_to_yaml(msg.maxfreqfailtime0, out);
    out << "\n";
  }

  // member: reserved2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved2: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved2, out);
    out << "\n";
  }

  // member: profindex1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "profindex1: ";
    rosidl_generator_traits::value_to_yaml(msg.profindex1, out);
    out << "\n";
  }

  // member: reserved3
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved3: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved3, out);
    out << "\n";
  }

  // member: reserved4
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved4: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved4, out);
    out << "\n";
  }

  // member: maxfreqerval1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "maxfreqerval1: ";
    rosidl_generator_traits::value_to_yaml(msg.maxfreqerval1, out);
    out << "\n";
  }

  // member: freqfailcnt1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "freqfailcnt1: ";
    rosidl_generator_traits::value_to_yaml(msg.freqfailcnt1, out);
    out << "\n";
  }

  // member: maxfreqfailtime1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "maxfreqfailtime1: ";
    rosidl_generator_traits::value_to_yaml(msg.maxfreqfailtime1, out);
    out << "\n";
  }

  // member: reserved5
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved5: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved5, out);
    out << "\n";
  }

  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RlMonSynthFreqNonLiveRep & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::RlMonSynthFreqNonLiveRep>()
{
  return "radar_msgs::msg::RlMonSynthFreqNonLiveRep";
}

template<>
inline const char * name<radar_msgs::msg::RlMonSynthFreqNonLiveRep>()
{
  return "radar_msgs/msg/RlMonSynthFreqNonLiveRep";
}

template<>
struct has_fixed_size<radar_msgs::msg::RlMonSynthFreqNonLiveRep>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<radar_msgs::msg::RlMonSynthFreqNonLiveRep>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<radar_msgs::msg::RlMonSynthFreqNonLiveRep>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_SYNTH_FREQ_NON_LIVE_REP__TRAITS_HPP_
