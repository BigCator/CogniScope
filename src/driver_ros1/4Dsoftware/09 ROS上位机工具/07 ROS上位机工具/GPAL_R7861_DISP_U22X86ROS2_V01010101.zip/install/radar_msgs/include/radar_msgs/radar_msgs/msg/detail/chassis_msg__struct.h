// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/ChassisMsg.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ChassisMsg in the package radar_msgs.
typedef struct radar_msgs__msg__ChassisMsg
{
  /// packet header
  std_msgs__msg__Header header;
  bool islessinfo;
  uint8_t reserved;
  ///  lessinfo start
  /// yaw
  float vehdynyawratehsc2;
  float vehdynyawratevhsc2;
  /// shift
  int32_t trshftlvrpos_h1hsc2;
  int32_t trshftlvrposv_h1hsc2;
  /// spped
  float vehspdavgdrvnhsc2;
  int32_t vehspdavgdrvnvhsc2;
  float vehspdavgnondrvnhsc2;
  int32_t vehspdavgnondrvnvhsc2;
  /// wheel
  float strgwhlanghsc2;
  int32_t strgwhlangvhsc2;
  /// lessinfo end
  /// more info start
  int16_t ncounter;
  /// inertial
  int64_t itimestamp;
  double flatitude;
  double flongitude;
  float faltitude;
  float faccx;
  float faccy;
  float faccz;
  float fangratex;
  float fangratey;
  float fangratez;
  float fvelnorth;
  float fvelwest;
  float fvelup;
  float fheading;
  float fpitch;
  float froll;
  int8_t nnavstatus;
  /// uint8 nwiperstatus
  /// float32 fdrnvell
  /// float32 fnondrnvell
  /// float32 fdrnvelr
  /// float32 fnondrnvelr
  /// float32 dtrailerangle
  ///  vcu_vehicle_inf0
  int64_t vtimestamp;
  /// float32 fsteeringanglevel
  float fsteeringangle;
  float fspeed;
  float fyawrate;
  float ffrontleftwheelspeed;
  float ffrontrightwheelspeed;
  float frearleftwheelspeed;
  float frearrightwheelspeed;
  uint8_t nshifterposition;
  uint8_t nleftdirectionlamp;
  uint8_t nrightdirectionlamp;
  uint8_t nmainbeamlamp;
  uint8_t ndippedbeamlamp;
  uint8_t nwiperstate;
  float flateralaccel;
  float flongituaccel;
  int16_t nleftdrivenwheelpulsecounters;
  int16_t nrightdrivenwheelpulsecounters;
  int16_t nleftnondrivenwheelpulsecounters;
  int16_t nrightnondrivenwheelpulsecounters;
  uint8_t ndrivemode;
} radar_msgs__msg__ChassisMsg;

// Struct for a sequence of radar_msgs__msg__ChassisMsg.
typedef struct radar_msgs__msg__ChassisMsg__Sequence
{
  radar_msgs__msg__ChassisMsg * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__ChassisMsg__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__STRUCT_H_
