// generated from rosidl_generator_c/resource/idl.h.em
// with input from radar_msgs:msg/AlarmStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__ALARM_STATUS_H_
#define RADAR_MSGS__MSG__ALARM_STATUS_H_

#include "radar_msgs/msg/detail/alarm_status__struct.h"
#include "radar_msgs/msg/detail/alarm_status__functions.h"
#include "radar_msgs/msg/detail/alarm_status__type_support.h"

#endif  // RADAR_MSGS__MSG__ALARM_STATUS_H_
