// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonSynthFreqNonLiveRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_SYNTH_FREQ_NON_LIVE_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_SYNTH_FREQ_NON_LIVE_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_synth_freq_non_live_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonSynthFreqNonLiveRep_timestamp
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_timestamp(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep timestamp(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_reserved5
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_reserved5(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_timestamp reserved5(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_reserved5_type arg)
  {
    msg_.reserved5 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_maxfreqfailtime1
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_maxfreqfailtime1(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_reserved5 maxfreqfailtime1(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_maxfreqfailtime1_type arg)
  {
    msg_.maxfreqfailtime1 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_reserved5(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_freqfailcnt1
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_freqfailcnt1(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_maxfreqfailtime1 freqfailcnt1(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_freqfailcnt1_type arg)
  {
    msg_.freqfailcnt1 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_maxfreqfailtime1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_maxfreqerval1
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_maxfreqerval1(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_freqfailcnt1 maxfreqerval1(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_maxfreqerval1_type arg)
  {
    msg_.maxfreqerval1 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_freqfailcnt1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_reserved4
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_reserved4(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_maxfreqerval1 reserved4(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_reserved4_type arg)
  {
    msg_.reserved4 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_maxfreqerval1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_reserved3
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_reserved3(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_reserved4 reserved3(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_reserved3_type arg)
  {
    msg_.reserved3 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_reserved4(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_profindex1
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_profindex1(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_reserved3 profindex1(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_profindex1_type arg)
  {
    msg_.profindex1 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_reserved3(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_reserved2
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_reserved2(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_profindex1 reserved2(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_reserved2_type arg)
  {
    msg_.reserved2 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_profindex1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_maxfreqfailtime0
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_maxfreqfailtime0(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_reserved2 maxfreqfailtime0(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_maxfreqfailtime0_type arg)
  {
    msg_.maxfreqfailtime0 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_reserved2(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_freqfailcnt0
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_freqfailcnt0(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_maxfreqfailtime0 freqfailcnt0(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_freqfailcnt0_type arg)
  {
    msg_.freqfailcnt0 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_maxfreqfailtime0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_maxfreqerval0
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_maxfreqerval0(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_freqfailcnt0 maxfreqerval0(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_maxfreqerval0_type arg)
  {
    msg_.maxfreqerval0 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_freqfailcnt0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_reserved1
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_reserved1(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_maxfreqerval0 reserved1(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_reserved1_type arg)
  {
    msg_.reserved1 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_maxfreqerval0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_reserved0
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_reserved0(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_reserved1 reserved0(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_reserved1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_profindex0
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_profindex0(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_reserved0 profindex0(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_profindex0_type arg)
  {
    msg_.profindex0 = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_errorcode
{
public:
  explicit Init_RlMonSynthFreqNonLiveRep_errorcode(::radar_msgs::msg::RlMonSynthFreqNonLiveRep & msg)
  : msg_(msg)
  {}
  Init_RlMonSynthFreqNonLiveRep_profindex0 errorcode(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_profindex0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

class Init_RlMonSynthFreqNonLiveRep_statusflags
{
public:
  Init_RlMonSynthFreqNonLiveRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonSynthFreqNonLiveRep_errorcode statusflags(::radar_msgs::msg::RlMonSynthFreqNonLiveRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonSynthFreqNonLiveRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonSynthFreqNonLiveRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonSynthFreqNonLiveRep>()
{
  return radar_msgs::msg::builder::Init_RlMonSynthFreqNonLiveRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_SYNTH_FREQ_NON_LIVE_REP__BUILDER_HPP_
