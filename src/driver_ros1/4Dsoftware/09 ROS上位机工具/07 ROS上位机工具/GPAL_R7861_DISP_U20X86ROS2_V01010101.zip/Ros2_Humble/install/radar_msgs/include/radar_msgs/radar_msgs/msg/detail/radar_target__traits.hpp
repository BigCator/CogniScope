// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/RadarTarget.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/radar_target__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const RadarTarget & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: radar_id
  {
    out << "radar_id: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_id, out);
    out << ", ";
  }

  // member: frame_cnt
  {
    out << "frame_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_cnt, out);
    out << ", ";
  }

  // member: type
  {
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << ", ";
  }

  // member: target_num
  {
    out << "target_num: ";
    rosidl_generator_traits::value_to_yaml(msg.target_num, out);
    out << ", ";
  }

  // member: polar_state
  {
    out << "polar_state: ";
    rosidl_generator_traits::value_to_yaml(msg.polar_state, out);
    out << ", ";
  }

  // member: x
  {
    if (msg.x.size() == 0) {
      out << "x: []";
    } else {
      out << "x: [";
      size_t pending_items = msg.x.size();
      for (auto item : msg.x) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: y
  {
    if (msg.y.size() == 0) {
      out << "y: []";
    } else {
      out << "y: [";
      size_t pending_items = msg.y.size();
      for (auto item : msg.y) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: z
  {
    if (msg.z.size() == 0) {
      out << "z: []";
    } else {
      out << "z: [";
      size_t pending_items = msg.z.size();
      for (auto item : msg.z) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: v
  {
    if (msg.v.size() == 0) {
      out << "v: []";
    } else {
      out << "v: [";
      size_t pending_items = msg.v.size();
      for (auto item : msg.v) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: azimuth
  {
    if (msg.azimuth.size() == 0) {
      out << "azimuth: []";
    } else {
      out << "azimuth: [";
      size_t pending_items = msg.azimuth.size();
      for (auto item : msg.azimuth) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: elevation
  {
    if (msg.elevation.size() == 0) {
      out << "elevation: []";
    } else {
      out << "elevation: [";
      size_t pending_items = msg.elevation.size();
      for (auto item : msg.elevation) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: snr
  {
    if (msg.snr.size() == 0) {
      out << "snr: []";
    } else {
      out << "snr: [";
      size_t pending_items = msg.snr.size();
      for (auto item : msg.snr) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: power
  {
    if (msg.power.size() == 0) {
      out << "power: []";
    } else {
      out << "power: [";
      size_t pending_items = msg.power.size();
      for (auto item : msg.power) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: valid_flg
  {
    if (msg.valid_flg.size() == 0) {
      out << "valid_flg: []";
    } else {
      out << "valid_flg: [";
      size_t pending_items = msg.valid_flg.size();
      for (auto item : msg.valid_flg) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: existance_probability
  {
    if (msg.existance_probability.size() == 0) {
      out << "existance_probability: []";
    } else {
      out << "existance_probability: [";
      size_t pending_items = msg.existance_probability.size();
      for (auto item : msg.existance_probability) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: motion_state
  {
    if (msg.motion_state.size() == 0) {
      out << "motion_state: []";
    } else {
      out << "motion_state: [";
      size_t pending_items = msg.motion_state.size();
      for (auto item : msg.motion_state) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: detection_class
  {
    if (msg.detection_class.size() == 0) {
      out << "detection_class: []";
    } else {
      out << "detection_class: [";
      size_t pending_items = msg.detection_class.size();
      for (auto item : msg.detection_class) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reset_cnt
  {
    if (msg.reset_cnt.size() == 0) {
      out << "reset_cnt: []";
    } else {
      out << "reset_cnt: [";
      size_t pending_items = msg.reset_cnt.size();
      for (auto item : msg.reset_cnt) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: od_timeout_cnt
  {
    if (msg.od_timeout_cnt.size() == 0) {
      out << "od_timeout_cnt: []";
    } else {
      out << "od_timeout_cnt: [";
      size_t pending_items = msg.od_timeout_cnt.size();
      for (auto item : msg.od_timeout_cnt) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_a
  {
    if (msg.reserved_a.size() == 0) {
      out << "reserved_a: []";
    } else {
      out << "reserved_a: [";
      size_t pending_items = msg.reserved_a.size();
      for (auto item : msg.reserved_a) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_b
  {
    if (msg.reserved_b.size() == 0) {
      out << "reserved_b: []";
    } else {
      out << "reserved_b: [";
      size_t pending_items = msg.reserved_b.size();
      for (auto item : msg.reserved_b) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_c
  {
    if (msg.reserved_c.size() == 0) {
      out << "reserved_c: []";
    } else {
      out << "reserved_c: [";
      size_t pending_items = msg.reserved_c.size();
      for (auto item : msg.reserved_c) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_d
  {
    if (msg.reserved_d.size() == 0) {
      out << "reserved_d: []";
    } else {
      out << "reserved_d: [";
      size_t pending_items = msg.reserved_d.size();
      for (auto item : msg.reserved_d) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_e
  {
    if (msg.reserved_e.size() == 0) {
      out << "reserved_e: []";
    } else {
      out << "reserved_e: [";
      size_t pending_items = msg.reserved_e.size();
      for (auto item : msg.reserved_e) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_f
  {
    if (msg.reserved_f.size() == 0) {
      out << "reserved_f: []";
    } else {
      out << "reserved_f: [";
      size_t pending_items = msg.reserved_f.size();
      for (auto item : msg.reserved_f) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_g
  {
    if (msg.reserved_g.size() == 0) {
      out << "reserved_g: []";
    } else {
      out << "reserved_g: [";
      size_t pending_items = msg.reserved_g.size();
      for (auto item : msg.reserved_g) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_h
  {
    if (msg.reserved_h.size() == 0) {
      out << "reserved_h: []";
    } else {
      out << "reserved_h: [";
      size_t pending_items = msg.reserved_h.size();
      for (auto item : msg.reserved_h) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_i
  {
    if (msg.reserved_i.size() == 0) {
      out << "reserved_i: []";
    } else {
      out << "reserved_i: [";
      size_t pending_items = msg.reserved_i.size();
      for (auto item : msg.reserved_i) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_j
  {
    if (msg.reserved_j.size() == 0) {
      out << "reserved_j: []";
    } else {
      out << "reserved_j: [";
      size_t pending_items = msg.reserved_j.size();
      for (auto item : msg.reserved_j) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_k
  {
    if (msg.reserved_k.size() == 0) {
      out << "reserved_k: []";
    } else {
      out << "reserved_k: [";
      size_t pending_items = msg.reserved_k.size();
      for (auto item : msg.reserved_k) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_l
  {
    if (msg.reserved_l.size() == 0) {
      out << "reserved_l: []";
    } else {
      out << "reserved_l: [";
      size_t pending_items = msg.reserved_l.size();
      for (auto item : msg.reserved_l) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_m
  {
    if (msg.reserved_m.size() == 0) {
      out << "reserved_m: []";
    } else {
      out << "reserved_m: [";
      size_t pending_items = msg.reserved_m.size();
      for (auto item : msg.reserved_m) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_n
  {
    if (msg.reserved_n.size() == 0) {
      out << "reserved_n: []";
    } else {
      out << "reserved_n: [";
      size_t pending_items = msg.reserved_n.size();
      for (auto item : msg.reserved_n) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_o
  {
    if (msg.reserved_o.size() == 0) {
      out << "reserved_o: []";
    } else {
      out << "reserved_o: [";
      size_t pending_items = msg.reserved_o.size();
      for (auto item : msg.reserved_o) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RadarTarget & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: radar_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "radar_id: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_id, out);
    out << "\n";
  }

  // member: frame_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_cnt, out);
    out << "\n";
  }

  // member: type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << "\n";
  }

  // member: target_num
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_num: ";
    rosidl_generator_traits::value_to_yaml(msg.target_num, out);
    out << "\n";
  }

  // member: polar_state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "polar_state: ";
    rosidl_generator_traits::value_to_yaml(msg.polar_state, out);
    out << "\n";
  }

  // member: x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.x.size() == 0) {
      out << "x: []\n";
    } else {
      out << "x:\n";
      for (auto item : msg.x) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.y.size() == 0) {
      out << "y: []\n";
    } else {
      out << "y:\n";
      for (auto item : msg.y) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.z.size() == 0) {
      out << "z: []\n";
    } else {
      out << "z:\n";
      for (auto item : msg.z) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: v
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.v.size() == 0) {
      out << "v: []\n";
    } else {
      out << "v:\n";
      for (auto item : msg.v) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: azimuth
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.azimuth.size() == 0) {
      out << "azimuth: []\n";
    } else {
      out << "azimuth:\n";
      for (auto item : msg.azimuth) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: elevation
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.elevation.size() == 0) {
      out << "elevation: []\n";
    } else {
      out << "elevation:\n";
      for (auto item : msg.elevation) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: snr
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.snr.size() == 0) {
      out << "snr: []\n";
    } else {
      out << "snr:\n";
      for (auto item : msg.snr) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: power
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.power.size() == 0) {
      out << "power: []\n";
    } else {
      out << "power:\n";
      for (auto item : msg.power) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: valid_flg
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.valid_flg.size() == 0) {
      out << "valid_flg: []\n";
    } else {
      out << "valid_flg:\n";
      for (auto item : msg.valid_flg) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: existance_probability
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.existance_probability.size() == 0) {
      out << "existance_probability: []\n";
    } else {
      out << "existance_probability:\n";
      for (auto item : msg.existance_probability) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: motion_state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motion_state.size() == 0) {
      out << "motion_state: []\n";
    } else {
      out << "motion_state:\n";
      for (auto item : msg.motion_state) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: detection_class
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.detection_class.size() == 0) {
      out << "detection_class: []\n";
    } else {
      out << "detection_class:\n";
      for (auto item : msg.detection_class) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reset_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reset_cnt.size() == 0) {
      out << "reset_cnt: []\n";
    } else {
      out << "reset_cnt:\n";
      for (auto item : msg.reset_cnt) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: od_timeout_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.od_timeout_cnt.size() == 0) {
      out << "od_timeout_cnt: []\n";
    } else {
      out << "od_timeout_cnt:\n";
      for (auto item : msg.od_timeout_cnt) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_a
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_a.size() == 0) {
      out << "reserved_a: []\n";
    } else {
      out << "reserved_a:\n";
      for (auto item : msg.reserved_a) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_b
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_b.size() == 0) {
      out << "reserved_b: []\n";
    } else {
      out << "reserved_b:\n";
      for (auto item : msg.reserved_b) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_c
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_c.size() == 0) {
      out << "reserved_c: []\n";
    } else {
      out << "reserved_c:\n";
      for (auto item : msg.reserved_c) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_d.size() == 0) {
      out << "reserved_d: []\n";
    } else {
      out << "reserved_d:\n";
      for (auto item : msg.reserved_d) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_e
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_e.size() == 0) {
      out << "reserved_e: []\n";
    } else {
      out << "reserved_e:\n";
      for (auto item : msg.reserved_e) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_f
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_f.size() == 0) {
      out << "reserved_f: []\n";
    } else {
      out << "reserved_f:\n";
      for (auto item : msg.reserved_f) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_g
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_g.size() == 0) {
      out << "reserved_g: []\n";
    } else {
      out << "reserved_g:\n";
      for (auto item : msg.reserved_g) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_h
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_h.size() == 0) {
      out << "reserved_h: []\n";
    } else {
      out << "reserved_h:\n";
      for (auto item : msg.reserved_h) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_i
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_i.size() == 0) {
      out << "reserved_i: []\n";
    } else {
      out << "reserved_i:\n";
      for (auto item : msg.reserved_i) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_j
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_j.size() == 0) {
      out << "reserved_j: []\n";
    } else {
      out << "reserved_j:\n";
      for (auto item : msg.reserved_j) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_k
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_k.size() == 0) {
      out << "reserved_k: []\n";
    } else {
      out << "reserved_k:\n";
      for (auto item : msg.reserved_k) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_l
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_l.size() == 0) {
      out << "reserved_l: []\n";
    } else {
      out << "reserved_l:\n";
      for (auto item : msg.reserved_l) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_m.size() == 0) {
      out << "reserved_m: []\n";
    } else {
      out << "reserved_m:\n";
      for (auto item : msg.reserved_m) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_n
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_n.size() == 0) {
      out << "reserved_n: []\n";
    } else {
      out << "reserved_n:\n";
      for (auto item : msg.reserved_n) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_o
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_o.size() == 0) {
      out << "reserved_o: []\n";
    } else {
      out << "reserved_o:\n";
      for (auto item : msg.reserved_o) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RadarTarget & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::RadarTarget & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::RadarTarget & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::RadarTarget>()
{
  return "radar_msgs::msg::RadarTarget";
}

template<>
inline const char * name<radar_msgs::msg::RadarTarget>()
{
  return "radar_msgs/msg/RadarTarget";
}

template<>
struct has_fixed_size<radar_msgs::msg::RadarTarget>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<radar_msgs::msg::RadarTarget>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<radar_msgs::msg::RadarTarget>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__TRAITS_HPP_
