// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/AlarmStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__AlarmStatus __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__AlarmStatus __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AlarmStatus_
{
  using Type = AlarmStatus_<ContainerAllocator>;

  explicit AlarmStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radarid = 0ul;
      this->framecnt = 0ul;
      this->alarmnum = 0ul;
      this->alarmcode01 = 0;
      this->alarmcode02 = 0;
      this->alarmcode03 = 0;
      this->alarmcode04 = 0;
      this->alarmcode05 = 0;
      this->alarmcode06 = 0;
      this->alarmcode07 = 0;
      this->alarmcode08 = 0;
      this->alarmcode09 = 0;
      this->alarmcode10 = 0;
      this->alarmcode11 = 0;
      this->alarmcode12 = 0;
      this->alarmcode13 = 0;
      this->alarmcode14 = 0;
      this->alarmcode15 = 0;
      this->alarmcode16 = 0;
      this->alarmcode17 = 0;
      this->alarmcode18 = 0;
      this->alarmcode19 = 0;
      this->alarmcode20 = 0;
    }
  }

  explicit AlarmStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radarid = 0ul;
      this->framecnt = 0ul;
      this->alarmnum = 0ul;
      this->alarmcode01 = 0;
      this->alarmcode02 = 0;
      this->alarmcode03 = 0;
      this->alarmcode04 = 0;
      this->alarmcode05 = 0;
      this->alarmcode06 = 0;
      this->alarmcode07 = 0;
      this->alarmcode08 = 0;
      this->alarmcode09 = 0;
      this->alarmcode10 = 0;
      this->alarmcode11 = 0;
      this->alarmcode12 = 0;
      this->alarmcode13 = 0;
      this->alarmcode14 = 0;
      this->alarmcode15 = 0;
      this->alarmcode16 = 0;
      this->alarmcode17 = 0;
      this->alarmcode18 = 0;
      this->alarmcode19 = 0;
      this->alarmcode20 = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _radarid_type =
    uint32_t;
  _radarid_type radarid;
  using _framecnt_type =
    uint32_t;
  _framecnt_type framecnt;
  using _alarmnum_type =
    uint32_t;
  _alarmnum_type alarmnum;
  using _alarmcode01_type =
    uint16_t;
  _alarmcode01_type alarmcode01;
  using _alarmcode02_type =
    uint16_t;
  _alarmcode02_type alarmcode02;
  using _alarmcode03_type =
    uint16_t;
  _alarmcode03_type alarmcode03;
  using _alarmcode04_type =
    uint16_t;
  _alarmcode04_type alarmcode04;
  using _alarmcode05_type =
    uint16_t;
  _alarmcode05_type alarmcode05;
  using _alarmcode06_type =
    uint16_t;
  _alarmcode06_type alarmcode06;
  using _alarmcode07_type =
    uint16_t;
  _alarmcode07_type alarmcode07;
  using _alarmcode08_type =
    uint16_t;
  _alarmcode08_type alarmcode08;
  using _alarmcode09_type =
    uint16_t;
  _alarmcode09_type alarmcode09;
  using _alarmcode10_type =
    uint16_t;
  _alarmcode10_type alarmcode10;
  using _alarmcode11_type =
    uint16_t;
  _alarmcode11_type alarmcode11;
  using _alarmcode12_type =
    uint16_t;
  _alarmcode12_type alarmcode12;
  using _alarmcode13_type =
    uint16_t;
  _alarmcode13_type alarmcode13;
  using _alarmcode14_type =
    uint16_t;
  _alarmcode14_type alarmcode14;
  using _alarmcode15_type =
    uint16_t;
  _alarmcode15_type alarmcode15;
  using _alarmcode16_type =
    uint16_t;
  _alarmcode16_type alarmcode16;
  using _alarmcode17_type =
    uint16_t;
  _alarmcode17_type alarmcode17;
  using _alarmcode18_type =
    uint16_t;
  _alarmcode18_type alarmcode18;
  using _alarmcode19_type =
    uint16_t;
  _alarmcode19_type alarmcode19;
  using _alarmcode20_type =
    uint16_t;
  _alarmcode20_type alarmcode20;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__radarid(
    const uint32_t & _arg)
  {
    this->radarid = _arg;
    return *this;
  }
  Type & set__framecnt(
    const uint32_t & _arg)
  {
    this->framecnt = _arg;
    return *this;
  }
  Type & set__alarmnum(
    const uint32_t & _arg)
  {
    this->alarmnum = _arg;
    return *this;
  }
  Type & set__alarmcode01(
    const uint16_t & _arg)
  {
    this->alarmcode01 = _arg;
    return *this;
  }
  Type & set__alarmcode02(
    const uint16_t & _arg)
  {
    this->alarmcode02 = _arg;
    return *this;
  }
  Type & set__alarmcode03(
    const uint16_t & _arg)
  {
    this->alarmcode03 = _arg;
    return *this;
  }
  Type & set__alarmcode04(
    const uint16_t & _arg)
  {
    this->alarmcode04 = _arg;
    return *this;
  }
  Type & set__alarmcode05(
    const uint16_t & _arg)
  {
    this->alarmcode05 = _arg;
    return *this;
  }
  Type & set__alarmcode06(
    const uint16_t & _arg)
  {
    this->alarmcode06 = _arg;
    return *this;
  }
  Type & set__alarmcode07(
    const uint16_t & _arg)
  {
    this->alarmcode07 = _arg;
    return *this;
  }
  Type & set__alarmcode08(
    const uint16_t & _arg)
  {
    this->alarmcode08 = _arg;
    return *this;
  }
  Type & set__alarmcode09(
    const uint16_t & _arg)
  {
    this->alarmcode09 = _arg;
    return *this;
  }
  Type & set__alarmcode10(
    const uint16_t & _arg)
  {
    this->alarmcode10 = _arg;
    return *this;
  }
  Type & set__alarmcode11(
    const uint16_t & _arg)
  {
    this->alarmcode11 = _arg;
    return *this;
  }
  Type & set__alarmcode12(
    const uint16_t & _arg)
  {
    this->alarmcode12 = _arg;
    return *this;
  }
  Type & set__alarmcode13(
    const uint16_t & _arg)
  {
    this->alarmcode13 = _arg;
    return *this;
  }
  Type & set__alarmcode14(
    const uint16_t & _arg)
  {
    this->alarmcode14 = _arg;
    return *this;
  }
  Type & set__alarmcode15(
    const uint16_t & _arg)
  {
    this->alarmcode15 = _arg;
    return *this;
  }
  Type & set__alarmcode16(
    const uint16_t & _arg)
  {
    this->alarmcode16 = _arg;
    return *this;
  }
  Type & set__alarmcode17(
    const uint16_t & _arg)
  {
    this->alarmcode17 = _arg;
    return *this;
  }
  Type & set__alarmcode18(
    const uint16_t & _arg)
  {
    this->alarmcode18 = _arg;
    return *this;
  }
  Type & set__alarmcode19(
    const uint16_t & _arg)
  {
    this->alarmcode19 = _arg;
    return *this;
  }
  Type & set__alarmcode20(
    const uint16_t & _arg)
  {
    this->alarmcode20 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::AlarmStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::AlarmStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::AlarmStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::AlarmStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::AlarmStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::AlarmStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::AlarmStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::AlarmStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::AlarmStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::AlarmStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__AlarmStatus
    std::shared_ptr<radar_msgs::msg::AlarmStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__AlarmStatus
    std::shared_ptr<radar_msgs::msg::AlarmStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AlarmStatus_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->radarid != other.radarid) {
      return false;
    }
    if (this->framecnt != other.framecnt) {
      return false;
    }
    if (this->alarmnum != other.alarmnum) {
      return false;
    }
    if (this->alarmcode01 != other.alarmcode01) {
      return false;
    }
    if (this->alarmcode02 != other.alarmcode02) {
      return false;
    }
    if (this->alarmcode03 != other.alarmcode03) {
      return false;
    }
    if (this->alarmcode04 != other.alarmcode04) {
      return false;
    }
    if (this->alarmcode05 != other.alarmcode05) {
      return false;
    }
    if (this->alarmcode06 != other.alarmcode06) {
      return false;
    }
    if (this->alarmcode07 != other.alarmcode07) {
      return false;
    }
    if (this->alarmcode08 != other.alarmcode08) {
      return false;
    }
    if (this->alarmcode09 != other.alarmcode09) {
      return false;
    }
    if (this->alarmcode10 != other.alarmcode10) {
      return false;
    }
    if (this->alarmcode11 != other.alarmcode11) {
      return false;
    }
    if (this->alarmcode12 != other.alarmcode12) {
      return false;
    }
    if (this->alarmcode13 != other.alarmcode13) {
      return false;
    }
    if (this->alarmcode14 != other.alarmcode14) {
      return false;
    }
    if (this->alarmcode15 != other.alarmcode15) {
      return false;
    }
    if (this->alarmcode16 != other.alarmcode16) {
      return false;
    }
    if (this->alarmcode17 != other.alarmcode17) {
      return false;
    }
    if (this->alarmcode18 != other.alarmcode18) {
      return false;
    }
    if (this->alarmcode19 != other.alarmcode19) {
      return false;
    }
    if (this->alarmcode20 != other.alarmcode20) {
      return false;
    }
    return true;
  }
  bool operator!=(const AlarmStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AlarmStatus_

// alias to use template instance with default allocator
using AlarmStatus =
  radar_msgs::msg::AlarmStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__STRUCT_HPP_
