// generated from rosidl_generator_c/resource/idl.h.em
// with input from radar_msgs:msg/RlDigLatentFaultReportData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__RL_DIG_LATENT_FAULT_REPORT_DATA_H_
#define RADAR_MSGS__MSG__RL_DIG_LATENT_FAULT_REPORT_DATA_H_

#include "radar_msgs/msg/detail/rl_dig_latent_fault_report_data__struct.h"
#include "radar_msgs/msg/detail/rl_dig_latent_fault_report_data__functions.h"
#include "radar_msgs/msg/detail/rl_dig_latent_fault_report_data__type_support.h"

#endif  // RADAR_MSGS__MSG__RL_DIG_LATENT_FAULT_REPORT_DATA_H_
