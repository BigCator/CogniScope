// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__RL_CAL_MON_TIMING_ERROR_REPORT_DATA_HPP_
#define RADAR_MSGS__MSG__RL_CAL_MON_TIMING_ERROR_REPORT_DATA_HPP_

#include "radar_msgs/msg/detail/rl_cal_mon_timing_error_report_data__struct.hpp"
#include "radar_msgs/msg/detail/rl_cal_mon_timing_error_report_data__builder.hpp"
#include "radar_msgs/msg/detail/rl_cal_mon_timing_error_report_data__traits.hpp"

#endif  // RADAR_MSGS__MSG__RL_CAL_MON_TIMING_ERROR_REPORT_DATA_HPP_
