// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonRxIntAnaSigRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_RX_INT_ANA_SIG_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_RX_INT_ANA_SIG_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_rx_int_ana_sig_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonRxIntAnaSigRep_timestamp
{
public:
  explicit Init_RlMonRxIntAnaSigRep_timestamp(::radar_msgs::msg::RlMonRxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonRxIntAnaSigRep timestamp(::radar_msgs::msg::RlMonRxIntAnaSigRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIntAnaSigRep msg_;
};

class Init_RlMonRxIntAnaSigRep_reserved1
{
public:
  explicit Init_RlMonRxIntAnaSigRep_reserved1(::radar_msgs::msg::RlMonRxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIntAnaSigRep_timestamp reserved1(::radar_msgs::msg::RlMonRxIntAnaSigRep::_reserved1_type arg)
  {
    msg_.reserved1 = std::move(arg);
    return Init_RlMonRxIntAnaSigRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIntAnaSigRep msg_;
};

class Init_RlMonRxIntAnaSigRep_reserved0
{
public:
  explicit Init_RlMonRxIntAnaSigRep_reserved0(::radar_msgs::msg::RlMonRxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIntAnaSigRep_reserved1 reserved0(::radar_msgs::msg::RlMonRxIntAnaSigRep::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlMonRxIntAnaSigRep_reserved1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIntAnaSigRep msg_;
};

class Init_RlMonRxIntAnaSigRep_profindex
{
public:
  explicit Init_RlMonRxIntAnaSigRep_profindex(::radar_msgs::msg::RlMonRxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIntAnaSigRep_reserved0 profindex(::radar_msgs::msg::RlMonRxIntAnaSigRep::_profindex_type arg)
  {
    msg_.profindex = std::move(arg);
    return Init_RlMonRxIntAnaSigRep_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIntAnaSigRep msg_;
};

class Init_RlMonRxIntAnaSigRep_errorcode
{
public:
  explicit Init_RlMonRxIntAnaSigRep_errorcode(::radar_msgs::msg::RlMonRxIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIntAnaSigRep_profindex errorcode(::radar_msgs::msg::RlMonRxIntAnaSigRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonRxIntAnaSigRep_profindex(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIntAnaSigRep msg_;
};

class Init_RlMonRxIntAnaSigRep_statusflags
{
public:
  Init_RlMonRxIntAnaSigRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonRxIntAnaSigRep_errorcode statusflags(::radar_msgs::msg::RlMonRxIntAnaSigRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonRxIntAnaSigRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIntAnaSigRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonRxIntAnaSigRep>()
{
  return radar_msgs::msg::builder::Init_RlMonRxIntAnaSigRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_RX_INT_ANA_SIG_REP__BUILDER_HPP_
