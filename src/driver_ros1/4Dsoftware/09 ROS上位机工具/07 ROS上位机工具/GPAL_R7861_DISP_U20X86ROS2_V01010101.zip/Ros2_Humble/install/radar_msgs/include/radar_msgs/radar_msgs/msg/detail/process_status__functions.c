// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/ProcessStatus.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/process_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
radar_msgs__msg__ProcessStatus__init(radar_msgs__msg__ProcessStatus * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__ProcessStatus__fini(msg);
    return false;
  }
  // radar_id
  // frame_cnt
  // capture_time
  // framelost_cnt
  // adcerrcnt
  // reserved_a
  // reserved_b
  // time1dfft
  // reserved_c
  // reserved_d
  // reserved_e
  // reserved_f
  // time2dfft
  // reserved_g
  // reserved_h
  // reserved_i
  // reserved_j
  // timerdmap
  // reserved_k
  // reserved_l
  // reserved_m
  // reserved_n
  // timecfar
  // reserved_o
  // reserved_p
  // reserved_q
  // reserved_r
  // timedoa
  // reserved_s
  // reserved_t
  // reserved_u
  // reserved_v
  // timepcl
  // reserved_w
  // reserved_x
  // reserved_y
  // reserved_z
  // timeod
  // odtimeoutcnt
  // selfcalistatus
  // reserved_aa
  // reserved_ab
  // reserved_ac
  // reserved_ad
  return true;
}

void
radar_msgs__msg__ProcessStatus__fini(radar_msgs__msg__ProcessStatus * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // radar_id
  // frame_cnt
  // capture_time
  // framelost_cnt
  // adcerrcnt
  // reserved_a
  // reserved_b
  // time1dfft
  // reserved_c
  // reserved_d
  // reserved_e
  // reserved_f
  // time2dfft
  // reserved_g
  // reserved_h
  // reserved_i
  // reserved_j
  // timerdmap
  // reserved_k
  // reserved_l
  // reserved_m
  // reserved_n
  // timecfar
  // reserved_o
  // reserved_p
  // reserved_q
  // reserved_r
  // timedoa
  // reserved_s
  // reserved_t
  // reserved_u
  // reserved_v
  // timepcl
  // reserved_w
  // reserved_x
  // reserved_y
  // reserved_z
  // timeod
  // odtimeoutcnt
  // selfcalistatus
  // reserved_aa
  // reserved_ab
  // reserved_ac
  // reserved_ad
}

bool
radar_msgs__msg__ProcessStatus__are_equal(const radar_msgs__msg__ProcessStatus * lhs, const radar_msgs__msg__ProcessStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // radar_id
  if (lhs->radar_id != rhs->radar_id) {
    return false;
  }
  // frame_cnt
  if (lhs->frame_cnt != rhs->frame_cnt) {
    return false;
  }
  // capture_time
  if (lhs->capture_time != rhs->capture_time) {
    return false;
  }
  // framelost_cnt
  if (lhs->framelost_cnt != rhs->framelost_cnt) {
    return false;
  }
  // adcerrcnt
  if (lhs->adcerrcnt != rhs->adcerrcnt) {
    return false;
  }
  // reserved_a
  if (lhs->reserved_a != rhs->reserved_a) {
    return false;
  }
  // reserved_b
  if (lhs->reserved_b != rhs->reserved_b) {
    return false;
  }
  // time1dfft
  if (lhs->time1dfft != rhs->time1dfft) {
    return false;
  }
  // reserved_c
  if (lhs->reserved_c != rhs->reserved_c) {
    return false;
  }
  // reserved_d
  if (lhs->reserved_d != rhs->reserved_d) {
    return false;
  }
  // reserved_e
  if (lhs->reserved_e != rhs->reserved_e) {
    return false;
  }
  // reserved_f
  if (lhs->reserved_f != rhs->reserved_f) {
    return false;
  }
  // time2dfft
  if (lhs->time2dfft != rhs->time2dfft) {
    return false;
  }
  // reserved_g
  if (lhs->reserved_g != rhs->reserved_g) {
    return false;
  }
  // reserved_h
  if (lhs->reserved_h != rhs->reserved_h) {
    return false;
  }
  // reserved_i
  if (lhs->reserved_i != rhs->reserved_i) {
    return false;
  }
  // reserved_j
  if (lhs->reserved_j != rhs->reserved_j) {
    return false;
  }
  // timerdmap
  if (lhs->timerdmap != rhs->timerdmap) {
    return false;
  }
  // reserved_k
  if (lhs->reserved_k != rhs->reserved_k) {
    return false;
  }
  // reserved_l
  if (lhs->reserved_l != rhs->reserved_l) {
    return false;
  }
  // reserved_m
  if (lhs->reserved_m != rhs->reserved_m) {
    return false;
  }
  // reserved_n
  if (lhs->reserved_n != rhs->reserved_n) {
    return false;
  }
  // timecfar
  if (lhs->timecfar != rhs->timecfar) {
    return false;
  }
  // reserved_o
  if (lhs->reserved_o != rhs->reserved_o) {
    return false;
  }
  // reserved_p
  if (lhs->reserved_p != rhs->reserved_p) {
    return false;
  }
  // reserved_q
  if (lhs->reserved_q != rhs->reserved_q) {
    return false;
  }
  // reserved_r
  if (lhs->reserved_r != rhs->reserved_r) {
    return false;
  }
  // timedoa
  if (lhs->timedoa != rhs->timedoa) {
    return false;
  }
  // reserved_s
  if (lhs->reserved_s != rhs->reserved_s) {
    return false;
  }
  // reserved_t
  if (lhs->reserved_t != rhs->reserved_t) {
    return false;
  }
  // reserved_u
  if (lhs->reserved_u != rhs->reserved_u) {
    return false;
  }
  // reserved_v
  if (lhs->reserved_v != rhs->reserved_v) {
    return false;
  }
  // timepcl
  if (lhs->timepcl != rhs->timepcl) {
    return false;
  }
  // reserved_w
  if (lhs->reserved_w != rhs->reserved_w) {
    return false;
  }
  // reserved_x
  if (lhs->reserved_x != rhs->reserved_x) {
    return false;
  }
  // reserved_y
  if (lhs->reserved_y != rhs->reserved_y) {
    return false;
  }
  // reserved_z
  if (lhs->reserved_z != rhs->reserved_z) {
    return false;
  }
  // timeod
  if (lhs->timeod != rhs->timeod) {
    return false;
  }
  // odtimeoutcnt
  if (lhs->odtimeoutcnt != rhs->odtimeoutcnt) {
    return false;
  }
  // selfcalistatus
  if (lhs->selfcalistatus != rhs->selfcalistatus) {
    return false;
  }
  // reserved_aa
  if (lhs->reserved_aa != rhs->reserved_aa) {
    return false;
  }
  // reserved_ab
  if (lhs->reserved_ab != rhs->reserved_ab) {
    return false;
  }
  // reserved_ac
  if (lhs->reserved_ac != rhs->reserved_ac) {
    return false;
  }
  // reserved_ad
  if (lhs->reserved_ad != rhs->reserved_ad) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__ProcessStatus__copy(
  const radar_msgs__msg__ProcessStatus * input,
  radar_msgs__msg__ProcessStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // radar_id
  output->radar_id = input->radar_id;
  // frame_cnt
  output->frame_cnt = input->frame_cnt;
  // capture_time
  output->capture_time = input->capture_time;
  // framelost_cnt
  output->framelost_cnt = input->framelost_cnt;
  // adcerrcnt
  output->adcerrcnt = input->adcerrcnt;
  // reserved_a
  output->reserved_a = input->reserved_a;
  // reserved_b
  output->reserved_b = input->reserved_b;
  // time1dfft
  output->time1dfft = input->time1dfft;
  // reserved_c
  output->reserved_c = input->reserved_c;
  // reserved_d
  output->reserved_d = input->reserved_d;
  // reserved_e
  output->reserved_e = input->reserved_e;
  // reserved_f
  output->reserved_f = input->reserved_f;
  // time2dfft
  output->time2dfft = input->time2dfft;
  // reserved_g
  output->reserved_g = input->reserved_g;
  // reserved_h
  output->reserved_h = input->reserved_h;
  // reserved_i
  output->reserved_i = input->reserved_i;
  // reserved_j
  output->reserved_j = input->reserved_j;
  // timerdmap
  output->timerdmap = input->timerdmap;
  // reserved_k
  output->reserved_k = input->reserved_k;
  // reserved_l
  output->reserved_l = input->reserved_l;
  // reserved_m
  output->reserved_m = input->reserved_m;
  // reserved_n
  output->reserved_n = input->reserved_n;
  // timecfar
  output->timecfar = input->timecfar;
  // reserved_o
  output->reserved_o = input->reserved_o;
  // reserved_p
  output->reserved_p = input->reserved_p;
  // reserved_q
  output->reserved_q = input->reserved_q;
  // reserved_r
  output->reserved_r = input->reserved_r;
  // timedoa
  output->timedoa = input->timedoa;
  // reserved_s
  output->reserved_s = input->reserved_s;
  // reserved_t
  output->reserved_t = input->reserved_t;
  // reserved_u
  output->reserved_u = input->reserved_u;
  // reserved_v
  output->reserved_v = input->reserved_v;
  // timepcl
  output->timepcl = input->timepcl;
  // reserved_w
  output->reserved_w = input->reserved_w;
  // reserved_x
  output->reserved_x = input->reserved_x;
  // reserved_y
  output->reserved_y = input->reserved_y;
  // reserved_z
  output->reserved_z = input->reserved_z;
  // timeod
  output->timeod = input->timeod;
  // odtimeoutcnt
  output->odtimeoutcnt = input->odtimeoutcnt;
  // selfcalistatus
  output->selfcalistatus = input->selfcalistatus;
  // reserved_aa
  output->reserved_aa = input->reserved_aa;
  // reserved_ab
  output->reserved_ab = input->reserved_ab;
  // reserved_ac
  output->reserved_ac = input->reserved_ac;
  // reserved_ad
  output->reserved_ad = input->reserved_ad;
  return true;
}

radar_msgs__msg__ProcessStatus *
radar_msgs__msg__ProcessStatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__ProcessStatus * msg = (radar_msgs__msg__ProcessStatus *)allocator.allocate(sizeof(radar_msgs__msg__ProcessStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__ProcessStatus));
  bool success = radar_msgs__msg__ProcessStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__ProcessStatus__destroy(radar_msgs__msg__ProcessStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__ProcessStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__ProcessStatus__Sequence__init(radar_msgs__msg__ProcessStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__ProcessStatus * data = NULL;

  if (size) {
    data = (radar_msgs__msg__ProcessStatus *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__ProcessStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__ProcessStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__ProcessStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__ProcessStatus__Sequence__fini(radar_msgs__msg__ProcessStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__ProcessStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__ProcessStatus__Sequence *
radar_msgs__msg__ProcessStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__ProcessStatus__Sequence * array = (radar_msgs__msg__ProcessStatus__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__ProcessStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__ProcessStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__ProcessStatus__Sequence__destroy(radar_msgs__msg__ProcessStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__ProcessStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__ProcessStatus__Sequence__are_equal(const radar_msgs__msg__ProcessStatus__Sequence * lhs, const radar_msgs__msg__ProcessStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__ProcessStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__ProcessStatus__Sequence__copy(
  const radar_msgs__msg__ProcessStatus__Sequence * input,
  radar_msgs__msg__ProcessStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__ProcessStatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__ProcessStatus * data =
      (radar_msgs__msg__ProcessStatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__ProcessStatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__ProcessStatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__ProcessStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
