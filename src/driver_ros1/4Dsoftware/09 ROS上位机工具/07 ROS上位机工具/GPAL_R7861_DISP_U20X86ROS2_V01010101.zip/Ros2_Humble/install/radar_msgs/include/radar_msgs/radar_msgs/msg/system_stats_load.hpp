// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__SYSTEM_STATS_LOAD_HPP_
#define RADAR_MSGS__MSG__SYSTEM_STATS_LOAD_HPP_

#include "radar_msgs/msg/detail/system_stats_load__struct.hpp"
#include "radar_msgs/msg/detail/system_stats_load__builder.hpp"
#include "radar_msgs/msg/detail/system_stats_load__traits.hpp"

#endif  // RADAR_MSGS__MSG__SYSTEM_STATS_LOAD_HPP_
