// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RlMonReportHdrData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_REPORT_HDR_DATA__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_REPORT_HDR_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RlMonReportHdrData __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RlMonReportHdrData __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RlMonReportHdrData_
{
  using Type = RlMonReportHdrData_<ContainerAllocator>;

  explicit RlMonReportHdrData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ftticount = 0ul;
      this->avgtemp = 0;
      this->reserved0 = 0;
      this->reserved1 = 0ul;
    }
  }

  explicit RlMonReportHdrData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ftticount = 0ul;
      this->avgtemp = 0;
      this->reserved0 = 0;
      this->reserved1 = 0ul;
    }
  }

  // field types and members
  using _ftticount_type =
    uint32_t;
  _ftticount_type ftticount;
  using _avgtemp_type =
    uint16_t;
  _avgtemp_type avgtemp;
  using _reserved0_type =
    uint16_t;
  _reserved0_type reserved0;
  using _reserved1_type =
    uint32_t;
  _reserved1_type reserved1;

  // setters for named parameter idiom
  Type & set__ftticount(
    const uint32_t & _arg)
  {
    this->ftticount = _arg;
    return *this;
  }
  Type & set__avgtemp(
    const uint16_t & _arg)
  {
    this->avgtemp = _arg;
    return *this;
  }
  Type & set__reserved0(
    const uint16_t & _arg)
  {
    this->reserved0 = _arg;
    return *this;
  }
  Type & set__reserved1(
    const uint32_t & _arg)
  {
    this->reserved1 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RlMonReportHdrData
    std::shared_ptr<radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RlMonReportHdrData
    std::shared_ptr<radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RlMonReportHdrData_ & other) const
  {
    if (this->ftticount != other.ftticount) {
      return false;
    }
    if (this->avgtemp != other.avgtemp) {
      return false;
    }
    if (this->reserved0 != other.reserved0) {
      return false;
    }
    if (this->reserved1 != other.reserved1) {
      return false;
    }
    return true;
  }
  bool operator!=(const RlMonReportHdrData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RlMonReportHdrData_

// alias to use template instance with default allocator
using RlMonReportHdrData =
  radar_msgs::msg::RlMonReportHdrData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_REPORT_HDR_DATA__STRUCT_HPP_
