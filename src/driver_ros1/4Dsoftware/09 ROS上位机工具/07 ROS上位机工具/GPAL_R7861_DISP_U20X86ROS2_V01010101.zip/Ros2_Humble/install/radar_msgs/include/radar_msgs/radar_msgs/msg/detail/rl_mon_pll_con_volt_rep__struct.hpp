// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RlMonPllConVoltRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_PLL_CON_VOLT_REP__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_PLL_CON_VOLT_REP__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RlMonPllConVoltRep __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RlMonPllConVoltRep __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RlMonPllConVoltRep_
{
  using Type = RlMonPllConVoltRep_<ContainerAllocator>;

  explicit RlMonPllConVoltRep_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      std::fill<typename std::array<int16_t, 8>::iterator, int16_t>(this->pllcontvoltval.begin(), this->pllcontvoltval.end(), 0);
      this->reserved = 0ul;
      this->timestamp = 0ul;
    }
  }

  explicit RlMonPllConVoltRep_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pllcontvoltval(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      std::fill<typename std::array<int16_t, 8>::iterator, int16_t>(this->pllcontvoltval.begin(), this->pllcontvoltval.end(), 0);
      this->reserved = 0ul;
      this->timestamp = 0ul;
    }
  }

  // field types and members
  using _statusflags_type =
    uint16_t;
  _statusflags_type statusflags;
  using _errorcode_type =
    uint16_t;
  _errorcode_type errorcode;
  using _pllcontvoltval_type =
    std::array<int16_t, 8>;
  _pllcontvoltval_type pllcontvoltval;
  using _reserved_type =
    uint32_t;
  _reserved_type reserved;
  using _timestamp_type =
    uint32_t;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__statusflags(
    const uint16_t & _arg)
  {
    this->statusflags = _arg;
    return *this;
  }
  Type & set__errorcode(
    const uint16_t & _arg)
  {
    this->errorcode = _arg;
    return *this;
  }
  Type & set__pllcontvoltval(
    const std::array<int16_t, 8> & _arg)
  {
    this->pllcontvoltval = _arg;
    return *this;
  }
  Type & set__reserved(
    const uint32_t & _arg)
  {
    this->reserved = _arg;
    return *this;
  }
  Type & set__timestamp(
    const uint32_t & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RlMonPllConVoltRep
    std::shared_ptr<radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RlMonPllConVoltRep
    std::shared_ptr<radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RlMonPllConVoltRep_ & other) const
  {
    if (this->statusflags != other.statusflags) {
      return false;
    }
    if (this->errorcode != other.errorcode) {
      return false;
    }
    if (this->pllcontvoltval != other.pllcontvoltval) {
      return false;
    }
    if (this->reserved != other.reserved) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const RlMonPllConVoltRep_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RlMonPllConVoltRep_

// alias to use template instance with default allocator
using RlMonPllConVoltRep =
  radar_msgs::msg::RlMonPllConVoltRep_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_PLL_CON_VOLT_REP__STRUCT_HPP_
