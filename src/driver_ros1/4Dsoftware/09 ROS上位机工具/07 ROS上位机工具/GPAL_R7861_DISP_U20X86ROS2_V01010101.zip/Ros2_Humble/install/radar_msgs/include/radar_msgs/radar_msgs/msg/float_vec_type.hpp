// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__FLOAT_VEC_TYPE_HPP_
#define RADAR_MSGS__MSG__FLOAT_VEC_TYPE_HPP_

#include "radar_msgs/msg/detail/float_vec_type__struct.hpp"
#include "radar_msgs/msg/detail/float_vec_type__builder.hpp"
#include "radar_msgs/msg/detail/float_vec_type__traits.hpp"

#endif  // RADAR_MSGS__MSG__FLOAT_VEC_TYPE_HPP_
