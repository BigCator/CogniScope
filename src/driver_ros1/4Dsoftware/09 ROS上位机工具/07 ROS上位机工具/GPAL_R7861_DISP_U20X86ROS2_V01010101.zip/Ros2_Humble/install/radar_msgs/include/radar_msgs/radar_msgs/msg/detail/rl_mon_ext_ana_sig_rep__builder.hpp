// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonExtAnaSigRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_EXT_ANA_SIG_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_EXT_ANA_SIG_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_ext_ana_sig_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonExtAnaSigRep_timestamp
{
public:
  explicit Init_RlMonExtAnaSigRep_timestamp(::radar_msgs::msg::RlMonExtAnaSigRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonExtAnaSigRep timestamp(::radar_msgs::msg::RlMonExtAnaSigRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonExtAnaSigRep msg_;
};

class Init_RlMonExtAnaSigRep_reserved
{
public:
  explicit Init_RlMonExtAnaSigRep_reserved(::radar_msgs::msg::RlMonExtAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonExtAnaSigRep_timestamp reserved(::radar_msgs::msg::RlMonExtAnaSigRep::_reserved_type arg)
  {
    msg_.reserved = std::move(arg);
    return Init_RlMonExtAnaSigRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonExtAnaSigRep msg_;
};

class Init_RlMonExtAnaSigRep_extanasigval
{
public:
  explicit Init_RlMonExtAnaSigRep_extanasigval(::radar_msgs::msg::RlMonExtAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonExtAnaSigRep_reserved extanasigval(::radar_msgs::msg::RlMonExtAnaSigRep::_extanasigval_type arg)
  {
    msg_.extanasigval = std::move(arg);
    return Init_RlMonExtAnaSigRep_reserved(msg_);
  }

private:
  ::radar_msgs::msg::RlMonExtAnaSigRep msg_;
};

class Init_RlMonExtAnaSigRep_errorcode
{
public:
  explicit Init_RlMonExtAnaSigRep_errorcode(::radar_msgs::msg::RlMonExtAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonExtAnaSigRep_extanasigval errorcode(::radar_msgs::msg::RlMonExtAnaSigRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonExtAnaSigRep_extanasigval(msg_);
  }

private:
  ::radar_msgs::msg::RlMonExtAnaSigRep msg_;
};

class Init_RlMonExtAnaSigRep_statusflags
{
public:
  Init_RlMonExtAnaSigRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonExtAnaSigRep_errorcode statusflags(::radar_msgs::msg::RlMonExtAnaSigRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonExtAnaSigRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonExtAnaSigRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonExtAnaSigRep>()
{
  return radar_msgs::msg::builder::Init_RlMonExtAnaSigRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_EXT_ANA_SIG_REP__BUILDER_HPP_
