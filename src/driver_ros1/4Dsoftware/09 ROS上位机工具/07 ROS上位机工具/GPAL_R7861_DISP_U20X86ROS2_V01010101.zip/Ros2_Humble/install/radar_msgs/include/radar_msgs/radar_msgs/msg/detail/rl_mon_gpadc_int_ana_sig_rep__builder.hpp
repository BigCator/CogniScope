// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonGpadcIntAnaSigRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_GPADC_INT_ANA_SIG_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_GPADC_INT_ANA_SIG_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_gpadc_int_ana_sig_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonGpadcIntAnaSigRep_timestamp
{
public:
  explicit Init_RlMonGpadcIntAnaSigRep_timestamp(::radar_msgs::msg::RlMonGpadcIntAnaSigRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonGpadcIntAnaSigRep timestamp(::radar_msgs::msg::RlMonGpadcIntAnaSigRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonGpadcIntAnaSigRep msg_;
};

class Init_RlMonGpadcIntAnaSigRep_reserved
{
public:
  explicit Init_RlMonGpadcIntAnaSigRep_reserved(::radar_msgs::msg::RlMonGpadcIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonGpadcIntAnaSigRep_timestamp reserved(::radar_msgs::msg::RlMonGpadcIntAnaSigRep::_reserved_type arg)
  {
    msg_.reserved = std::move(arg);
    return Init_RlMonGpadcIntAnaSigRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonGpadcIntAnaSigRep msg_;
};

class Init_RlMonGpadcIntAnaSigRep_gpadcref2val
{
public:
  explicit Init_RlMonGpadcIntAnaSigRep_gpadcref2val(::radar_msgs::msg::RlMonGpadcIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonGpadcIntAnaSigRep_reserved gpadcref2val(::radar_msgs::msg::RlMonGpadcIntAnaSigRep::_gpadcref2val_type arg)
  {
    msg_.gpadcref2val = std::move(arg);
    return Init_RlMonGpadcIntAnaSigRep_reserved(msg_);
  }

private:
  ::radar_msgs::msg::RlMonGpadcIntAnaSigRep msg_;
};

class Init_RlMonGpadcIntAnaSigRep_gpadcref1val
{
public:
  explicit Init_RlMonGpadcIntAnaSigRep_gpadcref1val(::radar_msgs::msg::RlMonGpadcIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonGpadcIntAnaSigRep_gpadcref2val gpadcref1val(::radar_msgs::msg::RlMonGpadcIntAnaSigRep::_gpadcref1val_type arg)
  {
    msg_.gpadcref1val = std::move(arg);
    return Init_RlMonGpadcIntAnaSigRep_gpadcref2val(msg_);
  }

private:
  ::radar_msgs::msg::RlMonGpadcIntAnaSigRep msg_;
};

class Init_RlMonGpadcIntAnaSigRep_errorcode
{
public:
  explicit Init_RlMonGpadcIntAnaSigRep_errorcode(::radar_msgs::msg::RlMonGpadcIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonGpadcIntAnaSigRep_gpadcref1val errorcode(::radar_msgs::msg::RlMonGpadcIntAnaSigRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonGpadcIntAnaSigRep_gpadcref1val(msg_);
  }

private:
  ::radar_msgs::msg::RlMonGpadcIntAnaSigRep msg_;
};

class Init_RlMonGpadcIntAnaSigRep_statusflags
{
public:
  Init_RlMonGpadcIntAnaSigRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonGpadcIntAnaSigRep_errorcode statusflags(::radar_msgs::msg::RlMonGpadcIntAnaSigRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonGpadcIntAnaSigRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonGpadcIntAnaSigRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonGpadcIntAnaSigRep>()
{
  return radar_msgs::msg::builder::Init_RlMonGpadcIntAnaSigRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_GPADC_INT_ANA_SIG_REP__BUILDER_HPP_
