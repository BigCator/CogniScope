// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RfStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RF_STATUS__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RF_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rf_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RfStatus_reporttimingerrordata
{
public:
  explicit Init_RfStatus_reporttimingerrordata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RfStatus reporttimingerrordata(::radar_msgs::msg::RfStatus::_reporttimingerrordata_type arg)
  {
    msg_.reporttimingerrordata = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportanalogfaultdata
{
public:
  explicit Init_RfStatus_reportanalogfaultdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reporttimingerrordata reportanalogfaultdata(::radar_msgs::msg::RfStatus::_reportanalogfaultdata_type arg)
  {
    msg_.reportanalogfaultdata = std::move(arg);
    return Init_RfStatus_reporttimingerrordata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportrecvdgpadcdata
{
public:
  explicit Init_RfStatus_reportrecvdgpadcdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportanalogfaultdata reportrecvdgpadcdata(::radar_msgs::msg::RfStatus::_reportrecvdgpadcdata_type arg)
  {
    msg_.reportrecvdgpadcdata = std::move(arg);
    return Init_RfStatus_reportanalogfaultdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reporttxpowdata
{
public:
  explicit Init_RfStatus_reporttxpowdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportrecvdgpadcdata reporttxpowdata(::radar_msgs::msg::RfStatus::_reporttxpowdata_type arg)
  {
    msg_.reporttxpowdata = std::move(arg);
    return Init_RfStatus_reportrecvdgpadcdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reporttxballbreakdata
{
public:
  explicit Init_RfStatus_reporttxballbreakdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reporttxpowdata reporttxballbreakdata(::radar_msgs::msg::RfStatus::_reporttxballbreakdata_type arg)
  {
    msg_.reporttxballbreakdata = std::move(arg);
    return Init_RfStatus_reporttxpowdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reporttxgainphamisdata
{
public:
  explicit Init_RfStatus_reporttxgainphamisdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reporttxballbreakdata reporttxgainphamisdata(::radar_msgs::msg::RfStatus::_reporttxgainphamisdata_type arg)
  {
    msg_.reporttxgainphamisdata = std::move(arg);
    return Init_RfStatus_reporttxballbreakdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reporttxphshiftdata
{
public:
  explicit Init_RfStatus_reporttxphshiftdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reporttxgainphamisdata reporttxphshiftdata(::radar_msgs::msg::RfStatus::_reporttxphshiftdata_type arg)
  {
    msg_.reporttxphshiftdata = std::move(arg);
    return Init_RfStatus_reporttxgainphamisdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportsynthfreqdata
{
public:
  explicit Init_RfStatus_reportsynthfreqdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reporttxphshiftdata reportsynthfreqdata(::radar_msgs::msg::RfStatus::_reportsynthfreqdata_type arg)
  {
    msg_.reportsynthfreqdata = std::move(arg);
    return Init_RfStatus_reporttxphshiftdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportextanasigdata
{
public:
  explicit Init_RfStatus_reportextanasigdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportsynthfreqdata reportextanasigdata(::radar_msgs::msg::RfStatus::_reportextanasigdata_type arg)
  {
    msg_.reportextanasigdata = std::move(arg);
    return Init_RfStatus_reportsynthfreqdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reporttxintanasigdata
{
public:
  explicit Init_RfStatus_reporttxintanasigdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportextanasigdata reporttxintanasigdata(::radar_msgs::msg::RfStatus::_reporttxintanasigdata_type arg)
  {
    msg_.reporttxintanasigdata = std::move(arg);
    return Init_RfStatus_reportextanasigdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportrxmixrinpwrdata
{
public:
  explicit Init_RfStatus_reportrxmixrinpwrdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reporttxintanasigdata reportrxmixrinpwrdata(::radar_msgs::msg::RfStatus::_reportrxmixrinpwrdata_type arg)
  {
    msg_.reportrxmixrinpwrdata = std::move(arg);
    return Init_RfStatus_reporttxintanasigdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportsynthfreqnonlivedata
{
public:
  explicit Init_RfStatus_reportsynthfreqnonlivedata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportrxmixrinpwrdata reportsynthfreqnonlivedata(::radar_msgs::msg::RfStatus::_reportsynthfreqnonlivedata_type arg)
  {
    msg_.reportsynthfreqnonlivedata = std::move(arg);
    return Init_RfStatus_reportrxmixrinpwrdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportdccclkfreqdata
{
public:
  explicit Init_RfStatus_reportdccclkfreqdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportsynthfreqnonlivedata reportdccclkfreqdata(::radar_msgs::msg::RfStatus::_reportdccclkfreqdata_type arg)
  {
    msg_.reportdccclkfreqdata = std::move(arg);
    return Init_RfStatus_reportsynthfreqnonlivedata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportpllconvoltdata
{
public:
  explicit Init_RfStatus_reportpllconvoltdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportdccclkfreqdata reportpllconvoltdata(::radar_msgs::msg::RfStatus::_reportpllconvoltdata_type arg)
  {
    msg_.reportpllconvoltdata = std::move(arg);
    return Init_RfStatus_reportdccclkfreqdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportgpadcintanasigdata
{
public:
  explicit Init_RfStatus_reportgpadcintanasigdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportpllconvoltdata reportgpadcintanasigdata(::radar_msgs::msg::RfStatus::_reportgpadcintanasigdata_type arg)
  {
    msg_.reportgpadcintanasigdata = std::move(arg);
    return Init_RfStatus_reportpllconvoltdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportpmclklointanasigdata
{
public:
  explicit Init_RfStatus_reportpmclklointanasigdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportgpadcintanasigdata reportpmclklointanasigdata(::radar_msgs::msg::RfStatus::_reportpmclklointanasigdata_type arg)
  {
    msg_.reportpmclklointanasigdata = std::move(arg);
    return Init_RfStatus_reportgpadcintanasigdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportrxintanasigdata
{
public:
  explicit Init_RfStatus_reportrxintanasigdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportpmclklointanasigdata reportrxintanasigdata(::radar_msgs::msg::RfStatus::_reportrxintanasigdata_type arg)
  {
    msg_.reportrxintanasigdata = std::move(arg);
    return Init_RfStatus_reportpmclklointanasigdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportrxifstagedata
{
public:
  explicit Init_RfStatus_reportrxifstagedata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportrxintanasigdata reportrxifstagedata(::radar_msgs::msg::RfStatus::_reportrxifstagedata_type arg)
  {
    msg_.reportrxifstagedata = std::move(arg);
    return Init_RfStatus_reportrxintanasigdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportrxnoisefigdata
{
public:
  explicit Init_RfStatus_reportrxnoisefigdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportrxifstagedata reportrxnoisefigdata(::radar_msgs::msg::RfStatus::_reportrxnoisefigdata_type arg)
  {
    msg_.reportrxnoisefigdata = std::move(arg);
    return Init_RfStatus_reportrxifstagedata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportrxgainphdata
{
public:
  explicit Init_RfStatus_reportrxgainphdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportrxnoisefigdata reportrxgainphdata(::radar_msgs::msg::RfStatus::_reportrxgainphdata_type arg)
  {
    msg_.reportrxgainphdata = std::move(arg);
    return Init_RfStatus_reportrxnoisefigdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_digperiodicreportdata
{
public:
  explicit Init_RfStatus_digperiodicreportdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportrxgainphdata digperiodicreportdata(::radar_msgs::msg::RfStatus::_digperiodicreportdata_type arg)
  {
    msg_.digperiodicreportdata = std::move(arg);
    return Init_RfStatus_reportrxgainphdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reporttempdata
{
public:
  explicit Init_RfStatus_reporttempdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_digperiodicreportdata reporttempdata(::radar_msgs::msg::RfStatus::_reporttempdata_type arg)
  {
    msg_.reporttempdata = std::move(arg);
    return Init_RfStatus_digperiodicreportdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_reportheaderdata
{
public:
  explicit Init_RfStatus_reportheaderdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reporttempdata reportheaderdata(::radar_msgs::msg::RfStatus::_reportheaderdata_type arg)
  {
    msg_.reportheaderdata = std::move(arg);
    return Init_RfStatus_reporttempdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_diglatentfaultdata
{
public:
  explicit Init_RfStatus_diglatentfaultdata(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_reportheaderdata diglatentfaultdata(::radar_msgs::msg::RfStatus::_diglatentfaultdata_type arg)
  {
    msg_.diglatentfaultdata = std::move(arg);
    return Init_RfStatus_reportheaderdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_framecnt
{
public:
  explicit Init_RfStatus_framecnt(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_diglatentfaultdata framecnt(::radar_msgs::msg::RfStatus::_framecnt_type arg)
  {
    msg_.framecnt = std::move(arg);
    return Init_RfStatus_diglatentfaultdata(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_radarid
{
public:
  explicit Init_RfStatus_radarid(::radar_msgs::msg::RfStatus & msg)
  : msg_(msg)
  {}
  Init_RfStatus_framecnt radarid(::radar_msgs::msg::RfStatus::_radarid_type arg)
  {
    msg_.radarid = std::move(arg);
    return Init_RfStatus_framecnt(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

class Init_RfStatus_header
{
public:
  Init_RfStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RfStatus_radarid header(::radar_msgs::msg::RfStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_RfStatus_radarid(msg_);
  }

private:
  ::radar_msgs::msg::RfStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RfStatus>()
{
  return radar_msgs::msg::builder::Init_RfStatus_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RF_STATUS__BUILDER_HPP_
