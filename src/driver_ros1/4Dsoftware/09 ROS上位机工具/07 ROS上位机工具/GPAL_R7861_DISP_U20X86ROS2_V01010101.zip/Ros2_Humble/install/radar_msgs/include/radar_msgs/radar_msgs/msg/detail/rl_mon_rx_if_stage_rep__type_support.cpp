// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from radar_msgs:msg/RlMonRxIfStageRep.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "radar_msgs/msg/detail/rl_mon_rx_if_stage_rep__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace radar_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void RlMonRxIfStageRep_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) radar_msgs::msg::RlMonRxIfStageRep(_init);
}

void RlMonRxIfStageRep_fini_function(void * message_memory)
{
  auto typed_message = static_cast<radar_msgs::msg::RlMonRxIfStageRep *>(message_memory);
  typed_message->~RlMonRxIfStageRep();
}

size_t size_function__RlMonRxIfStageRep__hpfcutofffreqer(const void * untyped_member)
{
  (void)untyped_member;
  return 8;
}

const void * get_const_function__RlMonRxIfStageRep__hpfcutofffreqer(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<int8_t, 8> *>(untyped_member);
  return &member[index];
}

void * get_function__RlMonRxIfStageRep__hpfcutofffreqer(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<int8_t, 8> *>(untyped_member);
  return &member[index];
}

void fetch_function__RlMonRxIfStageRep__hpfcutofffreqer(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const int8_t *>(
    get_const_function__RlMonRxIfStageRep__hpfcutofffreqer(untyped_member, index));
  auto & value = *reinterpret_cast<int8_t *>(untyped_value);
  value = item;
}

void assign_function__RlMonRxIfStageRep__hpfcutofffreqer(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<int8_t *>(
    get_function__RlMonRxIfStageRep__hpfcutofffreqer(untyped_member, index));
  const auto & value = *reinterpret_cast<const int8_t *>(untyped_value);
  item = value;
}

size_t size_function__RlMonRxIfStageRep__lpfcutoffstopbandatten(const void * untyped_member)
{
  (void)untyped_member;
  return 8;
}

const void * get_const_function__RlMonRxIfStageRep__lpfcutoffstopbandatten(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<int8_t, 8> *>(untyped_member);
  return &member[index];
}

void * get_function__RlMonRxIfStageRep__lpfcutoffstopbandatten(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<int8_t, 8> *>(untyped_member);
  return &member[index];
}

void fetch_function__RlMonRxIfStageRep__lpfcutoffstopbandatten(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const int8_t *>(
    get_const_function__RlMonRxIfStageRep__lpfcutoffstopbandatten(untyped_member, index));
  auto & value = *reinterpret_cast<int8_t *>(untyped_value);
  value = item;
}

void assign_function__RlMonRxIfStageRep__lpfcutoffstopbandatten(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<int8_t *>(
    get_function__RlMonRxIfStageRep__lpfcutoffstopbandatten(untyped_member, index));
  const auto & value = *reinterpret_cast<const int8_t *>(untyped_value);
  item = value;
}

size_t size_function__RlMonRxIfStageRep__rxifagainerval(const void * untyped_member)
{
  (void)untyped_member;
  return 8;
}

const void * get_const_function__RlMonRxIfStageRep__rxifagainerval(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<int8_t, 8> *>(untyped_member);
  return &member[index];
}

void * get_function__RlMonRxIfStageRep__rxifagainerval(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<int8_t, 8> *>(untyped_member);
  return &member[index];
}

void fetch_function__RlMonRxIfStageRep__rxifagainerval(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const int8_t *>(
    get_const_function__RlMonRxIfStageRep__rxifagainerval(untyped_member, index));
  auto & value = *reinterpret_cast<int8_t *>(untyped_value);
  value = item;
}

void assign_function__RlMonRxIfStageRep__rxifagainerval(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<int8_t *>(
    get_function__RlMonRxIfStageRep__rxifagainerval(untyped_member, index));
  const auto & value = *reinterpret_cast<const int8_t *>(untyped_value);
  item = value;
}

size_t size_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx(const void * untyped_member)
{
  (void)untyped_member;
  return 6;
}

const void * get_const_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<int8_t, 6> *>(untyped_member);
  return &member[index];
}

void * get_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<int8_t, 6> *>(untyped_member);
  return &member[index];
}

void fetch_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const int8_t *>(
    get_const_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx(untyped_member, index));
  auto & value = *reinterpret_cast<int8_t *>(untyped_value);
  value = item;
}

void assign_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<int8_t *>(
    get_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx(untyped_member, index));
  const auto & value = *reinterpret_cast<const int8_t *>(untyped_value);
  item = value;
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember RlMonRxIfStageRep_message_member_array[12] = {
  {
    "statusflags",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, statusflags),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "errorcode",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, errorcode),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "profindex",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, profindex),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reserved0",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, reserved0),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "lpfcutoffbandedgedroopvalrx0",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, lpfcutoffbandedgedroopvalrx0),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "hpfcutofffreqer",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    8,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, hpfcutofffreqer),  // bytes offset in struct
    nullptr,  // default value
    size_function__RlMonRxIfStageRep__hpfcutofffreqer,  // size() function pointer
    get_const_function__RlMonRxIfStageRep__hpfcutofffreqer,  // get_const(index) function pointer
    get_function__RlMonRxIfStageRep__hpfcutofffreqer,  // get(index) function pointer
    fetch_function__RlMonRxIfStageRep__hpfcutofffreqer,  // fetch(index, &value) function pointer
    assign_function__RlMonRxIfStageRep__hpfcutofffreqer,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "lpfcutoffstopbandatten",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    8,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, lpfcutoffstopbandatten),  // bytes offset in struct
    nullptr,  // default value
    size_function__RlMonRxIfStageRep__lpfcutoffstopbandatten,  // size() function pointer
    get_const_function__RlMonRxIfStageRep__lpfcutoffstopbandatten,  // get_const(index) function pointer
    get_function__RlMonRxIfStageRep__lpfcutoffstopbandatten,  // get(index) function pointer
    fetch_function__RlMonRxIfStageRep__lpfcutoffstopbandatten,  // fetch(index, &value) function pointer
    assign_function__RlMonRxIfStageRep__lpfcutoffstopbandatten,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "rxifagainerval",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    8,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, rxifagainerval),  // bytes offset in struct
    nullptr,  // default value
    size_function__RlMonRxIfStageRep__rxifagainerval,  // size() function pointer
    get_const_function__RlMonRxIfStageRep__rxifagainerval,  // get_const(index) function pointer
    get_function__RlMonRxIfStageRep__rxifagainerval,  // get(index) function pointer
    fetch_function__RlMonRxIfStageRep__rxifagainerval,  // fetch(index, &value) function pointer
    assign_function__RlMonRxIfStageRep__rxifagainerval,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "ifgainexp",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, ifgainexp),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reserved2",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, reserved2),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "lpfcutoffbandedgedroopvalrx",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    6,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, lpfcutoffbandedgedroopvalrx),  // bytes offset in struct
    nullptr,  // default value
    size_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx,  // size() function pointer
    get_const_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx,  // get_const(index) function pointer
    get_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx,  // get(index) function pointer
    fetch_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx,  // fetch(index, &value) function pointer
    assign_function__RlMonRxIfStageRep__lpfcutoffbandedgedroopvalrx,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "timestamp",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RlMonRxIfStageRep, timestamp),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers RlMonRxIfStageRep_message_members = {
  "radar_msgs::msg",  // message namespace
  "RlMonRxIfStageRep",  // message name
  12,  // number of fields
  sizeof(radar_msgs::msg::RlMonRxIfStageRep),
  RlMonRxIfStageRep_message_member_array,  // message members
  RlMonRxIfStageRep_init_function,  // function to initialize message memory (memory has to be allocated)
  RlMonRxIfStageRep_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t RlMonRxIfStageRep_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &RlMonRxIfStageRep_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace radar_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<radar_msgs::msg::RlMonRxIfStageRep>()
{
  return &::radar_msgs::msg::rosidl_typesupport_introspection_cpp::RlMonRxIfStageRep_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, radar_msgs, msg, RlMonRxIfStageRep)() {
  return &::radar_msgs::msg::rosidl_typesupport_introspection_cpp::RlMonRxIfStageRep_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
