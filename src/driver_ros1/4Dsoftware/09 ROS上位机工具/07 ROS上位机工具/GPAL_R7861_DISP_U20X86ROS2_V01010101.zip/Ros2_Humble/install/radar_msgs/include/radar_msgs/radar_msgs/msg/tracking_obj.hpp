// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__TRACKING_OBJ_HPP_
#define RADAR_MSGS__MSG__TRACKING_OBJ_HPP_

#include "radar_msgs/msg/detail/tracking_obj__struct.hpp"
#include "radar_msgs/msg/detail/tracking_obj__builder.hpp"
#include "radar_msgs/msg/detail/tracking_obj__traits.hpp"

#endif  // RADAR_MSGS__MSG__TRACKING_OBJ_HPP_
