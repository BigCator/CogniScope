// generated from rosidl_generator_c/resource/idl.h.em
// with input from radar_msgs:msg/TrackingObjArray.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__TRACKING_OBJ_ARRAY_H_
#define RADAR_MSGS__MSG__TRACKING_OBJ_ARRAY_H_

#include "radar_msgs/msg/detail/tracking_obj_array__struct.h"
#include "radar_msgs/msg/detail/tracking_obj_array__functions.h"
#include "radar_msgs/msg/detail/tracking_obj_array__type_support.h"

#endif  // RADAR_MSGS__MSG__TRACKING_OBJ_ARRAY_H_
