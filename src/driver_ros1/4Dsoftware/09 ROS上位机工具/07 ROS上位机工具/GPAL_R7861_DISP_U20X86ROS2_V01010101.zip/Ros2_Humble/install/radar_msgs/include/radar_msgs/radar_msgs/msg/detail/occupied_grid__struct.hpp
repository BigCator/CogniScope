// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/OccupiedGrid.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__OccupiedGrid __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__OccupiedGrid __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct OccupiedGrid_
{
  using Type = OccupiedGrid_<ContainerAllocator>;

  explicit OccupiedGrid_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radar_id = 0ul;
      this->frame_cnt = 0ul;
      this->occupied_num = 0ul;
      this->grid_x_length = 0.0f;
      this->grid_y_length = 0.0f;
      this->reserved_a = 0.0f;
      this->reserved_b = 0.0f;
      this->reserved_c = 0.0f;
    }
  }

  explicit OccupiedGrid_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radar_id = 0ul;
      this->frame_cnt = 0ul;
      this->occupied_num = 0ul;
      this->grid_x_length = 0.0f;
      this->grid_y_length = 0.0f;
      this->reserved_a = 0.0f;
      this->reserved_b = 0.0f;
      this->reserved_c = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _radar_id_type =
    uint32_t;
  _radar_id_type radar_id;
  using _frame_cnt_type =
    uint32_t;
  _frame_cnt_type frame_cnt;
  using _occupied_num_type =
    uint32_t;
  _occupied_num_type occupied_num;
  using _grid_x_length_type =
    float;
  _grid_x_length_type grid_x_length;
  using _grid_y_length_type =
    float;
  _grid_y_length_type grid_y_length;
  using _grid_x_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _grid_x_type grid_x;
  using _grid_y_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _grid_y_type grid_y;
  using _reserved_a_type =
    float;
  _reserved_a_type reserved_a;
  using _reserved_b_type =
    float;
  _reserved_b_type reserved_b;
  using _reserved_c_type =
    float;
  _reserved_c_type reserved_c;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__radar_id(
    const uint32_t & _arg)
  {
    this->radar_id = _arg;
    return *this;
  }
  Type & set__frame_cnt(
    const uint32_t & _arg)
  {
    this->frame_cnt = _arg;
    return *this;
  }
  Type & set__occupied_num(
    const uint32_t & _arg)
  {
    this->occupied_num = _arg;
    return *this;
  }
  Type & set__grid_x_length(
    const float & _arg)
  {
    this->grid_x_length = _arg;
    return *this;
  }
  Type & set__grid_y_length(
    const float & _arg)
  {
    this->grid_y_length = _arg;
    return *this;
  }
  Type & set__grid_x(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->grid_x = _arg;
    return *this;
  }
  Type & set__grid_y(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->grid_y = _arg;
    return *this;
  }
  Type & set__reserved_a(
    const float & _arg)
  {
    this->reserved_a = _arg;
    return *this;
  }
  Type & set__reserved_b(
    const float & _arg)
  {
    this->reserved_b = _arg;
    return *this;
  }
  Type & set__reserved_c(
    const float & _arg)
  {
    this->reserved_c = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::OccupiedGrid_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::OccupiedGrid_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::OccupiedGrid_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::OccupiedGrid_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::OccupiedGrid_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::OccupiedGrid_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::OccupiedGrid_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::OccupiedGrid_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::OccupiedGrid_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::OccupiedGrid_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__OccupiedGrid
    std::shared_ptr<radar_msgs::msg::OccupiedGrid_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__OccupiedGrid
    std::shared_ptr<radar_msgs::msg::OccupiedGrid_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const OccupiedGrid_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->radar_id != other.radar_id) {
      return false;
    }
    if (this->frame_cnt != other.frame_cnt) {
      return false;
    }
    if (this->occupied_num != other.occupied_num) {
      return false;
    }
    if (this->grid_x_length != other.grid_x_length) {
      return false;
    }
    if (this->grid_y_length != other.grid_y_length) {
      return false;
    }
    if (this->grid_x != other.grid_x) {
      return false;
    }
    if (this->grid_y != other.grid_y) {
      return false;
    }
    if (this->reserved_a != other.reserved_a) {
      return false;
    }
    if (this->reserved_b != other.reserved_b) {
      return false;
    }
    if (this->reserved_c != other.reserved_c) {
      return false;
    }
    return true;
  }
  bool operator!=(const OccupiedGrid_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct OccupiedGrid_

// alias to use template instance with default allocator
using OccupiedGrid =
  radar_msgs::msg::OccupiedGrid_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__STRUCT_HPP_
