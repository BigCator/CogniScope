// generated from rosidl_generator_c/resource/idl.h.em
// with input from radar_msgs:msg/SystemStateWoPtp.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__SYSTEM_STATE_WO_PTP_H_
#define RADAR_MSGS__MSG__SYSTEM_STATE_WO_PTP_H_

#include "radar_msgs/msg/detail/system_state_wo_ptp__struct.h"
#include "radar_msgs/msg/detail/system_state_wo_ptp__functions.h"
#include "radar_msgs/msg/detail/system_state_wo_ptp__type_support.h"

#endif  // RADAR_MSGS__MSG__SYSTEM_STATE_WO_PTP_H_
