// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RadarTarget.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/radar_target__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RadarTarget_reserved_o
{
public:
  explicit Init_RadarTarget_reserved_o(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RadarTarget reserved_o(::radar_msgs::msg::RadarTarget::_reserved_o_type arg)
  {
    msg_.reserved_o = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_n
{
public:
  explicit Init_RadarTarget_reserved_n(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_o reserved_n(::radar_msgs::msg::RadarTarget::_reserved_n_type arg)
  {
    msg_.reserved_n = std::move(arg);
    return Init_RadarTarget_reserved_o(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_m
{
public:
  explicit Init_RadarTarget_reserved_m(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_n reserved_m(::radar_msgs::msg::RadarTarget::_reserved_m_type arg)
  {
    msg_.reserved_m = std::move(arg);
    return Init_RadarTarget_reserved_n(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_l
{
public:
  explicit Init_RadarTarget_reserved_l(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_m reserved_l(::radar_msgs::msg::RadarTarget::_reserved_l_type arg)
  {
    msg_.reserved_l = std::move(arg);
    return Init_RadarTarget_reserved_m(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_k
{
public:
  explicit Init_RadarTarget_reserved_k(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_l reserved_k(::radar_msgs::msg::RadarTarget::_reserved_k_type arg)
  {
    msg_.reserved_k = std::move(arg);
    return Init_RadarTarget_reserved_l(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_j
{
public:
  explicit Init_RadarTarget_reserved_j(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_k reserved_j(::radar_msgs::msg::RadarTarget::_reserved_j_type arg)
  {
    msg_.reserved_j = std::move(arg);
    return Init_RadarTarget_reserved_k(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_i
{
public:
  explicit Init_RadarTarget_reserved_i(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_j reserved_i(::radar_msgs::msg::RadarTarget::_reserved_i_type arg)
  {
    msg_.reserved_i = std::move(arg);
    return Init_RadarTarget_reserved_j(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_h
{
public:
  explicit Init_RadarTarget_reserved_h(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_i reserved_h(::radar_msgs::msg::RadarTarget::_reserved_h_type arg)
  {
    msg_.reserved_h = std::move(arg);
    return Init_RadarTarget_reserved_i(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_g
{
public:
  explicit Init_RadarTarget_reserved_g(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_h reserved_g(::radar_msgs::msg::RadarTarget::_reserved_g_type arg)
  {
    msg_.reserved_g = std::move(arg);
    return Init_RadarTarget_reserved_h(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_f
{
public:
  explicit Init_RadarTarget_reserved_f(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_g reserved_f(::radar_msgs::msg::RadarTarget::_reserved_f_type arg)
  {
    msg_.reserved_f = std::move(arg);
    return Init_RadarTarget_reserved_g(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_e
{
public:
  explicit Init_RadarTarget_reserved_e(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_f reserved_e(::radar_msgs::msg::RadarTarget::_reserved_e_type arg)
  {
    msg_.reserved_e = std::move(arg);
    return Init_RadarTarget_reserved_f(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_d
{
public:
  explicit Init_RadarTarget_reserved_d(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_e reserved_d(::radar_msgs::msg::RadarTarget::_reserved_d_type arg)
  {
    msg_.reserved_d = std::move(arg);
    return Init_RadarTarget_reserved_e(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_c
{
public:
  explicit Init_RadarTarget_reserved_c(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_d reserved_c(::radar_msgs::msg::RadarTarget::_reserved_c_type arg)
  {
    msg_.reserved_c = std::move(arg);
    return Init_RadarTarget_reserved_d(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_b
{
public:
  explicit Init_RadarTarget_reserved_b(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_c reserved_b(::radar_msgs::msg::RadarTarget::_reserved_b_type arg)
  {
    msg_.reserved_b = std::move(arg);
    return Init_RadarTarget_reserved_c(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reserved_a
{
public:
  explicit Init_RadarTarget_reserved_a(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_b reserved_a(::radar_msgs::msg::RadarTarget::_reserved_a_type arg)
  {
    msg_.reserved_a = std::move(arg);
    return Init_RadarTarget_reserved_b(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_od_timeout_cnt
{
public:
  explicit Init_RadarTarget_od_timeout_cnt(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reserved_a od_timeout_cnt(::radar_msgs::msg::RadarTarget::_od_timeout_cnt_type arg)
  {
    msg_.od_timeout_cnt = std::move(arg);
    return Init_RadarTarget_reserved_a(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_reset_cnt
{
public:
  explicit Init_RadarTarget_reset_cnt(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_od_timeout_cnt reset_cnt(::radar_msgs::msg::RadarTarget::_reset_cnt_type arg)
  {
    msg_.reset_cnt = std::move(arg);
    return Init_RadarTarget_od_timeout_cnt(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_detection_class
{
public:
  explicit Init_RadarTarget_detection_class(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_reset_cnt detection_class(::radar_msgs::msg::RadarTarget::_detection_class_type arg)
  {
    msg_.detection_class = std::move(arg);
    return Init_RadarTarget_reset_cnt(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_motion_state
{
public:
  explicit Init_RadarTarget_motion_state(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_detection_class motion_state(::radar_msgs::msg::RadarTarget::_motion_state_type arg)
  {
    msg_.motion_state = std::move(arg);
    return Init_RadarTarget_detection_class(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_existance_probability
{
public:
  explicit Init_RadarTarget_existance_probability(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_motion_state existance_probability(::radar_msgs::msg::RadarTarget::_existance_probability_type arg)
  {
    msg_.existance_probability = std::move(arg);
    return Init_RadarTarget_motion_state(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_valid_flg
{
public:
  explicit Init_RadarTarget_valid_flg(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_existance_probability valid_flg(::radar_msgs::msg::RadarTarget::_valid_flg_type arg)
  {
    msg_.valid_flg = std::move(arg);
    return Init_RadarTarget_existance_probability(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_power
{
public:
  explicit Init_RadarTarget_power(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_valid_flg power(::radar_msgs::msg::RadarTarget::_power_type arg)
  {
    msg_.power = std::move(arg);
    return Init_RadarTarget_valid_flg(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_snr
{
public:
  explicit Init_RadarTarget_snr(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_power snr(::radar_msgs::msg::RadarTarget::_snr_type arg)
  {
    msg_.snr = std::move(arg);
    return Init_RadarTarget_power(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_elevation
{
public:
  explicit Init_RadarTarget_elevation(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_snr elevation(::radar_msgs::msg::RadarTarget::_elevation_type arg)
  {
    msg_.elevation = std::move(arg);
    return Init_RadarTarget_snr(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_azimuth
{
public:
  explicit Init_RadarTarget_azimuth(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_elevation azimuth(::radar_msgs::msg::RadarTarget::_azimuth_type arg)
  {
    msg_.azimuth = std::move(arg);
    return Init_RadarTarget_elevation(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_v
{
public:
  explicit Init_RadarTarget_v(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_azimuth v(::radar_msgs::msg::RadarTarget::_v_type arg)
  {
    msg_.v = std::move(arg);
    return Init_RadarTarget_azimuth(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_z
{
public:
  explicit Init_RadarTarget_z(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_v z(::radar_msgs::msg::RadarTarget::_z_type arg)
  {
    msg_.z = std::move(arg);
    return Init_RadarTarget_v(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_y
{
public:
  explicit Init_RadarTarget_y(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_z y(::radar_msgs::msg::RadarTarget::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_RadarTarget_z(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_x
{
public:
  explicit Init_RadarTarget_x(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_y x(::radar_msgs::msg::RadarTarget::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_RadarTarget_y(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_polar_state
{
public:
  explicit Init_RadarTarget_polar_state(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_x polar_state(::radar_msgs::msg::RadarTarget::_polar_state_type arg)
  {
    msg_.polar_state = std::move(arg);
    return Init_RadarTarget_x(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_target_num
{
public:
  explicit Init_RadarTarget_target_num(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_polar_state target_num(::radar_msgs::msg::RadarTarget::_target_num_type arg)
  {
    msg_.target_num = std::move(arg);
    return Init_RadarTarget_polar_state(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_type
{
public:
  explicit Init_RadarTarget_type(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_target_num type(::radar_msgs::msg::RadarTarget::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_RadarTarget_target_num(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_frame_cnt
{
public:
  explicit Init_RadarTarget_frame_cnt(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_type frame_cnt(::radar_msgs::msg::RadarTarget::_frame_cnt_type arg)
  {
    msg_.frame_cnt = std::move(arg);
    return Init_RadarTarget_type(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_radar_id
{
public:
  explicit Init_RadarTarget_radar_id(::radar_msgs::msg::RadarTarget & msg)
  : msg_(msg)
  {}
  Init_RadarTarget_frame_cnt radar_id(::radar_msgs::msg::RadarTarget::_radar_id_type arg)
  {
    msg_.radar_id = std::move(arg);
    return Init_RadarTarget_frame_cnt(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

class Init_RadarTarget_header
{
public:
  Init_RadarTarget_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RadarTarget_radar_id header(::radar_msgs::msg::RadarTarget::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_RadarTarget_radar_id(msg_);
  }

private:
  ::radar_msgs::msg::RadarTarget msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RadarTarget>()
{
  return radar_msgs::msg::builder::Init_RadarTarget_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__BUILDER_HPP_
