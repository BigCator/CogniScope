// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/Od.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OD__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__OD__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'pose'
// Member 'pose_nearest'
#include "geometry_msgs/msg/detail/pose__struct.hpp"
// Member 'dimensions'
#include "geometry_msgs/msg/detail/vector3__struct.hpp"
// Member 'velocity'
// Member 'acceleration'
// Member 'v2ground'
#include "geometry_msgs/msg/detail/twist__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__Od __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__Od __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Od_
{
  using Type = Od_<ContainerAllocator>;

  explicit Od_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pose(_init),
    dimensions(_init),
    velocity(_init),
    acceleration(_init),
    v2ground(_init),
    pose_nearest(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->object_id = 0ul;
      this->age = 0;
      this->measurement_status = 0;
      this->motion_state = 0;
      this->existance_confidence = 0;
      this->type = 0;
      this->car_confidence = 0;
      this->bike_confidence = 0;
      this->ped_confidence = 0;
      this->truck_confidence = 0;
      this->signboard_confidence = 0;
      this->ground_confidence = 0;
      this->obstacle_confidence = 0;
      this->enrollptsnum = 0.0f;
      this->nearestptsx = 0.0f;
      this->nearestptsy = 0.0f;
      this->nearestptsz = 0.0f;
      this->reserved_d = 0.0f;
      this->reserved_e = 0ul;
      this->reserved_f = 0ul;
      this->reserved_g = 0l;
      this->reserved_h = 0l;
      this->reserved_i = 0;
      this->reserved_j = 0;
      this->reserved_k = 0;
      this->reserved_l = 0;
      this->reserved_m = 0;
      this->reserved_n = 0;
      this->reserved_o = "";
      this->reserved_p = "";
    }
  }

  explicit Od_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pose(_alloc, _init),
    dimensions(_alloc, _init),
    velocity(_alloc, _init),
    acceleration(_alloc, _init),
    v2ground(_alloc, _init),
    pose_nearest(_alloc, _init),
    reserved_o(_alloc),
    reserved_p(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->object_id = 0ul;
      this->age = 0;
      this->measurement_status = 0;
      this->motion_state = 0;
      this->existance_confidence = 0;
      this->type = 0;
      this->car_confidence = 0;
      this->bike_confidence = 0;
      this->ped_confidence = 0;
      this->truck_confidence = 0;
      this->signboard_confidence = 0;
      this->ground_confidence = 0;
      this->obstacle_confidence = 0;
      this->enrollptsnum = 0.0f;
      this->nearestptsx = 0.0f;
      this->nearestptsy = 0.0f;
      this->nearestptsz = 0.0f;
      this->reserved_d = 0.0f;
      this->reserved_e = 0ul;
      this->reserved_f = 0ul;
      this->reserved_g = 0l;
      this->reserved_h = 0l;
      this->reserved_i = 0;
      this->reserved_j = 0;
      this->reserved_k = 0;
      this->reserved_l = 0;
      this->reserved_m = 0;
      this->reserved_n = 0;
      this->reserved_o = "";
      this->reserved_p = "";
    }
  }

  // field types and members
  using _object_id_type =
    uint32_t;
  _object_id_type object_id;
  using _age_type =
    uint16_t;
  _age_type age;
  using _measurement_status_type =
    uint8_t;
  _measurement_status_type measurement_status;
  using _motion_state_type =
    uint8_t;
  _motion_state_type motion_state;
  using _existance_confidence_type =
    uint8_t;
  _existance_confidence_type existance_confidence;
  using _pose_type =
    geometry_msgs::msg::Pose_<ContainerAllocator>;
  _pose_type pose;
  using _dimensions_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _dimensions_type dimensions;
  using _velocity_type =
    geometry_msgs::msg::Twist_<ContainerAllocator>;
  _velocity_type velocity;
  using _acceleration_type =
    geometry_msgs::msg::Twist_<ContainerAllocator>;
  _acceleration_type acceleration;
  using _v2ground_type =
    geometry_msgs::msg::Twist_<ContainerAllocator>;
  _v2ground_type v2ground;
  using _pose_nearest_type =
    geometry_msgs::msg::Pose_<ContainerAllocator>;
  _pose_nearest_type pose_nearest;
  using _type_type =
    uint8_t;
  _type_type type;
  using _car_confidence_type =
    uint8_t;
  _car_confidence_type car_confidence;
  using _bike_confidence_type =
    uint8_t;
  _bike_confidence_type bike_confidence;
  using _ped_confidence_type =
    uint8_t;
  _ped_confidence_type ped_confidence;
  using _truck_confidence_type =
    uint8_t;
  _truck_confidence_type truck_confidence;
  using _signboard_confidence_type =
    uint8_t;
  _signboard_confidence_type signboard_confidence;
  using _ground_confidence_type =
    uint8_t;
  _ground_confidence_type ground_confidence;
  using _obstacle_confidence_type =
    uint8_t;
  _obstacle_confidence_type obstacle_confidence;
  using _enrollptsnum_type =
    float;
  _enrollptsnum_type enrollptsnum;
  using _nearestptsx_type =
    float;
  _nearestptsx_type nearestptsx;
  using _nearestptsy_type =
    float;
  _nearestptsy_type nearestptsy;
  using _nearestptsz_type =
    float;
  _nearestptsz_type nearestptsz;
  using _reserved_d_type =
    float;
  _reserved_d_type reserved_d;
  using _reserved_e_type =
    uint32_t;
  _reserved_e_type reserved_e;
  using _reserved_f_type =
    uint32_t;
  _reserved_f_type reserved_f;
  using _reserved_g_type =
    int32_t;
  _reserved_g_type reserved_g;
  using _reserved_h_type =
    int32_t;
  _reserved_h_type reserved_h;
  using _reserved_i_type =
    uint16_t;
  _reserved_i_type reserved_i;
  using _reserved_j_type =
    uint16_t;
  _reserved_j_type reserved_j;
  using _reserved_k_type =
    int16_t;
  _reserved_k_type reserved_k;
  using _reserved_l_type =
    int16_t;
  _reserved_l_type reserved_l;
  using _reserved_m_type =
    uint8_t;
  _reserved_m_type reserved_m;
  using _reserved_n_type =
    uint8_t;
  _reserved_n_type reserved_n;
  using _reserved_o_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _reserved_o_type reserved_o;
  using _reserved_p_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _reserved_p_type reserved_p;

  // setters for named parameter idiom
  Type & set__object_id(
    const uint32_t & _arg)
  {
    this->object_id = _arg;
    return *this;
  }
  Type & set__age(
    const uint16_t & _arg)
  {
    this->age = _arg;
    return *this;
  }
  Type & set__measurement_status(
    const uint8_t & _arg)
  {
    this->measurement_status = _arg;
    return *this;
  }
  Type & set__motion_state(
    const uint8_t & _arg)
  {
    this->motion_state = _arg;
    return *this;
  }
  Type & set__existance_confidence(
    const uint8_t & _arg)
  {
    this->existance_confidence = _arg;
    return *this;
  }
  Type & set__pose(
    const geometry_msgs::msg::Pose_<ContainerAllocator> & _arg)
  {
    this->pose = _arg;
    return *this;
  }
  Type & set__dimensions(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->dimensions = _arg;
    return *this;
  }
  Type & set__velocity(
    const geometry_msgs::msg::Twist_<ContainerAllocator> & _arg)
  {
    this->velocity = _arg;
    return *this;
  }
  Type & set__acceleration(
    const geometry_msgs::msg::Twist_<ContainerAllocator> & _arg)
  {
    this->acceleration = _arg;
    return *this;
  }
  Type & set__v2ground(
    const geometry_msgs::msg::Twist_<ContainerAllocator> & _arg)
  {
    this->v2ground = _arg;
    return *this;
  }
  Type & set__pose_nearest(
    const geometry_msgs::msg::Pose_<ContainerAllocator> & _arg)
  {
    this->pose_nearest = _arg;
    return *this;
  }
  Type & set__type(
    const uint8_t & _arg)
  {
    this->type = _arg;
    return *this;
  }
  Type & set__car_confidence(
    const uint8_t & _arg)
  {
    this->car_confidence = _arg;
    return *this;
  }
  Type & set__bike_confidence(
    const uint8_t & _arg)
  {
    this->bike_confidence = _arg;
    return *this;
  }
  Type & set__ped_confidence(
    const uint8_t & _arg)
  {
    this->ped_confidence = _arg;
    return *this;
  }
  Type & set__truck_confidence(
    const uint8_t & _arg)
  {
    this->truck_confidence = _arg;
    return *this;
  }
  Type & set__signboard_confidence(
    const uint8_t & _arg)
  {
    this->signboard_confidence = _arg;
    return *this;
  }
  Type & set__ground_confidence(
    const uint8_t & _arg)
  {
    this->ground_confidence = _arg;
    return *this;
  }
  Type & set__obstacle_confidence(
    const uint8_t & _arg)
  {
    this->obstacle_confidence = _arg;
    return *this;
  }
  Type & set__enrollptsnum(
    const float & _arg)
  {
    this->enrollptsnum = _arg;
    return *this;
  }
  Type & set__nearestptsx(
    const float & _arg)
  {
    this->nearestptsx = _arg;
    return *this;
  }
  Type & set__nearestptsy(
    const float & _arg)
  {
    this->nearestptsy = _arg;
    return *this;
  }
  Type & set__nearestptsz(
    const float & _arg)
  {
    this->nearestptsz = _arg;
    return *this;
  }
  Type & set__reserved_d(
    const float & _arg)
  {
    this->reserved_d = _arg;
    return *this;
  }
  Type & set__reserved_e(
    const uint32_t & _arg)
  {
    this->reserved_e = _arg;
    return *this;
  }
  Type & set__reserved_f(
    const uint32_t & _arg)
  {
    this->reserved_f = _arg;
    return *this;
  }
  Type & set__reserved_g(
    const int32_t & _arg)
  {
    this->reserved_g = _arg;
    return *this;
  }
  Type & set__reserved_h(
    const int32_t & _arg)
  {
    this->reserved_h = _arg;
    return *this;
  }
  Type & set__reserved_i(
    const uint16_t & _arg)
  {
    this->reserved_i = _arg;
    return *this;
  }
  Type & set__reserved_j(
    const uint16_t & _arg)
  {
    this->reserved_j = _arg;
    return *this;
  }
  Type & set__reserved_k(
    const int16_t & _arg)
  {
    this->reserved_k = _arg;
    return *this;
  }
  Type & set__reserved_l(
    const int16_t & _arg)
  {
    this->reserved_l = _arg;
    return *this;
  }
  Type & set__reserved_m(
    const uint8_t & _arg)
  {
    this->reserved_m = _arg;
    return *this;
  }
  Type & set__reserved_n(
    const uint8_t & _arg)
  {
    this->reserved_n = _arg;
    return *this;
  }
  Type & set__reserved_o(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->reserved_o = _arg;
    return *this;
  }
  Type & set__reserved_p(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->reserved_p = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::Od_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::Od_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::Od_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::Od_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::Od_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::Od_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::Od_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::Od_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::Od_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::Od_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__Od
    std::shared_ptr<radar_msgs::msg::Od_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__Od
    std::shared_ptr<radar_msgs::msg::Od_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Od_ & other) const
  {
    if (this->object_id != other.object_id) {
      return false;
    }
    if (this->age != other.age) {
      return false;
    }
    if (this->measurement_status != other.measurement_status) {
      return false;
    }
    if (this->motion_state != other.motion_state) {
      return false;
    }
    if (this->existance_confidence != other.existance_confidence) {
      return false;
    }
    if (this->pose != other.pose) {
      return false;
    }
    if (this->dimensions != other.dimensions) {
      return false;
    }
    if (this->velocity != other.velocity) {
      return false;
    }
    if (this->acceleration != other.acceleration) {
      return false;
    }
    if (this->v2ground != other.v2ground) {
      return false;
    }
    if (this->pose_nearest != other.pose_nearest) {
      return false;
    }
    if (this->type != other.type) {
      return false;
    }
    if (this->car_confidence != other.car_confidence) {
      return false;
    }
    if (this->bike_confidence != other.bike_confidence) {
      return false;
    }
    if (this->ped_confidence != other.ped_confidence) {
      return false;
    }
    if (this->truck_confidence != other.truck_confidence) {
      return false;
    }
    if (this->signboard_confidence != other.signboard_confidence) {
      return false;
    }
    if (this->ground_confidence != other.ground_confidence) {
      return false;
    }
    if (this->obstacle_confidence != other.obstacle_confidence) {
      return false;
    }
    if (this->enrollptsnum != other.enrollptsnum) {
      return false;
    }
    if (this->nearestptsx != other.nearestptsx) {
      return false;
    }
    if (this->nearestptsy != other.nearestptsy) {
      return false;
    }
    if (this->nearestptsz != other.nearestptsz) {
      return false;
    }
    if (this->reserved_d != other.reserved_d) {
      return false;
    }
    if (this->reserved_e != other.reserved_e) {
      return false;
    }
    if (this->reserved_f != other.reserved_f) {
      return false;
    }
    if (this->reserved_g != other.reserved_g) {
      return false;
    }
    if (this->reserved_h != other.reserved_h) {
      return false;
    }
    if (this->reserved_i != other.reserved_i) {
      return false;
    }
    if (this->reserved_j != other.reserved_j) {
      return false;
    }
    if (this->reserved_k != other.reserved_k) {
      return false;
    }
    if (this->reserved_l != other.reserved_l) {
      return false;
    }
    if (this->reserved_m != other.reserved_m) {
      return false;
    }
    if (this->reserved_n != other.reserved_n) {
      return false;
    }
    if (this->reserved_o != other.reserved_o) {
      return false;
    }
    if (this->reserved_p != other.reserved_p) {
      return false;
    }
    return true;
  }
  bool operator!=(const Od_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Od_

// alias to use template instance with default allocator
using Od =
  radar_msgs::msg::Od_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__OD__STRUCT_HPP_
