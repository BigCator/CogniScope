// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/PointCnt.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__POINT_CNT__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__POINT_CNT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/PointCnt in the package radar_msgs.
typedef struct radar_msgs__msg__PointCnt
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  uint32_t frame_id;
  /// cfar count
  uint32_t cfar_count;
  /// targets Num
  uint32_t target_num;
  /// reset count
  int16_t resetcnt;
  /// object number of this frame
  uint32_t objnum;
  /// duration of od process (us)
  float od_process_time;
  /// ego car speed
  float carspeed;
  /// ego car yaw rate
  float caryawrate;
  int16_t odtimeoutcnt;
  uint16_t comprotv_i;
  uint16_t comprotv_ii;
  uint16_t framelostcnt;
  uint16_t beforeadcerrcnt;
  uint16_t afteradcerrcnt;
  uint32_t udprramelostcnt;
} radar_msgs__msg__PointCnt;

// Struct for a sequence of radar_msgs__msg__PointCnt.
typedef struct radar_msgs__msg__PointCnt__Sequence
{
  radar_msgs__msg__PointCnt * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__PointCnt__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__POINT_CNT__STRUCT_H_
