// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/OccupiedGrid.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/occupied_grid__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const OccupiedGrid & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: radar_id
  {
    out << "radar_id: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_id, out);
    out << ", ";
  }

  // member: frame_cnt
  {
    out << "frame_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_cnt, out);
    out << ", ";
  }

  // member: occupied_num
  {
    out << "occupied_num: ";
    rosidl_generator_traits::value_to_yaml(msg.occupied_num, out);
    out << ", ";
  }

  // member: grid_x_length
  {
    out << "grid_x_length: ";
    rosidl_generator_traits::value_to_yaml(msg.grid_x_length, out);
    out << ", ";
  }

  // member: grid_y_length
  {
    out << "grid_y_length: ";
    rosidl_generator_traits::value_to_yaml(msg.grid_y_length, out);
    out << ", ";
  }

  // member: grid_x
  {
    if (msg.grid_x.size() == 0) {
      out << "grid_x: []";
    } else {
      out << "grid_x: [";
      size_t pending_items = msg.grid_x.size();
      for (auto item : msg.grid_x) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: grid_y
  {
    if (msg.grid_y.size() == 0) {
      out << "grid_y: []";
    } else {
      out << "grid_y: [";
      size_t pending_items = msg.grid_y.size();
      for (auto item : msg.grid_y) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_a
  {
    out << "reserved_a: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_a, out);
    out << ", ";
  }

  // member: reserved_b
  {
    out << "reserved_b: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_b, out);
    out << ", ";
  }

  // member: reserved_c
  {
    out << "reserved_c: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_c, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const OccupiedGrid & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: radar_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "radar_id: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_id, out);
    out << "\n";
  }

  // member: frame_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_cnt, out);
    out << "\n";
  }

  // member: occupied_num
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "occupied_num: ";
    rosidl_generator_traits::value_to_yaml(msg.occupied_num, out);
    out << "\n";
  }

  // member: grid_x_length
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "grid_x_length: ";
    rosidl_generator_traits::value_to_yaml(msg.grid_x_length, out);
    out << "\n";
  }

  // member: grid_y_length
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "grid_y_length: ";
    rosidl_generator_traits::value_to_yaml(msg.grid_y_length, out);
    out << "\n";
  }

  // member: grid_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.grid_x.size() == 0) {
      out << "grid_x: []\n";
    } else {
      out << "grid_x:\n";
      for (auto item : msg.grid_x) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: grid_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.grid_y.size() == 0) {
      out << "grid_y: []\n";
    } else {
      out << "grid_y:\n";
      for (auto item : msg.grid_y) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_a
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_a: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_a, out);
    out << "\n";
  }

  // member: reserved_b
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_b: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_b, out);
    out << "\n";
  }

  // member: reserved_c
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_c: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_c, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const OccupiedGrid & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::OccupiedGrid & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::OccupiedGrid & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::OccupiedGrid>()
{
  return "radar_msgs::msg::OccupiedGrid";
}

template<>
inline const char * name<radar_msgs::msg::OccupiedGrid>()
{
  return "radar_msgs/msg/OccupiedGrid";
}

template<>
struct has_fixed_size<radar_msgs::msg::OccupiedGrid>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<radar_msgs::msg::OccupiedGrid>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<radar_msgs::msg::OccupiedGrid>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__TRAITS_HPP_
