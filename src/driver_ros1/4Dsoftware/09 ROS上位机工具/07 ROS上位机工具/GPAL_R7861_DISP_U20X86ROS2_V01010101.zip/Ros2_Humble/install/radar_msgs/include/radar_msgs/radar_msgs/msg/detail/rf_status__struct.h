// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/RfStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RF_STATUS__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__RF_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'diglatentfaultdata'
#include "radar_msgs/msg/detail/rl_dig_latent_fault_report_data__struct.h"
// Member 'reportheaderdata'
#include "radar_msgs/msg/detail/rl_mon_report_hdr_data__struct.h"
// Member 'reporttempdata'
#include "radar_msgs/msg/detail/rl_mon_temp_report_data__struct.h"
// Member 'digperiodicreportdata'
#include "radar_msgs/msg/detail/rl_dig_periodic_report_data__struct.h"
// Member 'reportrxgainphdata'
#include "radar_msgs/msg/detail/rl_mon_rx_gain_ph_rep__struct.h"
// Member 'reportrxnoisefigdata'
#include "radar_msgs/msg/detail/rl_mon_rx_noise_fig_rep__struct.h"
// Member 'reportrxifstagedata'
#include "radar_msgs/msg/detail/rl_mon_rx_if_stage_rep__struct.h"
// Member 'reportrxintanasigdata'
#include "radar_msgs/msg/detail/rl_mon_rx_int_ana_sig_rep__struct.h"
// Member 'reportpmclklointanasigdata'
#include "radar_msgs/msg/detail/rl_mon_pmclklo_int_ana_sig_rep__struct.h"
// Member 'reportgpadcintanasigdata'
#include "radar_msgs/msg/detail/rl_mon_gpadc_int_ana_sig_rep__struct.h"
// Member 'reportpllconvoltdata'
#include "radar_msgs/msg/detail/rl_mon_pll_con_volt_rep__struct.h"
// Member 'reportdccclkfreqdata'
#include "radar_msgs/msg/detail/rl_mon_dcc_clk_freq_rep__struct.h"
// Member 'reportsynthfreqnonlivedata'
#include "radar_msgs/msg/detail/rl_mon_synth_freq_non_live_rep__struct.h"
// Member 'reportrxmixrinpwrdata'
#include "radar_msgs/msg/detail/rl_mon_rx_mixr_in_pwr_rep__struct.h"
// Member 'reporttxintanasigdata'
#include "radar_msgs/msg/detail/rl_mon_tx_int_ana_sig_rep__struct.h"
// Member 'reportextanasigdata'
#include "radar_msgs/msg/detail/rl_mon_ext_ana_sig_rep__struct.h"
// Member 'reportsynthfreqdata'
#include "radar_msgs/msg/detail/rl_mon_synth_freq_rep__struct.h"
// Member 'reporttxphshiftdata'
#include "radar_msgs/msg/detail/rl_mon_tx_ph_shift_rep__struct.h"
// Member 'reporttxgainphamisdata'
#include "radar_msgs/msg/detail/rl_mon_tx_gain_pha_mis_rep__struct.h"
// Member 'reporttxballbreakdata'
#include "radar_msgs/msg/detail/rl_mon_tx_ball_break_rep__struct.h"
// Member 'reporttxpowdata'
#include "radar_msgs/msg/detail/rl_mon_tx_pow_rep__struct.h"
// Member 'reportrecvdgpadcdata'
#include "radar_msgs/msg/detail/rl_recvd_gp_adc_data__struct.h"
// Member 'reportanalogfaultdata'
#include "radar_msgs/msg/detail/rl_analog_fault_report_data__struct.h"
// Member 'reporttimingerrordata'
#include "radar_msgs/msg/detail/rl_cal_mon_timing_error_report_data__struct.h"

/// Struct defined in msg/RfStatus in the package radar_msgs.
typedef struct radar_msgs__msg__RfStatus
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  /// radar ID
  uint32_t radarid;
  /// frame cnt in radar
  uint32_t framecnt;
  radar_msgs__msg__RlDigLatentFaultReportData diglatentfaultdata;
  radar_msgs__msg__RlMonReportHdrData reportheaderdata;
  radar_msgs__msg__RlMonTempReportData reporttempdata;
  radar_msgs__msg__RlDigPeriodicReportData digperiodicreportdata;
  radar_msgs__msg__RlMonRxGainPhRep reportrxgainphdata[2];
  radar_msgs__msg__RlMonRxNoiseFigRep reportrxnoisefigdata[2];
  radar_msgs__msg__RlMonRxIfStageRep reportrxifstagedata[2];
  radar_msgs__msg__RlMonRxIntAnaSigRep reportrxintanasigdata[2];
  radar_msgs__msg__RlMonPmclkloIntAnaSigRep reportpmclklointanasigdata[2];
  radar_msgs__msg__RlMonGpadcIntAnaSigRep reportgpadcintanasigdata;
  radar_msgs__msg__RlMonPllConVoltRep reportpllconvoltdata;
  radar_msgs__msg__RlMonDccClkFreqRep reportdccclkfreqdata;
  radar_msgs__msg__RlMonSynthFreqNonLiveRep reportsynthfreqnonlivedata;
  radar_msgs__msg__RlMonRxMixrInPwrRep reportrxmixrinpwrdata[2];
  radar_msgs__msg__RlMonTxIntAnaSigRep reporttxintanasigdata[2];
  radar_msgs__msg__RlMonExtAnaSigRep reportextanasigdata;
  radar_msgs__msg__RlMonSynthFreqRep reportsynthfreqdata[2];
  radar_msgs__msg__RlMonTxPhShiftRep reporttxphshiftdata[2];
  radar_msgs__msg__RlMonTxGainPhaMisRep reporttxgainphamisdata[2];
  radar_msgs__msg__RlMonTxBallBreakRep reporttxballbreakdata;
  radar_msgs__msg__RlMonTxPowRep reporttxpowdata[2];
  radar_msgs__msg__RlRecvdGpAdcData reportrecvdgpadcdata;
  radar_msgs__msg__RlAnalogFaultReportData reportanalogfaultdata;
  radar_msgs__msg__RlCalMonTimingErrorReportData reporttimingerrordata;
} radar_msgs__msg__RfStatus;

// Struct for a sequence of radar_msgs__msg__RfStatus.
typedef struct radar_msgs__msg__RfStatus__Sequence
{
  radar_msgs__msg__RfStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__RfStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__RF_STATUS__STRUCT_H_
