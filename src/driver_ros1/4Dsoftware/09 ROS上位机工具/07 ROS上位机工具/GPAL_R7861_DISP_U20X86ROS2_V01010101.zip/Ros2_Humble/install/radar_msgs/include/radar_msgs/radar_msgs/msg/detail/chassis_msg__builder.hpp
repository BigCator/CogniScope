// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/ChassisMsg.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/chassis_msg__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_ChassisMsg_ndrivemode
{
public:
  explicit Init_ChassisMsg_ndrivemode(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::ChassisMsg ndrivemode(::radar_msgs::msg::ChassisMsg::_ndrivemode_type arg)
  {
    msg_.ndrivemode = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_nrightnondrivenwheelpulsecounters
{
public:
  explicit Init_ChassisMsg_nrightnondrivenwheelpulsecounters(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_ndrivemode nrightnondrivenwheelpulsecounters(::radar_msgs::msg::ChassisMsg::_nrightnondrivenwheelpulsecounters_type arg)
  {
    msg_.nrightnondrivenwheelpulsecounters = std::move(arg);
    return Init_ChassisMsg_ndrivemode(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_nleftnondrivenwheelpulsecounters
{
public:
  explicit Init_ChassisMsg_nleftnondrivenwheelpulsecounters(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_nrightnondrivenwheelpulsecounters nleftnondrivenwheelpulsecounters(::radar_msgs::msg::ChassisMsg::_nleftnondrivenwheelpulsecounters_type arg)
  {
    msg_.nleftnondrivenwheelpulsecounters = std::move(arg);
    return Init_ChassisMsg_nrightnondrivenwheelpulsecounters(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_nrightdrivenwheelpulsecounters
{
public:
  explicit Init_ChassisMsg_nrightdrivenwheelpulsecounters(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_nleftnondrivenwheelpulsecounters nrightdrivenwheelpulsecounters(::radar_msgs::msg::ChassisMsg::_nrightdrivenwheelpulsecounters_type arg)
  {
    msg_.nrightdrivenwheelpulsecounters = std::move(arg);
    return Init_ChassisMsg_nleftnondrivenwheelpulsecounters(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_nleftdrivenwheelpulsecounters
{
public:
  explicit Init_ChassisMsg_nleftdrivenwheelpulsecounters(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_nrightdrivenwheelpulsecounters nleftdrivenwheelpulsecounters(::radar_msgs::msg::ChassisMsg::_nleftdrivenwheelpulsecounters_type arg)
  {
    msg_.nleftdrivenwheelpulsecounters = std::move(arg);
    return Init_ChassisMsg_nrightdrivenwheelpulsecounters(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_flongituaccel
{
public:
  explicit Init_ChassisMsg_flongituaccel(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_nleftdrivenwheelpulsecounters flongituaccel(::radar_msgs::msg::ChassisMsg::_flongituaccel_type arg)
  {
    msg_.flongituaccel = std::move(arg);
    return Init_ChassisMsg_nleftdrivenwheelpulsecounters(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_flateralaccel
{
public:
  explicit Init_ChassisMsg_flateralaccel(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_flongituaccel flateralaccel(::radar_msgs::msg::ChassisMsg::_flateralaccel_type arg)
  {
    msg_.flateralaccel = std::move(arg);
    return Init_ChassisMsg_flongituaccel(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_nwiperstate
{
public:
  explicit Init_ChassisMsg_nwiperstate(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_flateralaccel nwiperstate(::radar_msgs::msg::ChassisMsg::_nwiperstate_type arg)
  {
    msg_.nwiperstate = std::move(arg);
    return Init_ChassisMsg_flateralaccel(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_ndippedbeamlamp
{
public:
  explicit Init_ChassisMsg_ndippedbeamlamp(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_nwiperstate ndippedbeamlamp(::radar_msgs::msg::ChassisMsg::_ndippedbeamlamp_type arg)
  {
    msg_.ndippedbeamlamp = std::move(arg);
    return Init_ChassisMsg_nwiperstate(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_nmainbeamlamp
{
public:
  explicit Init_ChassisMsg_nmainbeamlamp(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_ndippedbeamlamp nmainbeamlamp(::radar_msgs::msg::ChassisMsg::_nmainbeamlamp_type arg)
  {
    msg_.nmainbeamlamp = std::move(arg);
    return Init_ChassisMsg_ndippedbeamlamp(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_nrightdirectionlamp
{
public:
  explicit Init_ChassisMsg_nrightdirectionlamp(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_nmainbeamlamp nrightdirectionlamp(::radar_msgs::msg::ChassisMsg::_nrightdirectionlamp_type arg)
  {
    msg_.nrightdirectionlamp = std::move(arg);
    return Init_ChassisMsg_nmainbeamlamp(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_nleftdirectionlamp
{
public:
  explicit Init_ChassisMsg_nleftdirectionlamp(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_nrightdirectionlamp nleftdirectionlamp(::radar_msgs::msg::ChassisMsg::_nleftdirectionlamp_type arg)
  {
    msg_.nleftdirectionlamp = std::move(arg);
    return Init_ChassisMsg_nrightdirectionlamp(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_nshifterposition
{
public:
  explicit Init_ChassisMsg_nshifterposition(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_nleftdirectionlamp nshifterposition(::radar_msgs::msg::ChassisMsg::_nshifterposition_type arg)
  {
    msg_.nshifterposition = std::move(arg);
    return Init_ChassisMsg_nleftdirectionlamp(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_frearrightwheelspeed
{
public:
  explicit Init_ChassisMsg_frearrightwheelspeed(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_nshifterposition frearrightwheelspeed(::radar_msgs::msg::ChassisMsg::_frearrightwheelspeed_type arg)
  {
    msg_.frearrightwheelspeed = std::move(arg);
    return Init_ChassisMsg_nshifterposition(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_frearleftwheelspeed
{
public:
  explicit Init_ChassisMsg_frearleftwheelspeed(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_frearrightwheelspeed frearleftwheelspeed(::radar_msgs::msg::ChassisMsg::_frearleftwheelspeed_type arg)
  {
    msg_.frearleftwheelspeed = std::move(arg);
    return Init_ChassisMsg_frearrightwheelspeed(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_ffrontrightwheelspeed
{
public:
  explicit Init_ChassisMsg_ffrontrightwheelspeed(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_frearleftwheelspeed ffrontrightwheelspeed(::radar_msgs::msg::ChassisMsg::_ffrontrightwheelspeed_type arg)
  {
    msg_.ffrontrightwheelspeed = std::move(arg);
    return Init_ChassisMsg_frearleftwheelspeed(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_ffrontleftwheelspeed
{
public:
  explicit Init_ChassisMsg_ffrontleftwheelspeed(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_ffrontrightwheelspeed ffrontleftwheelspeed(::radar_msgs::msg::ChassisMsg::_ffrontleftwheelspeed_type arg)
  {
    msg_.ffrontleftwheelspeed = std::move(arg);
    return Init_ChassisMsg_ffrontrightwheelspeed(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fyawrate
{
public:
  explicit Init_ChassisMsg_fyawrate(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_ffrontleftwheelspeed fyawrate(::radar_msgs::msg::ChassisMsg::_fyawrate_type arg)
  {
    msg_.fyawrate = std::move(arg);
    return Init_ChassisMsg_ffrontleftwheelspeed(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fspeed
{
public:
  explicit Init_ChassisMsg_fspeed(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fyawrate fspeed(::radar_msgs::msg::ChassisMsg::_fspeed_type arg)
  {
    msg_.fspeed = std::move(arg);
    return Init_ChassisMsg_fyawrate(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fsteeringangle
{
public:
  explicit Init_ChassisMsg_fsteeringangle(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fspeed fsteeringangle(::radar_msgs::msg::ChassisMsg::_fsteeringangle_type arg)
  {
    msg_.fsteeringangle = std::move(arg);
    return Init_ChassisMsg_fspeed(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_vtimestamp
{
public:
  explicit Init_ChassisMsg_vtimestamp(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fsteeringangle vtimestamp(::radar_msgs::msg::ChassisMsg::_vtimestamp_type arg)
  {
    msg_.vtimestamp = std::move(arg);
    return Init_ChassisMsg_fsteeringangle(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_nnavstatus
{
public:
  explicit Init_ChassisMsg_nnavstatus(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_vtimestamp nnavstatus(::radar_msgs::msg::ChassisMsg::_nnavstatus_type arg)
  {
    msg_.nnavstatus = std::move(arg);
    return Init_ChassisMsg_vtimestamp(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_froll
{
public:
  explicit Init_ChassisMsg_froll(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_nnavstatus froll(::radar_msgs::msg::ChassisMsg::_froll_type arg)
  {
    msg_.froll = std::move(arg);
    return Init_ChassisMsg_nnavstatus(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fpitch
{
public:
  explicit Init_ChassisMsg_fpitch(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_froll fpitch(::radar_msgs::msg::ChassisMsg::_fpitch_type arg)
  {
    msg_.fpitch = std::move(arg);
    return Init_ChassisMsg_froll(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fheading
{
public:
  explicit Init_ChassisMsg_fheading(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fpitch fheading(::radar_msgs::msg::ChassisMsg::_fheading_type arg)
  {
    msg_.fheading = std::move(arg);
    return Init_ChassisMsg_fpitch(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fvelup
{
public:
  explicit Init_ChassisMsg_fvelup(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fheading fvelup(::radar_msgs::msg::ChassisMsg::_fvelup_type arg)
  {
    msg_.fvelup = std::move(arg);
    return Init_ChassisMsg_fheading(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fvelwest
{
public:
  explicit Init_ChassisMsg_fvelwest(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fvelup fvelwest(::radar_msgs::msg::ChassisMsg::_fvelwest_type arg)
  {
    msg_.fvelwest = std::move(arg);
    return Init_ChassisMsg_fvelup(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fvelnorth
{
public:
  explicit Init_ChassisMsg_fvelnorth(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fvelwest fvelnorth(::radar_msgs::msg::ChassisMsg::_fvelnorth_type arg)
  {
    msg_.fvelnorth = std::move(arg);
    return Init_ChassisMsg_fvelwest(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fangratez
{
public:
  explicit Init_ChassisMsg_fangratez(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fvelnorth fangratez(::radar_msgs::msg::ChassisMsg::_fangratez_type arg)
  {
    msg_.fangratez = std::move(arg);
    return Init_ChassisMsg_fvelnorth(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fangratey
{
public:
  explicit Init_ChassisMsg_fangratey(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fangratez fangratey(::radar_msgs::msg::ChassisMsg::_fangratey_type arg)
  {
    msg_.fangratey = std::move(arg);
    return Init_ChassisMsg_fangratez(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_fangratex
{
public:
  explicit Init_ChassisMsg_fangratex(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fangratey fangratex(::radar_msgs::msg::ChassisMsg::_fangratex_type arg)
  {
    msg_.fangratex = std::move(arg);
    return Init_ChassisMsg_fangratey(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_faccz
{
public:
  explicit Init_ChassisMsg_faccz(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_fangratex faccz(::radar_msgs::msg::ChassisMsg::_faccz_type arg)
  {
    msg_.faccz = std::move(arg);
    return Init_ChassisMsg_fangratex(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_faccy
{
public:
  explicit Init_ChassisMsg_faccy(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_faccz faccy(::radar_msgs::msg::ChassisMsg::_faccy_type arg)
  {
    msg_.faccy = std::move(arg);
    return Init_ChassisMsg_faccz(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_faccx
{
public:
  explicit Init_ChassisMsg_faccx(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_faccy faccx(::radar_msgs::msg::ChassisMsg::_faccx_type arg)
  {
    msg_.faccx = std::move(arg);
    return Init_ChassisMsg_faccy(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_faltitude
{
public:
  explicit Init_ChassisMsg_faltitude(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_faccx faltitude(::radar_msgs::msg::ChassisMsg::_faltitude_type arg)
  {
    msg_.faltitude = std::move(arg);
    return Init_ChassisMsg_faccx(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_flongitude
{
public:
  explicit Init_ChassisMsg_flongitude(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_faltitude flongitude(::radar_msgs::msg::ChassisMsg::_flongitude_type arg)
  {
    msg_.flongitude = std::move(arg);
    return Init_ChassisMsg_faltitude(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_flatitude
{
public:
  explicit Init_ChassisMsg_flatitude(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_flongitude flatitude(::radar_msgs::msg::ChassisMsg::_flatitude_type arg)
  {
    msg_.flatitude = std::move(arg);
    return Init_ChassisMsg_flongitude(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_itimestamp
{
public:
  explicit Init_ChassisMsg_itimestamp(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_flatitude itimestamp(::radar_msgs::msg::ChassisMsg::_itimestamp_type arg)
  {
    msg_.itimestamp = std::move(arg);
    return Init_ChassisMsg_flatitude(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_ncounter
{
public:
  explicit Init_ChassisMsg_ncounter(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_itimestamp ncounter(::radar_msgs::msg::ChassisMsg::_ncounter_type arg)
  {
    msg_.ncounter = std::move(arg);
    return Init_ChassisMsg_itimestamp(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_strgwhlangvhsc2
{
public:
  explicit Init_ChassisMsg_strgwhlangvhsc2(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_ncounter strgwhlangvhsc2(::radar_msgs::msg::ChassisMsg::_strgwhlangvhsc2_type arg)
  {
    msg_.strgwhlangvhsc2 = std::move(arg);
    return Init_ChassisMsg_ncounter(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_strgwhlanghsc2
{
public:
  explicit Init_ChassisMsg_strgwhlanghsc2(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_strgwhlangvhsc2 strgwhlanghsc2(::radar_msgs::msg::ChassisMsg::_strgwhlanghsc2_type arg)
  {
    msg_.strgwhlanghsc2 = std::move(arg);
    return Init_ChassisMsg_strgwhlangvhsc2(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_vehspdavgnondrvnvhsc2
{
public:
  explicit Init_ChassisMsg_vehspdavgnondrvnvhsc2(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_strgwhlanghsc2 vehspdavgnondrvnvhsc2(::radar_msgs::msg::ChassisMsg::_vehspdavgnondrvnvhsc2_type arg)
  {
    msg_.vehspdavgnondrvnvhsc2 = std::move(arg);
    return Init_ChassisMsg_strgwhlanghsc2(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_vehspdavgnondrvnhsc2
{
public:
  explicit Init_ChassisMsg_vehspdavgnondrvnhsc2(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_vehspdavgnondrvnvhsc2 vehspdavgnondrvnhsc2(::radar_msgs::msg::ChassisMsg::_vehspdavgnondrvnhsc2_type arg)
  {
    msg_.vehspdavgnondrvnhsc2 = std::move(arg);
    return Init_ChassisMsg_vehspdavgnondrvnvhsc2(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_vehspdavgdrvnvhsc2
{
public:
  explicit Init_ChassisMsg_vehspdavgdrvnvhsc2(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_vehspdavgnondrvnhsc2 vehspdavgdrvnvhsc2(::radar_msgs::msg::ChassisMsg::_vehspdavgdrvnvhsc2_type arg)
  {
    msg_.vehspdavgdrvnvhsc2 = std::move(arg);
    return Init_ChassisMsg_vehspdavgnondrvnhsc2(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_vehspdavgdrvnhsc2
{
public:
  explicit Init_ChassisMsg_vehspdavgdrvnhsc2(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_vehspdavgdrvnvhsc2 vehspdavgdrvnhsc2(::radar_msgs::msg::ChassisMsg::_vehspdavgdrvnhsc2_type arg)
  {
    msg_.vehspdavgdrvnhsc2 = std::move(arg);
    return Init_ChassisMsg_vehspdavgdrvnvhsc2(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_trshftlvrposv_h1hsc2
{
public:
  explicit Init_ChassisMsg_trshftlvrposv_h1hsc2(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_vehspdavgdrvnhsc2 trshftlvrposv_h1hsc2(::radar_msgs::msg::ChassisMsg::_trshftlvrposv_h1hsc2_type arg)
  {
    msg_.trshftlvrposv_h1hsc2 = std::move(arg);
    return Init_ChassisMsg_vehspdavgdrvnhsc2(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_trshftlvrpos_h1hsc2
{
public:
  explicit Init_ChassisMsg_trshftlvrpos_h1hsc2(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_trshftlvrposv_h1hsc2 trshftlvrpos_h1hsc2(::radar_msgs::msg::ChassisMsg::_trshftlvrpos_h1hsc2_type arg)
  {
    msg_.trshftlvrpos_h1hsc2 = std::move(arg);
    return Init_ChassisMsg_trshftlvrposv_h1hsc2(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_vehdynyawratevhsc2
{
public:
  explicit Init_ChassisMsg_vehdynyawratevhsc2(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_trshftlvrpos_h1hsc2 vehdynyawratevhsc2(::radar_msgs::msg::ChassisMsg::_vehdynyawratevhsc2_type arg)
  {
    msg_.vehdynyawratevhsc2 = std::move(arg);
    return Init_ChassisMsg_trshftlvrpos_h1hsc2(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_vehdynyawratehsc2
{
public:
  explicit Init_ChassisMsg_vehdynyawratehsc2(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_vehdynyawratevhsc2 vehdynyawratehsc2(::radar_msgs::msg::ChassisMsg::_vehdynyawratehsc2_type arg)
  {
    msg_.vehdynyawratehsc2 = std::move(arg);
    return Init_ChassisMsg_vehdynyawratevhsc2(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_reserved
{
public:
  explicit Init_ChassisMsg_reserved(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_vehdynyawratehsc2 reserved(::radar_msgs::msg::ChassisMsg::_reserved_type arg)
  {
    msg_.reserved = std::move(arg);
    return Init_ChassisMsg_vehdynyawratehsc2(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_islessinfo
{
public:
  explicit Init_ChassisMsg_islessinfo(::radar_msgs::msg::ChassisMsg & msg)
  : msg_(msg)
  {}
  Init_ChassisMsg_reserved islessinfo(::radar_msgs::msg::ChassisMsg::_islessinfo_type arg)
  {
    msg_.islessinfo = std::move(arg);
    return Init_ChassisMsg_reserved(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

class Init_ChassisMsg_header
{
public:
  Init_ChassisMsg_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ChassisMsg_islessinfo header(::radar_msgs::msg::ChassisMsg::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ChassisMsg_islessinfo(msg_);
  }

private:
  ::radar_msgs::msg::ChassisMsg msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::ChassisMsg>()
{
  return radar_msgs::msg::builder::Init_ChassisMsg_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__BUILDER_HPP_
