// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RadarTarget.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RadarTarget __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RadarTarget __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RadarTarget_
{
  using Type = RadarTarget_<ContainerAllocator>;

  explicit RadarTarget_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radar_id = 0ul;
      this->frame_cnt = 0ul;
      this->type = 0ul;
      this->target_num = 0ul;
      this->polar_state = 0ul;
    }
  }

  explicit RadarTarget_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radar_id = 0ul;
      this->frame_cnt = 0ul;
      this->type = 0ul;
      this->target_num = 0ul;
      this->polar_state = 0ul;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _radar_id_type =
    uint32_t;
  _radar_id_type radar_id;
  using _frame_cnt_type =
    uint32_t;
  _frame_cnt_type frame_cnt;
  using _type_type =
    uint32_t;
  _type_type type;
  using _target_num_type =
    uint32_t;
  _target_num_type target_num;
  using _polar_state_type =
    uint32_t;
  _polar_state_type polar_state;
  using _x_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _x_type x;
  using _y_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _y_type y;
  using _z_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _z_type z;
  using _v_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _v_type v;
  using _azimuth_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _azimuth_type azimuth;
  using _elevation_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _elevation_type elevation;
  using _snr_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _snr_type snr;
  using _power_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _power_type power;
  using _valid_flg_type =
    std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>>;
  _valid_flg_type valid_flg;
  using _existance_probability_type =
    std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>>;
  _existance_probability_type existance_probability;
  using _motion_state_type =
    std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>>;
  _motion_state_type motion_state;
  using _detection_class_type =
    std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>>;
  _detection_class_type detection_class;
  using _reset_cnt_type =
    std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>>;
  _reset_cnt_type reset_cnt;
  using _od_timeout_cnt_type =
    std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>>;
  _od_timeout_cnt_type od_timeout_cnt;
  using _reserved_a_type =
    std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>>;
  _reserved_a_type reserved_a;
  using _reserved_b_type =
    std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>>;
  _reserved_b_type reserved_b;
  using _reserved_c_type =
    std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>>;
  _reserved_c_type reserved_c;
  using _reserved_d_type =
    std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>>;
  _reserved_d_type reserved_d;
  using _reserved_e_type =
    std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>>;
  _reserved_e_type reserved_e;
  using _reserved_f_type =
    std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>>;
  _reserved_f_type reserved_f;
  using _reserved_g_type =
    std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>>;
  _reserved_g_type reserved_g;
  using _reserved_h_type =
    std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>>;
  _reserved_h_type reserved_h;
  using _reserved_i_type =
    std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>>;
  _reserved_i_type reserved_i;
  using _reserved_j_type =
    std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>>;
  _reserved_j_type reserved_j;
  using _reserved_k_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _reserved_k_type reserved_k;
  using _reserved_l_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _reserved_l_type reserved_l;
  using _reserved_m_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _reserved_m_type reserved_m;
  using _reserved_n_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _reserved_n_type reserved_n;
  using _reserved_o_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _reserved_o_type reserved_o;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__radar_id(
    const uint32_t & _arg)
  {
    this->radar_id = _arg;
    return *this;
  }
  Type & set__frame_cnt(
    const uint32_t & _arg)
  {
    this->frame_cnt = _arg;
    return *this;
  }
  Type & set__type(
    const uint32_t & _arg)
  {
    this->type = _arg;
    return *this;
  }
  Type & set__target_num(
    const uint32_t & _arg)
  {
    this->target_num = _arg;
    return *this;
  }
  Type & set__polar_state(
    const uint32_t & _arg)
  {
    this->polar_state = _arg;
    return *this;
  }
  Type & set__x(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->x = _arg;
    return *this;
  }
  Type & set__y(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->y = _arg;
    return *this;
  }
  Type & set__z(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->z = _arg;
    return *this;
  }
  Type & set__v(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->v = _arg;
    return *this;
  }
  Type & set__azimuth(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->azimuth = _arg;
    return *this;
  }
  Type & set__elevation(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->elevation = _arg;
    return *this;
  }
  Type & set__snr(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->snr = _arg;
    return *this;
  }
  Type & set__power(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->power = _arg;
    return *this;
  }
  Type & set__valid_flg(
    const std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>> & _arg)
  {
    this->valid_flg = _arg;
    return *this;
  }
  Type & set__existance_probability(
    const std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>> & _arg)
  {
    this->existance_probability = _arg;
    return *this;
  }
  Type & set__motion_state(
    const std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>> & _arg)
  {
    this->motion_state = _arg;
    return *this;
  }
  Type & set__detection_class(
    const std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>> & _arg)
  {
    this->detection_class = _arg;
    return *this;
  }
  Type & set__reset_cnt(
    const std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>> & _arg)
  {
    this->reset_cnt = _arg;
    return *this;
  }
  Type & set__od_timeout_cnt(
    const std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>> & _arg)
  {
    this->od_timeout_cnt = _arg;
    return *this;
  }
  Type & set__reserved_a(
    const std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>> & _arg)
  {
    this->reserved_a = _arg;
    return *this;
  }
  Type & set__reserved_b(
    const std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>> & _arg)
  {
    this->reserved_b = _arg;
    return *this;
  }
  Type & set__reserved_c(
    const std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>> & _arg)
  {
    this->reserved_c = _arg;
    return *this;
  }
  Type & set__reserved_d(
    const std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>> & _arg)
  {
    this->reserved_d = _arg;
    return *this;
  }
  Type & set__reserved_e(
    const std::vector<uint16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint16_t>> & _arg)
  {
    this->reserved_e = _arg;
    return *this;
  }
  Type & set__reserved_f(
    const std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>> & _arg)
  {
    this->reserved_f = _arg;
    return *this;
  }
  Type & set__reserved_g(
    const std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>> & _arg)
  {
    this->reserved_g = _arg;
    return *this;
  }
  Type & set__reserved_h(
    const std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>> & _arg)
  {
    this->reserved_h = _arg;
    return *this;
  }
  Type & set__reserved_i(
    const std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>> & _arg)
  {
    this->reserved_i = _arg;
    return *this;
  }
  Type & set__reserved_j(
    const std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>> & _arg)
  {
    this->reserved_j = _arg;
    return *this;
  }
  Type & set__reserved_k(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->reserved_k = _arg;
    return *this;
  }
  Type & set__reserved_l(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->reserved_l = _arg;
    return *this;
  }
  Type & set__reserved_m(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->reserved_m = _arg;
    return *this;
  }
  Type & set__reserved_n(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->reserved_n = _arg;
    return *this;
  }
  Type & set__reserved_o(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->reserved_o = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RadarTarget_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RadarTarget_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RadarTarget_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RadarTarget_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RadarTarget_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RadarTarget_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RadarTarget_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RadarTarget_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RadarTarget_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RadarTarget_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RadarTarget
    std::shared_ptr<radar_msgs::msg::RadarTarget_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RadarTarget
    std::shared_ptr<radar_msgs::msg::RadarTarget_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RadarTarget_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->radar_id != other.radar_id) {
      return false;
    }
    if (this->frame_cnt != other.frame_cnt) {
      return false;
    }
    if (this->type != other.type) {
      return false;
    }
    if (this->target_num != other.target_num) {
      return false;
    }
    if (this->polar_state != other.polar_state) {
      return false;
    }
    if (this->x != other.x) {
      return false;
    }
    if (this->y != other.y) {
      return false;
    }
    if (this->z != other.z) {
      return false;
    }
    if (this->v != other.v) {
      return false;
    }
    if (this->azimuth != other.azimuth) {
      return false;
    }
    if (this->elevation != other.elevation) {
      return false;
    }
    if (this->snr != other.snr) {
      return false;
    }
    if (this->power != other.power) {
      return false;
    }
    if (this->valid_flg != other.valid_flg) {
      return false;
    }
    if (this->existance_probability != other.existance_probability) {
      return false;
    }
    if (this->motion_state != other.motion_state) {
      return false;
    }
    if (this->detection_class != other.detection_class) {
      return false;
    }
    if (this->reset_cnt != other.reset_cnt) {
      return false;
    }
    if (this->od_timeout_cnt != other.od_timeout_cnt) {
      return false;
    }
    if (this->reserved_a != other.reserved_a) {
      return false;
    }
    if (this->reserved_b != other.reserved_b) {
      return false;
    }
    if (this->reserved_c != other.reserved_c) {
      return false;
    }
    if (this->reserved_d != other.reserved_d) {
      return false;
    }
    if (this->reserved_e != other.reserved_e) {
      return false;
    }
    if (this->reserved_f != other.reserved_f) {
      return false;
    }
    if (this->reserved_g != other.reserved_g) {
      return false;
    }
    if (this->reserved_h != other.reserved_h) {
      return false;
    }
    if (this->reserved_i != other.reserved_i) {
      return false;
    }
    if (this->reserved_j != other.reserved_j) {
      return false;
    }
    if (this->reserved_k != other.reserved_k) {
      return false;
    }
    if (this->reserved_l != other.reserved_l) {
      return false;
    }
    if (this->reserved_m != other.reserved_m) {
      return false;
    }
    if (this->reserved_n != other.reserved_n) {
      return false;
    }
    if (this->reserved_o != other.reserved_o) {
      return false;
    }
    return true;
  }
  bool operator!=(const RadarTarget_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RadarTarget_

// alias to use template instance with default allocator
using RadarTarget =
  radar_msgs::msg::RadarTarget_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__STRUCT_HPP_
