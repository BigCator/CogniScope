// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/RfStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RF_STATUS__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__RF_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/rf_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'diglatentfaultdata'
#include "radar_msgs/msg/detail/rl_dig_latent_fault_report_data__traits.hpp"
// Member 'reportheaderdata'
#include "radar_msgs/msg/detail/rl_mon_report_hdr_data__traits.hpp"
// Member 'reporttempdata'
#include "radar_msgs/msg/detail/rl_mon_temp_report_data__traits.hpp"
// Member 'digperiodicreportdata'
#include "radar_msgs/msg/detail/rl_dig_periodic_report_data__traits.hpp"
// Member 'reportrxgainphdata'
#include "radar_msgs/msg/detail/rl_mon_rx_gain_ph_rep__traits.hpp"
// Member 'reportrxnoisefigdata'
#include "radar_msgs/msg/detail/rl_mon_rx_noise_fig_rep__traits.hpp"
// Member 'reportrxifstagedata'
#include "radar_msgs/msg/detail/rl_mon_rx_if_stage_rep__traits.hpp"
// Member 'reportrxintanasigdata'
#include "radar_msgs/msg/detail/rl_mon_rx_int_ana_sig_rep__traits.hpp"
// Member 'reportpmclklointanasigdata'
#include "radar_msgs/msg/detail/rl_mon_pmclklo_int_ana_sig_rep__traits.hpp"
// Member 'reportgpadcintanasigdata'
#include "radar_msgs/msg/detail/rl_mon_gpadc_int_ana_sig_rep__traits.hpp"
// Member 'reportpllconvoltdata'
#include "radar_msgs/msg/detail/rl_mon_pll_con_volt_rep__traits.hpp"
// Member 'reportdccclkfreqdata'
#include "radar_msgs/msg/detail/rl_mon_dcc_clk_freq_rep__traits.hpp"
// Member 'reportsynthfreqnonlivedata'
#include "radar_msgs/msg/detail/rl_mon_synth_freq_non_live_rep__traits.hpp"
// Member 'reportrxmixrinpwrdata'
#include "radar_msgs/msg/detail/rl_mon_rx_mixr_in_pwr_rep__traits.hpp"
// Member 'reporttxintanasigdata'
#include "radar_msgs/msg/detail/rl_mon_tx_int_ana_sig_rep__traits.hpp"
// Member 'reportextanasigdata'
#include "radar_msgs/msg/detail/rl_mon_ext_ana_sig_rep__traits.hpp"
// Member 'reportsynthfreqdata'
#include "radar_msgs/msg/detail/rl_mon_synth_freq_rep__traits.hpp"
// Member 'reporttxphshiftdata'
#include "radar_msgs/msg/detail/rl_mon_tx_ph_shift_rep__traits.hpp"
// Member 'reporttxgainphamisdata'
#include "radar_msgs/msg/detail/rl_mon_tx_gain_pha_mis_rep__traits.hpp"
// Member 'reporttxballbreakdata'
#include "radar_msgs/msg/detail/rl_mon_tx_ball_break_rep__traits.hpp"
// Member 'reporttxpowdata'
#include "radar_msgs/msg/detail/rl_mon_tx_pow_rep__traits.hpp"
// Member 'reportrecvdgpadcdata'
#include "radar_msgs/msg/detail/rl_recvd_gp_adc_data__traits.hpp"
// Member 'reportanalogfaultdata'
#include "radar_msgs/msg/detail/rl_analog_fault_report_data__traits.hpp"
// Member 'reporttimingerrordata'
#include "radar_msgs/msg/detail/rl_cal_mon_timing_error_report_data__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const RfStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: radarid
  {
    out << "radarid: ";
    rosidl_generator_traits::value_to_yaml(msg.radarid, out);
    out << ", ";
  }

  // member: framecnt
  {
    out << "framecnt: ";
    rosidl_generator_traits::value_to_yaml(msg.framecnt, out);
    out << ", ";
  }

  // member: diglatentfaultdata
  {
    out << "diglatentfaultdata: ";
    to_flow_style_yaml(msg.diglatentfaultdata, out);
    out << ", ";
  }

  // member: reportheaderdata
  {
    out << "reportheaderdata: ";
    to_flow_style_yaml(msg.reportheaderdata, out);
    out << ", ";
  }

  // member: reporttempdata
  {
    out << "reporttempdata: ";
    to_flow_style_yaml(msg.reporttempdata, out);
    out << ", ";
  }

  // member: digperiodicreportdata
  {
    out << "digperiodicreportdata: ";
    to_flow_style_yaml(msg.digperiodicreportdata, out);
    out << ", ";
  }

  // member: reportrxgainphdata
  {
    if (msg.reportrxgainphdata.size() == 0) {
      out << "reportrxgainphdata: []";
    } else {
      out << "reportrxgainphdata: [";
      size_t pending_items = msg.reportrxgainphdata.size();
      for (auto item : msg.reportrxgainphdata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reportrxnoisefigdata
  {
    if (msg.reportrxnoisefigdata.size() == 0) {
      out << "reportrxnoisefigdata: []";
    } else {
      out << "reportrxnoisefigdata: [";
      size_t pending_items = msg.reportrxnoisefigdata.size();
      for (auto item : msg.reportrxnoisefigdata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reportrxifstagedata
  {
    if (msg.reportrxifstagedata.size() == 0) {
      out << "reportrxifstagedata: []";
    } else {
      out << "reportrxifstagedata: [";
      size_t pending_items = msg.reportrxifstagedata.size();
      for (auto item : msg.reportrxifstagedata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reportrxintanasigdata
  {
    if (msg.reportrxintanasigdata.size() == 0) {
      out << "reportrxintanasigdata: []";
    } else {
      out << "reportrxintanasigdata: [";
      size_t pending_items = msg.reportrxintanasigdata.size();
      for (auto item : msg.reportrxintanasigdata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reportpmclklointanasigdata
  {
    if (msg.reportpmclklointanasigdata.size() == 0) {
      out << "reportpmclklointanasigdata: []";
    } else {
      out << "reportpmclklointanasigdata: [";
      size_t pending_items = msg.reportpmclklointanasigdata.size();
      for (auto item : msg.reportpmclklointanasigdata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reportgpadcintanasigdata
  {
    out << "reportgpadcintanasigdata: ";
    to_flow_style_yaml(msg.reportgpadcintanasigdata, out);
    out << ", ";
  }

  // member: reportpllconvoltdata
  {
    out << "reportpllconvoltdata: ";
    to_flow_style_yaml(msg.reportpllconvoltdata, out);
    out << ", ";
  }

  // member: reportdccclkfreqdata
  {
    out << "reportdccclkfreqdata: ";
    to_flow_style_yaml(msg.reportdccclkfreqdata, out);
    out << ", ";
  }

  // member: reportsynthfreqnonlivedata
  {
    out << "reportsynthfreqnonlivedata: ";
    to_flow_style_yaml(msg.reportsynthfreqnonlivedata, out);
    out << ", ";
  }

  // member: reportrxmixrinpwrdata
  {
    if (msg.reportrxmixrinpwrdata.size() == 0) {
      out << "reportrxmixrinpwrdata: []";
    } else {
      out << "reportrxmixrinpwrdata: [";
      size_t pending_items = msg.reportrxmixrinpwrdata.size();
      for (auto item : msg.reportrxmixrinpwrdata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reporttxintanasigdata
  {
    if (msg.reporttxintanasigdata.size() == 0) {
      out << "reporttxintanasigdata: []";
    } else {
      out << "reporttxintanasigdata: [";
      size_t pending_items = msg.reporttxintanasigdata.size();
      for (auto item : msg.reporttxintanasigdata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reportextanasigdata
  {
    out << "reportextanasigdata: ";
    to_flow_style_yaml(msg.reportextanasigdata, out);
    out << ", ";
  }

  // member: reportsynthfreqdata
  {
    if (msg.reportsynthfreqdata.size() == 0) {
      out << "reportsynthfreqdata: []";
    } else {
      out << "reportsynthfreqdata: [";
      size_t pending_items = msg.reportsynthfreqdata.size();
      for (auto item : msg.reportsynthfreqdata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reporttxphshiftdata
  {
    if (msg.reporttxphshiftdata.size() == 0) {
      out << "reporttxphshiftdata: []";
    } else {
      out << "reporttxphshiftdata: [";
      size_t pending_items = msg.reporttxphshiftdata.size();
      for (auto item : msg.reporttxphshiftdata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reporttxgainphamisdata
  {
    if (msg.reporttxgainphamisdata.size() == 0) {
      out << "reporttxgainphamisdata: []";
    } else {
      out << "reporttxgainphamisdata: [";
      size_t pending_items = msg.reporttxgainphamisdata.size();
      for (auto item : msg.reporttxgainphamisdata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reporttxballbreakdata
  {
    out << "reporttxballbreakdata: ";
    to_flow_style_yaml(msg.reporttxballbreakdata, out);
    out << ", ";
  }

  // member: reporttxpowdata
  {
    if (msg.reporttxpowdata.size() == 0) {
      out << "reporttxpowdata: []";
    } else {
      out << "reporttxpowdata: [";
      size_t pending_items = msg.reporttxpowdata.size();
      for (auto item : msg.reporttxpowdata) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reportrecvdgpadcdata
  {
    out << "reportrecvdgpadcdata: ";
    to_flow_style_yaml(msg.reportrecvdgpadcdata, out);
    out << ", ";
  }

  // member: reportanalogfaultdata
  {
    out << "reportanalogfaultdata: ";
    to_flow_style_yaml(msg.reportanalogfaultdata, out);
    out << ", ";
  }

  // member: reporttimingerrordata
  {
    out << "reporttimingerrordata: ";
    to_flow_style_yaml(msg.reporttimingerrordata, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RfStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: radarid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "radarid: ";
    rosidl_generator_traits::value_to_yaml(msg.radarid, out);
    out << "\n";
  }

  // member: framecnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "framecnt: ";
    rosidl_generator_traits::value_to_yaml(msg.framecnt, out);
    out << "\n";
  }

  // member: diglatentfaultdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "diglatentfaultdata:\n";
    to_block_style_yaml(msg.diglatentfaultdata, out, indentation + 2);
  }

  // member: reportheaderdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reportheaderdata:\n";
    to_block_style_yaml(msg.reportheaderdata, out, indentation + 2);
  }

  // member: reporttempdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reporttempdata:\n";
    to_block_style_yaml(msg.reporttempdata, out, indentation + 2);
  }

  // member: digperiodicreportdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "digperiodicreportdata:\n";
    to_block_style_yaml(msg.digperiodicreportdata, out, indentation + 2);
  }

  // member: reportrxgainphdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reportrxgainphdata.size() == 0) {
      out << "reportrxgainphdata: []\n";
    } else {
      out << "reportrxgainphdata:\n";
      for (auto item : msg.reportrxgainphdata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reportrxnoisefigdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reportrxnoisefigdata.size() == 0) {
      out << "reportrxnoisefigdata: []\n";
    } else {
      out << "reportrxnoisefigdata:\n";
      for (auto item : msg.reportrxnoisefigdata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reportrxifstagedata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reportrxifstagedata.size() == 0) {
      out << "reportrxifstagedata: []\n";
    } else {
      out << "reportrxifstagedata:\n";
      for (auto item : msg.reportrxifstagedata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reportrxintanasigdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reportrxintanasigdata.size() == 0) {
      out << "reportrxintanasigdata: []\n";
    } else {
      out << "reportrxintanasigdata:\n";
      for (auto item : msg.reportrxintanasigdata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reportpmclklointanasigdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reportpmclklointanasigdata.size() == 0) {
      out << "reportpmclklointanasigdata: []\n";
    } else {
      out << "reportpmclklointanasigdata:\n";
      for (auto item : msg.reportpmclklointanasigdata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reportgpadcintanasigdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reportgpadcintanasigdata:\n";
    to_block_style_yaml(msg.reportgpadcintanasigdata, out, indentation + 2);
  }

  // member: reportpllconvoltdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reportpllconvoltdata:\n";
    to_block_style_yaml(msg.reportpllconvoltdata, out, indentation + 2);
  }

  // member: reportdccclkfreqdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reportdccclkfreqdata:\n";
    to_block_style_yaml(msg.reportdccclkfreqdata, out, indentation + 2);
  }

  // member: reportsynthfreqnonlivedata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reportsynthfreqnonlivedata:\n";
    to_block_style_yaml(msg.reportsynthfreqnonlivedata, out, indentation + 2);
  }

  // member: reportrxmixrinpwrdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reportrxmixrinpwrdata.size() == 0) {
      out << "reportrxmixrinpwrdata: []\n";
    } else {
      out << "reportrxmixrinpwrdata:\n";
      for (auto item : msg.reportrxmixrinpwrdata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reporttxintanasigdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reporttxintanasigdata.size() == 0) {
      out << "reporttxintanasigdata: []\n";
    } else {
      out << "reporttxintanasigdata:\n";
      for (auto item : msg.reporttxintanasigdata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reportextanasigdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reportextanasigdata:\n";
    to_block_style_yaml(msg.reportextanasigdata, out, indentation + 2);
  }

  // member: reportsynthfreqdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reportsynthfreqdata.size() == 0) {
      out << "reportsynthfreqdata: []\n";
    } else {
      out << "reportsynthfreqdata:\n";
      for (auto item : msg.reportsynthfreqdata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reporttxphshiftdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reporttxphshiftdata.size() == 0) {
      out << "reporttxphshiftdata: []\n";
    } else {
      out << "reporttxphshiftdata:\n";
      for (auto item : msg.reporttxphshiftdata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reporttxgainphamisdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reporttxgainphamisdata.size() == 0) {
      out << "reporttxgainphamisdata: []\n";
    } else {
      out << "reporttxgainphamisdata:\n";
      for (auto item : msg.reporttxgainphamisdata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reporttxballbreakdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reporttxballbreakdata:\n";
    to_block_style_yaml(msg.reporttxballbreakdata, out, indentation + 2);
  }

  // member: reporttxpowdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reporttxpowdata.size() == 0) {
      out << "reporttxpowdata: []\n";
    } else {
      out << "reporttxpowdata:\n";
      for (auto item : msg.reporttxpowdata) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: reportrecvdgpadcdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reportrecvdgpadcdata:\n";
    to_block_style_yaml(msg.reportrecvdgpadcdata, out, indentation + 2);
  }

  // member: reportanalogfaultdata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reportanalogfaultdata:\n";
    to_block_style_yaml(msg.reportanalogfaultdata, out, indentation + 2);
  }

  // member: reporttimingerrordata
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reporttimingerrordata:\n";
    to_block_style_yaml(msg.reporttimingerrordata, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RfStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::RfStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::RfStatus & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::RfStatus>()
{
  return "radar_msgs::msg::RfStatus";
}

template<>
inline const char * name<radar_msgs::msg::RfStatus>()
{
  return "radar_msgs/msg/RfStatus";
}

template<>
struct has_fixed_size<radar_msgs::msg::RfStatus>
  : std::integral_constant<bool, has_fixed_size<radar_msgs::msg::RlAnalogFaultReportData>::value && has_fixed_size<radar_msgs::msg::RlCalMonTimingErrorReportData>::value && has_fixed_size<radar_msgs::msg::RlDigLatentFaultReportData>::value && has_fixed_size<radar_msgs::msg::RlDigPeriodicReportData>::value && has_fixed_size<radar_msgs::msg::RlMonDccClkFreqRep>::value && has_fixed_size<radar_msgs::msg::RlMonExtAnaSigRep>::value && has_fixed_size<radar_msgs::msg::RlMonGpadcIntAnaSigRep>::value && has_fixed_size<radar_msgs::msg::RlMonPllConVoltRep>::value && has_fixed_size<radar_msgs::msg::RlMonPmclkloIntAnaSigRep>::value && has_fixed_size<radar_msgs::msg::RlMonReportHdrData>::value && has_fixed_size<radar_msgs::msg::RlMonRxGainPhRep>::value && has_fixed_size<radar_msgs::msg::RlMonRxIfStageRep>::value && has_fixed_size<radar_msgs::msg::RlMonRxIntAnaSigRep>::value && has_fixed_size<radar_msgs::msg::RlMonRxMixrInPwrRep>::value && has_fixed_size<radar_msgs::msg::RlMonRxNoiseFigRep>::value && has_fixed_size<radar_msgs::msg::RlMonSynthFreqNonLiveRep>::value && has_fixed_size<radar_msgs::msg::RlMonSynthFreqRep>::value && has_fixed_size<radar_msgs::msg::RlMonTempReportData>::value && has_fixed_size<radar_msgs::msg::RlMonTxBallBreakRep>::value && has_fixed_size<radar_msgs::msg::RlMonTxGainPhaMisRep>::value && has_fixed_size<radar_msgs::msg::RlMonTxIntAnaSigRep>::value && has_fixed_size<radar_msgs::msg::RlMonTxPhShiftRep>::value && has_fixed_size<radar_msgs::msg::RlMonTxPowRep>::value && has_fixed_size<radar_msgs::msg::RlRecvdGpAdcData>::value && has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<radar_msgs::msg::RfStatus>
  : std::integral_constant<bool, has_bounded_size<radar_msgs::msg::RlAnalogFaultReportData>::value && has_bounded_size<radar_msgs::msg::RlCalMonTimingErrorReportData>::value && has_bounded_size<radar_msgs::msg::RlDigLatentFaultReportData>::value && has_bounded_size<radar_msgs::msg::RlDigPeriodicReportData>::value && has_bounded_size<radar_msgs::msg::RlMonDccClkFreqRep>::value && has_bounded_size<radar_msgs::msg::RlMonExtAnaSigRep>::value && has_bounded_size<radar_msgs::msg::RlMonGpadcIntAnaSigRep>::value && has_bounded_size<radar_msgs::msg::RlMonPllConVoltRep>::value && has_bounded_size<radar_msgs::msg::RlMonPmclkloIntAnaSigRep>::value && has_bounded_size<radar_msgs::msg::RlMonReportHdrData>::value && has_bounded_size<radar_msgs::msg::RlMonRxGainPhRep>::value && has_bounded_size<radar_msgs::msg::RlMonRxIfStageRep>::value && has_bounded_size<radar_msgs::msg::RlMonRxIntAnaSigRep>::value && has_bounded_size<radar_msgs::msg::RlMonRxMixrInPwrRep>::value && has_bounded_size<radar_msgs::msg::RlMonRxNoiseFigRep>::value && has_bounded_size<radar_msgs::msg::RlMonSynthFreqNonLiveRep>::value && has_bounded_size<radar_msgs::msg::RlMonSynthFreqRep>::value && has_bounded_size<radar_msgs::msg::RlMonTempReportData>::value && has_bounded_size<radar_msgs::msg::RlMonTxBallBreakRep>::value && has_bounded_size<radar_msgs::msg::RlMonTxGainPhaMisRep>::value && has_bounded_size<radar_msgs::msg::RlMonTxIntAnaSigRep>::value && has_bounded_size<radar_msgs::msg::RlMonTxPhShiftRep>::value && has_bounded_size<radar_msgs::msg::RlMonTxPowRep>::value && has_bounded_size<radar_msgs::msg::RlRecvdGpAdcData>::value && has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<radar_msgs::msg::RfStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__RF_STATUS__TRAITS_HPP_
