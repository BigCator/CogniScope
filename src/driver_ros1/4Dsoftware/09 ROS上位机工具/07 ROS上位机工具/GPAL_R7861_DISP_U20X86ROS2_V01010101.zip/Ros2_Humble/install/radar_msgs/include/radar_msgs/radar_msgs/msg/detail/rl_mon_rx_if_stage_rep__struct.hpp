// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RlMonRxIfStageRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_RX_IF_STAGE_REP__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_RX_IF_STAGE_REP__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RlMonRxIfStageRep __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RlMonRxIfStageRep __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RlMonRxIfStageRep_
{
  using Type = RlMonRxIfStageRep_<ContainerAllocator>;

  explicit RlMonRxIfStageRep_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      this->profindex = 0;
      this->reserved0 = 0;
      this->lpfcutoffbandedgedroopvalrx0 = 0;
      std::fill<typename std::array<int8_t, 8>::iterator, int8_t>(this->hpfcutofffreqer.begin(), this->hpfcutofffreqer.end(), 0);
      std::fill<typename std::array<int8_t, 8>::iterator, int8_t>(this->lpfcutoffstopbandatten.begin(), this->lpfcutoffstopbandatten.end(), 0);
      std::fill<typename std::array<int8_t, 8>::iterator, int8_t>(this->rxifagainerval.begin(), this->rxifagainerval.end(), 0);
      this->ifgainexp = 0;
      this->reserved2 = 0;
      std::fill<typename std::array<int8_t, 6>::iterator, int8_t>(this->lpfcutoffbandedgedroopvalrx.begin(), this->lpfcutoffbandedgedroopvalrx.end(), 0);
      this->timestamp = 0ul;
    }
  }

  explicit RlMonRxIfStageRep_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : hpfcutofffreqer(_alloc),
    lpfcutoffstopbandatten(_alloc),
    rxifagainerval(_alloc),
    lpfcutoffbandedgedroopvalrx(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      this->profindex = 0;
      this->reserved0 = 0;
      this->lpfcutoffbandedgedroopvalrx0 = 0;
      std::fill<typename std::array<int8_t, 8>::iterator, int8_t>(this->hpfcutofffreqer.begin(), this->hpfcutofffreqer.end(), 0);
      std::fill<typename std::array<int8_t, 8>::iterator, int8_t>(this->lpfcutoffstopbandatten.begin(), this->lpfcutoffstopbandatten.end(), 0);
      std::fill<typename std::array<int8_t, 8>::iterator, int8_t>(this->rxifagainerval.begin(), this->rxifagainerval.end(), 0);
      this->ifgainexp = 0;
      this->reserved2 = 0;
      std::fill<typename std::array<int8_t, 6>::iterator, int8_t>(this->lpfcutoffbandedgedroopvalrx.begin(), this->lpfcutoffbandedgedroopvalrx.end(), 0);
      this->timestamp = 0ul;
    }
  }

  // field types and members
  using _statusflags_type =
    uint16_t;
  _statusflags_type statusflags;
  using _errorcode_type =
    uint16_t;
  _errorcode_type errorcode;
  using _profindex_type =
    uint8_t;
  _profindex_type profindex;
  using _reserved0_type =
    uint8_t;
  _reserved0_type reserved0;
  using _lpfcutoffbandedgedroopvalrx0_type =
    int16_t;
  _lpfcutoffbandedgedroopvalrx0_type lpfcutoffbandedgedroopvalrx0;
  using _hpfcutofffreqer_type =
    std::array<int8_t, 8>;
  _hpfcutofffreqer_type hpfcutofffreqer;
  using _lpfcutoffstopbandatten_type =
    std::array<int8_t, 8>;
  _lpfcutoffstopbandatten_type lpfcutoffstopbandatten;
  using _rxifagainerval_type =
    std::array<int8_t, 8>;
  _rxifagainerval_type rxifagainerval;
  using _ifgainexp_type =
    int8_t;
  _ifgainexp_type ifgainexp;
  using _reserved2_type =
    uint8_t;
  _reserved2_type reserved2;
  using _lpfcutoffbandedgedroopvalrx_type =
    std::array<int8_t, 6>;
  _lpfcutoffbandedgedroopvalrx_type lpfcutoffbandedgedroopvalrx;
  using _timestamp_type =
    uint32_t;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__statusflags(
    const uint16_t & _arg)
  {
    this->statusflags = _arg;
    return *this;
  }
  Type & set__errorcode(
    const uint16_t & _arg)
  {
    this->errorcode = _arg;
    return *this;
  }
  Type & set__profindex(
    const uint8_t & _arg)
  {
    this->profindex = _arg;
    return *this;
  }
  Type & set__reserved0(
    const uint8_t & _arg)
  {
    this->reserved0 = _arg;
    return *this;
  }
  Type & set__lpfcutoffbandedgedroopvalrx0(
    const int16_t & _arg)
  {
    this->lpfcutoffbandedgedroopvalrx0 = _arg;
    return *this;
  }
  Type & set__hpfcutofffreqer(
    const std::array<int8_t, 8> & _arg)
  {
    this->hpfcutofffreqer = _arg;
    return *this;
  }
  Type & set__lpfcutoffstopbandatten(
    const std::array<int8_t, 8> & _arg)
  {
    this->lpfcutoffstopbandatten = _arg;
    return *this;
  }
  Type & set__rxifagainerval(
    const std::array<int8_t, 8> & _arg)
  {
    this->rxifagainerval = _arg;
    return *this;
  }
  Type & set__ifgainexp(
    const int8_t & _arg)
  {
    this->ifgainexp = _arg;
    return *this;
  }
  Type & set__reserved2(
    const uint8_t & _arg)
  {
    this->reserved2 = _arg;
    return *this;
  }
  Type & set__lpfcutoffbandedgedroopvalrx(
    const std::array<int8_t, 6> & _arg)
  {
    this->lpfcutoffbandedgedroopvalrx = _arg;
    return *this;
  }
  Type & set__timestamp(
    const uint32_t & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RlMonRxIfStageRep
    std::shared_ptr<radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RlMonRxIfStageRep
    std::shared_ptr<radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RlMonRxIfStageRep_ & other) const
  {
    if (this->statusflags != other.statusflags) {
      return false;
    }
    if (this->errorcode != other.errorcode) {
      return false;
    }
    if (this->profindex != other.profindex) {
      return false;
    }
    if (this->reserved0 != other.reserved0) {
      return false;
    }
    if (this->lpfcutoffbandedgedroopvalrx0 != other.lpfcutoffbandedgedroopvalrx0) {
      return false;
    }
    if (this->hpfcutofffreqer != other.hpfcutofffreqer) {
      return false;
    }
    if (this->lpfcutoffstopbandatten != other.lpfcutoffstopbandatten) {
      return false;
    }
    if (this->rxifagainerval != other.rxifagainerval) {
      return false;
    }
    if (this->ifgainexp != other.ifgainexp) {
      return false;
    }
    if (this->reserved2 != other.reserved2) {
      return false;
    }
    if (this->lpfcutoffbandedgedroopvalrx != other.lpfcutoffbandedgedroopvalrx) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const RlMonRxIfStageRep_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RlMonRxIfStageRep_

// alias to use template instance with default allocator
using RlMonRxIfStageRep =
  radar_msgs::msg::RlMonRxIfStageRep_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_RX_IF_STAGE_REP__STRUCT_HPP_
