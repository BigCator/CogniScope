// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonDccClkFreqRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_DCC_CLK_FREQ_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_DCC_CLK_FREQ_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_dcc_clk_freq_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonDccClkFreqRep_timestamp
{
public:
  explicit Init_RlMonDccClkFreqRep_timestamp(::radar_msgs::msg::RlMonDccClkFreqRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonDccClkFreqRep timestamp(::radar_msgs::msg::RlMonDccClkFreqRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonDccClkFreqRep msg_;
};

class Init_RlMonDccClkFreqRep_reserved
{
public:
  explicit Init_RlMonDccClkFreqRep_reserved(::radar_msgs::msg::RlMonDccClkFreqRep & msg)
  : msg_(msg)
  {}
  Init_RlMonDccClkFreqRep_timestamp reserved(::radar_msgs::msg::RlMonDccClkFreqRep::_reserved_type arg)
  {
    msg_.reserved = std::move(arg);
    return Init_RlMonDccClkFreqRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonDccClkFreqRep msg_;
};

class Init_RlMonDccClkFreqRep_freqmeasval
{
public:
  explicit Init_RlMonDccClkFreqRep_freqmeasval(::radar_msgs::msg::RlMonDccClkFreqRep & msg)
  : msg_(msg)
  {}
  Init_RlMonDccClkFreqRep_reserved freqmeasval(::radar_msgs::msg::RlMonDccClkFreqRep::_freqmeasval_type arg)
  {
    msg_.freqmeasval = std::move(arg);
    return Init_RlMonDccClkFreqRep_reserved(msg_);
  }

private:
  ::radar_msgs::msg::RlMonDccClkFreqRep msg_;
};

class Init_RlMonDccClkFreqRep_errorcode
{
public:
  explicit Init_RlMonDccClkFreqRep_errorcode(::radar_msgs::msg::RlMonDccClkFreqRep & msg)
  : msg_(msg)
  {}
  Init_RlMonDccClkFreqRep_freqmeasval errorcode(::radar_msgs::msg::RlMonDccClkFreqRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonDccClkFreqRep_freqmeasval(msg_);
  }

private:
  ::radar_msgs::msg::RlMonDccClkFreqRep msg_;
};

class Init_RlMonDccClkFreqRep_statusflags
{
public:
  Init_RlMonDccClkFreqRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonDccClkFreqRep_errorcode statusflags(::radar_msgs::msg::RlMonDccClkFreqRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonDccClkFreqRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonDccClkFreqRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonDccClkFreqRep>()
{
  return radar_msgs::msg::builder::Init_RlMonDccClkFreqRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_DCC_CLK_FREQ_REP__BUILDER_HPP_
