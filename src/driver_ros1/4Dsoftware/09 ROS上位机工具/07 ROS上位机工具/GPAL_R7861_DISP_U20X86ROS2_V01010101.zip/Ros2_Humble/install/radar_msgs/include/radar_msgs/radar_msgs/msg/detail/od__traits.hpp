// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/Od.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OD__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__OD__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/od__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'pose'
// Member 'pose_nearest'
#include "geometry_msgs/msg/detail/pose__traits.hpp"
// Member 'dimensions'
#include "geometry_msgs/msg/detail/vector3__traits.hpp"
// Member 'velocity'
// Member 'acceleration'
// Member 'v2ground'
#include "geometry_msgs/msg/detail/twist__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Od & msg,
  std::ostream & out)
{
  out << "{";
  // member: object_id
  {
    out << "object_id: ";
    rosidl_generator_traits::value_to_yaml(msg.object_id, out);
    out << ", ";
  }

  // member: age
  {
    out << "age: ";
    rosidl_generator_traits::value_to_yaml(msg.age, out);
    out << ", ";
  }

  // member: measurement_status
  {
    out << "measurement_status: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_status, out);
    out << ", ";
  }

  // member: motion_state
  {
    out << "motion_state: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_state, out);
    out << ", ";
  }

  // member: existance_confidence
  {
    out << "existance_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.existance_confidence, out);
    out << ", ";
  }

  // member: pose
  {
    out << "pose: ";
    to_flow_style_yaml(msg.pose, out);
    out << ", ";
  }

  // member: dimensions
  {
    out << "dimensions: ";
    to_flow_style_yaml(msg.dimensions, out);
    out << ", ";
  }

  // member: velocity
  {
    out << "velocity: ";
    to_flow_style_yaml(msg.velocity, out);
    out << ", ";
  }

  // member: acceleration
  {
    out << "acceleration: ";
    to_flow_style_yaml(msg.acceleration, out);
    out << ", ";
  }

  // member: v2ground
  {
    out << "v2ground: ";
    to_flow_style_yaml(msg.v2ground, out);
    out << ", ";
  }

  // member: pose_nearest
  {
    out << "pose_nearest: ";
    to_flow_style_yaml(msg.pose_nearest, out);
    out << ", ";
  }

  // member: type
  {
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << ", ";
  }

  // member: car_confidence
  {
    out << "car_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.car_confidence, out);
    out << ", ";
  }

  // member: bike_confidence
  {
    out << "bike_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.bike_confidence, out);
    out << ", ";
  }

  // member: ped_confidence
  {
    out << "ped_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.ped_confidence, out);
    out << ", ";
  }

  // member: truck_confidence
  {
    out << "truck_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.truck_confidence, out);
    out << ", ";
  }

  // member: signboard_confidence
  {
    out << "signboard_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.signboard_confidence, out);
    out << ", ";
  }

  // member: ground_confidence
  {
    out << "ground_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.ground_confidence, out);
    out << ", ";
  }

  // member: obstacle_confidence
  {
    out << "obstacle_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_confidence, out);
    out << ", ";
  }

  // member: enrollptsnum
  {
    out << "enrollptsnum: ";
    rosidl_generator_traits::value_to_yaml(msg.enrollptsnum, out);
    out << ", ";
  }

  // member: nearestptsx
  {
    out << "nearestptsx: ";
    rosidl_generator_traits::value_to_yaml(msg.nearestptsx, out);
    out << ", ";
  }

  // member: nearestptsy
  {
    out << "nearestptsy: ";
    rosidl_generator_traits::value_to_yaml(msg.nearestptsy, out);
    out << ", ";
  }

  // member: nearestptsz
  {
    out << "nearestptsz: ";
    rosidl_generator_traits::value_to_yaml(msg.nearestptsz, out);
    out << ", ";
  }

  // member: reserved_d
  {
    out << "reserved_d: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_d, out);
    out << ", ";
  }

  // member: reserved_e
  {
    out << "reserved_e: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_e, out);
    out << ", ";
  }

  // member: reserved_f
  {
    out << "reserved_f: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_f, out);
    out << ", ";
  }

  // member: reserved_g
  {
    out << "reserved_g: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_g, out);
    out << ", ";
  }

  // member: reserved_h
  {
    out << "reserved_h: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_h, out);
    out << ", ";
  }

  // member: reserved_i
  {
    out << "reserved_i: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_i, out);
    out << ", ";
  }

  // member: reserved_j
  {
    out << "reserved_j: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_j, out);
    out << ", ";
  }

  // member: reserved_k
  {
    out << "reserved_k: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_k, out);
    out << ", ";
  }

  // member: reserved_l
  {
    out << "reserved_l: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_l, out);
    out << ", ";
  }

  // member: reserved_m
  {
    out << "reserved_m: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_m, out);
    out << ", ";
  }

  // member: reserved_n
  {
    out << "reserved_n: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_n, out);
    out << ", ";
  }

  // member: reserved_o
  {
    out << "reserved_o: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_o, out);
    out << ", ";
  }

  // member: reserved_p
  {
    out << "reserved_p: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_p, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Od & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: object_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "object_id: ";
    rosidl_generator_traits::value_to_yaml(msg.object_id, out);
    out << "\n";
  }

  // member: age
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "age: ";
    rosidl_generator_traits::value_to_yaml(msg.age, out);
    out << "\n";
  }

  // member: measurement_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "measurement_status: ";
    rosidl_generator_traits::value_to_yaml(msg.measurement_status, out);
    out << "\n";
  }

  // member: motion_state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motion_state: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_state, out);
    out << "\n";
  }

  // member: existance_confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "existance_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.existance_confidence, out);
    out << "\n";
  }

  // member: pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pose:\n";
    to_block_style_yaml(msg.pose, out, indentation + 2);
  }

  // member: dimensions
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dimensions:\n";
    to_block_style_yaml(msg.dimensions, out, indentation + 2);
  }

  // member: velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "velocity:\n";
    to_block_style_yaml(msg.velocity, out, indentation + 2);
  }

  // member: acceleration
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acceleration:\n";
    to_block_style_yaml(msg.acceleration, out, indentation + 2);
  }

  // member: v2ground
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "v2ground:\n";
    to_block_style_yaml(msg.v2ground, out, indentation + 2);
  }

  // member: pose_nearest
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pose_nearest:\n";
    to_block_style_yaml(msg.pose_nearest, out, indentation + 2);
  }

  // member: type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << "\n";
  }

  // member: car_confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "car_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.car_confidence, out);
    out << "\n";
  }

  // member: bike_confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "bike_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.bike_confidence, out);
    out << "\n";
  }

  // member: ped_confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ped_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.ped_confidence, out);
    out << "\n";
  }

  // member: truck_confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "truck_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.truck_confidence, out);
    out << "\n";
  }

  // member: signboard_confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "signboard_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.signboard_confidence, out);
    out << "\n";
  }

  // member: ground_confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ground_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.ground_confidence, out);
    out << "\n";
  }

  // member: obstacle_confidence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_confidence: ";
    rosidl_generator_traits::value_to_yaml(msg.obstacle_confidence, out);
    out << "\n";
  }

  // member: enrollptsnum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "enrollptsnum: ";
    rosidl_generator_traits::value_to_yaml(msg.enrollptsnum, out);
    out << "\n";
  }

  // member: nearestptsx
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nearestptsx: ";
    rosidl_generator_traits::value_to_yaml(msg.nearestptsx, out);
    out << "\n";
  }

  // member: nearestptsy
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nearestptsy: ";
    rosidl_generator_traits::value_to_yaml(msg.nearestptsy, out);
    out << "\n";
  }

  // member: nearestptsz
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nearestptsz: ";
    rosidl_generator_traits::value_to_yaml(msg.nearestptsz, out);
    out << "\n";
  }

  // member: reserved_d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_d: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_d, out);
    out << "\n";
  }

  // member: reserved_e
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_e: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_e, out);
    out << "\n";
  }

  // member: reserved_f
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_f: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_f, out);
    out << "\n";
  }

  // member: reserved_g
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_g: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_g, out);
    out << "\n";
  }

  // member: reserved_h
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_h: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_h, out);
    out << "\n";
  }

  // member: reserved_i
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_i: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_i, out);
    out << "\n";
  }

  // member: reserved_j
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_j: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_j, out);
    out << "\n";
  }

  // member: reserved_k
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_k: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_k, out);
    out << "\n";
  }

  // member: reserved_l
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_l: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_l, out);
    out << "\n";
  }

  // member: reserved_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_m: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_m, out);
    out << "\n";
  }

  // member: reserved_n
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_n: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_n, out);
    out << "\n";
  }

  // member: reserved_o
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_o: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_o, out);
    out << "\n";
  }

  // member: reserved_p
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_p: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_p, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Od & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::Od & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::Od & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::Od>()
{
  return "radar_msgs::msg::Od";
}

template<>
inline const char * name<radar_msgs::msg::Od>()
{
  return "radar_msgs/msg/Od";
}

template<>
struct has_fixed_size<radar_msgs::msg::Od>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<radar_msgs::msg::Od>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<radar_msgs::msg::Od>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__OD__TRAITS_HPP_
