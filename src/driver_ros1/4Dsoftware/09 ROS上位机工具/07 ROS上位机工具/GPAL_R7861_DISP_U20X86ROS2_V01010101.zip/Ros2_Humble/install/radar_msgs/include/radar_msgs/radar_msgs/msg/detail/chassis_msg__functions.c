// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/ChassisMsg.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/chassis_msg__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
radar_msgs__msg__ChassisMsg__init(radar_msgs__msg__ChassisMsg * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__ChassisMsg__fini(msg);
    return false;
  }
  // islessinfo
  // reserved
  // vehdynyawratehsc2
  // vehdynyawratevhsc2
  // trshftlvrpos_h1hsc2
  // trshftlvrposv_h1hsc2
  // vehspdavgdrvnhsc2
  // vehspdavgdrvnvhsc2
  // vehspdavgnondrvnhsc2
  // vehspdavgnondrvnvhsc2
  // strgwhlanghsc2
  // strgwhlangvhsc2
  // ncounter
  // itimestamp
  // flatitude
  // flongitude
  // faltitude
  // faccx
  // faccy
  // faccz
  // fangratex
  // fangratey
  // fangratez
  // fvelnorth
  // fvelwest
  // fvelup
  // fheading
  // fpitch
  // froll
  // nnavstatus
  // vtimestamp
  // fsteeringangle
  // fspeed
  // fyawrate
  // ffrontleftwheelspeed
  // ffrontrightwheelspeed
  // frearleftwheelspeed
  // frearrightwheelspeed
  // nshifterposition
  // nleftdirectionlamp
  // nrightdirectionlamp
  // nmainbeamlamp
  // ndippedbeamlamp
  // nwiperstate
  // flateralaccel
  // flongituaccel
  // nleftdrivenwheelpulsecounters
  // nrightdrivenwheelpulsecounters
  // nleftnondrivenwheelpulsecounters
  // nrightnondrivenwheelpulsecounters
  // ndrivemode
  return true;
}

void
radar_msgs__msg__ChassisMsg__fini(radar_msgs__msg__ChassisMsg * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // islessinfo
  // reserved
  // vehdynyawratehsc2
  // vehdynyawratevhsc2
  // trshftlvrpos_h1hsc2
  // trshftlvrposv_h1hsc2
  // vehspdavgdrvnhsc2
  // vehspdavgdrvnvhsc2
  // vehspdavgnondrvnhsc2
  // vehspdavgnondrvnvhsc2
  // strgwhlanghsc2
  // strgwhlangvhsc2
  // ncounter
  // itimestamp
  // flatitude
  // flongitude
  // faltitude
  // faccx
  // faccy
  // faccz
  // fangratex
  // fangratey
  // fangratez
  // fvelnorth
  // fvelwest
  // fvelup
  // fheading
  // fpitch
  // froll
  // nnavstatus
  // vtimestamp
  // fsteeringangle
  // fspeed
  // fyawrate
  // ffrontleftwheelspeed
  // ffrontrightwheelspeed
  // frearleftwheelspeed
  // frearrightwheelspeed
  // nshifterposition
  // nleftdirectionlamp
  // nrightdirectionlamp
  // nmainbeamlamp
  // ndippedbeamlamp
  // nwiperstate
  // flateralaccel
  // flongituaccel
  // nleftdrivenwheelpulsecounters
  // nrightdrivenwheelpulsecounters
  // nleftnondrivenwheelpulsecounters
  // nrightnondrivenwheelpulsecounters
  // ndrivemode
}

bool
radar_msgs__msg__ChassisMsg__are_equal(const radar_msgs__msg__ChassisMsg * lhs, const radar_msgs__msg__ChassisMsg * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // islessinfo
  if (lhs->islessinfo != rhs->islessinfo) {
    return false;
  }
  // reserved
  if (lhs->reserved != rhs->reserved) {
    return false;
  }
  // vehdynyawratehsc2
  if (lhs->vehdynyawratehsc2 != rhs->vehdynyawratehsc2) {
    return false;
  }
  // vehdynyawratevhsc2
  if (lhs->vehdynyawratevhsc2 != rhs->vehdynyawratevhsc2) {
    return false;
  }
  // trshftlvrpos_h1hsc2
  if (lhs->trshftlvrpos_h1hsc2 != rhs->trshftlvrpos_h1hsc2) {
    return false;
  }
  // trshftlvrposv_h1hsc2
  if (lhs->trshftlvrposv_h1hsc2 != rhs->trshftlvrposv_h1hsc2) {
    return false;
  }
  // vehspdavgdrvnhsc2
  if (lhs->vehspdavgdrvnhsc2 != rhs->vehspdavgdrvnhsc2) {
    return false;
  }
  // vehspdavgdrvnvhsc2
  if (lhs->vehspdavgdrvnvhsc2 != rhs->vehspdavgdrvnvhsc2) {
    return false;
  }
  // vehspdavgnondrvnhsc2
  if (lhs->vehspdavgnondrvnhsc2 != rhs->vehspdavgnondrvnhsc2) {
    return false;
  }
  // vehspdavgnondrvnvhsc2
  if (lhs->vehspdavgnondrvnvhsc2 != rhs->vehspdavgnondrvnvhsc2) {
    return false;
  }
  // strgwhlanghsc2
  if (lhs->strgwhlanghsc2 != rhs->strgwhlanghsc2) {
    return false;
  }
  // strgwhlangvhsc2
  if (lhs->strgwhlangvhsc2 != rhs->strgwhlangvhsc2) {
    return false;
  }
  // ncounter
  if (lhs->ncounter != rhs->ncounter) {
    return false;
  }
  // itimestamp
  if (lhs->itimestamp != rhs->itimestamp) {
    return false;
  }
  // flatitude
  if (lhs->flatitude != rhs->flatitude) {
    return false;
  }
  // flongitude
  if (lhs->flongitude != rhs->flongitude) {
    return false;
  }
  // faltitude
  if (lhs->faltitude != rhs->faltitude) {
    return false;
  }
  // faccx
  if (lhs->faccx != rhs->faccx) {
    return false;
  }
  // faccy
  if (lhs->faccy != rhs->faccy) {
    return false;
  }
  // faccz
  if (lhs->faccz != rhs->faccz) {
    return false;
  }
  // fangratex
  if (lhs->fangratex != rhs->fangratex) {
    return false;
  }
  // fangratey
  if (lhs->fangratey != rhs->fangratey) {
    return false;
  }
  // fangratez
  if (lhs->fangratez != rhs->fangratez) {
    return false;
  }
  // fvelnorth
  if (lhs->fvelnorth != rhs->fvelnorth) {
    return false;
  }
  // fvelwest
  if (lhs->fvelwest != rhs->fvelwest) {
    return false;
  }
  // fvelup
  if (lhs->fvelup != rhs->fvelup) {
    return false;
  }
  // fheading
  if (lhs->fheading != rhs->fheading) {
    return false;
  }
  // fpitch
  if (lhs->fpitch != rhs->fpitch) {
    return false;
  }
  // froll
  if (lhs->froll != rhs->froll) {
    return false;
  }
  // nnavstatus
  if (lhs->nnavstatus != rhs->nnavstatus) {
    return false;
  }
  // vtimestamp
  if (lhs->vtimestamp != rhs->vtimestamp) {
    return false;
  }
  // fsteeringangle
  if (lhs->fsteeringangle != rhs->fsteeringangle) {
    return false;
  }
  // fspeed
  if (lhs->fspeed != rhs->fspeed) {
    return false;
  }
  // fyawrate
  if (lhs->fyawrate != rhs->fyawrate) {
    return false;
  }
  // ffrontleftwheelspeed
  if (lhs->ffrontleftwheelspeed != rhs->ffrontleftwheelspeed) {
    return false;
  }
  // ffrontrightwheelspeed
  if (lhs->ffrontrightwheelspeed != rhs->ffrontrightwheelspeed) {
    return false;
  }
  // frearleftwheelspeed
  if (lhs->frearleftwheelspeed != rhs->frearleftwheelspeed) {
    return false;
  }
  // frearrightwheelspeed
  if (lhs->frearrightwheelspeed != rhs->frearrightwheelspeed) {
    return false;
  }
  // nshifterposition
  if (lhs->nshifterposition != rhs->nshifterposition) {
    return false;
  }
  // nleftdirectionlamp
  if (lhs->nleftdirectionlamp != rhs->nleftdirectionlamp) {
    return false;
  }
  // nrightdirectionlamp
  if (lhs->nrightdirectionlamp != rhs->nrightdirectionlamp) {
    return false;
  }
  // nmainbeamlamp
  if (lhs->nmainbeamlamp != rhs->nmainbeamlamp) {
    return false;
  }
  // ndippedbeamlamp
  if (lhs->ndippedbeamlamp != rhs->ndippedbeamlamp) {
    return false;
  }
  // nwiperstate
  if (lhs->nwiperstate != rhs->nwiperstate) {
    return false;
  }
  // flateralaccel
  if (lhs->flateralaccel != rhs->flateralaccel) {
    return false;
  }
  // flongituaccel
  if (lhs->flongituaccel != rhs->flongituaccel) {
    return false;
  }
  // nleftdrivenwheelpulsecounters
  if (lhs->nleftdrivenwheelpulsecounters != rhs->nleftdrivenwheelpulsecounters) {
    return false;
  }
  // nrightdrivenwheelpulsecounters
  if (lhs->nrightdrivenwheelpulsecounters != rhs->nrightdrivenwheelpulsecounters) {
    return false;
  }
  // nleftnondrivenwheelpulsecounters
  if (lhs->nleftnondrivenwheelpulsecounters != rhs->nleftnondrivenwheelpulsecounters) {
    return false;
  }
  // nrightnondrivenwheelpulsecounters
  if (lhs->nrightnondrivenwheelpulsecounters != rhs->nrightnondrivenwheelpulsecounters) {
    return false;
  }
  // ndrivemode
  if (lhs->ndrivemode != rhs->ndrivemode) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__ChassisMsg__copy(
  const radar_msgs__msg__ChassisMsg * input,
  radar_msgs__msg__ChassisMsg * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // islessinfo
  output->islessinfo = input->islessinfo;
  // reserved
  output->reserved = input->reserved;
  // vehdynyawratehsc2
  output->vehdynyawratehsc2 = input->vehdynyawratehsc2;
  // vehdynyawratevhsc2
  output->vehdynyawratevhsc2 = input->vehdynyawratevhsc2;
  // trshftlvrpos_h1hsc2
  output->trshftlvrpos_h1hsc2 = input->trshftlvrpos_h1hsc2;
  // trshftlvrposv_h1hsc2
  output->trshftlvrposv_h1hsc2 = input->trshftlvrposv_h1hsc2;
  // vehspdavgdrvnhsc2
  output->vehspdavgdrvnhsc2 = input->vehspdavgdrvnhsc2;
  // vehspdavgdrvnvhsc2
  output->vehspdavgdrvnvhsc2 = input->vehspdavgdrvnvhsc2;
  // vehspdavgnondrvnhsc2
  output->vehspdavgnondrvnhsc2 = input->vehspdavgnondrvnhsc2;
  // vehspdavgnondrvnvhsc2
  output->vehspdavgnondrvnvhsc2 = input->vehspdavgnondrvnvhsc2;
  // strgwhlanghsc2
  output->strgwhlanghsc2 = input->strgwhlanghsc2;
  // strgwhlangvhsc2
  output->strgwhlangvhsc2 = input->strgwhlangvhsc2;
  // ncounter
  output->ncounter = input->ncounter;
  // itimestamp
  output->itimestamp = input->itimestamp;
  // flatitude
  output->flatitude = input->flatitude;
  // flongitude
  output->flongitude = input->flongitude;
  // faltitude
  output->faltitude = input->faltitude;
  // faccx
  output->faccx = input->faccx;
  // faccy
  output->faccy = input->faccy;
  // faccz
  output->faccz = input->faccz;
  // fangratex
  output->fangratex = input->fangratex;
  // fangratey
  output->fangratey = input->fangratey;
  // fangratez
  output->fangratez = input->fangratez;
  // fvelnorth
  output->fvelnorth = input->fvelnorth;
  // fvelwest
  output->fvelwest = input->fvelwest;
  // fvelup
  output->fvelup = input->fvelup;
  // fheading
  output->fheading = input->fheading;
  // fpitch
  output->fpitch = input->fpitch;
  // froll
  output->froll = input->froll;
  // nnavstatus
  output->nnavstatus = input->nnavstatus;
  // vtimestamp
  output->vtimestamp = input->vtimestamp;
  // fsteeringangle
  output->fsteeringangle = input->fsteeringangle;
  // fspeed
  output->fspeed = input->fspeed;
  // fyawrate
  output->fyawrate = input->fyawrate;
  // ffrontleftwheelspeed
  output->ffrontleftwheelspeed = input->ffrontleftwheelspeed;
  // ffrontrightwheelspeed
  output->ffrontrightwheelspeed = input->ffrontrightwheelspeed;
  // frearleftwheelspeed
  output->frearleftwheelspeed = input->frearleftwheelspeed;
  // frearrightwheelspeed
  output->frearrightwheelspeed = input->frearrightwheelspeed;
  // nshifterposition
  output->nshifterposition = input->nshifterposition;
  // nleftdirectionlamp
  output->nleftdirectionlamp = input->nleftdirectionlamp;
  // nrightdirectionlamp
  output->nrightdirectionlamp = input->nrightdirectionlamp;
  // nmainbeamlamp
  output->nmainbeamlamp = input->nmainbeamlamp;
  // ndippedbeamlamp
  output->ndippedbeamlamp = input->ndippedbeamlamp;
  // nwiperstate
  output->nwiperstate = input->nwiperstate;
  // flateralaccel
  output->flateralaccel = input->flateralaccel;
  // flongituaccel
  output->flongituaccel = input->flongituaccel;
  // nleftdrivenwheelpulsecounters
  output->nleftdrivenwheelpulsecounters = input->nleftdrivenwheelpulsecounters;
  // nrightdrivenwheelpulsecounters
  output->nrightdrivenwheelpulsecounters = input->nrightdrivenwheelpulsecounters;
  // nleftnondrivenwheelpulsecounters
  output->nleftnondrivenwheelpulsecounters = input->nleftnondrivenwheelpulsecounters;
  // nrightnondrivenwheelpulsecounters
  output->nrightnondrivenwheelpulsecounters = input->nrightnondrivenwheelpulsecounters;
  // ndrivemode
  output->ndrivemode = input->ndrivemode;
  return true;
}

radar_msgs__msg__ChassisMsg *
radar_msgs__msg__ChassisMsg__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__ChassisMsg * msg = (radar_msgs__msg__ChassisMsg *)allocator.allocate(sizeof(radar_msgs__msg__ChassisMsg), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__ChassisMsg));
  bool success = radar_msgs__msg__ChassisMsg__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__ChassisMsg__destroy(radar_msgs__msg__ChassisMsg * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__ChassisMsg__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__ChassisMsg__Sequence__init(radar_msgs__msg__ChassisMsg__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__ChassisMsg * data = NULL;

  if (size) {
    data = (radar_msgs__msg__ChassisMsg *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__ChassisMsg), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__ChassisMsg__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__ChassisMsg__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__ChassisMsg__Sequence__fini(radar_msgs__msg__ChassisMsg__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__ChassisMsg__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__ChassisMsg__Sequence *
radar_msgs__msg__ChassisMsg__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__ChassisMsg__Sequence * array = (radar_msgs__msg__ChassisMsg__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__ChassisMsg__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__ChassisMsg__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__ChassisMsg__Sequence__destroy(radar_msgs__msg__ChassisMsg__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__ChassisMsg__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__ChassisMsg__Sequence__are_equal(const radar_msgs__msg__ChassisMsg__Sequence * lhs, const radar_msgs__msg__ChassisMsg__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__ChassisMsg__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__ChassisMsg__Sequence__copy(
  const radar_msgs__msg__ChassisMsg__Sequence * input,
  radar_msgs__msg__ChassisMsg__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__ChassisMsg);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__ChassisMsg * data =
      (radar_msgs__msg__ChassisMsg *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__ChassisMsg__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__ChassisMsg__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__ChassisMsg__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
