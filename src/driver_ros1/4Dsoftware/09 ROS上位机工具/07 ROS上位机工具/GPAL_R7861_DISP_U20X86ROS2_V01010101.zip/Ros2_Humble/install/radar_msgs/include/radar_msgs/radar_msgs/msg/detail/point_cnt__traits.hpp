// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/PointCnt.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__POINT_CNT__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__POINT_CNT__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/point_cnt__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const PointCnt & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: frame_id
  {
    out << "frame_id: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_id, out);
    out << ", ";
  }

  // member: cfar_count
  {
    out << "cfar_count: ";
    rosidl_generator_traits::value_to_yaml(msg.cfar_count, out);
    out << ", ";
  }

  // member: target_num
  {
    out << "target_num: ";
    rosidl_generator_traits::value_to_yaml(msg.target_num, out);
    out << ", ";
  }

  // member: resetcnt
  {
    out << "resetcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.resetcnt, out);
    out << ", ";
  }

  // member: objnum
  {
    out << "objnum: ";
    rosidl_generator_traits::value_to_yaml(msg.objnum, out);
    out << ", ";
  }

  // member: od_process_time
  {
    out << "od_process_time: ";
    rosidl_generator_traits::value_to_yaml(msg.od_process_time, out);
    out << ", ";
  }

  // member: carspeed
  {
    out << "carspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.carspeed, out);
    out << ", ";
  }

  // member: caryawrate
  {
    out << "caryawrate: ";
    rosidl_generator_traits::value_to_yaml(msg.caryawrate, out);
    out << ", ";
  }

  // member: odtimeoutcnt
  {
    out << "odtimeoutcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.odtimeoutcnt, out);
    out << ", ";
  }

  // member: comprotv_i
  {
    out << "comprotv_i: ";
    rosidl_generator_traits::value_to_yaml(msg.comprotv_i, out);
    out << ", ";
  }

  // member: comprotv_ii
  {
    out << "comprotv_ii: ";
    rosidl_generator_traits::value_to_yaml(msg.comprotv_ii, out);
    out << ", ";
  }

  // member: framelostcnt
  {
    out << "framelostcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.framelostcnt, out);
    out << ", ";
  }

  // member: beforeadcerrcnt
  {
    out << "beforeadcerrcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.beforeadcerrcnt, out);
    out << ", ";
  }

  // member: afteradcerrcnt
  {
    out << "afteradcerrcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.afteradcerrcnt, out);
    out << ", ";
  }

  // member: udprramelostcnt
  {
    out << "udprramelostcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.udprramelostcnt, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const PointCnt & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: frame_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_id: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_id, out);
    out << "\n";
  }

  // member: cfar_count
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cfar_count: ";
    rosidl_generator_traits::value_to_yaml(msg.cfar_count, out);
    out << "\n";
  }

  // member: target_num
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_num: ";
    rosidl_generator_traits::value_to_yaml(msg.target_num, out);
    out << "\n";
  }

  // member: resetcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "resetcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.resetcnt, out);
    out << "\n";
  }

  // member: objnum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "objnum: ";
    rosidl_generator_traits::value_to_yaml(msg.objnum, out);
    out << "\n";
  }

  // member: od_process_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "od_process_time: ";
    rosidl_generator_traits::value_to_yaml(msg.od_process_time, out);
    out << "\n";
  }

  // member: carspeed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "carspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.carspeed, out);
    out << "\n";
  }

  // member: caryawrate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "caryawrate: ";
    rosidl_generator_traits::value_to_yaml(msg.caryawrate, out);
    out << "\n";
  }

  // member: odtimeoutcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "odtimeoutcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.odtimeoutcnt, out);
    out << "\n";
  }

  // member: comprotv_i
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "comprotv_i: ";
    rosidl_generator_traits::value_to_yaml(msg.comprotv_i, out);
    out << "\n";
  }

  // member: comprotv_ii
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "comprotv_ii: ";
    rosidl_generator_traits::value_to_yaml(msg.comprotv_ii, out);
    out << "\n";
  }

  // member: framelostcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "framelostcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.framelostcnt, out);
    out << "\n";
  }

  // member: beforeadcerrcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "beforeadcerrcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.beforeadcerrcnt, out);
    out << "\n";
  }

  // member: afteradcerrcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "afteradcerrcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.afteradcerrcnt, out);
    out << "\n";
  }

  // member: udprramelostcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udprramelostcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.udprramelostcnt, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const PointCnt & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::PointCnt & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::PointCnt & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::PointCnt>()
{
  return "radar_msgs::msg::PointCnt";
}

template<>
inline const char * name<radar_msgs::msg::PointCnt>()
{
  return "radar_msgs/msg/PointCnt";
}

template<>
struct has_fixed_size<radar_msgs::msg::PointCnt>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<radar_msgs::msg::PointCnt>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<radar_msgs::msg::PointCnt>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__POINT_CNT__TRAITS_HPP_
