// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonPmclkloIntAnaSigRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_PMCLKLO_INT_ANA_SIG_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_PMCLKLO_INT_ANA_SIG_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_pmclklo_int_ana_sig_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonPmclkloIntAnaSigRep_timestamp
{
public:
  explicit Init_RlMonPmclkloIntAnaSigRep_timestamp(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonPmclkloIntAnaSigRep timestamp(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPmclkloIntAnaSigRep msg_;
};

class Init_RlMonPmclkloIntAnaSigRep_reserved
{
public:
  explicit Init_RlMonPmclkloIntAnaSigRep_reserved(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonPmclkloIntAnaSigRep_timestamp reserved(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep::_reserved_type arg)
  {
    msg_.reserved = std::move(arg);
    return Init_RlMonPmclkloIntAnaSigRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPmclkloIntAnaSigRep msg_;
};

class Init_RlMonPmclkloIntAnaSigRep_sync20gpower
{
public:
  explicit Init_RlMonPmclkloIntAnaSigRep_sync20gpower(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonPmclkloIntAnaSigRep_reserved sync20gpower(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep::_sync20gpower_type arg)
  {
    msg_.sync20gpower = std::move(arg);
    return Init_RlMonPmclkloIntAnaSigRep_reserved(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPmclkloIntAnaSigRep msg_;
};

class Init_RlMonPmclkloIntAnaSigRep_profindex
{
public:
  explicit Init_RlMonPmclkloIntAnaSigRep_profindex(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonPmclkloIntAnaSigRep_sync20gpower profindex(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep::_profindex_type arg)
  {
    msg_.profindex = std::move(arg);
    return Init_RlMonPmclkloIntAnaSigRep_sync20gpower(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPmclkloIntAnaSigRep msg_;
};

class Init_RlMonPmclkloIntAnaSigRep_errorcode
{
public:
  explicit Init_RlMonPmclkloIntAnaSigRep_errorcode(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep & msg)
  : msg_(msg)
  {}
  Init_RlMonPmclkloIntAnaSigRep_profindex errorcode(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonPmclkloIntAnaSigRep_profindex(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPmclkloIntAnaSigRep msg_;
};

class Init_RlMonPmclkloIntAnaSigRep_statusflags
{
public:
  Init_RlMonPmclkloIntAnaSigRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonPmclkloIntAnaSigRep_errorcode statusflags(::radar_msgs::msg::RlMonPmclkloIntAnaSigRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonPmclkloIntAnaSigRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPmclkloIntAnaSigRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonPmclkloIntAnaSigRep>()
{
  return radar_msgs::msg::builder::Init_RlMonPmclkloIntAnaSigRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_PMCLKLO_INT_ANA_SIG_REP__BUILDER_HPP_
