// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/FloatVecType.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__FLOAT_VEC_TYPE__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__FLOAT_VEC_TYPE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/float_vec_type__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_FloatVecType_data
{
public:
  explicit Init_FloatVecType_data(::radar_msgs::msg::FloatVecType & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::FloatVecType data(::radar_msgs::msg::FloatVecType::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::FloatVecType msg_;
};

class Init_FloatVecType_cfar_obj
{
public:
  explicit Init_FloatVecType_cfar_obj(::radar_msgs::msg::FloatVecType & msg)
  : msg_(msg)
  {}
  Init_FloatVecType_data cfar_obj(::radar_msgs::msg::FloatVecType::_cfar_obj_type arg)
  {
    msg_.cfar_obj = std::move(arg);
    return Init_FloatVecType_data(msg_);
  }

private:
  ::radar_msgs::msg::FloatVecType msg_;
};

class Init_FloatVecType_cfar_count
{
public:
  explicit Init_FloatVecType_cfar_count(::radar_msgs::msg::FloatVecType & msg)
  : msg_(msg)
  {}
  Init_FloatVecType_cfar_obj cfar_count(::radar_msgs::msg::FloatVecType::_cfar_count_type arg)
  {
    msg_.cfar_count = std::move(arg);
    return Init_FloatVecType_cfar_obj(msg_);
  }

private:
  ::radar_msgs::msg::FloatVecType msg_;
};

class Init_FloatVecType_frame_id
{
public:
  explicit Init_FloatVecType_frame_id(::radar_msgs::msg::FloatVecType & msg)
  : msg_(msg)
  {}
  Init_FloatVecType_cfar_count frame_id(::radar_msgs::msg::FloatVecType::_frame_id_type arg)
  {
    msg_.frame_id = std::move(arg);
    return Init_FloatVecType_cfar_count(msg_);
  }

private:
  ::radar_msgs::msg::FloatVecType msg_;
};

class Init_FloatVecType_height
{
public:
  explicit Init_FloatVecType_height(::radar_msgs::msg::FloatVecType & msg)
  : msg_(msg)
  {}
  Init_FloatVecType_frame_id height(::radar_msgs::msg::FloatVecType::_height_type arg)
  {
    msg_.height = std::move(arg);
    return Init_FloatVecType_frame_id(msg_);
  }

private:
  ::radar_msgs::msg::FloatVecType msg_;
};

class Init_FloatVecType_width
{
public:
  explicit Init_FloatVecType_width(::radar_msgs::msg::FloatVecType & msg)
  : msg_(msg)
  {}
  Init_FloatVecType_height width(::radar_msgs::msg::FloatVecType::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_FloatVecType_height(msg_);
  }

private:
  ::radar_msgs::msg::FloatVecType msg_;
};

class Init_FloatVecType_header
{
public:
  Init_FloatVecType_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FloatVecType_width header(::radar_msgs::msg::FloatVecType::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_FloatVecType_width(msg_);
  }

private:
  ::radar_msgs::msg::FloatVecType msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::FloatVecType>()
{
  return radar_msgs::msg::builder::Init_FloatVecType_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__FLOAT_VEC_TYPE__BUILDER_HPP_
