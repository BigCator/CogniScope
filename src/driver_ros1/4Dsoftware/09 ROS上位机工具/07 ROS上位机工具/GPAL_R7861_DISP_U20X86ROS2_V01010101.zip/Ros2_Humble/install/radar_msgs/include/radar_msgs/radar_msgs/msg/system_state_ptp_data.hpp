// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__SYSTEM_STATE_PTP_DATA_HPP_
#define RADAR_MSGS__MSG__SYSTEM_STATE_PTP_DATA_HPP_

#include "radar_msgs/msg/detail/system_state_ptp_data__struct.hpp"
#include "radar_msgs/msg/detail/system_state_ptp_data__builder.hpp"
#include "radar_msgs/msg/detail/system_state_ptp_data__traits.hpp"

#endif  // RADAR_MSGS__MSG__SYSTEM_STATE_PTP_DATA_HPP_
