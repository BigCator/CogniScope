// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/AlarmStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/alarm_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const AlarmStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: radarid
  {
    out << "radarid: ";
    rosidl_generator_traits::value_to_yaml(msg.radarid, out);
    out << ", ";
  }

  // member: framecnt
  {
    out << "framecnt: ";
    rosidl_generator_traits::value_to_yaml(msg.framecnt, out);
    out << ", ";
  }

  // member: alarmnum
  {
    out << "alarmnum: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmnum, out);
    out << ", ";
  }

  // member: alarmcode01
  {
    out << "alarmcode01: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode01, out);
    out << ", ";
  }

  // member: alarmcode02
  {
    out << "alarmcode02: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode02, out);
    out << ", ";
  }

  // member: alarmcode03
  {
    out << "alarmcode03: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode03, out);
    out << ", ";
  }

  // member: alarmcode04
  {
    out << "alarmcode04: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode04, out);
    out << ", ";
  }

  // member: alarmcode05
  {
    out << "alarmcode05: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode05, out);
    out << ", ";
  }

  // member: alarmcode06
  {
    out << "alarmcode06: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode06, out);
    out << ", ";
  }

  // member: alarmcode07
  {
    out << "alarmcode07: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode07, out);
    out << ", ";
  }

  // member: alarmcode08
  {
    out << "alarmcode08: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode08, out);
    out << ", ";
  }

  // member: alarmcode09
  {
    out << "alarmcode09: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode09, out);
    out << ", ";
  }

  // member: alarmcode10
  {
    out << "alarmcode10: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode10, out);
    out << ", ";
  }

  // member: alarmcode11
  {
    out << "alarmcode11: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode11, out);
    out << ", ";
  }

  // member: alarmcode12
  {
    out << "alarmcode12: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode12, out);
    out << ", ";
  }

  // member: alarmcode13
  {
    out << "alarmcode13: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode13, out);
    out << ", ";
  }

  // member: alarmcode14
  {
    out << "alarmcode14: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode14, out);
    out << ", ";
  }

  // member: alarmcode15
  {
    out << "alarmcode15: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode15, out);
    out << ", ";
  }

  // member: alarmcode16
  {
    out << "alarmcode16: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode16, out);
    out << ", ";
  }

  // member: alarmcode17
  {
    out << "alarmcode17: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode17, out);
    out << ", ";
  }

  // member: alarmcode18
  {
    out << "alarmcode18: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode18, out);
    out << ", ";
  }

  // member: alarmcode19
  {
    out << "alarmcode19: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode19, out);
    out << ", ";
  }

  // member: alarmcode20
  {
    out << "alarmcode20: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode20, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const AlarmStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: radarid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "radarid: ";
    rosidl_generator_traits::value_to_yaml(msg.radarid, out);
    out << "\n";
  }

  // member: framecnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "framecnt: ";
    rosidl_generator_traits::value_to_yaml(msg.framecnt, out);
    out << "\n";
  }

  // member: alarmnum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmnum: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmnum, out);
    out << "\n";
  }

  // member: alarmcode01
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode01: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode01, out);
    out << "\n";
  }

  // member: alarmcode02
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode02: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode02, out);
    out << "\n";
  }

  // member: alarmcode03
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode03: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode03, out);
    out << "\n";
  }

  // member: alarmcode04
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode04: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode04, out);
    out << "\n";
  }

  // member: alarmcode05
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode05: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode05, out);
    out << "\n";
  }

  // member: alarmcode06
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode06: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode06, out);
    out << "\n";
  }

  // member: alarmcode07
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode07: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode07, out);
    out << "\n";
  }

  // member: alarmcode08
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode08: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode08, out);
    out << "\n";
  }

  // member: alarmcode09
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode09: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode09, out);
    out << "\n";
  }

  // member: alarmcode10
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode10: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode10, out);
    out << "\n";
  }

  // member: alarmcode11
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode11: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode11, out);
    out << "\n";
  }

  // member: alarmcode12
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode12: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode12, out);
    out << "\n";
  }

  // member: alarmcode13
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode13: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode13, out);
    out << "\n";
  }

  // member: alarmcode14
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode14: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode14, out);
    out << "\n";
  }

  // member: alarmcode15
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode15: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode15, out);
    out << "\n";
  }

  // member: alarmcode16
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode16: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode16, out);
    out << "\n";
  }

  // member: alarmcode17
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode17: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode17, out);
    out << "\n";
  }

  // member: alarmcode18
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode18: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode18, out);
    out << "\n";
  }

  // member: alarmcode19
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode19: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode19, out);
    out << "\n";
  }

  // member: alarmcode20
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alarmcode20: ";
    rosidl_generator_traits::value_to_yaml(msg.alarmcode20, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const AlarmStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::AlarmStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::AlarmStatus & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::AlarmStatus>()
{
  return "radar_msgs::msg::AlarmStatus";
}

template<>
inline const char * name<radar_msgs::msg::AlarmStatus>()
{
  return "radar_msgs/msg/AlarmStatus";
}

template<>
struct has_fixed_size<radar_msgs::msg::AlarmStatus>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<radar_msgs::msg::AlarmStatus>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<radar_msgs::msg::AlarmStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__ALARM_STATUS__TRAITS_HPP_
