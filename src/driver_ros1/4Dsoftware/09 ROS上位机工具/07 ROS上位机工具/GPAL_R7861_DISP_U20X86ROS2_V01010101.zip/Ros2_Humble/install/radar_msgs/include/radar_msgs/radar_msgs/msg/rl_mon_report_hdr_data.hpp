// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__RL_MON_REPORT_HDR_DATA_HPP_
#define RADAR_MSGS__MSG__RL_MON_REPORT_HDR_DATA_HPP_

#include "radar_msgs/msg/detail/rl_mon_report_hdr_data__struct.hpp"
#include "radar_msgs/msg/detail/rl_mon_report_hdr_data__builder.hpp"
#include "radar_msgs/msg/detail/rl_mon_report_hdr_data__traits.hpp"

#endif  // RADAR_MSGS__MSG__RL_MON_REPORT_HDR_DATA_HPP_
