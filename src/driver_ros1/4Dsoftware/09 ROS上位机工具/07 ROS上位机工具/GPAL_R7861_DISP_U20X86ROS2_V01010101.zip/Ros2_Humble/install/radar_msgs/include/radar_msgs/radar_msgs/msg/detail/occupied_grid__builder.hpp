// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/OccupiedGrid.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/occupied_grid__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_OccupiedGrid_reserved_c
{
public:
  explicit Init_OccupiedGrid_reserved_c(::radar_msgs::msg::OccupiedGrid & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::OccupiedGrid reserved_c(::radar_msgs::msg::OccupiedGrid::_reserved_c_type arg)
  {
    msg_.reserved_c = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

class Init_OccupiedGrid_reserved_b
{
public:
  explicit Init_OccupiedGrid_reserved_b(::radar_msgs::msg::OccupiedGrid & msg)
  : msg_(msg)
  {}
  Init_OccupiedGrid_reserved_c reserved_b(::radar_msgs::msg::OccupiedGrid::_reserved_b_type arg)
  {
    msg_.reserved_b = std::move(arg);
    return Init_OccupiedGrid_reserved_c(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

class Init_OccupiedGrid_reserved_a
{
public:
  explicit Init_OccupiedGrid_reserved_a(::radar_msgs::msg::OccupiedGrid & msg)
  : msg_(msg)
  {}
  Init_OccupiedGrid_reserved_b reserved_a(::radar_msgs::msg::OccupiedGrid::_reserved_a_type arg)
  {
    msg_.reserved_a = std::move(arg);
    return Init_OccupiedGrid_reserved_b(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

class Init_OccupiedGrid_grid_y
{
public:
  explicit Init_OccupiedGrid_grid_y(::radar_msgs::msg::OccupiedGrid & msg)
  : msg_(msg)
  {}
  Init_OccupiedGrid_reserved_a grid_y(::radar_msgs::msg::OccupiedGrid::_grid_y_type arg)
  {
    msg_.grid_y = std::move(arg);
    return Init_OccupiedGrid_reserved_a(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

class Init_OccupiedGrid_grid_x
{
public:
  explicit Init_OccupiedGrid_grid_x(::radar_msgs::msg::OccupiedGrid & msg)
  : msg_(msg)
  {}
  Init_OccupiedGrid_grid_y grid_x(::radar_msgs::msg::OccupiedGrid::_grid_x_type arg)
  {
    msg_.grid_x = std::move(arg);
    return Init_OccupiedGrid_grid_y(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

class Init_OccupiedGrid_grid_y_length
{
public:
  explicit Init_OccupiedGrid_grid_y_length(::radar_msgs::msg::OccupiedGrid & msg)
  : msg_(msg)
  {}
  Init_OccupiedGrid_grid_x grid_y_length(::radar_msgs::msg::OccupiedGrid::_grid_y_length_type arg)
  {
    msg_.grid_y_length = std::move(arg);
    return Init_OccupiedGrid_grid_x(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

class Init_OccupiedGrid_grid_x_length
{
public:
  explicit Init_OccupiedGrid_grid_x_length(::radar_msgs::msg::OccupiedGrid & msg)
  : msg_(msg)
  {}
  Init_OccupiedGrid_grid_y_length grid_x_length(::radar_msgs::msg::OccupiedGrid::_grid_x_length_type arg)
  {
    msg_.grid_x_length = std::move(arg);
    return Init_OccupiedGrid_grid_y_length(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

class Init_OccupiedGrid_occupied_num
{
public:
  explicit Init_OccupiedGrid_occupied_num(::radar_msgs::msg::OccupiedGrid & msg)
  : msg_(msg)
  {}
  Init_OccupiedGrid_grid_x_length occupied_num(::radar_msgs::msg::OccupiedGrid::_occupied_num_type arg)
  {
    msg_.occupied_num = std::move(arg);
    return Init_OccupiedGrid_grid_x_length(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

class Init_OccupiedGrid_frame_cnt
{
public:
  explicit Init_OccupiedGrid_frame_cnt(::radar_msgs::msg::OccupiedGrid & msg)
  : msg_(msg)
  {}
  Init_OccupiedGrid_occupied_num frame_cnt(::radar_msgs::msg::OccupiedGrid::_frame_cnt_type arg)
  {
    msg_.frame_cnt = std::move(arg);
    return Init_OccupiedGrid_occupied_num(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

class Init_OccupiedGrid_radar_id
{
public:
  explicit Init_OccupiedGrid_radar_id(::radar_msgs::msg::OccupiedGrid & msg)
  : msg_(msg)
  {}
  Init_OccupiedGrid_frame_cnt radar_id(::radar_msgs::msg::OccupiedGrid::_radar_id_type arg)
  {
    msg_.radar_id = std::move(arg);
    return Init_OccupiedGrid_frame_cnt(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

class Init_OccupiedGrid_header
{
public:
  Init_OccupiedGrid_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_OccupiedGrid_radar_id header(::radar_msgs::msg::OccupiedGrid::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_OccupiedGrid_radar_id(msg_);
  }

private:
  ::radar_msgs::msg::OccupiedGrid msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::OccupiedGrid>()
{
  return radar_msgs::msg::builder::Init_OccupiedGrid_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__OCCUPIED_GRID__BUILDER_HPP_
