﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/RadarTarget.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'x'
// Member 'y'
// Member 'z'
// Member 'v'
// Member 'azimuth'
// Member 'elevation'
// Member 'snr'
// Member 'power'
// Member 'valid_flg'
// Member 'existance_probability'
// Member 'motion_state'
// Member 'detection_class'
// Member 'reset_cnt'
// Member 'od_timeout_cnt'
// Member 'reserved_a'
// Member 'reserved_b'
// Member 'reserved_c'
// Member 'reserved_d'
// Member 'reserved_e'
// Member 'reserved_f'
// Member 'reserved_g'
// Member 'reserved_h'
// Member 'reserved_i'
// Member 'reserved_j'
// Member 'reserved_k'
// Member 'reserved_l'
// Member 'reserved_m'
// Member 'reserved_n'
// Member 'reserved_o'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/RadarTarget in the package radar_msgs.
typedef struct radar_msgs__msg__RadarTarget
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  /// radar ID
  uint32_t radar_id;
  /// frame cnt in radar
  uint32_t frame_cnt;
  uint32_t type;
  /// targets Num
  uint32_t target_num;
  /// true---数据是以极坐标方式提供,false---数据是以笛卡尔坐标系
  uint32_t polar_state;
  /// Position x, unit: m
  rosidl_runtime_c__float__Sequence x;
  /// Position y, unit: m
  rosidl_runtime_c__float__Sequence y;
  /// Position z, unit: m
  rosidl_runtime_c__float__Sequence z;
  /// target velocity, unit: m/s
  rosidl_runtime_c__float__Sequence v;
  /// target azimuth, unit: degree
  rosidl_runtime_c__float__Sequence azimuth;
  /// target elevation, unit: degree
  rosidl_runtime_c__float__Sequence elevation;
  /// target snr, unit: dB
  rosidl_runtime_c__float__Sequence snr;
  /// target power, unit: dB
  rosidl_runtime_c__float__Sequence power;
  /// target valid=0, target invalid=tbd
  rosidl_runtime_c__uint16__Sequence valid_flg;
  /// 0 ~ 100
  rosidl_runtime_c__uint16__Sequence existance_probability;
  /// 0:static, 1:dynamic
  rosidl_runtime_c__uint16__Sequence motion_state;
  /// 0 = NoClassification, 1 = Noise, 2 = Ground, 3 = TraversableUnder, 4 = Obstacle, 255 = Invalid
  rosidl_runtime_c__uint16__Sequence detection_class;
  /// counter of radar reset times
  rosidl_runtime_c__uint16__Sequence reset_cnt;
  /// counter of od process timeout
  rosidl_runtime_c__int16__Sequence od_timeout_cnt;
  /// temporarily set as frame lost cnt
  rosidl_runtime_c__uint16__Sequence reserved_a;
  rosidl_runtime_c__uint16__Sequence reserved_b;
  /// temporarily set as pcl with extreme value and azimuth/elevation flag
  rosidl_runtime_c__uint16__Sequence reserved_c;
  rosidl_runtime_c__uint16__Sequence reserved_d;
  rosidl_runtime_c__uint16__Sequence reserved_e;
  /// temporarily set as before adc error cnt
  rosidl_runtime_c__int16__Sequence reserved_f;
  /// temporarily set as after adc error cnt
  rosidl_runtime_c__int16__Sequence reserved_g;
  /// temporarily set as extreme point flag
  rosidl_runtime_c__int16__Sequence reserved_h;
  /// temporarily set as extreme value number
  rosidl_runtime_c__int16__Sequence reserved_i;
  /// temporarily set as profile 0/1 flag
  rosidl_runtime_c__int16__Sequence reserved_j;
  rosidl_runtime_c__float__Sequence reserved_k;
  rosidl_runtime_c__float__Sequence reserved_l;
  rosidl_runtime_c__float__Sequence reserved_m;
  rosidl_runtime_c__float__Sequence reserved_n;
  rosidl_runtime_c__float__Sequence reserved_o;
} radar_msgs__msg__RadarTarget;

// Struct for a sequence of radar_msgs__msg__RadarTarget.
typedef struct radar_msgs__msg__RadarTarget__Sequence
{
  radar_msgs__msg__RadarTarget * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__RadarTarget__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__RADAR_TARGET__STRUCT_H_
