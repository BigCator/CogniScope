// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/Od.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OD__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__OD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/od__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_Od_reserved_p
{
public:
  explicit Init_Od_reserved_p(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::Od reserved_p(::radar_msgs::msg::Od::_reserved_p_type arg)
  {
    msg_.reserved_p = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_o
{
public:
  explicit Init_Od_reserved_o(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_p reserved_o(::radar_msgs::msg::Od::_reserved_o_type arg)
  {
    msg_.reserved_o = std::move(arg);
    return Init_Od_reserved_p(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_n
{
public:
  explicit Init_Od_reserved_n(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_o reserved_n(::radar_msgs::msg::Od::_reserved_n_type arg)
  {
    msg_.reserved_n = std::move(arg);
    return Init_Od_reserved_o(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_m
{
public:
  explicit Init_Od_reserved_m(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_n reserved_m(::radar_msgs::msg::Od::_reserved_m_type arg)
  {
    msg_.reserved_m = std::move(arg);
    return Init_Od_reserved_n(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_l
{
public:
  explicit Init_Od_reserved_l(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_m reserved_l(::radar_msgs::msg::Od::_reserved_l_type arg)
  {
    msg_.reserved_l = std::move(arg);
    return Init_Od_reserved_m(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_k
{
public:
  explicit Init_Od_reserved_k(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_l reserved_k(::radar_msgs::msg::Od::_reserved_k_type arg)
  {
    msg_.reserved_k = std::move(arg);
    return Init_Od_reserved_l(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_j
{
public:
  explicit Init_Od_reserved_j(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_k reserved_j(::radar_msgs::msg::Od::_reserved_j_type arg)
  {
    msg_.reserved_j = std::move(arg);
    return Init_Od_reserved_k(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_i
{
public:
  explicit Init_Od_reserved_i(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_j reserved_i(::radar_msgs::msg::Od::_reserved_i_type arg)
  {
    msg_.reserved_i = std::move(arg);
    return Init_Od_reserved_j(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_h
{
public:
  explicit Init_Od_reserved_h(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_i reserved_h(::radar_msgs::msg::Od::_reserved_h_type arg)
  {
    msg_.reserved_h = std::move(arg);
    return Init_Od_reserved_i(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_g
{
public:
  explicit Init_Od_reserved_g(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_h reserved_g(::radar_msgs::msg::Od::_reserved_g_type arg)
  {
    msg_.reserved_g = std::move(arg);
    return Init_Od_reserved_h(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_f
{
public:
  explicit Init_Od_reserved_f(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_g reserved_f(::radar_msgs::msg::Od::_reserved_f_type arg)
  {
    msg_.reserved_f = std::move(arg);
    return Init_Od_reserved_g(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_e
{
public:
  explicit Init_Od_reserved_e(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_f reserved_e(::radar_msgs::msg::Od::_reserved_e_type arg)
  {
    msg_.reserved_e = std::move(arg);
    return Init_Od_reserved_f(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_reserved_d
{
public:
  explicit Init_Od_reserved_d(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_e reserved_d(::radar_msgs::msg::Od::_reserved_d_type arg)
  {
    msg_.reserved_d = std::move(arg);
    return Init_Od_reserved_e(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_nearestptsz
{
public:
  explicit Init_Od_nearestptsz(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_reserved_d nearestptsz(::radar_msgs::msg::Od::_nearestptsz_type arg)
  {
    msg_.nearestptsz = std::move(arg);
    return Init_Od_reserved_d(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_nearestptsy
{
public:
  explicit Init_Od_nearestptsy(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_nearestptsz nearestptsy(::radar_msgs::msg::Od::_nearestptsy_type arg)
  {
    msg_.nearestptsy = std::move(arg);
    return Init_Od_nearestptsz(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_nearestptsx
{
public:
  explicit Init_Od_nearestptsx(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_nearestptsy nearestptsx(::radar_msgs::msg::Od::_nearestptsx_type arg)
  {
    msg_.nearestptsx = std::move(arg);
    return Init_Od_nearestptsy(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_enrollptsnum
{
public:
  explicit Init_Od_enrollptsnum(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_nearestptsx enrollptsnum(::radar_msgs::msg::Od::_enrollptsnum_type arg)
  {
    msg_.enrollptsnum = std::move(arg);
    return Init_Od_nearestptsx(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_obstacle_confidence
{
public:
  explicit Init_Od_obstacle_confidence(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_enrollptsnum obstacle_confidence(::radar_msgs::msg::Od::_obstacle_confidence_type arg)
  {
    msg_.obstacle_confidence = std::move(arg);
    return Init_Od_enrollptsnum(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_ground_confidence
{
public:
  explicit Init_Od_ground_confidence(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_obstacle_confidence ground_confidence(::radar_msgs::msg::Od::_ground_confidence_type arg)
  {
    msg_.ground_confidence = std::move(arg);
    return Init_Od_obstacle_confidence(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_signboard_confidence
{
public:
  explicit Init_Od_signboard_confidence(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_ground_confidence signboard_confidence(::radar_msgs::msg::Od::_signboard_confidence_type arg)
  {
    msg_.signboard_confidence = std::move(arg);
    return Init_Od_ground_confidence(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_truck_confidence
{
public:
  explicit Init_Od_truck_confidence(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_signboard_confidence truck_confidence(::radar_msgs::msg::Od::_truck_confidence_type arg)
  {
    msg_.truck_confidence = std::move(arg);
    return Init_Od_signboard_confidence(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_ped_confidence
{
public:
  explicit Init_Od_ped_confidence(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_truck_confidence ped_confidence(::radar_msgs::msg::Od::_ped_confidence_type arg)
  {
    msg_.ped_confidence = std::move(arg);
    return Init_Od_truck_confidence(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_bike_confidence
{
public:
  explicit Init_Od_bike_confidence(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_ped_confidence bike_confidence(::radar_msgs::msg::Od::_bike_confidence_type arg)
  {
    msg_.bike_confidence = std::move(arg);
    return Init_Od_ped_confidence(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_car_confidence
{
public:
  explicit Init_Od_car_confidence(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_bike_confidence car_confidence(::radar_msgs::msg::Od::_car_confidence_type arg)
  {
    msg_.car_confidence = std::move(arg);
    return Init_Od_bike_confidence(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_type
{
public:
  explicit Init_Od_type(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_car_confidence type(::radar_msgs::msg::Od::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_Od_car_confidence(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_pose_nearest
{
public:
  explicit Init_Od_pose_nearest(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_type pose_nearest(::radar_msgs::msg::Od::_pose_nearest_type arg)
  {
    msg_.pose_nearest = std::move(arg);
    return Init_Od_type(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_v2ground
{
public:
  explicit Init_Od_v2ground(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_pose_nearest v2ground(::radar_msgs::msg::Od::_v2ground_type arg)
  {
    msg_.v2ground = std::move(arg);
    return Init_Od_pose_nearest(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_acceleration
{
public:
  explicit Init_Od_acceleration(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_v2ground acceleration(::radar_msgs::msg::Od::_acceleration_type arg)
  {
    msg_.acceleration = std::move(arg);
    return Init_Od_v2ground(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_velocity
{
public:
  explicit Init_Od_velocity(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_acceleration velocity(::radar_msgs::msg::Od::_velocity_type arg)
  {
    msg_.velocity = std::move(arg);
    return Init_Od_acceleration(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_dimensions
{
public:
  explicit Init_Od_dimensions(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_velocity dimensions(::radar_msgs::msg::Od::_dimensions_type arg)
  {
    msg_.dimensions = std::move(arg);
    return Init_Od_velocity(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_pose
{
public:
  explicit Init_Od_pose(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_dimensions pose(::radar_msgs::msg::Od::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return Init_Od_dimensions(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_existance_confidence
{
public:
  explicit Init_Od_existance_confidence(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_pose existance_confidence(::radar_msgs::msg::Od::_existance_confidence_type arg)
  {
    msg_.existance_confidence = std::move(arg);
    return Init_Od_pose(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_motion_state
{
public:
  explicit Init_Od_motion_state(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_existance_confidence motion_state(::radar_msgs::msg::Od::_motion_state_type arg)
  {
    msg_.motion_state = std::move(arg);
    return Init_Od_existance_confidence(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_measurement_status
{
public:
  explicit Init_Od_measurement_status(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_motion_state measurement_status(::radar_msgs::msg::Od::_measurement_status_type arg)
  {
    msg_.measurement_status = std::move(arg);
    return Init_Od_motion_state(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_age
{
public:
  explicit Init_Od_age(::radar_msgs::msg::Od & msg)
  : msg_(msg)
  {}
  Init_Od_measurement_status age(::radar_msgs::msg::Od::_age_type arg)
  {
    msg_.age = std::move(arg);
    return Init_Od_measurement_status(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

class Init_Od_object_id
{
public:
  Init_Od_object_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Od_age object_id(::radar_msgs::msg::Od::_object_id_type arg)
  {
    msg_.object_id = std::move(arg);
    return Init_Od_age(msg_);
  }

private:
  ::radar_msgs::msg::Od msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::Od>()
{
  return radar_msgs::msg::builder::Init_Od_object_id();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__OD__BUILDER_HPP_
