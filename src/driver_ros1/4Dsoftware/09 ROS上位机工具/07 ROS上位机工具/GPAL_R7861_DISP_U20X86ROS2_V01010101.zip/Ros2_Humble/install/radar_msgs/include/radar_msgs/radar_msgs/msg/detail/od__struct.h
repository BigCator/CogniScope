﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/Od.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__OD__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__OD__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'pose'
// Member 'pose_nearest'
#include "geometry_msgs/msg/detail/pose__struct.h"
// Member 'dimensions'
#include "geometry_msgs/msg/detail/vector3__struct.h"
// Member 'velocity'
// Member 'acceleration'
// Member 'v2ground'
#include "geometry_msgs/msg/detail/twist__struct.h"
// Member 'reserved_o'
// Member 'reserved_p'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/Od in the package radar_msgs.
/**
  * Header    header               # Includes measurement timestamp and coordinate frame.
 */
typedef struct radar_msgs__msg__Od
{
  /// object ID
  uint32_t object_id;
  /// total frames from the object occurs
  uint16_t age;
  /// track status (0: measured; 1: new; 2: predicted)
  uint8_t measurement_status;
  /// movement state ( 0: static; 1: dynamic)
  uint8_t motion_state;
  /// existance confidence
  uint8_t existance_confidence;
  /// central position x, y, z; roll=0, pitch=0, yaw to quaternion
  geometry_msgs__msg__Pose pose;
  /// length, width, height
  geometry_msgs__msg__Vector3 dimensions;
  geometry_msgs__msg__Twist velocity;
  geometry_msgs__msg__Twist acceleration;
  /// velocity towards ground of x, y, z orientation
  geometry_msgs__msg__Twist v2ground;
  /// nearestpts x, y, z
  geometry_msgs__msg__Pose pose_nearest;
  /// object type (（0: car 小型汽车; 1: bike 两轮车; 2: pedestrian 行人; 3: truck 大车; 4: signboard 高空物; 5: ground 地面; 6: obstacle 静态障碍物)
  uint8_t type;
  /// car confidence
  uint8_t car_confidence;
  /// bike confidence
  uint8_t bike_confidence;
  /// pedestrian confidence
  uint8_t ped_confidence;
  /// truck confidence
  uint8_t truck_confidence;
  /// signboard confidence
  uint8_t signboard_confidence;
  /// ground confidence
  uint8_t ground_confidence;
  /// obstacle confidence
  uint8_t obstacle_confidence;
  /// EnrollPtsNum
  float enrollptsnum;
  /// nearestptsX
  float nearestptsx;
  /// nearestptsY
  float nearestptsy;
  /// nearestptsZ
  float nearestptsz;
  float reserved_d;
  uint32_t reserved_e;
  uint32_t reserved_f;
  int32_t reserved_g;
  int32_t reserved_h;
  uint16_t reserved_i;
  uint16_t reserved_j;
  int16_t reserved_k;
  int16_t reserved_l;
  uint8_t reserved_m;
  uint8_t reserved_n;
  rosidl_runtime_c__String reserved_o;
  rosidl_runtime_c__String reserved_p;
} radar_msgs__msg__Od;

// Struct for a sequence of radar_msgs__msg__Od.
typedef struct radar_msgs__msg__Od__Sequence
{
  radar_msgs__msg__Od * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__Od__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__OD__STRUCT_H_
