// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RdInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RD_INFO__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RD_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RdInfo __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RdInfo __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RdInfo_
{
  using Type = RdInfo_<ContainerAllocator>;

  explicit RdInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->frameid = 0ul;
      this->cfarcount = 0ul;
      this->targetnum = 0ul;
      this->resetcnt = 0;
      this->objnum = 0ul;
      this->carspeed = 0.0f;
      this->caryawrate = 0.0f;
      this->gearstate = 0;
      this->odtimeoutcnt = 0;
      this->comprotv_i = 0;
      this->comprotv_ii = 0;
      this->framelostcnt = 0;
      this->beforeadcerrcnt = 0;
      this->afteradcerrcnt = 0;
      this->udpframelostcnt = 0ul;
      this->udpfreq = 0.0f;
      this->timesyncstatus = 0;
      this->velestimate = 0.0f;
      this->gndk = 0.0f;
      this->gndb = 0.0f;
      this->pcl_time = 0.0f;
      this->od_time = 0.0f;
      this->rdframelostcnt = 0ul;
      this->jamstatusprofile0 = 0;
      this->jamstatusprofile1 = 0;
    }
  }

  explicit RdInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->frameid = 0ul;
      this->cfarcount = 0ul;
      this->targetnum = 0ul;
      this->resetcnt = 0;
      this->objnum = 0ul;
      this->carspeed = 0.0f;
      this->caryawrate = 0.0f;
      this->gearstate = 0;
      this->odtimeoutcnt = 0;
      this->comprotv_i = 0;
      this->comprotv_ii = 0;
      this->framelostcnt = 0;
      this->beforeadcerrcnt = 0;
      this->afteradcerrcnt = 0;
      this->udpframelostcnt = 0ul;
      this->udpfreq = 0.0f;
      this->timesyncstatus = 0;
      this->velestimate = 0.0f;
      this->gndk = 0.0f;
      this->gndb = 0.0f;
      this->pcl_time = 0.0f;
      this->od_time = 0.0f;
      this->rdframelostcnt = 0ul;
      this->jamstatusprofile0 = 0;
      this->jamstatusprofile1 = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _frameid_type =
    uint32_t;
  _frameid_type frameid;
  using _cfarcount_type =
    uint32_t;
  _cfarcount_type cfarcount;
  using _targetnum_type =
    uint32_t;
  _targetnum_type targetnum;
  using _resetcnt_type =
    int16_t;
  _resetcnt_type resetcnt;
  using _objnum_type =
    uint32_t;
  _objnum_type objnum;
  using _carspeed_type =
    float;
  _carspeed_type carspeed;
  using _caryawrate_type =
    float;
  _caryawrate_type caryawrate;
  using _gearstate_type =
    uint16_t;
  _gearstate_type gearstate;
  using _odtimeoutcnt_type =
    int16_t;
  _odtimeoutcnt_type odtimeoutcnt;
  using _comprotv_i_type =
    uint16_t;
  _comprotv_i_type comprotv_i;
  using _comprotv_ii_type =
    uint16_t;
  _comprotv_ii_type comprotv_ii;
  using _framelostcnt_type =
    uint16_t;
  _framelostcnt_type framelostcnt;
  using _beforeadcerrcnt_type =
    uint16_t;
  _beforeadcerrcnt_type beforeadcerrcnt;
  using _afteradcerrcnt_type =
    uint16_t;
  _afteradcerrcnt_type afteradcerrcnt;
  using _udpframelostcnt_type =
    uint32_t;
  _udpframelostcnt_type udpframelostcnt;
  using _udpfreq_type =
    float;
  _udpfreq_type udpfreq;
  using _timesyncstatus_type =
    uint16_t;
  _timesyncstatus_type timesyncstatus;
  using _velestimate_type =
    float;
  _velestimate_type velestimate;
  using _gndk_type =
    float;
  _gndk_type gndk;
  using _gndb_type =
    float;
  _gndb_type gndb;
  using _pcl_time_type =
    float;
  _pcl_time_type pcl_time;
  using _od_time_type =
    float;
  _od_time_type od_time;
  using _rdframelostcnt_type =
    uint32_t;
  _rdframelostcnt_type rdframelostcnt;
  using _jamstatusprofile0_type =
    uint16_t;
  _jamstatusprofile0_type jamstatusprofile0;
  using _jamstatusprofile1_type =
    uint16_t;
  _jamstatusprofile1_type jamstatusprofile1;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__frameid(
    const uint32_t & _arg)
  {
    this->frameid = _arg;
    return *this;
  }
  Type & set__cfarcount(
    const uint32_t & _arg)
  {
    this->cfarcount = _arg;
    return *this;
  }
  Type & set__targetnum(
    const uint32_t & _arg)
  {
    this->targetnum = _arg;
    return *this;
  }
  Type & set__resetcnt(
    const int16_t & _arg)
  {
    this->resetcnt = _arg;
    return *this;
  }
  Type & set__objnum(
    const uint32_t & _arg)
  {
    this->objnum = _arg;
    return *this;
  }
  Type & set__carspeed(
    const float & _arg)
  {
    this->carspeed = _arg;
    return *this;
  }
  Type & set__caryawrate(
    const float & _arg)
  {
    this->caryawrate = _arg;
    return *this;
  }
  Type & set__gearstate(
    const uint16_t & _arg)
  {
    this->gearstate = _arg;
    return *this;
  }
  Type & set__odtimeoutcnt(
    const int16_t & _arg)
  {
    this->odtimeoutcnt = _arg;
    return *this;
  }
  Type & set__comprotv_i(
    const uint16_t & _arg)
  {
    this->comprotv_i = _arg;
    return *this;
  }
  Type & set__comprotv_ii(
    const uint16_t & _arg)
  {
    this->comprotv_ii = _arg;
    return *this;
  }
  Type & set__framelostcnt(
    const uint16_t & _arg)
  {
    this->framelostcnt = _arg;
    return *this;
  }
  Type & set__beforeadcerrcnt(
    const uint16_t & _arg)
  {
    this->beforeadcerrcnt = _arg;
    return *this;
  }
  Type & set__afteradcerrcnt(
    const uint16_t & _arg)
  {
    this->afteradcerrcnt = _arg;
    return *this;
  }
  Type & set__udpframelostcnt(
    const uint32_t & _arg)
  {
    this->udpframelostcnt = _arg;
    return *this;
  }
  Type & set__udpfreq(
    const float & _arg)
  {
    this->udpfreq = _arg;
    return *this;
  }
  Type & set__timesyncstatus(
    const uint16_t & _arg)
  {
    this->timesyncstatus = _arg;
    return *this;
  }
  Type & set__velestimate(
    const float & _arg)
  {
    this->velestimate = _arg;
    return *this;
  }
  Type & set__gndk(
    const float & _arg)
  {
    this->gndk = _arg;
    return *this;
  }
  Type & set__gndb(
    const float & _arg)
  {
    this->gndb = _arg;
    return *this;
  }
  Type & set__pcl_time(
    const float & _arg)
  {
    this->pcl_time = _arg;
    return *this;
  }
  Type & set__od_time(
    const float & _arg)
  {
    this->od_time = _arg;
    return *this;
  }
  Type & set__rdframelostcnt(
    const uint32_t & _arg)
  {
    this->rdframelostcnt = _arg;
    return *this;
  }
  Type & set__jamstatusprofile0(
    const uint16_t & _arg)
  {
    this->jamstatusprofile0 = _arg;
    return *this;
  }
  Type & set__jamstatusprofile1(
    const uint16_t & _arg)
  {
    this->jamstatusprofile1 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RdInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RdInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RdInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RdInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RdInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RdInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RdInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RdInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RdInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RdInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RdInfo
    std::shared_ptr<radar_msgs::msg::RdInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RdInfo
    std::shared_ptr<radar_msgs::msg::RdInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RdInfo_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->frameid != other.frameid) {
      return false;
    }
    if (this->cfarcount != other.cfarcount) {
      return false;
    }
    if (this->targetnum != other.targetnum) {
      return false;
    }
    if (this->resetcnt != other.resetcnt) {
      return false;
    }
    if (this->objnum != other.objnum) {
      return false;
    }
    if (this->carspeed != other.carspeed) {
      return false;
    }
    if (this->caryawrate != other.caryawrate) {
      return false;
    }
    if (this->gearstate != other.gearstate) {
      return false;
    }
    if (this->odtimeoutcnt != other.odtimeoutcnt) {
      return false;
    }
    if (this->comprotv_i != other.comprotv_i) {
      return false;
    }
    if (this->comprotv_ii != other.comprotv_ii) {
      return false;
    }
    if (this->framelostcnt != other.framelostcnt) {
      return false;
    }
    if (this->beforeadcerrcnt != other.beforeadcerrcnt) {
      return false;
    }
    if (this->afteradcerrcnt != other.afteradcerrcnt) {
      return false;
    }
    if (this->udpframelostcnt != other.udpframelostcnt) {
      return false;
    }
    if (this->udpfreq != other.udpfreq) {
      return false;
    }
    if (this->timesyncstatus != other.timesyncstatus) {
      return false;
    }
    if (this->velestimate != other.velestimate) {
      return false;
    }
    if (this->gndk != other.gndk) {
      return false;
    }
    if (this->gndb != other.gndb) {
      return false;
    }
    if (this->pcl_time != other.pcl_time) {
      return false;
    }
    if (this->od_time != other.od_time) {
      return false;
    }
    if (this->rdframelostcnt != other.rdframelostcnt) {
      return false;
    }
    if (this->jamstatusprofile0 != other.jamstatusprofile0) {
      return false;
    }
    if (this->jamstatusprofile1 != other.jamstatusprofile1) {
      return false;
    }
    return true;
  }
  bool operator!=(const RdInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RdInfo_

// alias to use template instance with default allocator
using RdInfo =
  radar_msgs::msg::RdInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RD_INFO__STRUCT_HPP_
