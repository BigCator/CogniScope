// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/ProcessStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/process_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ProcessStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: radar_id
  {
    out << "radar_id: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_id, out);
    out << ", ";
  }

  // member: frame_cnt
  {
    out << "frame_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_cnt, out);
    out << ", ";
  }

  // member: capture_time
  {
    out << "capture_time: ";
    rosidl_generator_traits::value_to_yaml(msg.capture_time, out);
    out << ", ";
  }

  // member: framelost_cnt
  {
    out << "framelost_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.framelost_cnt, out);
    out << ", ";
  }

  // member: adcerrcnt
  {
    out << "adcerrcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.adcerrcnt, out);
    out << ", ";
  }

  // member: reserved_a
  {
    out << "reserved_a: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_a, out);
    out << ", ";
  }

  // member: reserved_b
  {
    out << "reserved_b: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_b, out);
    out << ", ";
  }

  // member: time1dfft
  {
    out << "time1dfft: ";
    rosidl_generator_traits::value_to_yaml(msg.time1dfft, out);
    out << ", ";
  }

  // member: reserved_c
  {
    out << "reserved_c: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_c, out);
    out << ", ";
  }

  // member: reserved_d
  {
    out << "reserved_d: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_d, out);
    out << ", ";
  }

  // member: reserved_e
  {
    out << "reserved_e: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_e, out);
    out << ", ";
  }

  // member: reserved_f
  {
    out << "reserved_f: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_f, out);
    out << ", ";
  }

  // member: time2dfft
  {
    out << "time2dfft: ";
    rosidl_generator_traits::value_to_yaml(msg.time2dfft, out);
    out << ", ";
  }

  // member: reserved_g
  {
    out << "reserved_g: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_g, out);
    out << ", ";
  }

  // member: reserved_h
  {
    out << "reserved_h: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_h, out);
    out << ", ";
  }

  // member: reserved_i
  {
    out << "reserved_i: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_i, out);
    out << ", ";
  }

  // member: reserved_j
  {
    out << "reserved_j: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_j, out);
    out << ", ";
  }

  // member: timerdmap
  {
    out << "timerdmap: ";
    rosidl_generator_traits::value_to_yaml(msg.timerdmap, out);
    out << ", ";
  }

  // member: reserved_k
  {
    out << "reserved_k: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_k, out);
    out << ", ";
  }

  // member: reserved_l
  {
    out << "reserved_l: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_l, out);
    out << ", ";
  }

  // member: reserved_m
  {
    out << "reserved_m: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_m, out);
    out << ", ";
  }

  // member: reserved_n
  {
    out << "reserved_n: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_n, out);
    out << ", ";
  }

  // member: timecfar
  {
    out << "timecfar: ";
    rosidl_generator_traits::value_to_yaml(msg.timecfar, out);
    out << ", ";
  }

  // member: reserved_o
  {
    out << "reserved_o: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_o, out);
    out << ", ";
  }

  // member: reserved_p
  {
    out << "reserved_p: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_p, out);
    out << ", ";
  }

  // member: reserved_q
  {
    out << "reserved_q: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_q, out);
    out << ", ";
  }

  // member: reserved_r
  {
    out << "reserved_r: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_r, out);
    out << ", ";
  }

  // member: timedoa
  {
    out << "timedoa: ";
    rosidl_generator_traits::value_to_yaml(msg.timedoa, out);
    out << ", ";
  }

  // member: reserved_s
  {
    out << "reserved_s: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_s, out);
    out << ", ";
  }

  // member: reserved_t
  {
    out << "reserved_t: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_t, out);
    out << ", ";
  }

  // member: reserved_u
  {
    out << "reserved_u: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_u, out);
    out << ", ";
  }

  // member: reserved_v
  {
    out << "reserved_v: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_v, out);
    out << ", ";
  }

  // member: timepcl
  {
    out << "timepcl: ";
    rosidl_generator_traits::value_to_yaml(msg.timepcl, out);
    out << ", ";
  }

  // member: reserved_w
  {
    out << "reserved_w: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_w, out);
    out << ", ";
  }

  // member: reserved_x
  {
    out << "reserved_x: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_x, out);
    out << ", ";
  }

  // member: reserved_y
  {
    out << "reserved_y: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_y, out);
    out << ", ";
  }

  // member: reserved_z
  {
    out << "reserved_z: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_z, out);
    out << ", ";
  }

  // member: timeod
  {
    out << "timeod: ";
    rosidl_generator_traits::value_to_yaml(msg.timeod, out);
    out << ", ";
  }

  // member: odtimeoutcnt
  {
    out << "odtimeoutcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.odtimeoutcnt, out);
    out << ", ";
  }

  // member: selfcalistatus
  {
    out << "selfcalistatus: ";
    rosidl_generator_traits::value_to_yaml(msg.selfcalistatus, out);
    out << ", ";
  }

  // member: reserved_aa
  {
    out << "reserved_aa: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_aa, out);
    out << ", ";
  }

  // member: reserved_ab
  {
    out << "reserved_ab: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_ab, out);
    out << ", ";
  }

  // member: reserved_ac
  {
    out << "reserved_ac: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_ac, out);
    out << ", ";
  }

  // member: reserved_ad
  {
    out << "reserved_ad: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_ad, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ProcessStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: radar_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "radar_id: ";
    rosidl_generator_traits::value_to_yaml(msg.radar_id, out);
    out << "\n";
  }

  // member: frame_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_cnt, out);
    out << "\n";
  }

  // member: capture_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "capture_time: ";
    rosidl_generator_traits::value_to_yaml(msg.capture_time, out);
    out << "\n";
  }

  // member: framelost_cnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "framelost_cnt: ";
    rosidl_generator_traits::value_to_yaml(msg.framelost_cnt, out);
    out << "\n";
  }

  // member: adcerrcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "adcerrcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.adcerrcnt, out);
    out << "\n";
  }

  // member: reserved_a
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_a: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_a, out);
    out << "\n";
  }

  // member: reserved_b
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_b: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_b, out);
    out << "\n";
  }

  // member: time1dfft
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "time1dfft: ";
    rosidl_generator_traits::value_to_yaml(msg.time1dfft, out);
    out << "\n";
  }

  // member: reserved_c
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_c: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_c, out);
    out << "\n";
  }

  // member: reserved_d
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_d: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_d, out);
    out << "\n";
  }

  // member: reserved_e
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_e: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_e, out);
    out << "\n";
  }

  // member: reserved_f
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_f: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_f, out);
    out << "\n";
  }

  // member: time2dfft
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "time2dfft: ";
    rosidl_generator_traits::value_to_yaml(msg.time2dfft, out);
    out << "\n";
  }

  // member: reserved_g
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_g: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_g, out);
    out << "\n";
  }

  // member: reserved_h
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_h: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_h, out);
    out << "\n";
  }

  // member: reserved_i
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_i: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_i, out);
    out << "\n";
  }

  // member: reserved_j
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_j: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_j, out);
    out << "\n";
  }

  // member: timerdmap
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timerdmap: ";
    rosidl_generator_traits::value_to_yaml(msg.timerdmap, out);
    out << "\n";
  }

  // member: reserved_k
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_k: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_k, out);
    out << "\n";
  }

  // member: reserved_l
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_l: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_l, out);
    out << "\n";
  }

  // member: reserved_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_m: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_m, out);
    out << "\n";
  }

  // member: reserved_n
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_n: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_n, out);
    out << "\n";
  }

  // member: timecfar
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timecfar: ";
    rosidl_generator_traits::value_to_yaml(msg.timecfar, out);
    out << "\n";
  }

  // member: reserved_o
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_o: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_o, out);
    out << "\n";
  }

  // member: reserved_p
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_p: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_p, out);
    out << "\n";
  }

  // member: reserved_q
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_q: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_q, out);
    out << "\n";
  }

  // member: reserved_r
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_r: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_r, out);
    out << "\n";
  }

  // member: timedoa
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timedoa: ";
    rosidl_generator_traits::value_to_yaml(msg.timedoa, out);
    out << "\n";
  }

  // member: reserved_s
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_s: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_s, out);
    out << "\n";
  }

  // member: reserved_t
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_t: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_t, out);
    out << "\n";
  }

  // member: reserved_u
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_u: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_u, out);
    out << "\n";
  }

  // member: reserved_v
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_v: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_v, out);
    out << "\n";
  }

  // member: timepcl
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timepcl: ";
    rosidl_generator_traits::value_to_yaml(msg.timepcl, out);
    out << "\n";
  }

  // member: reserved_w
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_w: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_w, out);
    out << "\n";
  }

  // member: reserved_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_x: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_x, out);
    out << "\n";
  }

  // member: reserved_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_y: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_y, out);
    out << "\n";
  }

  // member: reserved_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_z: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_z, out);
    out << "\n";
  }

  // member: timeod
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timeod: ";
    rosidl_generator_traits::value_to_yaml(msg.timeod, out);
    out << "\n";
  }

  // member: odtimeoutcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "odtimeoutcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.odtimeoutcnt, out);
    out << "\n";
  }

  // member: selfcalistatus
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "selfcalistatus: ";
    rosidl_generator_traits::value_to_yaml(msg.selfcalistatus, out);
    out << "\n";
  }

  // member: reserved_aa
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_aa: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_aa, out);
    out << "\n";
  }

  // member: reserved_ab
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_ab: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_ab, out);
    out << "\n";
  }

  // member: reserved_ac
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_ac: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_ac, out);
    out << "\n";
  }

  // member: reserved_ad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved_ad: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved_ad, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ProcessStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::ProcessStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::ProcessStatus & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::ProcessStatus>()
{
  return "radar_msgs::msg::ProcessStatus";
}

template<>
inline const char * name<radar_msgs::msg::ProcessStatus>()
{
  return "radar_msgs/msg/ProcessStatus";
}

template<>
struct has_fixed_size<radar_msgs::msg::ProcessStatus>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<radar_msgs::msg::ProcessStatus>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<radar_msgs::msg::ProcessStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__TRAITS_HPP_
