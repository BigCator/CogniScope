// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonPllConVoltRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_PLL_CON_VOLT_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_PLL_CON_VOLT_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_pll_con_volt_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonPllConVoltRep_timestamp
{
public:
  explicit Init_RlMonPllConVoltRep_timestamp(::radar_msgs::msg::RlMonPllConVoltRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonPllConVoltRep timestamp(::radar_msgs::msg::RlMonPllConVoltRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPllConVoltRep msg_;
};

class Init_RlMonPllConVoltRep_reserved
{
public:
  explicit Init_RlMonPllConVoltRep_reserved(::radar_msgs::msg::RlMonPllConVoltRep & msg)
  : msg_(msg)
  {}
  Init_RlMonPllConVoltRep_timestamp reserved(::radar_msgs::msg::RlMonPllConVoltRep::_reserved_type arg)
  {
    msg_.reserved = std::move(arg);
    return Init_RlMonPllConVoltRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPllConVoltRep msg_;
};

class Init_RlMonPllConVoltRep_pllcontvoltval
{
public:
  explicit Init_RlMonPllConVoltRep_pllcontvoltval(::radar_msgs::msg::RlMonPllConVoltRep & msg)
  : msg_(msg)
  {}
  Init_RlMonPllConVoltRep_reserved pllcontvoltval(::radar_msgs::msg::RlMonPllConVoltRep::_pllcontvoltval_type arg)
  {
    msg_.pllcontvoltval = std::move(arg);
    return Init_RlMonPllConVoltRep_reserved(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPllConVoltRep msg_;
};

class Init_RlMonPllConVoltRep_errorcode
{
public:
  explicit Init_RlMonPllConVoltRep_errorcode(::radar_msgs::msg::RlMonPllConVoltRep & msg)
  : msg_(msg)
  {}
  Init_RlMonPllConVoltRep_pllcontvoltval errorcode(::radar_msgs::msg::RlMonPllConVoltRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonPllConVoltRep_pllcontvoltval(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPllConVoltRep msg_;
};

class Init_RlMonPllConVoltRep_statusflags
{
public:
  Init_RlMonPllConVoltRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonPllConVoltRep_errorcode statusflags(::radar_msgs::msg::RlMonPllConVoltRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonPllConVoltRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonPllConVoltRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonPllConVoltRep>()
{
  return radar_msgs::msg::builder::Init_RlMonPllConVoltRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_PLL_CON_VOLT_REP__BUILDER_HPP_
