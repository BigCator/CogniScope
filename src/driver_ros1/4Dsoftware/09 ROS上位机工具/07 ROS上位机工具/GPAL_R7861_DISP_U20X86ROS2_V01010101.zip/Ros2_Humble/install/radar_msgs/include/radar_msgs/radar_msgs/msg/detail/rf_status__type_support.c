// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from radar_msgs:msg/RfStatus.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "radar_msgs/msg/detail/rf_status__rosidl_typesupport_introspection_c.h"
#include "radar_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "radar_msgs/msg/detail/rf_status__functions.h"
#include "radar_msgs/msg/detail/rf_status__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `diglatentfaultdata`
#include "radar_msgs/msg/rl_dig_latent_fault_report_data.h"
// Member `diglatentfaultdata`
#include "radar_msgs/msg/detail/rl_dig_latent_fault_report_data__rosidl_typesupport_introspection_c.h"
// Member `reportheaderdata`
#include "radar_msgs/msg/rl_mon_report_hdr_data.h"
// Member `reportheaderdata`
#include "radar_msgs/msg/detail/rl_mon_report_hdr_data__rosidl_typesupport_introspection_c.h"
// Member `reporttempdata`
#include "radar_msgs/msg/rl_mon_temp_report_data.h"
// Member `reporttempdata`
#include "radar_msgs/msg/detail/rl_mon_temp_report_data__rosidl_typesupport_introspection_c.h"
// Member `digperiodicreportdata`
#include "radar_msgs/msg/rl_dig_periodic_report_data.h"
// Member `digperiodicreportdata`
#include "radar_msgs/msg/detail/rl_dig_periodic_report_data__rosidl_typesupport_introspection_c.h"
// Member `reportrxgainphdata`
#include "radar_msgs/msg/rl_mon_rx_gain_ph_rep.h"
// Member `reportrxgainphdata`
#include "radar_msgs/msg/detail/rl_mon_rx_gain_ph_rep__rosidl_typesupport_introspection_c.h"
// Member `reportrxnoisefigdata`
#include "radar_msgs/msg/rl_mon_rx_noise_fig_rep.h"
// Member `reportrxnoisefigdata`
#include "radar_msgs/msg/detail/rl_mon_rx_noise_fig_rep__rosidl_typesupport_introspection_c.h"
// Member `reportrxifstagedata`
#include "radar_msgs/msg/rl_mon_rx_if_stage_rep.h"
// Member `reportrxifstagedata`
#include "radar_msgs/msg/detail/rl_mon_rx_if_stage_rep__rosidl_typesupport_introspection_c.h"
// Member `reportrxintanasigdata`
#include "radar_msgs/msg/rl_mon_rx_int_ana_sig_rep.h"
// Member `reportrxintanasigdata`
#include "radar_msgs/msg/detail/rl_mon_rx_int_ana_sig_rep__rosidl_typesupport_introspection_c.h"
// Member `reportpmclklointanasigdata`
#include "radar_msgs/msg/rl_mon_pmclklo_int_ana_sig_rep.h"
// Member `reportpmclklointanasigdata`
#include "radar_msgs/msg/detail/rl_mon_pmclklo_int_ana_sig_rep__rosidl_typesupport_introspection_c.h"
// Member `reportgpadcintanasigdata`
#include "radar_msgs/msg/rl_mon_gpadc_int_ana_sig_rep.h"
// Member `reportgpadcintanasigdata`
#include "radar_msgs/msg/detail/rl_mon_gpadc_int_ana_sig_rep__rosidl_typesupport_introspection_c.h"
// Member `reportpllconvoltdata`
#include "radar_msgs/msg/rl_mon_pll_con_volt_rep.h"
// Member `reportpllconvoltdata`
#include "radar_msgs/msg/detail/rl_mon_pll_con_volt_rep__rosidl_typesupport_introspection_c.h"
// Member `reportdccclkfreqdata`
#include "radar_msgs/msg/rl_mon_dcc_clk_freq_rep.h"
// Member `reportdccclkfreqdata`
#include "radar_msgs/msg/detail/rl_mon_dcc_clk_freq_rep__rosidl_typesupport_introspection_c.h"
// Member `reportsynthfreqnonlivedata`
#include "radar_msgs/msg/rl_mon_synth_freq_non_live_rep.h"
// Member `reportsynthfreqnonlivedata`
#include "radar_msgs/msg/detail/rl_mon_synth_freq_non_live_rep__rosidl_typesupport_introspection_c.h"
// Member `reportrxmixrinpwrdata`
#include "radar_msgs/msg/rl_mon_rx_mixr_in_pwr_rep.h"
// Member `reportrxmixrinpwrdata`
#include "radar_msgs/msg/detail/rl_mon_rx_mixr_in_pwr_rep__rosidl_typesupport_introspection_c.h"
// Member `reporttxintanasigdata`
#include "radar_msgs/msg/rl_mon_tx_int_ana_sig_rep.h"
// Member `reporttxintanasigdata`
#include "radar_msgs/msg/detail/rl_mon_tx_int_ana_sig_rep__rosidl_typesupport_introspection_c.h"
// Member `reportextanasigdata`
#include "radar_msgs/msg/rl_mon_ext_ana_sig_rep.h"
// Member `reportextanasigdata`
#include "radar_msgs/msg/detail/rl_mon_ext_ana_sig_rep__rosidl_typesupport_introspection_c.h"
// Member `reportsynthfreqdata`
#include "radar_msgs/msg/rl_mon_synth_freq_rep.h"
// Member `reportsynthfreqdata`
#include "radar_msgs/msg/detail/rl_mon_synth_freq_rep__rosidl_typesupport_introspection_c.h"
// Member `reporttxphshiftdata`
#include "radar_msgs/msg/rl_mon_tx_ph_shift_rep.h"
// Member `reporttxphshiftdata`
#include "radar_msgs/msg/detail/rl_mon_tx_ph_shift_rep__rosidl_typesupport_introspection_c.h"
// Member `reporttxgainphamisdata`
#include "radar_msgs/msg/rl_mon_tx_gain_pha_mis_rep.h"
// Member `reporttxgainphamisdata`
#include "radar_msgs/msg/detail/rl_mon_tx_gain_pha_mis_rep__rosidl_typesupport_introspection_c.h"
// Member `reporttxballbreakdata`
#include "radar_msgs/msg/rl_mon_tx_ball_break_rep.h"
// Member `reporttxballbreakdata`
#include "radar_msgs/msg/detail/rl_mon_tx_ball_break_rep__rosidl_typesupport_introspection_c.h"
// Member `reporttxpowdata`
#include "radar_msgs/msg/rl_mon_tx_pow_rep.h"
// Member `reporttxpowdata`
#include "radar_msgs/msg/detail/rl_mon_tx_pow_rep__rosidl_typesupport_introspection_c.h"
// Member `reportrecvdgpadcdata`
#include "radar_msgs/msg/rl_recvd_gp_adc_data.h"
// Member `reportrecvdgpadcdata`
#include "radar_msgs/msg/detail/rl_recvd_gp_adc_data__rosidl_typesupport_introspection_c.h"
// Member `reportanalogfaultdata`
#include "radar_msgs/msg/rl_analog_fault_report_data.h"
// Member `reportanalogfaultdata`
#include "radar_msgs/msg/detail/rl_analog_fault_report_data__rosidl_typesupport_introspection_c.h"
// Member `reporttimingerrordata`
#include "radar_msgs/msg/rl_cal_mon_timing_error_report_data.h"
// Member `reporttimingerrordata`
#include "radar_msgs/msg/detail/rl_cal_mon_timing_error_report_data__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  radar_msgs__msg__RfStatus__init(message_memory);
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_fini_function(void * message_memory)
{
  radar_msgs__msg__RfStatus__fini(message_memory);
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportrxgainphdata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxgainphdata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonRxGainPhRep * member =
    (const radar_msgs__msg__RlMonRxGainPhRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxgainphdata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonRxGainPhRep * member =
    (radar_msgs__msg__RlMonRxGainPhRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportrxgainphdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonRxGainPhRep * item =
    ((const radar_msgs__msg__RlMonRxGainPhRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxgainphdata(untyped_member, index));
  radar_msgs__msg__RlMonRxGainPhRep * value =
    (radar_msgs__msg__RlMonRxGainPhRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportrxgainphdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonRxGainPhRep * item =
    ((radar_msgs__msg__RlMonRxGainPhRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxgainphdata(untyped_member, index));
  const radar_msgs__msg__RlMonRxGainPhRep * value =
    (const radar_msgs__msg__RlMonRxGainPhRep *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportrxnoisefigdata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxnoisefigdata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonRxNoiseFigRep * member =
    (const radar_msgs__msg__RlMonRxNoiseFigRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxnoisefigdata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonRxNoiseFigRep * member =
    (radar_msgs__msg__RlMonRxNoiseFigRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportrxnoisefigdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonRxNoiseFigRep * item =
    ((const radar_msgs__msg__RlMonRxNoiseFigRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxnoisefigdata(untyped_member, index));
  radar_msgs__msg__RlMonRxNoiseFigRep * value =
    (radar_msgs__msg__RlMonRxNoiseFigRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportrxnoisefigdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonRxNoiseFigRep * item =
    ((radar_msgs__msg__RlMonRxNoiseFigRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxnoisefigdata(untyped_member, index));
  const radar_msgs__msg__RlMonRxNoiseFigRep * value =
    (const radar_msgs__msg__RlMonRxNoiseFigRep *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportrxifstagedata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxifstagedata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonRxIfStageRep * member =
    (const radar_msgs__msg__RlMonRxIfStageRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxifstagedata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonRxIfStageRep * member =
    (radar_msgs__msg__RlMonRxIfStageRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportrxifstagedata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonRxIfStageRep * item =
    ((const radar_msgs__msg__RlMonRxIfStageRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxifstagedata(untyped_member, index));
  radar_msgs__msg__RlMonRxIfStageRep * value =
    (radar_msgs__msg__RlMonRxIfStageRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportrxifstagedata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonRxIfStageRep * item =
    ((radar_msgs__msg__RlMonRxIfStageRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxifstagedata(untyped_member, index));
  const radar_msgs__msg__RlMonRxIfStageRep * value =
    (const radar_msgs__msg__RlMonRxIfStageRep *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportrxintanasigdata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxintanasigdata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonRxIntAnaSigRep * member =
    (const radar_msgs__msg__RlMonRxIntAnaSigRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxintanasigdata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonRxIntAnaSigRep * member =
    (radar_msgs__msg__RlMonRxIntAnaSigRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportrxintanasigdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonRxIntAnaSigRep * item =
    ((const radar_msgs__msg__RlMonRxIntAnaSigRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxintanasigdata(untyped_member, index));
  radar_msgs__msg__RlMonRxIntAnaSigRep * value =
    (radar_msgs__msg__RlMonRxIntAnaSigRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportrxintanasigdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonRxIntAnaSigRep * item =
    ((radar_msgs__msg__RlMonRxIntAnaSigRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxintanasigdata(untyped_member, index));
  const radar_msgs__msg__RlMonRxIntAnaSigRep * value =
    (const radar_msgs__msg__RlMonRxIntAnaSigRep *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportpmclklointanasigdata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportpmclklointanasigdata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonPmclkloIntAnaSigRep * member =
    (const radar_msgs__msg__RlMonPmclkloIntAnaSigRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportpmclklointanasigdata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonPmclkloIntAnaSigRep * member =
    (radar_msgs__msg__RlMonPmclkloIntAnaSigRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportpmclklointanasigdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonPmclkloIntAnaSigRep * item =
    ((const radar_msgs__msg__RlMonPmclkloIntAnaSigRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportpmclklointanasigdata(untyped_member, index));
  radar_msgs__msg__RlMonPmclkloIntAnaSigRep * value =
    (radar_msgs__msg__RlMonPmclkloIntAnaSigRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportpmclklointanasigdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonPmclkloIntAnaSigRep * item =
    ((radar_msgs__msg__RlMonPmclkloIntAnaSigRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportpmclklointanasigdata(untyped_member, index));
  const radar_msgs__msg__RlMonPmclkloIntAnaSigRep * value =
    (const radar_msgs__msg__RlMonPmclkloIntAnaSigRep *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportrxmixrinpwrdata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxmixrinpwrdata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonRxMixrInPwrRep * member =
    (const radar_msgs__msg__RlMonRxMixrInPwrRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxmixrinpwrdata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonRxMixrInPwrRep * member =
    (radar_msgs__msg__RlMonRxMixrInPwrRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportrxmixrinpwrdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonRxMixrInPwrRep * item =
    ((const radar_msgs__msg__RlMonRxMixrInPwrRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxmixrinpwrdata(untyped_member, index));
  radar_msgs__msg__RlMonRxMixrInPwrRep * value =
    (radar_msgs__msg__RlMonRxMixrInPwrRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportrxmixrinpwrdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonRxMixrInPwrRep * item =
    ((radar_msgs__msg__RlMonRxMixrInPwrRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxmixrinpwrdata(untyped_member, index));
  const radar_msgs__msg__RlMonRxMixrInPwrRep * value =
    (const radar_msgs__msg__RlMonRxMixrInPwrRep *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reporttxintanasigdata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxintanasigdata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonTxIntAnaSigRep * member =
    (const radar_msgs__msg__RlMonTxIntAnaSigRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxintanasigdata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonTxIntAnaSigRep * member =
    (radar_msgs__msg__RlMonTxIntAnaSigRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reporttxintanasigdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonTxIntAnaSigRep * item =
    ((const radar_msgs__msg__RlMonTxIntAnaSigRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxintanasigdata(untyped_member, index));
  radar_msgs__msg__RlMonTxIntAnaSigRep * value =
    (radar_msgs__msg__RlMonTxIntAnaSigRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reporttxintanasigdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonTxIntAnaSigRep * item =
    ((radar_msgs__msg__RlMonTxIntAnaSigRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxintanasigdata(untyped_member, index));
  const radar_msgs__msg__RlMonTxIntAnaSigRep * value =
    (const radar_msgs__msg__RlMonTxIntAnaSigRep *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportsynthfreqdata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportsynthfreqdata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonSynthFreqRep * member =
    (const radar_msgs__msg__RlMonSynthFreqRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportsynthfreqdata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonSynthFreqRep * member =
    (radar_msgs__msg__RlMonSynthFreqRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportsynthfreqdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonSynthFreqRep * item =
    ((const radar_msgs__msg__RlMonSynthFreqRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportsynthfreqdata(untyped_member, index));
  radar_msgs__msg__RlMonSynthFreqRep * value =
    (radar_msgs__msg__RlMonSynthFreqRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportsynthfreqdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonSynthFreqRep * item =
    ((radar_msgs__msg__RlMonSynthFreqRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportsynthfreqdata(untyped_member, index));
  const radar_msgs__msg__RlMonSynthFreqRep * value =
    (const radar_msgs__msg__RlMonSynthFreqRep *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reporttxphshiftdata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxphshiftdata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonTxPhShiftRep * member =
    (const radar_msgs__msg__RlMonTxPhShiftRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxphshiftdata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonTxPhShiftRep * member =
    (radar_msgs__msg__RlMonTxPhShiftRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reporttxphshiftdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonTxPhShiftRep * item =
    ((const radar_msgs__msg__RlMonTxPhShiftRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxphshiftdata(untyped_member, index));
  radar_msgs__msg__RlMonTxPhShiftRep * value =
    (radar_msgs__msg__RlMonTxPhShiftRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reporttxphshiftdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonTxPhShiftRep * item =
    ((radar_msgs__msg__RlMonTxPhShiftRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxphshiftdata(untyped_member, index));
  const radar_msgs__msg__RlMonTxPhShiftRep * value =
    (const radar_msgs__msg__RlMonTxPhShiftRep *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reporttxgainphamisdata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxgainphamisdata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonTxGainPhaMisRep * member =
    (const radar_msgs__msg__RlMonTxGainPhaMisRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxgainphamisdata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonTxGainPhaMisRep * member =
    (radar_msgs__msg__RlMonTxGainPhaMisRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reporttxgainphamisdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonTxGainPhaMisRep * item =
    ((const radar_msgs__msg__RlMonTxGainPhaMisRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxgainphamisdata(untyped_member, index));
  radar_msgs__msg__RlMonTxGainPhaMisRep * value =
    (radar_msgs__msg__RlMonTxGainPhaMisRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reporttxgainphamisdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonTxGainPhaMisRep * item =
    ((radar_msgs__msg__RlMonTxGainPhaMisRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxgainphamisdata(untyped_member, index));
  const radar_msgs__msg__RlMonTxGainPhaMisRep * value =
    (const radar_msgs__msg__RlMonTxGainPhaMisRep *)(untyped_value);
  *item = *value;
}

size_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reporttxpowdata(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxpowdata(
  const void * untyped_member, size_t index)
{
  const radar_msgs__msg__RlMonTxPowRep * member =
    (const radar_msgs__msg__RlMonTxPowRep *)(untyped_member);
  return &member[index];
}

void * radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxpowdata(
  void * untyped_member, size_t index)
{
  radar_msgs__msg__RlMonTxPowRep * member =
    (radar_msgs__msg__RlMonTxPowRep *)(untyped_member);
  return &member[index];
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reporttxpowdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const radar_msgs__msg__RlMonTxPowRep * item =
    ((const radar_msgs__msg__RlMonTxPowRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxpowdata(untyped_member, index));
  radar_msgs__msg__RlMonTxPowRep * value =
    (radar_msgs__msg__RlMonTxPowRep *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reporttxpowdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  radar_msgs__msg__RlMonTxPowRep * item =
    ((radar_msgs__msg__RlMonTxPowRep *)
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxpowdata(untyped_member, index));
  const radar_msgs__msg__RlMonTxPowRep * value =
    (const radar_msgs__msg__RlMonTxPowRep *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[27] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "radarid",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, radarid),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "framecnt",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, framecnt),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "diglatentfaultdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, diglatentfaultdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportheaderdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportheaderdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reporttempdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reporttempdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "digperiodicreportdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, digperiodicreportdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportrxgainphdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportrxgainphdata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportrxgainphdata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxgainphdata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxgainphdata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportrxgainphdata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportrxgainphdata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportrxnoisefigdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportrxnoisefigdata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportrxnoisefigdata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxnoisefigdata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxnoisefigdata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportrxnoisefigdata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportrxnoisefigdata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportrxifstagedata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportrxifstagedata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportrxifstagedata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxifstagedata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxifstagedata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportrxifstagedata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportrxifstagedata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportrxintanasigdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportrxintanasigdata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportrxintanasigdata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxintanasigdata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxintanasigdata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportrxintanasigdata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportrxintanasigdata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportpmclklointanasigdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportpmclklointanasigdata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportpmclklointanasigdata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportpmclklointanasigdata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportpmclklointanasigdata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportpmclklointanasigdata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportpmclklointanasigdata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportgpadcintanasigdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportgpadcintanasigdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportpllconvoltdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportpllconvoltdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportdccclkfreqdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportdccclkfreqdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportsynthfreqnonlivedata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportsynthfreqnonlivedata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportrxmixrinpwrdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportrxmixrinpwrdata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportrxmixrinpwrdata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportrxmixrinpwrdata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportrxmixrinpwrdata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportrxmixrinpwrdata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportrxmixrinpwrdata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reporttxintanasigdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reporttxintanasigdata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reporttxintanasigdata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxintanasigdata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxintanasigdata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reporttxintanasigdata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reporttxintanasigdata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportextanasigdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportextanasigdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportsynthfreqdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportsynthfreqdata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reportsynthfreqdata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reportsynthfreqdata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reportsynthfreqdata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reportsynthfreqdata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reportsynthfreqdata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reporttxphshiftdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reporttxphshiftdata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reporttxphshiftdata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxphshiftdata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxphshiftdata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reporttxphshiftdata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reporttxphshiftdata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reporttxgainphamisdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reporttxgainphamisdata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reporttxgainphamisdata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxgainphamisdata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxgainphamisdata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reporttxgainphamisdata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reporttxgainphamisdata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reporttxballbreakdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reporttxballbreakdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reporttxpowdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reporttxpowdata),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__size_function__RfStatus__reporttxpowdata,  // size() function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_const_function__RfStatus__reporttxpowdata,  // get_const(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__get_function__RfStatus__reporttxpowdata,  // get(index) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__fetch_function__RfStatus__reporttxpowdata,  // fetch(index, &value) function pointer
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__assign_function__RfStatus__reporttxpowdata,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportrecvdgpadcdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportrecvdgpadcdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reportanalogfaultdata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reportanalogfaultdata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reporttimingerrordata",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__RfStatus, reporttimingerrordata),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_members = {
  "radar_msgs__msg",  // message namespace
  "RfStatus",  // message name
  27,  // number of fields
  sizeof(radar_msgs__msg__RfStatus),
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array,  // message members
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_init_function,  // function to initialize message memory (memory has to be allocated)
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_type_support_handle = {
  0,
  &radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_radar_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RfStatus)() {
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlDigLatentFaultReportData)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonReportHdrData)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[5].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonTempReportData)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[6].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlDigPeriodicReportData)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[7].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonRxGainPhRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[8].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonRxNoiseFigRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[9].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonRxIfStageRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[10].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonRxIntAnaSigRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[11].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonPmclkloIntAnaSigRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[12].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonGpadcIntAnaSigRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[13].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonPllConVoltRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[14].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonDccClkFreqRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[15].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonSynthFreqNonLiveRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[16].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonRxMixrInPwrRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[17].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonTxIntAnaSigRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[18].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonExtAnaSigRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[19].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonSynthFreqRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[20].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonTxPhShiftRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[21].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonTxGainPhaMisRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[22].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonTxBallBreakRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[23].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlMonTxPowRep)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[24].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlRecvdGpAdcData)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[25].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlAnalogFaultReportData)();
  radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_member_array[26].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, RlCalMonTimingErrorReportData)();
  if (!radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_type_support_handle.typesupport_identifier) {
    radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &radar_msgs__msg__RfStatus__rosidl_typesupport_introspection_c__RfStatus_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
