// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__SYSTEM_STATE_NEW_HPP_
#define RADAR_MSGS__MSG__SYSTEM_STATE_NEW_HPP_

#include "radar_msgs/msg/detail/system_state_new__struct.hpp"
#include "radar_msgs/msg/detail/system_state_new__builder.hpp"
#include "radar_msgs/msg/detail/system_state_new__traits.hpp"

#endif  // RADAR_MSGS__MSG__SYSTEM_STATE_NEW_HPP_
