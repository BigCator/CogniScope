// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/ChassisMsg.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__ChassisMsg __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__ChassisMsg __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ChassisMsg_
{
  using Type = ChassisMsg_<ContainerAllocator>;

  explicit ChassisMsg_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->islessinfo = false;
      this->reserved = 0;
      this->vehdynyawratehsc2 = 0.0f;
      this->vehdynyawratevhsc2 = 0.0f;
      this->trshftlvrpos_h1hsc2 = 0l;
      this->trshftlvrposv_h1hsc2 = 0l;
      this->vehspdavgdrvnhsc2 = 0.0f;
      this->vehspdavgdrvnvhsc2 = 0l;
      this->vehspdavgnondrvnhsc2 = 0.0f;
      this->vehspdavgnondrvnvhsc2 = 0l;
      this->strgwhlanghsc2 = 0.0f;
      this->strgwhlangvhsc2 = 0l;
      this->ncounter = 0;
      this->itimestamp = 0ll;
      this->flatitude = 0.0;
      this->flongitude = 0.0;
      this->faltitude = 0.0f;
      this->faccx = 0.0f;
      this->faccy = 0.0f;
      this->faccz = 0.0f;
      this->fangratex = 0.0f;
      this->fangratey = 0.0f;
      this->fangratez = 0.0f;
      this->fvelnorth = 0.0f;
      this->fvelwest = 0.0f;
      this->fvelup = 0.0f;
      this->fheading = 0.0f;
      this->fpitch = 0.0f;
      this->froll = 0.0f;
      this->nnavstatus = 0;
      this->vtimestamp = 0ll;
      this->fsteeringangle = 0.0f;
      this->fspeed = 0.0f;
      this->fyawrate = 0.0f;
      this->ffrontleftwheelspeed = 0.0f;
      this->ffrontrightwheelspeed = 0.0f;
      this->frearleftwheelspeed = 0.0f;
      this->frearrightwheelspeed = 0.0f;
      this->nshifterposition = 0;
      this->nleftdirectionlamp = 0;
      this->nrightdirectionlamp = 0;
      this->nmainbeamlamp = 0;
      this->ndippedbeamlamp = 0;
      this->nwiperstate = 0;
      this->flateralaccel = 0.0f;
      this->flongituaccel = 0.0f;
      this->nleftdrivenwheelpulsecounters = 0;
      this->nrightdrivenwheelpulsecounters = 0;
      this->nleftnondrivenwheelpulsecounters = 0;
      this->nrightnondrivenwheelpulsecounters = 0;
      this->ndrivemode = 0;
    }
  }

  explicit ChassisMsg_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->islessinfo = false;
      this->reserved = 0;
      this->vehdynyawratehsc2 = 0.0f;
      this->vehdynyawratevhsc2 = 0.0f;
      this->trshftlvrpos_h1hsc2 = 0l;
      this->trshftlvrposv_h1hsc2 = 0l;
      this->vehspdavgdrvnhsc2 = 0.0f;
      this->vehspdavgdrvnvhsc2 = 0l;
      this->vehspdavgnondrvnhsc2 = 0.0f;
      this->vehspdavgnondrvnvhsc2 = 0l;
      this->strgwhlanghsc2 = 0.0f;
      this->strgwhlangvhsc2 = 0l;
      this->ncounter = 0;
      this->itimestamp = 0ll;
      this->flatitude = 0.0;
      this->flongitude = 0.0;
      this->faltitude = 0.0f;
      this->faccx = 0.0f;
      this->faccy = 0.0f;
      this->faccz = 0.0f;
      this->fangratex = 0.0f;
      this->fangratey = 0.0f;
      this->fangratez = 0.0f;
      this->fvelnorth = 0.0f;
      this->fvelwest = 0.0f;
      this->fvelup = 0.0f;
      this->fheading = 0.0f;
      this->fpitch = 0.0f;
      this->froll = 0.0f;
      this->nnavstatus = 0;
      this->vtimestamp = 0ll;
      this->fsteeringangle = 0.0f;
      this->fspeed = 0.0f;
      this->fyawrate = 0.0f;
      this->ffrontleftwheelspeed = 0.0f;
      this->ffrontrightwheelspeed = 0.0f;
      this->frearleftwheelspeed = 0.0f;
      this->frearrightwheelspeed = 0.0f;
      this->nshifterposition = 0;
      this->nleftdirectionlamp = 0;
      this->nrightdirectionlamp = 0;
      this->nmainbeamlamp = 0;
      this->ndippedbeamlamp = 0;
      this->nwiperstate = 0;
      this->flateralaccel = 0.0f;
      this->flongituaccel = 0.0f;
      this->nleftdrivenwheelpulsecounters = 0;
      this->nrightdrivenwheelpulsecounters = 0;
      this->nleftnondrivenwheelpulsecounters = 0;
      this->nrightnondrivenwheelpulsecounters = 0;
      this->ndrivemode = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _islessinfo_type =
    bool;
  _islessinfo_type islessinfo;
  using _reserved_type =
    uint8_t;
  _reserved_type reserved;
  using _vehdynyawratehsc2_type =
    float;
  _vehdynyawratehsc2_type vehdynyawratehsc2;
  using _vehdynyawratevhsc2_type =
    float;
  _vehdynyawratevhsc2_type vehdynyawratevhsc2;
  using _trshftlvrpos_h1hsc2_type =
    int32_t;
  _trshftlvrpos_h1hsc2_type trshftlvrpos_h1hsc2;
  using _trshftlvrposv_h1hsc2_type =
    int32_t;
  _trshftlvrposv_h1hsc2_type trshftlvrposv_h1hsc2;
  using _vehspdavgdrvnhsc2_type =
    float;
  _vehspdavgdrvnhsc2_type vehspdavgdrvnhsc2;
  using _vehspdavgdrvnvhsc2_type =
    int32_t;
  _vehspdavgdrvnvhsc2_type vehspdavgdrvnvhsc2;
  using _vehspdavgnondrvnhsc2_type =
    float;
  _vehspdavgnondrvnhsc2_type vehspdavgnondrvnhsc2;
  using _vehspdavgnondrvnvhsc2_type =
    int32_t;
  _vehspdavgnondrvnvhsc2_type vehspdavgnondrvnvhsc2;
  using _strgwhlanghsc2_type =
    float;
  _strgwhlanghsc2_type strgwhlanghsc2;
  using _strgwhlangvhsc2_type =
    int32_t;
  _strgwhlangvhsc2_type strgwhlangvhsc2;
  using _ncounter_type =
    int16_t;
  _ncounter_type ncounter;
  using _itimestamp_type =
    int64_t;
  _itimestamp_type itimestamp;
  using _flatitude_type =
    double;
  _flatitude_type flatitude;
  using _flongitude_type =
    double;
  _flongitude_type flongitude;
  using _faltitude_type =
    float;
  _faltitude_type faltitude;
  using _faccx_type =
    float;
  _faccx_type faccx;
  using _faccy_type =
    float;
  _faccy_type faccy;
  using _faccz_type =
    float;
  _faccz_type faccz;
  using _fangratex_type =
    float;
  _fangratex_type fangratex;
  using _fangratey_type =
    float;
  _fangratey_type fangratey;
  using _fangratez_type =
    float;
  _fangratez_type fangratez;
  using _fvelnorth_type =
    float;
  _fvelnorth_type fvelnorth;
  using _fvelwest_type =
    float;
  _fvelwest_type fvelwest;
  using _fvelup_type =
    float;
  _fvelup_type fvelup;
  using _fheading_type =
    float;
  _fheading_type fheading;
  using _fpitch_type =
    float;
  _fpitch_type fpitch;
  using _froll_type =
    float;
  _froll_type froll;
  using _nnavstatus_type =
    int8_t;
  _nnavstatus_type nnavstatus;
  using _vtimestamp_type =
    int64_t;
  _vtimestamp_type vtimestamp;
  using _fsteeringangle_type =
    float;
  _fsteeringangle_type fsteeringangle;
  using _fspeed_type =
    float;
  _fspeed_type fspeed;
  using _fyawrate_type =
    float;
  _fyawrate_type fyawrate;
  using _ffrontleftwheelspeed_type =
    float;
  _ffrontleftwheelspeed_type ffrontleftwheelspeed;
  using _ffrontrightwheelspeed_type =
    float;
  _ffrontrightwheelspeed_type ffrontrightwheelspeed;
  using _frearleftwheelspeed_type =
    float;
  _frearleftwheelspeed_type frearleftwheelspeed;
  using _frearrightwheelspeed_type =
    float;
  _frearrightwheelspeed_type frearrightwheelspeed;
  using _nshifterposition_type =
    uint8_t;
  _nshifterposition_type nshifterposition;
  using _nleftdirectionlamp_type =
    uint8_t;
  _nleftdirectionlamp_type nleftdirectionlamp;
  using _nrightdirectionlamp_type =
    uint8_t;
  _nrightdirectionlamp_type nrightdirectionlamp;
  using _nmainbeamlamp_type =
    uint8_t;
  _nmainbeamlamp_type nmainbeamlamp;
  using _ndippedbeamlamp_type =
    uint8_t;
  _ndippedbeamlamp_type ndippedbeamlamp;
  using _nwiperstate_type =
    uint8_t;
  _nwiperstate_type nwiperstate;
  using _flateralaccel_type =
    float;
  _flateralaccel_type flateralaccel;
  using _flongituaccel_type =
    float;
  _flongituaccel_type flongituaccel;
  using _nleftdrivenwheelpulsecounters_type =
    int16_t;
  _nleftdrivenwheelpulsecounters_type nleftdrivenwheelpulsecounters;
  using _nrightdrivenwheelpulsecounters_type =
    int16_t;
  _nrightdrivenwheelpulsecounters_type nrightdrivenwheelpulsecounters;
  using _nleftnondrivenwheelpulsecounters_type =
    int16_t;
  _nleftnondrivenwheelpulsecounters_type nleftnondrivenwheelpulsecounters;
  using _nrightnondrivenwheelpulsecounters_type =
    int16_t;
  _nrightnondrivenwheelpulsecounters_type nrightnondrivenwheelpulsecounters;
  using _ndrivemode_type =
    uint8_t;
  _ndrivemode_type ndrivemode;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__islessinfo(
    const bool & _arg)
  {
    this->islessinfo = _arg;
    return *this;
  }
  Type & set__reserved(
    const uint8_t & _arg)
  {
    this->reserved = _arg;
    return *this;
  }
  Type & set__vehdynyawratehsc2(
    const float & _arg)
  {
    this->vehdynyawratehsc2 = _arg;
    return *this;
  }
  Type & set__vehdynyawratevhsc2(
    const float & _arg)
  {
    this->vehdynyawratevhsc2 = _arg;
    return *this;
  }
  Type & set__trshftlvrpos_h1hsc2(
    const int32_t & _arg)
  {
    this->trshftlvrpos_h1hsc2 = _arg;
    return *this;
  }
  Type & set__trshftlvrposv_h1hsc2(
    const int32_t & _arg)
  {
    this->trshftlvrposv_h1hsc2 = _arg;
    return *this;
  }
  Type & set__vehspdavgdrvnhsc2(
    const float & _arg)
  {
    this->vehspdavgdrvnhsc2 = _arg;
    return *this;
  }
  Type & set__vehspdavgdrvnvhsc2(
    const int32_t & _arg)
  {
    this->vehspdavgdrvnvhsc2 = _arg;
    return *this;
  }
  Type & set__vehspdavgnondrvnhsc2(
    const float & _arg)
  {
    this->vehspdavgnondrvnhsc2 = _arg;
    return *this;
  }
  Type & set__vehspdavgnondrvnvhsc2(
    const int32_t & _arg)
  {
    this->vehspdavgnondrvnvhsc2 = _arg;
    return *this;
  }
  Type & set__strgwhlanghsc2(
    const float & _arg)
  {
    this->strgwhlanghsc2 = _arg;
    return *this;
  }
  Type & set__strgwhlangvhsc2(
    const int32_t & _arg)
  {
    this->strgwhlangvhsc2 = _arg;
    return *this;
  }
  Type & set__ncounter(
    const int16_t & _arg)
  {
    this->ncounter = _arg;
    return *this;
  }
  Type & set__itimestamp(
    const int64_t & _arg)
  {
    this->itimestamp = _arg;
    return *this;
  }
  Type & set__flatitude(
    const double & _arg)
  {
    this->flatitude = _arg;
    return *this;
  }
  Type & set__flongitude(
    const double & _arg)
  {
    this->flongitude = _arg;
    return *this;
  }
  Type & set__faltitude(
    const float & _arg)
  {
    this->faltitude = _arg;
    return *this;
  }
  Type & set__faccx(
    const float & _arg)
  {
    this->faccx = _arg;
    return *this;
  }
  Type & set__faccy(
    const float & _arg)
  {
    this->faccy = _arg;
    return *this;
  }
  Type & set__faccz(
    const float & _arg)
  {
    this->faccz = _arg;
    return *this;
  }
  Type & set__fangratex(
    const float & _arg)
  {
    this->fangratex = _arg;
    return *this;
  }
  Type & set__fangratey(
    const float & _arg)
  {
    this->fangratey = _arg;
    return *this;
  }
  Type & set__fangratez(
    const float & _arg)
  {
    this->fangratez = _arg;
    return *this;
  }
  Type & set__fvelnorth(
    const float & _arg)
  {
    this->fvelnorth = _arg;
    return *this;
  }
  Type & set__fvelwest(
    const float & _arg)
  {
    this->fvelwest = _arg;
    return *this;
  }
  Type & set__fvelup(
    const float & _arg)
  {
    this->fvelup = _arg;
    return *this;
  }
  Type & set__fheading(
    const float & _arg)
  {
    this->fheading = _arg;
    return *this;
  }
  Type & set__fpitch(
    const float & _arg)
  {
    this->fpitch = _arg;
    return *this;
  }
  Type & set__froll(
    const float & _arg)
  {
    this->froll = _arg;
    return *this;
  }
  Type & set__nnavstatus(
    const int8_t & _arg)
  {
    this->nnavstatus = _arg;
    return *this;
  }
  Type & set__vtimestamp(
    const int64_t & _arg)
  {
    this->vtimestamp = _arg;
    return *this;
  }
  Type & set__fsteeringangle(
    const float & _arg)
  {
    this->fsteeringangle = _arg;
    return *this;
  }
  Type & set__fspeed(
    const float & _arg)
  {
    this->fspeed = _arg;
    return *this;
  }
  Type & set__fyawrate(
    const float & _arg)
  {
    this->fyawrate = _arg;
    return *this;
  }
  Type & set__ffrontleftwheelspeed(
    const float & _arg)
  {
    this->ffrontleftwheelspeed = _arg;
    return *this;
  }
  Type & set__ffrontrightwheelspeed(
    const float & _arg)
  {
    this->ffrontrightwheelspeed = _arg;
    return *this;
  }
  Type & set__frearleftwheelspeed(
    const float & _arg)
  {
    this->frearleftwheelspeed = _arg;
    return *this;
  }
  Type & set__frearrightwheelspeed(
    const float & _arg)
  {
    this->frearrightwheelspeed = _arg;
    return *this;
  }
  Type & set__nshifterposition(
    const uint8_t & _arg)
  {
    this->nshifterposition = _arg;
    return *this;
  }
  Type & set__nleftdirectionlamp(
    const uint8_t & _arg)
  {
    this->nleftdirectionlamp = _arg;
    return *this;
  }
  Type & set__nrightdirectionlamp(
    const uint8_t & _arg)
  {
    this->nrightdirectionlamp = _arg;
    return *this;
  }
  Type & set__nmainbeamlamp(
    const uint8_t & _arg)
  {
    this->nmainbeamlamp = _arg;
    return *this;
  }
  Type & set__ndippedbeamlamp(
    const uint8_t & _arg)
  {
    this->ndippedbeamlamp = _arg;
    return *this;
  }
  Type & set__nwiperstate(
    const uint8_t & _arg)
  {
    this->nwiperstate = _arg;
    return *this;
  }
  Type & set__flateralaccel(
    const float & _arg)
  {
    this->flateralaccel = _arg;
    return *this;
  }
  Type & set__flongituaccel(
    const float & _arg)
  {
    this->flongituaccel = _arg;
    return *this;
  }
  Type & set__nleftdrivenwheelpulsecounters(
    const int16_t & _arg)
  {
    this->nleftdrivenwheelpulsecounters = _arg;
    return *this;
  }
  Type & set__nrightdrivenwheelpulsecounters(
    const int16_t & _arg)
  {
    this->nrightdrivenwheelpulsecounters = _arg;
    return *this;
  }
  Type & set__nleftnondrivenwheelpulsecounters(
    const int16_t & _arg)
  {
    this->nleftnondrivenwheelpulsecounters = _arg;
    return *this;
  }
  Type & set__nrightnondrivenwheelpulsecounters(
    const int16_t & _arg)
  {
    this->nrightnondrivenwheelpulsecounters = _arg;
    return *this;
  }
  Type & set__ndrivemode(
    const uint8_t & _arg)
  {
    this->ndrivemode = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::ChassisMsg_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::ChassisMsg_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::ChassisMsg_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::ChassisMsg_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::ChassisMsg_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::ChassisMsg_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::ChassisMsg_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::ChassisMsg_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::ChassisMsg_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::ChassisMsg_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__ChassisMsg
    std::shared_ptr<radar_msgs::msg::ChassisMsg_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__ChassisMsg
    std::shared_ptr<radar_msgs::msg::ChassisMsg_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ChassisMsg_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->islessinfo != other.islessinfo) {
      return false;
    }
    if (this->reserved != other.reserved) {
      return false;
    }
    if (this->vehdynyawratehsc2 != other.vehdynyawratehsc2) {
      return false;
    }
    if (this->vehdynyawratevhsc2 != other.vehdynyawratevhsc2) {
      return false;
    }
    if (this->trshftlvrpos_h1hsc2 != other.trshftlvrpos_h1hsc2) {
      return false;
    }
    if (this->trshftlvrposv_h1hsc2 != other.trshftlvrposv_h1hsc2) {
      return false;
    }
    if (this->vehspdavgdrvnhsc2 != other.vehspdavgdrvnhsc2) {
      return false;
    }
    if (this->vehspdavgdrvnvhsc2 != other.vehspdavgdrvnvhsc2) {
      return false;
    }
    if (this->vehspdavgnondrvnhsc2 != other.vehspdavgnondrvnhsc2) {
      return false;
    }
    if (this->vehspdavgnondrvnvhsc2 != other.vehspdavgnondrvnvhsc2) {
      return false;
    }
    if (this->strgwhlanghsc2 != other.strgwhlanghsc2) {
      return false;
    }
    if (this->strgwhlangvhsc2 != other.strgwhlangvhsc2) {
      return false;
    }
    if (this->ncounter != other.ncounter) {
      return false;
    }
    if (this->itimestamp != other.itimestamp) {
      return false;
    }
    if (this->flatitude != other.flatitude) {
      return false;
    }
    if (this->flongitude != other.flongitude) {
      return false;
    }
    if (this->faltitude != other.faltitude) {
      return false;
    }
    if (this->faccx != other.faccx) {
      return false;
    }
    if (this->faccy != other.faccy) {
      return false;
    }
    if (this->faccz != other.faccz) {
      return false;
    }
    if (this->fangratex != other.fangratex) {
      return false;
    }
    if (this->fangratey != other.fangratey) {
      return false;
    }
    if (this->fangratez != other.fangratez) {
      return false;
    }
    if (this->fvelnorth != other.fvelnorth) {
      return false;
    }
    if (this->fvelwest != other.fvelwest) {
      return false;
    }
    if (this->fvelup != other.fvelup) {
      return false;
    }
    if (this->fheading != other.fheading) {
      return false;
    }
    if (this->fpitch != other.fpitch) {
      return false;
    }
    if (this->froll != other.froll) {
      return false;
    }
    if (this->nnavstatus != other.nnavstatus) {
      return false;
    }
    if (this->vtimestamp != other.vtimestamp) {
      return false;
    }
    if (this->fsteeringangle != other.fsteeringangle) {
      return false;
    }
    if (this->fspeed != other.fspeed) {
      return false;
    }
    if (this->fyawrate != other.fyawrate) {
      return false;
    }
    if (this->ffrontleftwheelspeed != other.ffrontleftwheelspeed) {
      return false;
    }
    if (this->ffrontrightwheelspeed != other.ffrontrightwheelspeed) {
      return false;
    }
    if (this->frearleftwheelspeed != other.frearleftwheelspeed) {
      return false;
    }
    if (this->frearrightwheelspeed != other.frearrightwheelspeed) {
      return false;
    }
    if (this->nshifterposition != other.nshifterposition) {
      return false;
    }
    if (this->nleftdirectionlamp != other.nleftdirectionlamp) {
      return false;
    }
    if (this->nrightdirectionlamp != other.nrightdirectionlamp) {
      return false;
    }
    if (this->nmainbeamlamp != other.nmainbeamlamp) {
      return false;
    }
    if (this->ndippedbeamlamp != other.ndippedbeamlamp) {
      return false;
    }
    if (this->nwiperstate != other.nwiperstate) {
      return false;
    }
    if (this->flateralaccel != other.flateralaccel) {
      return false;
    }
    if (this->flongituaccel != other.flongituaccel) {
      return false;
    }
    if (this->nleftdrivenwheelpulsecounters != other.nleftdrivenwheelpulsecounters) {
      return false;
    }
    if (this->nrightdrivenwheelpulsecounters != other.nrightdrivenwheelpulsecounters) {
      return false;
    }
    if (this->nleftnondrivenwheelpulsecounters != other.nleftnondrivenwheelpulsecounters) {
      return false;
    }
    if (this->nrightnondrivenwheelpulsecounters != other.nrightnondrivenwheelpulsecounters) {
      return false;
    }
    if (this->ndrivemode != other.ndrivemode) {
      return false;
    }
    return true;
  }
  bool operator!=(const ChassisMsg_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ChassisMsg_

// alias to use template instance with default allocator
using ChassisMsg =
  radar_msgs::msg::ChassisMsg_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__STRUCT_HPP_
