// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RdInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RD_INFO__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RD_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rd_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RdInfo_jamstatusprofile1
{
public:
  explicit Init_RdInfo_jamstatusprofile1(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RdInfo jamstatusprofile1(::radar_msgs::msg::RdInfo::_jamstatusprofile1_type arg)
  {
    msg_.jamstatusprofile1 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_jamstatusprofile0
{
public:
  explicit Init_RdInfo_jamstatusprofile0(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_jamstatusprofile1 jamstatusprofile0(::radar_msgs::msg::RdInfo::_jamstatusprofile0_type arg)
  {
    msg_.jamstatusprofile0 = std::move(arg);
    return Init_RdInfo_jamstatusprofile1(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_rdframelostcnt
{
public:
  explicit Init_RdInfo_rdframelostcnt(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_jamstatusprofile0 rdframelostcnt(::radar_msgs::msg::RdInfo::_rdframelostcnt_type arg)
  {
    msg_.rdframelostcnt = std::move(arg);
    return Init_RdInfo_jamstatusprofile0(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_od_time
{
public:
  explicit Init_RdInfo_od_time(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_rdframelostcnt od_time(::radar_msgs::msg::RdInfo::_od_time_type arg)
  {
    msg_.od_time = std::move(arg);
    return Init_RdInfo_rdframelostcnt(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_pcl_time
{
public:
  explicit Init_RdInfo_pcl_time(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_od_time pcl_time(::radar_msgs::msg::RdInfo::_pcl_time_type arg)
  {
    msg_.pcl_time = std::move(arg);
    return Init_RdInfo_od_time(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_gndb
{
public:
  explicit Init_RdInfo_gndb(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_pcl_time gndb(::radar_msgs::msg::RdInfo::_gndb_type arg)
  {
    msg_.gndb = std::move(arg);
    return Init_RdInfo_pcl_time(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_gndk
{
public:
  explicit Init_RdInfo_gndk(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_gndb gndk(::radar_msgs::msg::RdInfo::_gndk_type arg)
  {
    msg_.gndk = std::move(arg);
    return Init_RdInfo_gndb(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_velestimate
{
public:
  explicit Init_RdInfo_velestimate(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_gndk velestimate(::radar_msgs::msg::RdInfo::_velestimate_type arg)
  {
    msg_.velestimate = std::move(arg);
    return Init_RdInfo_gndk(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_timesyncstatus
{
public:
  explicit Init_RdInfo_timesyncstatus(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_velestimate timesyncstatus(::radar_msgs::msg::RdInfo::_timesyncstatus_type arg)
  {
    msg_.timesyncstatus = std::move(arg);
    return Init_RdInfo_velestimate(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_udpfreq
{
public:
  explicit Init_RdInfo_udpfreq(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_timesyncstatus udpfreq(::radar_msgs::msg::RdInfo::_udpfreq_type arg)
  {
    msg_.udpfreq = std::move(arg);
    return Init_RdInfo_timesyncstatus(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_udpframelostcnt
{
public:
  explicit Init_RdInfo_udpframelostcnt(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_udpfreq udpframelostcnt(::radar_msgs::msg::RdInfo::_udpframelostcnt_type arg)
  {
    msg_.udpframelostcnt = std::move(arg);
    return Init_RdInfo_udpfreq(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_afteradcerrcnt
{
public:
  explicit Init_RdInfo_afteradcerrcnt(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_udpframelostcnt afteradcerrcnt(::radar_msgs::msg::RdInfo::_afteradcerrcnt_type arg)
  {
    msg_.afteradcerrcnt = std::move(arg);
    return Init_RdInfo_udpframelostcnt(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_beforeadcerrcnt
{
public:
  explicit Init_RdInfo_beforeadcerrcnt(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_afteradcerrcnt beforeadcerrcnt(::radar_msgs::msg::RdInfo::_beforeadcerrcnt_type arg)
  {
    msg_.beforeadcerrcnt = std::move(arg);
    return Init_RdInfo_afteradcerrcnt(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_framelostcnt
{
public:
  explicit Init_RdInfo_framelostcnt(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_beforeadcerrcnt framelostcnt(::radar_msgs::msg::RdInfo::_framelostcnt_type arg)
  {
    msg_.framelostcnt = std::move(arg);
    return Init_RdInfo_beforeadcerrcnt(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_comprotv_ii
{
public:
  explicit Init_RdInfo_comprotv_ii(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_framelostcnt comprotv_ii(::radar_msgs::msg::RdInfo::_comprotv_ii_type arg)
  {
    msg_.comprotv_ii = std::move(arg);
    return Init_RdInfo_framelostcnt(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_comprotv_i
{
public:
  explicit Init_RdInfo_comprotv_i(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_comprotv_ii comprotv_i(::radar_msgs::msg::RdInfo::_comprotv_i_type arg)
  {
    msg_.comprotv_i = std::move(arg);
    return Init_RdInfo_comprotv_ii(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_odtimeoutcnt
{
public:
  explicit Init_RdInfo_odtimeoutcnt(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_comprotv_i odtimeoutcnt(::radar_msgs::msg::RdInfo::_odtimeoutcnt_type arg)
  {
    msg_.odtimeoutcnt = std::move(arg);
    return Init_RdInfo_comprotv_i(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_gearstate
{
public:
  explicit Init_RdInfo_gearstate(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_odtimeoutcnt gearstate(::radar_msgs::msg::RdInfo::_gearstate_type arg)
  {
    msg_.gearstate = std::move(arg);
    return Init_RdInfo_odtimeoutcnt(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_caryawrate
{
public:
  explicit Init_RdInfo_caryawrate(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_gearstate caryawrate(::radar_msgs::msg::RdInfo::_caryawrate_type arg)
  {
    msg_.caryawrate = std::move(arg);
    return Init_RdInfo_gearstate(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_carspeed
{
public:
  explicit Init_RdInfo_carspeed(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_caryawrate carspeed(::radar_msgs::msg::RdInfo::_carspeed_type arg)
  {
    msg_.carspeed = std::move(arg);
    return Init_RdInfo_caryawrate(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_objnum
{
public:
  explicit Init_RdInfo_objnum(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_carspeed objnum(::radar_msgs::msg::RdInfo::_objnum_type arg)
  {
    msg_.objnum = std::move(arg);
    return Init_RdInfo_carspeed(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_resetcnt
{
public:
  explicit Init_RdInfo_resetcnt(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_objnum resetcnt(::radar_msgs::msg::RdInfo::_resetcnt_type arg)
  {
    msg_.resetcnt = std::move(arg);
    return Init_RdInfo_objnum(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_targetnum
{
public:
  explicit Init_RdInfo_targetnum(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_resetcnt targetnum(::radar_msgs::msg::RdInfo::_targetnum_type arg)
  {
    msg_.targetnum = std::move(arg);
    return Init_RdInfo_resetcnt(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_cfarcount
{
public:
  explicit Init_RdInfo_cfarcount(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_targetnum cfarcount(::radar_msgs::msg::RdInfo::_cfarcount_type arg)
  {
    msg_.cfarcount = std::move(arg);
    return Init_RdInfo_targetnum(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_frameid
{
public:
  explicit Init_RdInfo_frameid(::radar_msgs::msg::RdInfo & msg)
  : msg_(msg)
  {}
  Init_RdInfo_cfarcount frameid(::radar_msgs::msg::RdInfo::_frameid_type arg)
  {
    msg_.frameid = std::move(arg);
    return Init_RdInfo_cfarcount(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

class Init_RdInfo_header
{
public:
  Init_RdInfo_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RdInfo_frameid header(::radar_msgs::msg::RdInfo::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_RdInfo_frameid(msg_);
  }

private:
  ::radar_msgs::msg::RdInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RdInfo>()
{
  return radar_msgs::msg::builder::Init_RdInfo_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RD_INFO__BUILDER_HPP_
