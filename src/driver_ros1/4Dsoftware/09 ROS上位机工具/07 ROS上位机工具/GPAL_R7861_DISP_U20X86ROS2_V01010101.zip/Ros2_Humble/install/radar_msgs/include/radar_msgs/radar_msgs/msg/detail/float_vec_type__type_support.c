// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from radar_msgs:msg/FloatVecType.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "radar_msgs/msg/detail/float_vec_type__rosidl_typesupport_introspection_c.h"
#include "radar_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "radar_msgs/msg/detail/float_vec_type__functions.h"
#include "radar_msgs/msg/detail/float_vec_type__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `cfar_obj`
// Member `data`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  radar_msgs__msg__FloatVecType__init(message_memory);
}

void radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_fini_function(void * message_memory)
{
  radar_msgs__msg__FloatVecType__fini(message_memory);
}

size_t radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__size_function__FloatVecType__cfar_obj(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_const_function__FloatVecType__cfar_obj(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_function__FloatVecType__cfar_obj(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__fetch_function__FloatVecType__cfar_obj(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_const_function__FloatVecType__cfar_obj(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__assign_function__FloatVecType__cfar_obj(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_function__FloatVecType__cfar_obj(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__resize_function__FloatVecType__cfar_obj(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__size_function__FloatVecType__data(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_const_function__FloatVecType__data(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_function__FloatVecType__data(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__fetch_function__FloatVecType__data(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_const_function__FloatVecType__data(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__assign_function__FloatVecType__data(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_function__FloatVecType__data(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__resize_function__FloatVecType__data(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_message_member_array[7] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__FloatVecType, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "width",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__FloatVecType, width),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "height",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__FloatVecType, height),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "frame_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__FloatVecType, frame_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "cfar_count",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__FloatVecType, cfar_count),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "cfar_obj",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__FloatVecType, cfar_obj),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__size_function__FloatVecType__cfar_obj,  // size() function pointer
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_const_function__FloatVecType__cfar_obj,  // get_const(index) function pointer
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_function__FloatVecType__cfar_obj,  // get(index) function pointer
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__fetch_function__FloatVecType__cfar_obj,  // fetch(index, &value) function pointer
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__assign_function__FloatVecType__cfar_obj,  // assign(index, value) function pointer
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__resize_function__FloatVecType__cfar_obj  // resize(index) function pointer
  },
  {
    "data",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs__msg__FloatVecType, data),  // bytes offset in struct
    NULL,  // default value
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__size_function__FloatVecType__data,  // size() function pointer
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_const_function__FloatVecType__data,  // get_const(index) function pointer
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__get_function__FloatVecType__data,  // get(index) function pointer
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__fetch_function__FloatVecType__data,  // fetch(index, &value) function pointer
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__assign_function__FloatVecType__data,  // assign(index, value) function pointer
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__resize_function__FloatVecType__data  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_message_members = {
  "radar_msgs__msg",  // message namespace
  "FloatVecType",  // message name
  7,  // number of fields
  sizeof(radar_msgs__msg__FloatVecType),
  radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_message_member_array,  // message members
  radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_init_function,  // function to initialize message memory (memory has to be allocated)
  radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_message_type_support_handle = {
  0,
  &radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_radar_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, radar_msgs, msg, FloatVecType)() {
  radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_message_type_support_handle.typesupport_identifier) {
    radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &radar_msgs__msg__FloatVecType__rosidl_typesupport_introspection_c__FloatVecType_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
