// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlDigPeriodicReportData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_DIG_PERIODIC_REPORT_DATA__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_DIG_PERIODIC_REPORT_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_dig_periodic_report_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlDigPeriodicReportData_timestamp
{
public:
  explicit Init_RlDigPeriodicReportData_timestamp(::radar_msgs::msg::RlDigPeriodicReportData & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlDigPeriodicReportData timestamp(::radar_msgs::msg::RlDigPeriodicReportData::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlDigPeriodicReportData msg_;
};

class Init_RlDigPeriodicReportData_digmonperiodicstatus
{
public:
  Init_RlDigPeriodicReportData_digmonperiodicstatus()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlDigPeriodicReportData_timestamp digmonperiodicstatus(::radar_msgs::msg::RlDigPeriodicReportData::_digmonperiodicstatus_type arg)
  {
    msg_.digmonperiodicstatus = std::move(arg);
    return Init_RlDigPeriodicReportData_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlDigPeriodicReportData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlDigPeriodicReportData>()
{
  return radar_msgs::msg::builder::Init_RlDigPeriodicReportData_digmonperiodicstatus();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_DIG_PERIODIC_REPORT_DATA__BUILDER_HPP_
