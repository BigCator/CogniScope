// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RlMonRxGainPhRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_RX_GAIN_PH_REP__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_RX_GAIN_PH_REP__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RlMonRxGainPhRep __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RlMonRxGainPhRep __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RlMonRxGainPhRep_
{
  using Type = RlMonRxGainPhRep_<ContainerAllocator>;

  explicit RlMonRxGainPhRep_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      this->profindex = 0;
      this->loopbackpowerrf1 = 0;
      this->loopbackpowerrf2 = 0;
      this->loopbackpowerrf3 = 0;
      std::fill<typename std::array<uint16_t, 12>::iterator, uint16_t>(this->rxgainval.begin(), this->rxgainval.end(), 0);
      std::fill<typename std::array<uint16_t, 12>::iterator, uint16_t>(this->rxphaseval.begin(), this->rxphaseval.end(), 0);
      this->rxnoisepower1 = 0ul;
      this->rxnoisepower2 = 0ul;
      this->timestamp = 0ul;
    }
  }

  explicit RlMonRxGainPhRep_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : rxgainval(_alloc),
    rxphaseval(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->statusflags = 0;
      this->errorcode = 0;
      this->profindex = 0;
      this->loopbackpowerrf1 = 0;
      this->loopbackpowerrf2 = 0;
      this->loopbackpowerrf3 = 0;
      std::fill<typename std::array<uint16_t, 12>::iterator, uint16_t>(this->rxgainval.begin(), this->rxgainval.end(), 0);
      std::fill<typename std::array<uint16_t, 12>::iterator, uint16_t>(this->rxphaseval.begin(), this->rxphaseval.end(), 0);
      this->rxnoisepower1 = 0ul;
      this->rxnoisepower2 = 0ul;
      this->timestamp = 0ul;
    }
  }

  // field types and members
  using _statusflags_type =
    uint16_t;
  _statusflags_type statusflags;
  using _errorcode_type =
    uint16_t;
  _errorcode_type errorcode;
  using _profindex_type =
    uint8_t;
  _profindex_type profindex;
  using _loopbackpowerrf1_type =
    uint8_t;
  _loopbackpowerrf1_type loopbackpowerrf1;
  using _loopbackpowerrf2_type =
    uint8_t;
  _loopbackpowerrf2_type loopbackpowerrf2;
  using _loopbackpowerrf3_type =
    uint8_t;
  _loopbackpowerrf3_type loopbackpowerrf3;
  using _rxgainval_type =
    std::array<uint16_t, 12>;
  _rxgainval_type rxgainval;
  using _rxphaseval_type =
    std::array<uint16_t, 12>;
  _rxphaseval_type rxphaseval;
  using _rxnoisepower1_type =
    uint32_t;
  _rxnoisepower1_type rxnoisepower1;
  using _rxnoisepower2_type =
    uint32_t;
  _rxnoisepower2_type rxnoisepower2;
  using _timestamp_type =
    uint32_t;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__statusflags(
    const uint16_t & _arg)
  {
    this->statusflags = _arg;
    return *this;
  }
  Type & set__errorcode(
    const uint16_t & _arg)
  {
    this->errorcode = _arg;
    return *this;
  }
  Type & set__profindex(
    const uint8_t & _arg)
  {
    this->profindex = _arg;
    return *this;
  }
  Type & set__loopbackpowerrf1(
    const uint8_t & _arg)
  {
    this->loopbackpowerrf1 = _arg;
    return *this;
  }
  Type & set__loopbackpowerrf2(
    const uint8_t & _arg)
  {
    this->loopbackpowerrf2 = _arg;
    return *this;
  }
  Type & set__loopbackpowerrf3(
    const uint8_t & _arg)
  {
    this->loopbackpowerrf3 = _arg;
    return *this;
  }
  Type & set__rxgainval(
    const std::array<uint16_t, 12> & _arg)
  {
    this->rxgainval = _arg;
    return *this;
  }
  Type & set__rxphaseval(
    const std::array<uint16_t, 12> & _arg)
  {
    this->rxphaseval = _arg;
    return *this;
  }
  Type & set__rxnoisepower1(
    const uint32_t & _arg)
  {
    this->rxnoisepower1 = _arg;
    return *this;
  }
  Type & set__rxnoisepower2(
    const uint32_t & _arg)
  {
    this->rxnoisepower2 = _arg;
    return *this;
  }
  Type & set__timestamp(
    const uint32_t & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RlMonRxGainPhRep
    std::shared_ptr<radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RlMonRxGainPhRep
    std::shared_ptr<radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RlMonRxGainPhRep_ & other) const
  {
    if (this->statusflags != other.statusflags) {
      return false;
    }
    if (this->errorcode != other.errorcode) {
      return false;
    }
    if (this->profindex != other.profindex) {
      return false;
    }
    if (this->loopbackpowerrf1 != other.loopbackpowerrf1) {
      return false;
    }
    if (this->loopbackpowerrf2 != other.loopbackpowerrf2) {
      return false;
    }
    if (this->loopbackpowerrf3 != other.loopbackpowerrf3) {
      return false;
    }
    if (this->rxgainval != other.rxgainval) {
      return false;
    }
    if (this->rxphaseval != other.rxphaseval) {
      return false;
    }
    if (this->rxnoisepower1 != other.rxnoisepower1) {
      return false;
    }
    if (this->rxnoisepower2 != other.rxnoisepower2) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const RlMonRxGainPhRep_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RlMonRxGainPhRep_

// alias to use template instance with default allocator
using RlMonRxGainPhRep =
  radar_msgs::msg::RlMonRxGainPhRep_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_RX_GAIN_PH_REP__STRUCT_HPP_
