// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/InstallInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__InstallInfo __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__InstallInfo __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct InstallInfo_
{
  using Type = InstallInfo_<ContainerAllocator>;

  explicit InstallInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radar_id = 0ul;
      this->frame_cnt = 0ul;
      this->sensor_positioninvalid_flags = 0;
      this->sensor_xposition = 0.0f;
      this->sensor_yposition = 0.0f;
      this->sensor_zposition = 0.0f;
      this->sensor_rollangle = 0.0f;
      this->sensor_pitchangle = 0.0f;
      this->sensor_yawangle = 0.0f;
      this->azimuth_correction = 0.0f;
      this->elevation_correction = 0.0f;
    }
  }

  explicit InstallInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radar_id = 0ul;
      this->frame_cnt = 0ul;
      this->sensor_positioninvalid_flags = 0;
      this->sensor_xposition = 0.0f;
      this->sensor_yposition = 0.0f;
      this->sensor_zposition = 0.0f;
      this->sensor_rollangle = 0.0f;
      this->sensor_pitchangle = 0.0f;
      this->sensor_yawangle = 0.0f;
      this->azimuth_correction = 0.0f;
      this->elevation_correction = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _radar_id_type =
    uint32_t;
  _radar_id_type radar_id;
  using _frame_cnt_type =
    uint32_t;
  _frame_cnt_type frame_cnt;
  using _sensor_positioninvalid_flags_type =
    uint16_t;
  _sensor_positioninvalid_flags_type sensor_positioninvalid_flags;
  using _sensor_xposition_type =
    float;
  _sensor_xposition_type sensor_xposition;
  using _sensor_yposition_type =
    float;
  _sensor_yposition_type sensor_yposition;
  using _sensor_zposition_type =
    float;
  _sensor_zposition_type sensor_zposition;
  using _sensor_rollangle_type =
    float;
  _sensor_rollangle_type sensor_rollangle;
  using _sensor_pitchangle_type =
    float;
  _sensor_pitchangle_type sensor_pitchangle;
  using _sensor_yawangle_type =
    float;
  _sensor_yawangle_type sensor_yawangle;
  using _azimuth_correction_type =
    float;
  _azimuth_correction_type azimuth_correction;
  using _elevation_correction_type =
    float;
  _elevation_correction_type elevation_correction;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__radar_id(
    const uint32_t & _arg)
  {
    this->radar_id = _arg;
    return *this;
  }
  Type & set__frame_cnt(
    const uint32_t & _arg)
  {
    this->frame_cnt = _arg;
    return *this;
  }
  Type & set__sensor_positioninvalid_flags(
    const uint16_t & _arg)
  {
    this->sensor_positioninvalid_flags = _arg;
    return *this;
  }
  Type & set__sensor_xposition(
    const float & _arg)
  {
    this->sensor_xposition = _arg;
    return *this;
  }
  Type & set__sensor_yposition(
    const float & _arg)
  {
    this->sensor_yposition = _arg;
    return *this;
  }
  Type & set__sensor_zposition(
    const float & _arg)
  {
    this->sensor_zposition = _arg;
    return *this;
  }
  Type & set__sensor_rollangle(
    const float & _arg)
  {
    this->sensor_rollangle = _arg;
    return *this;
  }
  Type & set__sensor_pitchangle(
    const float & _arg)
  {
    this->sensor_pitchangle = _arg;
    return *this;
  }
  Type & set__sensor_yawangle(
    const float & _arg)
  {
    this->sensor_yawangle = _arg;
    return *this;
  }
  Type & set__azimuth_correction(
    const float & _arg)
  {
    this->azimuth_correction = _arg;
    return *this;
  }
  Type & set__elevation_correction(
    const float & _arg)
  {
    this->elevation_correction = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::InstallInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::InstallInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::InstallInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::InstallInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::InstallInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::InstallInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::InstallInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::InstallInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::InstallInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::InstallInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__InstallInfo
    std::shared_ptr<radar_msgs::msg::InstallInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__InstallInfo
    std::shared_ptr<radar_msgs::msg::InstallInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const InstallInfo_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->radar_id != other.radar_id) {
      return false;
    }
    if (this->frame_cnt != other.frame_cnt) {
      return false;
    }
    if (this->sensor_positioninvalid_flags != other.sensor_positioninvalid_flags) {
      return false;
    }
    if (this->sensor_xposition != other.sensor_xposition) {
      return false;
    }
    if (this->sensor_yposition != other.sensor_yposition) {
      return false;
    }
    if (this->sensor_zposition != other.sensor_zposition) {
      return false;
    }
    if (this->sensor_rollangle != other.sensor_rollangle) {
      return false;
    }
    if (this->sensor_pitchangle != other.sensor_pitchangle) {
      return false;
    }
    if (this->sensor_yawangle != other.sensor_yawangle) {
      return false;
    }
    if (this->azimuth_correction != other.azimuth_correction) {
      return false;
    }
    if (this->elevation_correction != other.elevation_correction) {
      return false;
    }
    return true;
  }
  bool operator!=(const InstallInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct InstallInfo_

// alias to use template instance with default allocator
using InstallInfo =
  radar_msgs::msg::InstallInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__STRUCT_HPP_
