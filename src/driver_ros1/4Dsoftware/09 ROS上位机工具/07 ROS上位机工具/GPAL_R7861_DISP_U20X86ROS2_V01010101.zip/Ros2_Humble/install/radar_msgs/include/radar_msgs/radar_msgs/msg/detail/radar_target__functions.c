// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/RadarTarget.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/radar_target__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `x`
// Member `y`
// Member `z`
// Member `v`
// Member `azimuth`
// Member `elevation`
// Member `snr`
// Member `power`
// Member `valid_flg`
// Member `existance_probability`
// Member `motion_state`
// Member `detection_class`
// Member `reset_cnt`
// Member `od_timeout_cnt`
// Member `reserved_a`
// Member `reserved_b`
// Member `reserved_c`
// Member `reserved_d`
// Member `reserved_e`
// Member `reserved_f`
// Member `reserved_g`
// Member `reserved_h`
// Member `reserved_i`
// Member `reserved_j`
// Member `reserved_k`
// Member `reserved_l`
// Member `reserved_m`
// Member `reserved_n`
// Member `reserved_o`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
radar_msgs__msg__RadarTarget__init(radar_msgs__msg__RadarTarget * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // radar_id
  // frame_cnt
  // type
  // target_num
  // polar_state
  // x
  if (!rosidl_runtime_c__float__Sequence__init(&msg->x, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // y
  if (!rosidl_runtime_c__float__Sequence__init(&msg->y, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // z
  if (!rosidl_runtime_c__float__Sequence__init(&msg->z, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // v
  if (!rosidl_runtime_c__float__Sequence__init(&msg->v, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // azimuth
  if (!rosidl_runtime_c__float__Sequence__init(&msg->azimuth, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // elevation
  if (!rosidl_runtime_c__float__Sequence__init(&msg->elevation, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // snr
  if (!rosidl_runtime_c__float__Sequence__init(&msg->snr, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // power
  if (!rosidl_runtime_c__float__Sequence__init(&msg->power, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // valid_flg
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->valid_flg, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // existance_probability
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->existance_probability, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // motion_state
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->motion_state, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // detection_class
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->detection_class, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reset_cnt
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->reset_cnt, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // od_timeout_cnt
  if (!rosidl_runtime_c__int16__Sequence__init(&msg->od_timeout_cnt, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_a
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->reserved_a, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_b
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->reserved_b, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_c
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->reserved_c, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_d
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->reserved_d, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_e
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->reserved_e, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_f
  if (!rosidl_runtime_c__int16__Sequence__init(&msg->reserved_f, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_g
  if (!rosidl_runtime_c__int16__Sequence__init(&msg->reserved_g, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_h
  if (!rosidl_runtime_c__int16__Sequence__init(&msg->reserved_h, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_i
  if (!rosidl_runtime_c__int16__Sequence__init(&msg->reserved_i, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_j
  if (!rosidl_runtime_c__int16__Sequence__init(&msg->reserved_j, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_k
  if (!rosidl_runtime_c__float__Sequence__init(&msg->reserved_k, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_l
  if (!rosidl_runtime_c__float__Sequence__init(&msg->reserved_l, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_m
  if (!rosidl_runtime_c__float__Sequence__init(&msg->reserved_m, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_n
  if (!rosidl_runtime_c__float__Sequence__init(&msg->reserved_n, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  // reserved_o
  if (!rosidl_runtime_c__float__Sequence__init(&msg->reserved_o, 0)) {
    radar_msgs__msg__RadarTarget__fini(msg);
    return false;
  }
  return true;
}

void
radar_msgs__msg__RadarTarget__fini(radar_msgs__msg__RadarTarget * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // radar_id
  // frame_cnt
  // type
  // target_num
  // polar_state
  // x
  rosidl_runtime_c__float__Sequence__fini(&msg->x);
  // y
  rosidl_runtime_c__float__Sequence__fini(&msg->y);
  // z
  rosidl_runtime_c__float__Sequence__fini(&msg->z);
  // v
  rosidl_runtime_c__float__Sequence__fini(&msg->v);
  // azimuth
  rosidl_runtime_c__float__Sequence__fini(&msg->azimuth);
  // elevation
  rosidl_runtime_c__float__Sequence__fini(&msg->elevation);
  // snr
  rosidl_runtime_c__float__Sequence__fini(&msg->snr);
  // power
  rosidl_runtime_c__float__Sequence__fini(&msg->power);
  // valid_flg
  rosidl_runtime_c__uint16__Sequence__fini(&msg->valid_flg);
  // existance_probability
  rosidl_runtime_c__uint16__Sequence__fini(&msg->existance_probability);
  // motion_state
  rosidl_runtime_c__uint16__Sequence__fini(&msg->motion_state);
  // detection_class
  rosidl_runtime_c__uint16__Sequence__fini(&msg->detection_class);
  // reset_cnt
  rosidl_runtime_c__uint16__Sequence__fini(&msg->reset_cnt);
  // od_timeout_cnt
  rosidl_runtime_c__int16__Sequence__fini(&msg->od_timeout_cnt);
  // reserved_a
  rosidl_runtime_c__uint16__Sequence__fini(&msg->reserved_a);
  // reserved_b
  rosidl_runtime_c__uint16__Sequence__fini(&msg->reserved_b);
  // reserved_c
  rosidl_runtime_c__uint16__Sequence__fini(&msg->reserved_c);
  // reserved_d
  rosidl_runtime_c__uint16__Sequence__fini(&msg->reserved_d);
  // reserved_e
  rosidl_runtime_c__uint16__Sequence__fini(&msg->reserved_e);
  // reserved_f
  rosidl_runtime_c__int16__Sequence__fini(&msg->reserved_f);
  // reserved_g
  rosidl_runtime_c__int16__Sequence__fini(&msg->reserved_g);
  // reserved_h
  rosidl_runtime_c__int16__Sequence__fini(&msg->reserved_h);
  // reserved_i
  rosidl_runtime_c__int16__Sequence__fini(&msg->reserved_i);
  // reserved_j
  rosidl_runtime_c__int16__Sequence__fini(&msg->reserved_j);
  // reserved_k
  rosidl_runtime_c__float__Sequence__fini(&msg->reserved_k);
  // reserved_l
  rosidl_runtime_c__float__Sequence__fini(&msg->reserved_l);
  // reserved_m
  rosidl_runtime_c__float__Sequence__fini(&msg->reserved_m);
  // reserved_n
  rosidl_runtime_c__float__Sequence__fini(&msg->reserved_n);
  // reserved_o
  rosidl_runtime_c__float__Sequence__fini(&msg->reserved_o);
}

bool
radar_msgs__msg__RadarTarget__are_equal(const radar_msgs__msg__RadarTarget * lhs, const radar_msgs__msg__RadarTarget * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // radar_id
  if (lhs->radar_id != rhs->radar_id) {
    return false;
  }
  // frame_cnt
  if (lhs->frame_cnt != rhs->frame_cnt) {
    return false;
  }
  // type
  if (lhs->type != rhs->type) {
    return false;
  }
  // target_num
  if (lhs->target_num != rhs->target_num) {
    return false;
  }
  // polar_state
  if (lhs->polar_state != rhs->polar_state) {
    return false;
  }
  // x
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->x), &(rhs->x)))
  {
    return false;
  }
  // y
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->y), &(rhs->y)))
  {
    return false;
  }
  // z
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->z), &(rhs->z)))
  {
    return false;
  }
  // v
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->v), &(rhs->v)))
  {
    return false;
  }
  // azimuth
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->azimuth), &(rhs->azimuth)))
  {
    return false;
  }
  // elevation
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->elevation), &(rhs->elevation)))
  {
    return false;
  }
  // snr
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->snr), &(rhs->snr)))
  {
    return false;
  }
  // power
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->power), &(rhs->power)))
  {
    return false;
  }
  // valid_flg
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->valid_flg), &(rhs->valid_flg)))
  {
    return false;
  }
  // existance_probability
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->existance_probability), &(rhs->existance_probability)))
  {
    return false;
  }
  // motion_state
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->motion_state), &(rhs->motion_state)))
  {
    return false;
  }
  // detection_class
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->detection_class), &(rhs->detection_class)))
  {
    return false;
  }
  // reset_cnt
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->reset_cnt), &(rhs->reset_cnt)))
  {
    return false;
  }
  // od_timeout_cnt
  if (!rosidl_runtime_c__int16__Sequence__are_equal(
      &(lhs->od_timeout_cnt), &(rhs->od_timeout_cnt)))
  {
    return false;
  }
  // reserved_a
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->reserved_a), &(rhs->reserved_a)))
  {
    return false;
  }
  // reserved_b
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->reserved_b), &(rhs->reserved_b)))
  {
    return false;
  }
  // reserved_c
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->reserved_c), &(rhs->reserved_c)))
  {
    return false;
  }
  // reserved_d
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->reserved_d), &(rhs->reserved_d)))
  {
    return false;
  }
  // reserved_e
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->reserved_e), &(rhs->reserved_e)))
  {
    return false;
  }
  // reserved_f
  if (!rosidl_runtime_c__int16__Sequence__are_equal(
      &(lhs->reserved_f), &(rhs->reserved_f)))
  {
    return false;
  }
  // reserved_g
  if (!rosidl_runtime_c__int16__Sequence__are_equal(
      &(lhs->reserved_g), &(rhs->reserved_g)))
  {
    return false;
  }
  // reserved_h
  if (!rosidl_runtime_c__int16__Sequence__are_equal(
      &(lhs->reserved_h), &(rhs->reserved_h)))
  {
    return false;
  }
  // reserved_i
  if (!rosidl_runtime_c__int16__Sequence__are_equal(
      &(lhs->reserved_i), &(rhs->reserved_i)))
  {
    return false;
  }
  // reserved_j
  if (!rosidl_runtime_c__int16__Sequence__are_equal(
      &(lhs->reserved_j), &(rhs->reserved_j)))
  {
    return false;
  }
  // reserved_k
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->reserved_k), &(rhs->reserved_k)))
  {
    return false;
  }
  // reserved_l
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->reserved_l), &(rhs->reserved_l)))
  {
    return false;
  }
  // reserved_m
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->reserved_m), &(rhs->reserved_m)))
  {
    return false;
  }
  // reserved_n
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->reserved_n), &(rhs->reserved_n)))
  {
    return false;
  }
  // reserved_o
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->reserved_o), &(rhs->reserved_o)))
  {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__RadarTarget__copy(
  const radar_msgs__msg__RadarTarget * input,
  radar_msgs__msg__RadarTarget * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // radar_id
  output->radar_id = input->radar_id;
  // frame_cnt
  output->frame_cnt = input->frame_cnt;
  // type
  output->type = input->type;
  // target_num
  output->target_num = input->target_num;
  // polar_state
  output->polar_state = input->polar_state;
  // x
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->x), &(output->x)))
  {
    return false;
  }
  // y
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->y), &(output->y)))
  {
    return false;
  }
  // z
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->z), &(output->z)))
  {
    return false;
  }
  // v
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->v), &(output->v)))
  {
    return false;
  }
  // azimuth
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->azimuth), &(output->azimuth)))
  {
    return false;
  }
  // elevation
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->elevation), &(output->elevation)))
  {
    return false;
  }
  // snr
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->snr), &(output->snr)))
  {
    return false;
  }
  // power
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->power), &(output->power)))
  {
    return false;
  }
  // valid_flg
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->valid_flg), &(output->valid_flg)))
  {
    return false;
  }
  // existance_probability
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->existance_probability), &(output->existance_probability)))
  {
    return false;
  }
  // motion_state
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->motion_state), &(output->motion_state)))
  {
    return false;
  }
  // detection_class
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->detection_class), &(output->detection_class)))
  {
    return false;
  }
  // reset_cnt
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->reset_cnt), &(output->reset_cnt)))
  {
    return false;
  }
  // od_timeout_cnt
  if (!rosidl_runtime_c__int16__Sequence__copy(
      &(input->od_timeout_cnt), &(output->od_timeout_cnt)))
  {
    return false;
  }
  // reserved_a
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->reserved_a), &(output->reserved_a)))
  {
    return false;
  }
  // reserved_b
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->reserved_b), &(output->reserved_b)))
  {
    return false;
  }
  // reserved_c
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->reserved_c), &(output->reserved_c)))
  {
    return false;
  }
  // reserved_d
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->reserved_d), &(output->reserved_d)))
  {
    return false;
  }
  // reserved_e
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->reserved_e), &(output->reserved_e)))
  {
    return false;
  }
  // reserved_f
  if (!rosidl_runtime_c__int16__Sequence__copy(
      &(input->reserved_f), &(output->reserved_f)))
  {
    return false;
  }
  // reserved_g
  if (!rosidl_runtime_c__int16__Sequence__copy(
      &(input->reserved_g), &(output->reserved_g)))
  {
    return false;
  }
  // reserved_h
  if (!rosidl_runtime_c__int16__Sequence__copy(
      &(input->reserved_h), &(output->reserved_h)))
  {
    return false;
  }
  // reserved_i
  if (!rosidl_runtime_c__int16__Sequence__copy(
      &(input->reserved_i), &(output->reserved_i)))
  {
    return false;
  }
  // reserved_j
  if (!rosidl_runtime_c__int16__Sequence__copy(
      &(input->reserved_j), &(output->reserved_j)))
  {
    return false;
  }
  // reserved_k
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->reserved_k), &(output->reserved_k)))
  {
    return false;
  }
  // reserved_l
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->reserved_l), &(output->reserved_l)))
  {
    return false;
  }
  // reserved_m
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->reserved_m), &(output->reserved_m)))
  {
    return false;
  }
  // reserved_n
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->reserved_n), &(output->reserved_n)))
  {
    return false;
  }
  // reserved_o
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->reserved_o), &(output->reserved_o)))
  {
    return false;
  }
  return true;
}

radar_msgs__msg__RadarTarget *
radar_msgs__msg__RadarTarget__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RadarTarget * msg = (radar_msgs__msg__RadarTarget *)allocator.allocate(sizeof(radar_msgs__msg__RadarTarget), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__RadarTarget));
  bool success = radar_msgs__msg__RadarTarget__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__RadarTarget__destroy(radar_msgs__msg__RadarTarget * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__RadarTarget__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__RadarTarget__Sequence__init(radar_msgs__msg__RadarTarget__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RadarTarget * data = NULL;

  if (size) {
    data = (radar_msgs__msg__RadarTarget *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__RadarTarget), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__RadarTarget__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__RadarTarget__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__RadarTarget__Sequence__fini(radar_msgs__msg__RadarTarget__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__RadarTarget__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__RadarTarget__Sequence *
radar_msgs__msg__RadarTarget__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RadarTarget__Sequence * array = (radar_msgs__msg__RadarTarget__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__RadarTarget__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__RadarTarget__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__RadarTarget__Sequence__destroy(radar_msgs__msg__RadarTarget__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__RadarTarget__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__RadarTarget__Sequence__are_equal(const radar_msgs__msg__RadarTarget__Sequence * lhs, const radar_msgs__msg__RadarTarget__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__RadarTarget__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__RadarTarget__Sequence__copy(
  const radar_msgs__msg__RadarTarget__Sequence * input,
  radar_msgs__msg__RadarTarget__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__RadarTarget);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__RadarTarget * data =
      (radar_msgs__msg__RadarTarget *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__RadarTarget__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__RadarTarget__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__RadarTarget__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
