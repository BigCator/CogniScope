// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonRxGainPhRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_RX_GAIN_PH_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_RX_GAIN_PH_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_rx_gain_ph_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonRxGainPhRep_timestamp
{
public:
  explicit Init_RlMonRxGainPhRep_timestamp(::radar_msgs::msg::RlMonRxGainPhRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonRxGainPhRep timestamp(::radar_msgs::msg::RlMonRxGainPhRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

class Init_RlMonRxGainPhRep_rxnoisepower2
{
public:
  explicit Init_RlMonRxGainPhRep_rxnoisepower2(::radar_msgs::msg::RlMonRxGainPhRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxGainPhRep_timestamp rxnoisepower2(::radar_msgs::msg::RlMonRxGainPhRep::_rxnoisepower2_type arg)
  {
    msg_.rxnoisepower2 = std::move(arg);
    return Init_RlMonRxGainPhRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

class Init_RlMonRxGainPhRep_rxnoisepower1
{
public:
  explicit Init_RlMonRxGainPhRep_rxnoisepower1(::radar_msgs::msg::RlMonRxGainPhRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxGainPhRep_rxnoisepower2 rxnoisepower1(::radar_msgs::msg::RlMonRxGainPhRep::_rxnoisepower1_type arg)
  {
    msg_.rxnoisepower1 = std::move(arg);
    return Init_RlMonRxGainPhRep_rxnoisepower2(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

class Init_RlMonRxGainPhRep_rxphaseval
{
public:
  explicit Init_RlMonRxGainPhRep_rxphaseval(::radar_msgs::msg::RlMonRxGainPhRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxGainPhRep_rxnoisepower1 rxphaseval(::radar_msgs::msg::RlMonRxGainPhRep::_rxphaseval_type arg)
  {
    msg_.rxphaseval = std::move(arg);
    return Init_RlMonRxGainPhRep_rxnoisepower1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

class Init_RlMonRxGainPhRep_rxgainval
{
public:
  explicit Init_RlMonRxGainPhRep_rxgainval(::radar_msgs::msg::RlMonRxGainPhRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxGainPhRep_rxphaseval rxgainval(::radar_msgs::msg::RlMonRxGainPhRep::_rxgainval_type arg)
  {
    msg_.rxgainval = std::move(arg);
    return Init_RlMonRxGainPhRep_rxphaseval(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

class Init_RlMonRxGainPhRep_loopbackpowerrf3
{
public:
  explicit Init_RlMonRxGainPhRep_loopbackpowerrf3(::radar_msgs::msg::RlMonRxGainPhRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxGainPhRep_rxgainval loopbackpowerrf3(::radar_msgs::msg::RlMonRxGainPhRep::_loopbackpowerrf3_type arg)
  {
    msg_.loopbackpowerrf3 = std::move(arg);
    return Init_RlMonRxGainPhRep_rxgainval(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

class Init_RlMonRxGainPhRep_loopbackpowerrf2
{
public:
  explicit Init_RlMonRxGainPhRep_loopbackpowerrf2(::radar_msgs::msg::RlMonRxGainPhRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxGainPhRep_loopbackpowerrf3 loopbackpowerrf2(::radar_msgs::msg::RlMonRxGainPhRep::_loopbackpowerrf2_type arg)
  {
    msg_.loopbackpowerrf2 = std::move(arg);
    return Init_RlMonRxGainPhRep_loopbackpowerrf3(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

class Init_RlMonRxGainPhRep_loopbackpowerrf1
{
public:
  explicit Init_RlMonRxGainPhRep_loopbackpowerrf1(::radar_msgs::msg::RlMonRxGainPhRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxGainPhRep_loopbackpowerrf2 loopbackpowerrf1(::radar_msgs::msg::RlMonRxGainPhRep::_loopbackpowerrf1_type arg)
  {
    msg_.loopbackpowerrf1 = std::move(arg);
    return Init_RlMonRxGainPhRep_loopbackpowerrf2(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

class Init_RlMonRxGainPhRep_profindex
{
public:
  explicit Init_RlMonRxGainPhRep_profindex(::radar_msgs::msg::RlMonRxGainPhRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxGainPhRep_loopbackpowerrf1 profindex(::radar_msgs::msg::RlMonRxGainPhRep::_profindex_type arg)
  {
    msg_.profindex = std::move(arg);
    return Init_RlMonRxGainPhRep_loopbackpowerrf1(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

class Init_RlMonRxGainPhRep_errorcode
{
public:
  explicit Init_RlMonRxGainPhRep_errorcode(::radar_msgs::msg::RlMonRxGainPhRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxGainPhRep_profindex errorcode(::radar_msgs::msg::RlMonRxGainPhRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonRxGainPhRep_profindex(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

class Init_RlMonRxGainPhRep_statusflags
{
public:
  Init_RlMonRxGainPhRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonRxGainPhRep_errorcode statusflags(::radar_msgs::msg::RlMonRxGainPhRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonRxGainPhRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxGainPhRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonRxGainPhRep>()
{
  return radar_msgs::msg::builder::Init_RlMonRxGainPhRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_RX_GAIN_PH_REP__BUILDER_HPP_
