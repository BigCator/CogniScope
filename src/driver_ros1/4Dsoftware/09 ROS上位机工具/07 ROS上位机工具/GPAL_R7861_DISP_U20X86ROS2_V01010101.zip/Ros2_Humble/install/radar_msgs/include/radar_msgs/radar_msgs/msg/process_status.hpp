// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__PROCESS_STATUS_HPP_
#define RADAR_MSGS__MSG__PROCESS_STATUS_HPP_

#include "radar_msgs/msg/detail/process_status__struct.hpp"
#include "radar_msgs/msg/detail/process_status__builder.hpp"
#include "radar_msgs/msg/detail/process_status__traits.hpp"

#endif  // RADAR_MSGS__MSG__PROCESS_STATUS_HPP_
