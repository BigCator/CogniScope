// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from radar_msgs:msg/RfStatus.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "radar_msgs/msg/detail/rf_status__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace radar_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void RfStatus_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) radar_msgs::msg::RfStatus(_init);
}

void RfStatus_fini_function(void * message_memory)
{
  auto typed_message = static_cast<radar_msgs::msg::RfStatus *>(message_memory);
  typed_message->~RfStatus();
}

size_t size_function__RfStatus__reportrxgainphdata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reportrxgainphdata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonRxGainPhRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reportrxgainphdata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonRxGainPhRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reportrxgainphdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonRxGainPhRep *>(
    get_const_function__RfStatus__reportrxgainphdata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonRxGainPhRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reportrxgainphdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonRxGainPhRep *>(
    get_function__RfStatus__reportrxgainphdata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonRxGainPhRep *>(untyped_value);
  item = value;
}

size_t size_function__RfStatus__reportrxnoisefigdata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reportrxnoisefigdata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonRxNoiseFigRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reportrxnoisefigdata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonRxNoiseFigRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reportrxnoisefigdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonRxNoiseFigRep *>(
    get_const_function__RfStatus__reportrxnoisefigdata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonRxNoiseFigRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reportrxnoisefigdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonRxNoiseFigRep *>(
    get_function__RfStatus__reportrxnoisefigdata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonRxNoiseFigRep *>(untyped_value);
  item = value;
}

size_t size_function__RfStatus__reportrxifstagedata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reportrxifstagedata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonRxIfStageRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reportrxifstagedata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonRxIfStageRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reportrxifstagedata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonRxIfStageRep *>(
    get_const_function__RfStatus__reportrxifstagedata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonRxIfStageRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reportrxifstagedata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonRxIfStageRep *>(
    get_function__RfStatus__reportrxifstagedata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonRxIfStageRep *>(untyped_value);
  item = value;
}

size_t size_function__RfStatus__reportrxintanasigdata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reportrxintanasigdata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonRxIntAnaSigRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reportrxintanasigdata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonRxIntAnaSigRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reportrxintanasigdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonRxIntAnaSigRep *>(
    get_const_function__RfStatus__reportrxintanasigdata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonRxIntAnaSigRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reportrxintanasigdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonRxIntAnaSigRep *>(
    get_function__RfStatus__reportrxintanasigdata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonRxIntAnaSigRep *>(untyped_value);
  item = value;
}

size_t size_function__RfStatus__reportpmclklointanasigdata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reportpmclklointanasigdata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonPmclkloIntAnaSigRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reportpmclklointanasigdata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonPmclkloIntAnaSigRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reportpmclklointanasigdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonPmclkloIntAnaSigRep *>(
    get_const_function__RfStatus__reportpmclklointanasigdata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonPmclkloIntAnaSigRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reportpmclklointanasigdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonPmclkloIntAnaSigRep *>(
    get_function__RfStatus__reportpmclklointanasigdata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonPmclkloIntAnaSigRep *>(untyped_value);
  item = value;
}

size_t size_function__RfStatus__reportrxmixrinpwrdata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reportrxmixrinpwrdata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonRxMixrInPwrRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reportrxmixrinpwrdata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonRxMixrInPwrRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reportrxmixrinpwrdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonRxMixrInPwrRep *>(
    get_const_function__RfStatus__reportrxmixrinpwrdata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonRxMixrInPwrRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reportrxmixrinpwrdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonRxMixrInPwrRep *>(
    get_function__RfStatus__reportrxmixrinpwrdata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonRxMixrInPwrRep *>(untyped_value);
  item = value;
}

size_t size_function__RfStatus__reporttxintanasigdata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reporttxintanasigdata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonTxIntAnaSigRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reporttxintanasigdata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonTxIntAnaSigRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reporttxintanasigdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonTxIntAnaSigRep *>(
    get_const_function__RfStatus__reporttxintanasigdata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonTxIntAnaSigRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reporttxintanasigdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonTxIntAnaSigRep *>(
    get_function__RfStatus__reporttxintanasigdata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonTxIntAnaSigRep *>(untyped_value);
  item = value;
}

size_t size_function__RfStatus__reportsynthfreqdata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reportsynthfreqdata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonSynthFreqRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reportsynthfreqdata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonSynthFreqRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reportsynthfreqdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonSynthFreqRep *>(
    get_const_function__RfStatus__reportsynthfreqdata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonSynthFreqRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reportsynthfreqdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonSynthFreqRep *>(
    get_function__RfStatus__reportsynthfreqdata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonSynthFreqRep *>(untyped_value);
  item = value;
}

size_t size_function__RfStatus__reporttxphshiftdata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reporttxphshiftdata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonTxPhShiftRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reporttxphshiftdata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonTxPhShiftRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reporttxphshiftdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonTxPhShiftRep *>(
    get_const_function__RfStatus__reporttxphshiftdata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonTxPhShiftRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reporttxphshiftdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonTxPhShiftRep *>(
    get_function__RfStatus__reporttxphshiftdata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonTxPhShiftRep *>(untyped_value);
  item = value;
}

size_t size_function__RfStatus__reporttxgainphamisdata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reporttxgainphamisdata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonTxGainPhaMisRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reporttxgainphamisdata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonTxGainPhaMisRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reporttxgainphamisdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonTxGainPhaMisRep *>(
    get_const_function__RfStatus__reporttxgainphamisdata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonTxGainPhaMisRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reporttxgainphamisdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonTxGainPhaMisRep *>(
    get_function__RfStatus__reporttxgainphamisdata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonTxGainPhaMisRep *>(untyped_value);
  item = value;
}

size_t size_function__RfStatus__reporttxpowdata(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__RfStatus__reporttxpowdata(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<radar_msgs::msg::RlMonTxPowRep, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__RfStatus__reporttxpowdata(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<radar_msgs::msg::RlMonTxPowRep, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__RfStatus__reporttxpowdata(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const radar_msgs::msg::RlMonTxPowRep *>(
    get_const_function__RfStatus__reporttxpowdata(untyped_member, index));
  auto & value = *reinterpret_cast<radar_msgs::msg::RlMonTxPowRep *>(untyped_value);
  value = item;
}

void assign_function__RfStatus__reporttxpowdata(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<radar_msgs::msg::RlMonTxPowRep *>(
    get_function__RfStatus__reporttxpowdata(untyped_member, index));
  const auto & value = *reinterpret_cast<const radar_msgs::msg::RlMonTxPowRep *>(untyped_value);
  item = value;
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember RfStatus_message_member_array[27] = {
  {
    "header",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<std_msgs::msg::Header>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, header),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "radarid",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, radarid),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "framecnt",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, framecnt),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "diglatentfaultdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlDigLatentFaultReportData>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, diglatentfaultdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportheaderdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonReportHdrData>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportheaderdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reporttempdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonTempReportData>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reporttempdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "digperiodicreportdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlDigPeriodicReportData>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, digperiodicreportdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportrxgainphdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonRxGainPhRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportrxgainphdata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reportrxgainphdata,  // size() function pointer
    get_const_function__RfStatus__reportrxgainphdata,  // get_const(index) function pointer
    get_function__RfStatus__reportrxgainphdata,  // get(index) function pointer
    fetch_function__RfStatus__reportrxgainphdata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reportrxgainphdata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportrxnoisefigdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonRxNoiseFigRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportrxnoisefigdata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reportrxnoisefigdata,  // size() function pointer
    get_const_function__RfStatus__reportrxnoisefigdata,  // get_const(index) function pointer
    get_function__RfStatus__reportrxnoisefigdata,  // get(index) function pointer
    fetch_function__RfStatus__reportrxnoisefigdata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reportrxnoisefigdata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportrxifstagedata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonRxIfStageRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportrxifstagedata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reportrxifstagedata,  // size() function pointer
    get_const_function__RfStatus__reportrxifstagedata,  // get_const(index) function pointer
    get_function__RfStatus__reportrxifstagedata,  // get(index) function pointer
    fetch_function__RfStatus__reportrxifstagedata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reportrxifstagedata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportrxintanasigdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonRxIntAnaSigRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportrxintanasigdata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reportrxintanasigdata,  // size() function pointer
    get_const_function__RfStatus__reportrxintanasigdata,  // get_const(index) function pointer
    get_function__RfStatus__reportrxintanasigdata,  // get(index) function pointer
    fetch_function__RfStatus__reportrxintanasigdata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reportrxintanasigdata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportpmclklointanasigdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonPmclkloIntAnaSigRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportpmclklointanasigdata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reportpmclklointanasigdata,  // size() function pointer
    get_const_function__RfStatus__reportpmclklointanasigdata,  // get_const(index) function pointer
    get_function__RfStatus__reportpmclklointanasigdata,  // get(index) function pointer
    fetch_function__RfStatus__reportpmclklointanasigdata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reportpmclklointanasigdata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportgpadcintanasigdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonGpadcIntAnaSigRep>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportgpadcintanasigdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportpllconvoltdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonPllConVoltRep>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportpllconvoltdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportdccclkfreqdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonDccClkFreqRep>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportdccclkfreqdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportsynthfreqnonlivedata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonSynthFreqNonLiveRep>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportsynthfreqnonlivedata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportrxmixrinpwrdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonRxMixrInPwrRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportrxmixrinpwrdata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reportrxmixrinpwrdata,  // size() function pointer
    get_const_function__RfStatus__reportrxmixrinpwrdata,  // get_const(index) function pointer
    get_function__RfStatus__reportrxmixrinpwrdata,  // get(index) function pointer
    fetch_function__RfStatus__reportrxmixrinpwrdata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reportrxmixrinpwrdata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reporttxintanasigdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonTxIntAnaSigRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reporttxintanasigdata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reporttxintanasigdata,  // size() function pointer
    get_const_function__RfStatus__reporttxintanasigdata,  // get_const(index) function pointer
    get_function__RfStatus__reporttxintanasigdata,  // get(index) function pointer
    fetch_function__RfStatus__reporttxintanasigdata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reporttxintanasigdata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportextanasigdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonExtAnaSigRep>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportextanasigdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportsynthfreqdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonSynthFreqRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportsynthfreqdata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reportsynthfreqdata,  // size() function pointer
    get_const_function__RfStatus__reportsynthfreqdata,  // get_const(index) function pointer
    get_function__RfStatus__reportsynthfreqdata,  // get(index) function pointer
    fetch_function__RfStatus__reportsynthfreqdata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reportsynthfreqdata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reporttxphshiftdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonTxPhShiftRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reporttxphshiftdata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reporttxphshiftdata,  // size() function pointer
    get_const_function__RfStatus__reporttxphshiftdata,  // get_const(index) function pointer
    get_function__RfStatus__reporttxphshiftdata,  // get(index) function pointer
    fetch_function__RfStatus__reporttxphshiftdata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reporttxphshiftdata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reporttxgainphamisdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonTxGainPhaMisRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reporttxgainphamisdata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reporttxgainphamisdata,  // size() function pointer
    get_const_function__RfStatus__reporttxgainphamisdata,  // get_const(index) function pointer
    get_function__RfStatus__reporttxgainphamisdata,  // get(index) function pointer
    fetch_function__RfStatus__reporttxgainphamisdata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reporttxgainphamisdata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reporttxballbreakdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonTxBallBreakRep>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reporttxballbreakdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reporttxpowdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlMonTxPowRep>(),  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reporttxpowdata),  // bytes offset in struct
    nullptr,  // default value
    size_function__RfStatus__reporttxpowdata,  // size() function pointer
    get_const_function__RfStatus__reporttxpowdata,  // get_const(index) function pointer
    get_function__RfStatus__reporttxpowdata,  // get(index) function pointer
    fetch_function__RfStatus__reporttxpowdata,  // fetch(index, &value) function pointer
    assign_function__RfStatus__reporttxpowdata,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportrecvdgpadcdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlRecvdGpAdcData>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportrecvdgpadcdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reportanalogfaultdata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlAnalogFaultReportData>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reportanalogfaultdata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reporttimingerrordata",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<radar_msgs::msg::RlCalMonTimingErrorReportData>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(radar_msgs::msg::RfStatus, reporttimingerrordata),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers RfStatus_message_members = {
  "radar_msgs::msg",  // message namespace
  "RfStatus",  // message name
  27,  // number of fields
  sizeof(radar_msgs::msg::RfStatus),
  RfStatus_message_member_array,  // message members
  RfStatus_init_function,  // function to initialize message memory (memory has to be allocated)
  RfStatus_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t RfStatus_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &RfStatus_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace radar_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<radar_msgs::msg::RfStatus>()
{
  return &::radar_msgs::msg::rosidl_typesupport_introspection_cpp::RfStatus_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, radar_msgs, msg, RfStatus)() {
  return &::radar_msgs::msg::rosidl_typesupport_introspection_cpp::RfStatus_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
