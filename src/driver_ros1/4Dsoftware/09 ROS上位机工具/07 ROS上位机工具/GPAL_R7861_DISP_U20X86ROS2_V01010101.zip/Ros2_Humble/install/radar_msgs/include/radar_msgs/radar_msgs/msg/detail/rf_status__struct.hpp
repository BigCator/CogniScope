// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from radar_msgs:msg/RfStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RF_STATUS__STRUCT_HPP_
#define RADAR_MSGS__MSG__DETAIL__RF_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'diglatentfaultdata'
#include "radar_msgs/msg/detail/rl_dig_latent_fault_report_data__struct.hpp"
// Member 'reportheaderdata'
#include "radar_msgs/msg/detail/rl_mon_report_hdr_data__struct.hpp"
// Member 'reporttempdata'
#include "radar_msgs/msg/detail/rl_mon_temp_report_data__struct.hpp"
// Member 'digperiodicreportdata'
#include "radar_msgs/msg/detail/rl_dig_periodic_report_data__struct.hpp"
// Member 'reportrxgainphdata'
#include "radar_msgs/msg/detail/rl_mon_rx_gain_ph_rep__struct.hpp"
// Member 'reportrxnoisefigdata'
#include "radar_msgs/msg/detail/rl_mon_rx_noise_fig_rep__struct.hpp"
// Member 'reportrxifstagedata'
#include "radar_msgs/msg/detail/rl_mon_rx_if_stage_rep__struct.hpp"
// Member 'reportrxintanasigdata'
#include "radar_msgs/msg/detail/rl_mon_rx_int_ana_sig_rep__struct.hpp"
// Member 'reportpmclklointanasigdata'
#include "radar_msgs/msg/detail/rl_mon_pmclklo_int_ana_sig_rep__struct.hpp"
// Member 'reportgpadcintanasigdata'
#include "radar_msgs/msg/detail/rl_mon_gpadc_int_ana_sig_rep__struct.hpp"
// Member 'reportpllconvoltdata'
#include "radar_msgs/msg/detail/rl_mon_pll_con_volt_rep__struct.hpp"
// Member 'reportdccclkfreqdata'
#include "radar_msgs/msg/detail/rl_mon_dcc_clk_freq_rep__struct.hpp"
// Member 'reportsynthfreqnonlivedata'
#include "radar_msgs/msg/detail/rl_mon_synth_freq_non_live_rep__struct.hpp"
// Member 'reportrxmixrinpwrdata'
#include "radar_msgs/msg/detail/rl_mon_rx_mixr_in_pwr_rep__struct.hpp"
// Member 'reporttxintanasigdata'
#include "radar_msgs/msg/detail/rl_mon_tx_int_ana_sig_rep__struct.hpp"
// Member 'reportextanasigdata'
#include "radar_msgs/msg/detail/rl_mon_ext_ana_sig_rep__struct.hpp"
// Member 'reportsynthfreqdata'
#include "radar_msgs/msg/detail/rl_mon_synth_freq_rep__struct.hpp"
// Member 'reporttxphshiftdata'
#include "radar_msgs/msg/detail/rl_mon_tx_ph_shift_rep__struct.hpp"
// Member 'reporttxgainphamisdata'
#include "radar_msgs/msg/detail/rl_mon_tx_gain_pha_mis_rep__struct.hpp"
// Member 'reporttxballbreakdata'
#include "radar_msgs/msg/detail/rl_mon_tx_ball_break_rep__struct.hpp"
// Member 'reporttxpowdata'
#include "radar_msgs/msg/detail/rl_mon_tx_pow_rep__struct.hpp"
// Member 'reportrecvdgpadcdata'
#include "radar_msgs/msg/detail/rl_recvd_gp_adc_data__struct.hpp"
// Member 'reportanalogfaultdata'
#include "radar_msgs/msg/detail/rl_analog_fault_report_data__struct.hpp"
// Member 'reporttimingerrordata'
#include "radar_msgs/msg/detail/rl_cal_mon_timing_error_report_data__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__radar_msgs__msg__RfStatus __attribute__((deprecated))
#else
# define DEPRECATED__radar_msgs__msg__RfStatus __declspec(deprecated)
#endif

namespace radar_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RfStatus_
{
  using Type = RfStatus_<ContainerAllocator>;

  explicit RfStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    diglatentfaultdata(_init),
    reportheaderdata(_init),
    reporttempdata(_init),
    digperiodicreportdata(_init),
    reportgpadcintanasigdata(_init),
    reportpllconvoltdata(_init),
    reportdccclkfreqdata(_init),
    reportsynthfreqnonlivedata(_init),
    reportextanasigdata(_init),
    reporttxballbreakdata(_init),
    reportrecvdgpadcdata(_init),
    reportanalogfaultdata(_init),
    reporttimingerrordata(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radarid = 0ul;
      this->framecnt = 0ul;
      this->reportrxgainphdata.fill(radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator>{_init});
      this->reportrxnoisefigdata.fill(radar_msgs::msg::RlMonRxNoiseFigRep_<ContainerAllocator>{_init});
      this->reportrxifstagedata.fill(radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator>{_init});
      this->reportrxintanasigdata.fill(radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator>{_init});
      this->reportpmclklointanasigdata.fill(radar_msgs::msg::RlMonPmclkloIntAnaSigRep_<ContainerAllocator>{_init});
      this->reportrxmixrinpwrdata.fill(radar_msgs::msg::RlMonRxMixrInPwrRep_<ContainerAllocator>{_init});
      this->reporttxintanasigdata.fill(radar_msgs::msg::RlMonTxIntAnaSigRep_<ContainerAllocator>{_init});
      this->reportsynthfreqdata.fill(radar_msgs::msg::RlMonSynthFreqRep_<ContainerAllocator>{_init});
      this->reporttxphshiftdata.fill(radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator>{_init});
      this->reporttxgainphamisdata.fill(radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator>{_init});
      this->reporttxpowdata.fill(radar_msgs::msg::RlMonTxPowRep_<ContainerAllocator>{_init});
    }
  }

  explicit RfStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    diglatentfaultdata(_alloc, _init),
    reportheaderdata(_alloc, _init),
    reporttempdata(_alloc, _init),
    digperiodicreportdata(_alloc, _init),
    reportrxgainphdata(_alloc),
    reportrxnoisefigdata(_alloc),
    reportrxifstagedata(_alloc),
    reportrxintanasigdata(_alloc),
    reportpmclklointanasigdata(_alloc),
    reportgpadcintanasigdata(_alloc, _init),
    reportpllconvoltdata(_alloc, _init),
    reportdccclkfreqdata(_alloc, _init),
    reportsynthfreqnonlivedata(_alloc, _init),
    reportrxmixrinpwrdata(_alloc),
    reporttxintanasigdata(_alloc),
    reportextanasigdata(_alloc, _init),
    reportsynthfreqdata(_alloc),
    reporttxphshiftdata(_alloc),
    reporttxgainphamisdata(_alloc),
    reporttxballbreakdata(_alloc, _init),
    reporttxpowdata(_alloc),
    reportrecvdgpadcdata(_alloc, _init),
    reportanalogfaultdata(_alloc, _init),
    reporttimingerrordata(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->radarid = 0ul;
      this->framecnt = 0ul;
      this->reportrxgainphdata.fill(radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator>{_alloc, _init});
      this->reportrxnoisefigdata.fill(radar_msgs::msg::RlMonRxNoiseFigRep_<ContainerAllocator>{_alloc, _init});
      this->reportrxifstagedata.fill(radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator>{_alloc, _init});
      this->reportrxintanasigdata.fill(radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator>{_alloc, _init});
      this->reportpmclklointanasigdata.fill(radar_msgs::msg::RlMonPmclkloIntAnaSigRep_<ContainerAllocator>{_alloc, _init});
      this->reportrxmixrinpwrdata.fill(radar_msgs::msg::RlMonRxMixrInPwrRep_<ContainerAllocator>{_alloc, _init});
      this->reporttxintanasigdata.fill(radar_msgs::msg::RlMonTxIntAnaSigRep_<ContainerAllocator>{_alloc, _init});
      this->reportsynthfreqdata.fill(radar_msgs::msg::RlMonSynthFreqRep_<ContainerAllocator>{_alloc, _init});
      this->reporttxphshiftdata.fill(radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator>{_alloc, _init});
      this->reporttxgainphamisdata.fill(radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator>{_alloc, _init});
      this->reporttxpowdata.fill(radar_msgs::msg::RlMonTxPowRep_<ContainerAllocator>{_alloc, _init});
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _radarid_type =
    uint32_t;
  _radarid_type radarid;
  using _framecnt_type =
    uint32_t;
  _framecnt_type framecnt;
  using _diglatentfaultdata_type =
    radar_msgs::msg::RlDigLatentFaultReportData_<ContainerAllocator>;
  _diglatentfaultdata_type diglatentfaultdata;
  using _reportheaderdata_type =
    radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator>;
  _reportheaderdata_type reportheaderdata;
  using _reporttempdata_type =
    radar_msgs::msg::RlMonTempReportData_<ContainerAllocator>;
  _reporttempdata_type reporttempdata;
  using _digperiodicreportdata_type =
    radar_msgs::msg::RlDigPeriodicReportData_<ContainerAllocator>;
  _digperiodicreportdata_type digperiodicreportdata;
  using _reportrxgainphdata_type =
    std::array<radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator>, 2>;
  _reportrxgainphdata_type reportrxgainphdata;
  using _reportrxnoisefigdata_type =
    std::array<radar_msgs::msg::RlMonRxNoiseFigRep_<ContainerAllocator>, 2>;
  _reportrxnoisefigdata_type reportrxnoisefigdata;
  using _reportrxifstagedata_type =
    std::array<radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator>, 2>;
  _reportrxifstagedata_type reportrxifstagedata;
  using _reportrxintanasigdata_type =
    std::array<radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator>, 2>;
  _reportrxintanasigdata_type reportrxintanasigdata;
  using _reportpmclklointanasigdata_type =
    std::array<radar_msgs::msg::RlMonPmclkloIntAnaSigRep_<ContainerAllocator>, 2>;
  _reportpmclklointanasigdata_type reportpmclklointanasigdata;
  using _reportgpadcintanasigdata_type =
    radar_msgs::msg::RlMonGpadcIntAnaSigRep_<ContainerAllocator>;
  _reportgpadcintanasigdata_type reportgpadcintanasigdata;
  using _reportpllconvoltdata_type =
    radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator>;
  _reportpllconvoltdata_type reportpllconvoltdata;
  using _reportdccclkfreqdata_type =
    radar_msgs::msg::RlMonDccClkFreqRep_<ContainerAllocator>;
  _reportdccclkfreqdata_type reportdccclkfreqdata;
  using _reportsynthfreqnonlivedata_type =
    radar_msgs::msg::RlMonSynthFreqNonLiveRep_<ContainerAllocator>;
  _reportsynthfreqnonlivedata_type reportsynthfreqnonlivedata;
  using _reportrxmixrinpwrdata_type =
    std::array<radar_msgs::msg::RlMonRxMixrInPwrRep_<ContainerAllocator>, 2>;
  _reportrxmixrinpwrdata_type reportrxmixrinpwrdata;
  using _reporttxintanasigdata_type =
    std::array<radar_msgs::msg::RlMonTxIntAnaSigRep_<ContainerAllocator>, 2>;
  _reporttxintanasigdata_type reporttxintanasigdata;
  using _reportextanasigdata_type =
    radar_msgs::msg::RlMonExtAnaSigRep_<ContainerAllocator>;
  _reportextanasigdata_type reportextanasigdata;
  using _reportsynthfreqdata_type =
    std::array<radar_msgs::msg::RlMonSynthFreqRep_<ContainerAllocator>, 2>;
  _reportsynthfreqdata_type reportsynthfreqdata;
  using _reporttxphshiftdata_type =
    std::array<radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator>, 2>;
  _reporttxphshiftdata_type reporttxphshiftdata;
  using _reporttxgainphamisdata_type =
    std::array<radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator>, 2>;
  _reporttxgainphamisdata_type reporttxgainphamisdata;
  using _reporttxballbreakdata_type =
    radar_msgs::msg::RlMonTxBallBreakRep_<ContainerAllocator>;
  _reporttxballbreakdata_type reporttxballbreakdata;
  using _reporttxpowdata_type =
    std::array<radar_msgs::msg::RlMonTxPowRep_<ContainerAllocator>, 2>;
  _reporttxpowdata_type reporttxpowdata;
  using _reportrecvdgpadcdata_type =
    radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator>;
  _reportrecvdgpadcdata_type reportrecvdgpadcdata;
  using _reportanalogfaultdata_type =
    radar_msgs::msg::RlAnalogFaultReportData_<ContainerAllocator>;
  _reportanalogfaultdata_type reportanalogfaultdata;
  using _reporttimingerrordata_type =
    radar_msgs::msg::RlCalMonTimingErrorReportData_<ContainerAllocator>;
  _reporttimingerrordata_type reporttimingerrordata;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__radarid(
    const uint32_t & _arg)
  {
    this->radarid = _arg;
    return *this;
  }
  Type & set__framecnt(
    const uint32_t & _arg)
  {
    this->framecnt = _arg;
    return *this;
  }
  Type & set__diglatentfaultdata(
    const radar_msgs::msg::RlDigLatentFaultReportData_<ContainerAllocator> & _arg)
  {
    this->diglatentfaultdata = _arg;
    return *this;
  }
  Type & set__reportheaderdata(
    const radar_msgs::msg::RlMonReportHdrData_<ContainerAllocator> & _arg)
  {
    this->reportheaderdata = _arg;
    return *this;
  }
  Type & set__reporttempdata(
    const radar_msgs::msg::RlMonTempReportData_<ContainerAllocator> & _arg)
  {
    this->reporttempdata = _arg;
    return *this;
  }
  Type & set__digperiodicreportdata(
    const radar_msgs::msg::RlDigPeriodicReportData_<ContainerAllocator> & _arg)
  {
    this->digperiodicreportdata = _arg;
    return *this;
  }
  Type & set__reportrxgainphdata(
    const std::array<radar_msgs::msg::RlMonRxGainPhRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reportrxgainphdata = _arg;
    return *this;
  }
  Type & set__reportrxnoisefigdata(
    const std::array<radar_msgs::msg::RlMonRxNoiseFigRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reportrxnoisefigdata = _arg;
    return *this;
  }
  Type & set__reportrxifstagedata(
    const std::array<radar_msgs::msg::RlMonRxIfStageRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reportrxifstagedata = _arg;
    return *this;
  }
  Type & set__reportrxintanasigdata(
    const std::array<radar_msgs::msg::RlMonRxIntAnaSigRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reportrxintanasigdata = _arg;
    return *this;
  }
  Type & set__reportpmclklointanasigdata(
    const std::array<radar_msgs::msg::RlMonPmclkloIntAnaSigRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reportpmclklointanasigdata = _arg;
    return *this;
  }
  Type & set__reportgpadcintanasigdata(
    const radar_msgs::msg::RlMonGpadcIntAnaSigRep_<ContainerAllocator> & _arg)
  {
    this->reportgpadcintanasigdata = _arg;
    return *this;
  }
  Type & set__reportpllconvoltdata(
    const radar_msgs::msg::RlMonPllConVoltRep_<ContainerAllocator> & _arg)
  {
    this->reportpllconvoltdata = _arg;
    return *this;
  }
  Type & set__reportdccclkfreqdata(
    const radar_msgs::msg::RlMonDccClkFreqRep_<ContainerAllocator> & _arg)
  {
    this->reportdccclkfreqdata = _arg;
    return *this;
  }
  Type & set__reportsynthfreqnonlivedata(
    const radar_msgs::msg::RlMonSynthFreqNonLiveRep_<ContainerAllocator> & _arg)
  {
    this->reportsynthfreqnonlivedata = _arg;
    return *this;
  }
  Type & set__reportrxmixrinpwrdata(
    const std::array<radar_msgs::msg::RlMonRxMixrInPwrRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reportrxmixrinpwrdata = _arg;
    return *this;
  }
  Type & set__reporttxintanasigdata(
    const std::array<radar_msgs::msg::RlMonTxIntAnaSigRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reporttxintanasigdata = _arg;
    return *this;
  }
  Type & set__reportextanasigdata(
    const radar_msgs::msg::RlMonExtAnaSigRep_<ContainerAllocator> & _arg)
  {
    this->reportextanasigdata = _arg;
    return *this;
  }
  Type & set__reportsynthfreqdata(
    const std::array<radar_msgs::msg::RlMonSynthFreqRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reportsynthfreqdata = _arg;
    return *this;
  }
  Type & set__reporttxphshiftdata(
    const std::array<radar_msgs::msg::RlMonTxPhShiftRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reporttxphshiftdata = _arg;
    return *this;
  }
  Type & set__reporttxgainphamisdata(
    const std::array<radar_msgs::msg::RlMonTxGainPhaMisRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reporttxgainphamisdata = _arg;
    return *this;
  }
  Type & set__reporttxballbreakdata(
    const radar_msgs::msg::RlMonTxBallBreakRep_<ContainerAllocator> & _arg)
  {
    this->reporttxballbreakdata = _arg;
    return *this;
  }
  Type & set__reporttxpowdata(
    const std::array<radar_msgs::msg::RlMonTxPowRep_<ContainerAllocator>, 2> & _arg)
  {
    this->reporttxpowdata = _arg;
    return *this;
  }
  Type & set__reportrecvdgpadcdata(
    const radar_msgs::msg::RlRecvdGpAdcData_<ContainerAllocator> & _arg)
  {
    this->reportrecvdgpadcdata = _arg;
    return *this;
  }
  Type & set__reportanalogfaultdata(
    const radar_msgs::msg::RlAnalogFaultReportData_<ContainerAllocator> & _arg)
  {
    this->reportanalogfaultdata = _arg;
    return *this;
  }
  Type & set__reporttimingerrordata(
    const radar_msgs::msg::RlCalMonTimingErrorReportData_<ContainerAllocator> & _arg)
  {
    this->reporttimingerrordata = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    radar_msgs::msg::RfStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const radar_msgs::msg::RfStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<radar_msgs::msg::RfStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<radar_msgs::msg::RfStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RfStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RfStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      radar_msgs::msg::RfStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<radar_msgs::msg::RfStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<radar_msgs::msg::RfStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<radar_msgs::msg::RfStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__radar_msgs__msg__RfStatus
    std::shared_ptr<radar_msgs::msg::RfStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__radar_msgs__msg__RfStatus
    std::shared_ptr<radar_msgs::msg::RfStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RfStatus_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->radarid != other.radarid) {
      return false;
    }
    if (this->framecnt != other.framecnt) {
      return false;
    }
    if (this->diglatentfaultdata != other.diglatentfaultdata) {
      return false;
    }
    if (this->reportheaderdata != other.reportheaderdata) {
      return false;
    }
    if (this->reporttempdata != other.reporttempdata) {
      return false;
    }
    if (this->digperiodicreportdata != other.digperiodicreportdata) {
      return false;
    }
    if (this->reportrxgainphdata != other.reportrxgainphdata) {
      return false;
    }
    if (this->reportrxnoisefigdata != other.reportrxnoisefigdata) {
      return false;
    }
    if (this->reportrxifstagedata != other.reportrxifstagedata) {
      return false;
    }
    if (this->reportrxintanasigdata != other.reportrxintanasigdata) {
      return false;
    }
    if (this->reportpmclklointanasigdata != other.reportpmclklointanasigdata) {
      return false;
    }
    if (this->reportgpadcintanasigdata != other.reportgpadcintanasigdata) {
      return false;
    }
    if (this->reportpllconvoltdata != other.reportpllconvoltdata) {
      return false;
    }
    if (this->reportdccclkfreqdata != other.reportdccclkfreqdata) {
      return false;
    }
    if (this->reportsynthfreqnonlivedata != other.reportsynthfreqnonlivedata) {
      return false;
    }
    if (this->reportrxmixrinpwrdata != other.reportrxmixrinpwrdata) {
      return false;
    }
    if (this->reporttxintanasigdata != other.reporttxintanasigdata) {
      return false;
    }
    if (this->reportextanasigdata != other.reportextanasigdata) {
      return false;
    }
    if (this->reportsynthfreqdata != other.reportsynthfreqdata) {
      return false;
    }
    if (this->reporttxphshiftdata != other.reporttxphshiftdata) {
      return false;
    }
    if (this->reporttxgainphamisdata != other.reporttxgainphamisdata) {
      return false;
    }
    if (this->reporttxballbreakdata != other.reporttxballbreakdata) {
      return false;
    }
    if (this->reporttxpowdata != other.reporttxpowdata) {
      return false;
    }
    if (this->reportrecvdgpadcdata != other.reportrecvdgpadcdata) {
      return false;
    }
    if (this->reportanalogfaultdata != other.reportanalogfaultdata) {
      return false;
    }
    if (this->reporttimingerrordata != other.reporttimingerrordata) {
      return false;
    }
    return true;
  }
  bool operator!=(const RfStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RfStatus_

// alias to use template instance with default allocator
using RfStatus =
  radar_msgs::msg::RfStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RF_STATUS__STRUCT_HPP_
