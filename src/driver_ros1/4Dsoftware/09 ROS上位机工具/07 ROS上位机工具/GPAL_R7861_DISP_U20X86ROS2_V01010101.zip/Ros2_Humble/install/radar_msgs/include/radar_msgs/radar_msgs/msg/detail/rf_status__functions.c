// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/RfStatus.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/rf_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `diglatentfaultdata`
#include "radar_msgs/msg/detail/rl_dig_latent_fault_report_data__functions.h"
// Member `reportheaderdata`
#include "radar_msgs/msg/detail/rl_mon_report_hdr_data__functions.h"
// Member `reporttempdata`
#include "radar_msgs/msg/detail/rl_mon_temp_report_data__functions.h"
// Member `digperiodicreportdata`
#include "radar_msgs/msg/detail/rl_dig_periodic_report_data__functions.h"
// Member `reportrxgainphdata`
#include "radar_msgs/msg/detail/rl_mon_rx_gain_ph_rep__functions.h"
// Member `reportrxnoisefigdata`
#include "radar_msgs/msg/detail/rl_mon_rx_noise_fig_rep__functions.h"
// Member `reportrxifstagedata`
#include "radar_msgs/msg/detail/rl_mon_rx_if_stage_rep__functions.h"
// Member `reportrxintanasigdata`
#include "radar_msgs/msg/detail/rl_mon_rx_int_ana_sig_rep__functions.h"
// Member `reportpmclklointanasigdata`
#include "radar_msgs/msg/detail/rl_mon_pmclklo_int_ana_sig_rep__functions.h"
// Member `reportgpadcintanasigdata`
#include "radar_msgs/msg/detail/rl_mon_gpadc_int_ana_sig_rep__functions.h"
// Member `reportpllconvoltdata`
#include "radar_msgs/msg/detail/rl_mon_pll_con_volt_rep__functions.h"
// Member `reportdccclkfreqdata`
#include "radar_msgs/msg/detail/rl_mon_dcc_clk_freq_rep__functions.h"
// Member `reportsynthfreqnonlivedata`
#include "radar_msgs/msg/detail/rl_mon_synth_freq_non_live_rep__functions.h"
// Member `reportrxmixrinpwrdata`
#include "radar_msgs/msg/detail/rl_mon_rx_mixr_in_pwr_rep__functions.h"
// Member `reporttxintanasigdata`
#include "radar_msgs/msg/detail/rl_mon_tx_int_ana_sig_rep__functions.h"
// Member `reportextanasigdata`
#include "radar_msgs/msg/detail/rl_mon_ext_ana_sig_rep__functions.h"
// Member `reportsynthfreqdata`
#include "radar_msgs/msg/detail/rl_mon_synth_freq_rep__functions.h"
// Member `reporttxphshiftdata`
#include "radar_msgs/msg/detail/rl_mon_tx_ph_shift_rep__functions.h"
// Member `reporttxgainphamisdata`
#include "radar_msgs/msg/detail/rl_mon_tx_gain_pha_mis_rep__functions.h"
// Member `reporttxballbreakdata`
#include "radar_msgs/msg/detail/rl_mon_tx_ball_break_rep__functions.h"
// Member `reporttxpowdata`
#include "radar_msgs/msg/detail/rl_mon_tx_pow_rep__functions.h"
// Member `reportrecvdgpadcdata`
#include "radar_msgs/msg/detail/rl_recvd_gp_adc_data__functions.h"
// Member `reportanalogfaultdata`
#include "radar_msgs/msg/detail/rl_analog_fault_report_data__functions.h"
// Member `reporttimingerrordata`
#include "radar_msgs/msg/detail/rl_cal_mon_timing_error_report_data__functions.h"

bool
radar_msgs__msg__RfStatus__init(radar_msgs__msg__RfStatus * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // radarid
  // framecnt
  // diglatentfaultdata
  if (!radar_msgs__msg__RlDigLatentFaultReportData__init(&msg->diglatentfaultdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reportheaderdata
  if (!radar_msgs__msg__RlMonReportHdrData__init(&msg->reportheaderdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reporttempdata
  if (!radar_msgs__msg__RlMonTempReportData__init(&msg->reporttempdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // digperiodicreportdata
  if (!radar_msgs__msg__RlDigPeriodicReportData__init(&msg->digperiodicreportdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reportrxgainphdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxGainPhRep__init(&msg->reportrxgainphdata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reportrxnoisefigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxNoiseFigRep__init(&msg->reportrxnoisefigdata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reportrxifstagedata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxIfStageRep__init(&msg->reportrxifstagedata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reportrxintanasigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxIntAnaSigRep__init(&msg->reportrxintanasigdata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reportpmclklointanasigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonPmclkloIntAnaSigRep__init(&msg->reportpmclklointanasigdata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reportgpadcintanasigdata
  if (!radar_msgs__msg__RlMonGpadcIntAnaSigRep__init(&msg->reportgpadcintanasigdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reportpllconvoltdata
  if (!radar_msgs__msg__RlMonPllConVoltRep__init(&msg->reportpllconvoltdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reportdccclkfreqdata
  if (!radar_msgs__msg__RlMonDccClkFreqRep__init(&msg->reportdccclkfreqdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reportsynthfreqnonlivedata
  if (!radar_msgs__msg__RlMonSynthFreqNonLiveRep__init(&msg->reportsynthfreqnonlivedata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reportrxmixrinpwrdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxMixrInPwrRep__init(&msg->reportrxmixrinpwrdata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reporttxintanasigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxIntAnaSigRep__init(&msg->reporttxintanasigdata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reportextanasigdata
  if (!radar_msgs__msg__RlMonExtAnaSigRep__init(&msg->reportextanasigdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reportsynthfreqdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonSynthFreqRep__init(&msg->reportsynthfreqdata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reporttxphshiftdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxPhShiftRep__init(&msg->reporttxphshiftdata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reporttxgainphamisdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxGainPhaMisRep__init(&msg->reporttxgainphamisdata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reporttxballbreakdata
  if (!radar_msgs__msg__RlMonTxBallBreakRep__init(&msg->reporttxballbreakdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reporttxpowdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxPowRep__init(&msg->reporttxpowdata[i])) {
      radar_msgs__msg__RfStatus__fini(msg);
      return false;
    }
  }
  // reportrecvdgpadcdata
  if (!radar_msgs__msg__RlRecvdGpAdcData__init(&msg->reportrecvdgpadcdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reportanalogfaultdata
  if (!radar_msgs__msg__RlAnalogFaultReportData__init(&msg->reportanalogfaultdata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  // reporttimingerrordata
  if (!radar_msgs__msg__RlCalMonTimingErrorReportData__init(&msg->reporttimingerrordata)) {
    radar_msgs__msg__RfStatus__fini(msg);
    return false;
  }
  return true;
}

void
radar_msgs__msg__RfStatus__fini(radar_msgs__msg__RfStatus * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // radarid
  // framecnt
  // diglatentfaultdata
  radar_msgs__msg__RlDigLatentFaultReportData__fini(&msg->diglatentfaultdata);
  // reportheaderdata
  radar_msgs__msg__RlMonReportHdrData__fini(&msg->reportheaderdata);
  // reporttempdata
  radar_msgs__msg__RlMonTempReportData__fini(&msg->reporttempdata);
  // digperiodicreportdata
  radar_msgs__msg__RlDigPeriodicReportData__fini(&msg->digperiodicreportdata);
  // reportrxgainphdata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonRxGainPhRep__fini(&msg->reportrxgainphdata[i]);
  }
  // reportrxnoisefigdata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonRxNoiseFigRep__fini(&msg->reportrxnoisefigdata[i]);
  }
  // reportrxifstagedata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonRxIfStageRep__fini(&msg->reportrxifstagedata[i]);
  }
  // reportrxintanasigdata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonRxIntAnaSigRep__fini(&msg->reportrxintanasigdata[i]);
  }
  // reportpmclklointanasigdata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonPmclkloIntAnaSigRep__fini(&msg->reportpmclklointanasigdata[i]);
  }
  // reportgpadcintanasigdata
  radar_msgs__msg__RlMonGpadcIntAnaSigRep__fini(&msg->reportgpadcintanasigdata);
  // reportpllconvoltdata
  radar_msgs__msg__RlMonPllConVoltRep__fini(&msg->reportpllconvoltdata);
  // reportdccclkfreqdata
  radar_msgs__msg__RlMonDccClkFreqRep__fini(&msg->reportdccclkfreqdata);
  // reportsynthfreqnonlivedata
  radar_msgs__msg__RlMonSynthFreqNonLiveRep__fini(&msg->reportsynthfreqnonlivedata);
  // reportrxmixrinpwrdata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonRxMixrInPwrRep__fini(&msg->reportrxmixrinpwrdata[i]);
  }
  // reporttxintanasigdata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonTxIntAnaSigRep__fini(&msg->reporttxintanasigdata[i]);
  }
  // reportextanasigdata
  radar_msgs__msg__RlMonExtAnaSigRep__fini(&msg->reportextanasigdata);
  // reportsynthfreqdata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonSynthFreqRep__fini(&msg->reportsynthfreqdata[i]);
  }
  // reporttxphshiftdata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonTxPhShiftRep__fini(&msg->reporttxphshiftdata[i]);
  }
  // reporttxgainphamisdata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonTxGainPhaMisRep__fini(&msg->reporttxgainphamisdata[i]);
  }
  // reporttxballbreakdata
  radar_msgs__msg__RlMonTxBallBreakRep__fini(&msg->reporttxballbreakdata);
  // reporttxpowdata
  for (size_t i = 0; i < 2; ++i) {
    radar_msgs__msg__RlMonTxPowRep__fini(&msg->reporttxpowdata[i]);
  }
  // reportrecvdgpadcdata
  radar_msgs__msg__RlRecvdGpAdcData__fini(&msg->reportrecvdgpadcdata);
  // reportanalogfaultdata
  radar_msgs__msg__RlAnalogFaultReportData__fini(&msg->reportanalogfaultdata);
  // reporttimingerrordata
  radar_msgs__msg__RlCalMonTimingErrorReportData__fini(&msg->reporttimingerrordata);
}

bool
radar_msgs__msg__RfStatus__are_equal(const radar_msgs__msg__RfStatus * lhs, const radar_msgs__msg__RfStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // radarid
  if (lhs->radarid != rhs->radarid) {
    return false;
  }
  // framecnt
  if (lhs->framecnt != rhs->framecnt) {
    return false;
  }
  // diglatentfaultdata
  if (!radar_msgs__msg__RlDigLatentFaultReportData__are_equal(
      &(lhs->diglatentfaultdata), &(rhs->diglatentfaultdata)))
  {
    return false;
  }
  // reportheaderdata
  if (!radar_msgs__msg__RlMonReportHdrData__are_equal(
      &(lhs->reportheaderdata), &(rhs->reportheaderdata)))
  {
    return false;
  }
  // reporttempdata
  if (!radar_msgs__msg__RlMonTempReportData__are_equal(
      &(lhs->reporttempdata), &(rhs->reporttempdata)))
  {
    return false;
  }
  // digperiodicreportdata
  if (!radar_msgs__msg__RlDigPeriodicReportData__are_equal(
      &(lhs->digperiodicreportdata), &(rhs->digperiodicreportdata)))
  {
    return false;
  }
  // reportrxgainphdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxGainPhRep__are_equal(
        &(lhs->reportrxgainphdata[i]), &(rhs->reportrxgainphdata[i])))
    {
      return false;
    }
  }
  // reportrxnoisefigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxNoiseFigRep__are_equal(
        &(lhs->reportrxnoisefigdata[i]), &(rhs->reportrxnoisefigdata[i])))
    {
      return false;
    }
  }
  // reportrxifstagedata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxIfStageRep__are_equal(
        &(lhs->reportrxifstagedata[i]), &(rhs->reportrxifstagedata[i])))
    {
      return false;
    }
  }
  // reportrxintanasigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxIntAnaSigRep__are_equal(
        &(lhs->reportrxintanasigdata[i]), &(rhs->reportrxintanasigdata[i])))
    {
      return false;
    }
  }
  // reportpmclklointanasigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonPmclkloIntAnaSigRep__are_equal(
        &(lhs->reportpmclklointanasigdata[i]), &(rhs->reportpmclklointanasigdata[i])))
    {
      return false;
    }
  }
  // reportgpadcintanasigdata
  if (!radar_msgs__msg__RlMonGpadcIntAnaSigRep__are_equal(
      &(lhs->reportgpadcintanasigdata), &(rhs->reportgpadcintanasigdata)))
  {
    return false;
  }
  // reportpllconvoltdata
  if (!radar_msgs__msg__RlMonPllConVoltRep__are_equal(
      &(lhs->reportpllconvoltdata), &(rhs->reportpllconvoltdata)))
  {
    return false;
  }
  // reportdccclkfreqdata
  if (!radar_msgs__msg__RlMonDccClkFreqRep__are_equal(
      &(lhs->reportdccclkfreqdata), &(rhs->reportdccclkfreqdata)))
  {
    return false;
  }
  // reportsynthfreqnonlivedata
  if (!radar_msgs__msg__RlMonSynthFreqNonLiveRep__are_equal(
      &(lhs->reportsynthfreqnonlivedata), &(rhs->reportsynthfreqnonlivedata)))
  {
    return false;
  }
  // reportrxmixrinpwrdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxMixrInPwrRep__are_equal(
        &(lhs->reportrxmixrinpwrdata[i]), &(rhs->reportrxmixrinpwrdata[i])))
    {
      return false;
    }
  }
  // reporttxintanasigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxIntAnaSigRep__are_equal(
        &(lhs->reporttxintanasigdata[i]), &(rhs->reporttxintanasigdata[i])))
    {
      return false;
    }
  }
  // reportextanasigdata
  if (!radar_msgs__msg__RlMonExtAnaSigRep__are_equal(
      &(lhs->reportextanasigdata), &(rhs->reportextanasigdata)))
  {
    return false;
  }
  // reportsynthfreqdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonSynthFreqRep__are_equal(
        &(lhs->reportsynthfreqdata[i]), &(rhs->reportsynthfreqdata[i])))
    {
      return false;
    }
  }
  // reporttxphshiftdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxPhShiftRep__are_equal(
        &(lhs->reporttxphshiftdata[i]), &(rhs->reporttxphshiftdata[i])))
    {
      return false;
    }
  }
  // reporttxgainphamisdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxGainPhaMisRep__are_equal(
        &(lhs->reporttxgainphamisdata[i]), &(rhs->reporttxgainphamisdata[i])))
    {
      return false;
    }
  }
  // reporttxballbreakdata
  if (!radar_msgs__msg__RlMonTxBallBreakRep__are_equal(
      &(lhs->reporttxballbreakdata), &(rhs->reporttxballbreakdata)))
  {
    return false;
  }
  // reporttxpowdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxPowRep__are_equal(
        &(lhs->reporttxpowdata[i]), &(rhs->reporttxpowdata[i])))
    {
      return false;
    }
  }
  // reportrecvdgpadcdata
  if (!radar_msgs__msg__RlRecvdGpAdcData__are_equal(
      &(lhs->reportrecvdgpadcdata), &(rhs->reportrecvdgpadcdata)))
  {
    return false;
  }
  // reportanalogfaultdata
  if (!radar_msgs__msg__RlAnalogFaultReportData__are_equal(
      &(lhs->reportanalogfaultdata), &(rhs->reportanalogfaultdata)))
  {
    return false;
  }
  // reporttimingerrordata
  if (!radar_msgs__msg__RlCalMonTimingErrorReportData__are_equal(
      &(lhs->reporttimingerrordata), &(rhs->reporttimingerrordata)))
  {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__RfStatus__copy(
  const radar_msgs__msg__RfStatus * input,
  radar_msgs__msg__RfStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // radarid
  output->radarid = input->radarid;
  // framecnt
  output->framecnt = input->framecnt;
  // diglatentfaultdata
  if (!radar_msgs__msg__RlDigLatentFaultReportData__copy(
      &(input->diglatentfaultdata), &(output->diglatentfaultdata)))
  {
    return false;
  }
  // reportheaderdata
  if (!radar_msgs__msg__RlMonReportHdrData__copy(
      &(input->reportheaderdata), &(output->reportheaderdata)))
  {
    return false;
  }
  // reporttempdata
  if (!radar_msgs__msg__RlMonTempReportData__copy(
      &(input->reporttempdata), &(output->reporttempdata)))
  {
    return false;
  }
  // digperiodicreportdata
  if (!radar_msgs__msg__RlDigPeriodicReportData__copy(
      &(input->digperiodicreportdata), &(output->digperiodicreportdata)))
  {
    return false;
  }
  // reportrxgainphdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxGainPhRep__copy(
        &(input->reportrxgainphdata[i]), &(output->reportrxgainphdata[i])))
    {
      return false;
    }
  }
  // reportrxnoisefigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxNoiseFigRep__copy(
        &(input->reportrxnoisefigdata[i]), &(output->reportrxnoisefigdata[i])))
    {
      return false;
    }
  }
  // reportrxifstagedata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxIfStageRep__copy(
        &(input->reportrxifstagedata[i]), &(output->reportrxifstagedata[i])))
    {
      return false;
    }
  }
  // reportrxintanasigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxIntAnaSigRep__copy(
        &(input->reportrxintanasigdata[i]), &(output->reportrxintanasigdata[i])))
    {
      return false;
    }
  }
  // reportpmclklointanasigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonPmclkloIntAnaSigRep__copy(
        &(input->reportpmclklointanasigdata[i]), &(output->reportpmclklointanasigdata[i])))
    {
      return false;
    }
  }
  // reportgpadcintanasigdata
  if (!radar_msgs__msg__RlMonGpadcIntAnaSigRep__copy(
      &(input->reportgpadcintanasigdata), &(output->reportgpadcintanasigdata)))
  {
    return false;
  }
  // reportpllconvoltdata
  if (!radar_msgs__msg__RlMonPllConVoltRep__copy(
      &(input->reportpllconvoltdata), &(output->reportpllconvoltdata)))
  {
    return false;
  }
  // reportdccclkfreqdata
  if (!radar_msgs__msg__RlMonDccClkFreqRep__copy(
      &(input->reportdccclkfreqdata), &(output->reportdccclkfreqdata)))
  {
    return false;
  }
  // reportsynthfreqnonlivedata
  if (!radar_msgs__msg__RlMonSynthFreqNonLiveRep__copy(
      &(input->reportsynthfreqnonlivedata), &(output->reportsynthfreqnonlivedata)))
  {
    return false;
  }
  // reportrxmixrinpwrdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonRxMixrInPwrRep__copy(
        &(input->reportrxmixrinpwrdata[i]), &(output->reportrxmixrinpwrdata[i])))
    {
      return false;
    }
  }
  // reporttxintanasigdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxIntAnaSigRep__copy(
        &(input->reporttxintanasigdata[i]), &(output->reporttxintanasigdata[i])))
    {
      return false;
    }
  }
  // reportextanasigdata
  if (!radar_msgs__msg__RlMonExtAnaSigRep__copy(
      &(input->reportextanasigdata), &(output->reportextanasigdata)))
  {
    return false;
  }
  // reportsynthfreqdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonSynthFreqRep__copy(
        &(input->reportsynthfreqdata[i]), &(output->reportsynthfreqdata[i])))
    {
      return false;
    }
  }
  // reporttxphshiftdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxPhShiftRep__copy(
        &(input->reporttxphshiftdata[i]), &(output->reporttxphshiftdata[i])))
    {
      return false;
    }
  }
  // reporttxgainphamisdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxGainPhaMisRep__copy(
        &(input->reporttxgainphamisdata[i]), &(output->reporttxgainphamisdata[i])))
    {
      return false;
    }
  }
  // reporttxballbreakdata
  if (!radar_msgs__msg__RlMonTxBallBreakRep__copy(
      &(input->reporttxballbreakdata), &(output->reporttxballbreakdata)))
  {
    return false;
  }
  // reporttxpowdata
  for (size_t i = 0; i < 2; ++i) {
    if (!radar_msgs__msg__RlMonTxPowRep__copy(
        &(input->reporttxpowdata[i]), &(output->reporttxpowdata[i])))
    {
      return false;
    }
  }
  // reportrecvdgpadcdata
  if (!radar_msgs__msg__RlRecvdGpAdcData__copy(
      &(input->reportrecvdgpadcdata), &(output->reportrecvdgpadcdata)))
  {
    return false;
  }
  // reportanalogfaultdata
  if (!radar_msgs__msg__RlAnalogFaultReportData__copy(
      &(input->reportanalogfaultdata), &(output->reportanalogfaultdata)))
  {
    return false;
  }
  // reporttimingerrordata
  if (!radar_msgs__msg__RlCalMonTimingErrorReportData__copy(
      &(input->reporttimingerrordata), &(output->reporttimingerrordata)))
  {
    return false;
  }
  return true;
}

radar_msgs__msg__RfStatus *
radar_msgs__msg__RfStatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RfStatus * msg = (radar_msgs__msg__RfStatus *)allocator.allocate(sizeof(radar_msgs__msg__RfStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__RfStatus));
  bool success = radar_msgs__msg__RfStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__RfStatus__destroy(radar_msgs__msg__RfStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__RfStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__RfStatus__Sequence__init(radar_msgs__msg__RfStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RfStatus * data = NULL;

  if (size) {
    data = (radar_msgs__msg__RfStatus *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__RfStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__RfStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__RfStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__RfStatus__Sequence__fini(radar_msgs__msg__RfStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__RfStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__RfStatus__Sequence *
radar_msgs__msg__RfStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RfStatus__Sequence * array = (radar_msgs__msg__RfStatus__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__RfStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__RfStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__RfStatus__Sequence__destroy(radar_msgs__msg__RfStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__RfStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__RfStatus__Sequence__are_equal(const radar_msgs__msg__RfStatus__Sequence * lhs, const radar_msgs__msg__RfStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__RfStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__RfStatus__Sequence__copy(
  const radar_msgs__msg__RfStatus__Sequence * input,
  radar_msgs__msg__RfStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__RfStatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__RfStatus * data =
      (radar_msgs__msg__RfStatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__RfStatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__RfStatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__RfStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
