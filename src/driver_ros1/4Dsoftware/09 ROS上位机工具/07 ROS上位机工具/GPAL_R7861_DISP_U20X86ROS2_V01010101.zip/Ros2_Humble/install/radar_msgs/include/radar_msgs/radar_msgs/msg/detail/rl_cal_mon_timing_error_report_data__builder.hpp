// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlCalMonTimingErrorReportData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_CAL_MON_TIMING_ERROR_REPORT_DATA__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_CAL_MON_TIMING_ERROR_REPORT_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_cal_mon_timing_error_report_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlCalMonTimingErrorReportData_reserved
{
public:
  explicit Init_RlCalMonTimingErrorReportData_reserved(::radar_msgs::msg::RlCalMonTimingErrorReportData & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlCalMonTimingErrorReportData reserved(::radar_msgs::msg::RlCalMonTimingErrorReportData::_reserved_type arg)
  {
    msg_.reserved = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlCalMonTimingErrorReportData msg_;
};

class Init_RlCalMonTimingErrorReportData_timingfailcode
{
public:
  Init_RlCalMonTimingErrorReportData_timingfailcode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlCalMonTimingErrorReportData_reserved timingfailcode(::radar_msgs::msg::RlCalMonTimingErrorReportData::_timingfailcode_type arg)
  {
    msg_.timingfailcode = std::move(arg);
    return Init_RlCalMonTimingErrorReportData_reserved(msg_);
  }

private:
  ::radar_msgs::msg::RlCalMonTimingErrorReportData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlCalMonTimingErrorReportData>()
{
  return radar_msgs::msg::builder::Init_RlCalMonTimingErrorReportData_timingfailcode();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_CAL_MON_TIMING_ERROR_REPORT_DATA__BUILDER_HPP_
