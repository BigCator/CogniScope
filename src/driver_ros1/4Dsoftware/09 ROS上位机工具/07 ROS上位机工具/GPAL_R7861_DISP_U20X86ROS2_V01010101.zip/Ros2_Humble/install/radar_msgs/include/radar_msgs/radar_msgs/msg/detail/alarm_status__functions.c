// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/AlarmStatus.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/alarm_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
radar_msgs__msg__AlarmStatus__init(radar_msgs__msg__AlarmStatus * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    radar_msgs__msg__AlarmStatus__fini(msg);
    return false;
  }
  // radarid
  // framecnt
  // alarmnum
  // alarmcode01
  // alarmcode02
  // alarmcode03
  // alarmcode04
  // alarmcode05
  // alarmcode06
  // alarmcode07
  // alarmcode08
  // alarmcode09
  // alarmcode10
  // alarmcode11
  // alarmcode12
  // alarmcode13
  // alarmcode14
  // alarmcode15
  // alarmcode16
  // alarmcode17
  // alarmcode18
  // alarmcode19
  // alarmcode20
  return true;
}

void
radar_msgs__msg__AlarmStatus__fini(radar_msgs__msg__AlarmStatus * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // radarid
  // framecnt
  // alarmnum
  // alarmcode01
  // alarmcode02
  // alarmcode03
  // alarmcode04
  // alarmcode05
  // alarmcode06
  // alarmcode07
  // alarmcode08
  // alarmcode09
  // alarmcode10
  // alarmcode11
  // alarmcode12
  // alarmcode13
  // alarmcode14
  // alarmcode15
  // alarmcode16
  // alarmcode17
  // alarmcode18
  // alarmcode19
  // alarmcode20
}

bool
radar_msgs__msg__AlarmStatus__are_equal(const radar_msgs__msg__AlarmStatus * lhs, const radar_msgs__msg__AlarmStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // radarid
  if (lhs->radarid != rhs->radarid) {
    return false;
  }
  // framecnt
  if (lhs->framecnt != rhs->framecnt) {
    return false;
  }
  // alarmnum
  if (lhs->alarmnum != rhs->alarmnum) {
    return false;
  }
  // alarmcode01
  if (lhs->alarmcode01 != rhs->alarmcode01) {
    return false;
  }
  // alarmcode02
  if (lhs->alarmcode02 != rhs->alarmcode02) {
    return false;
  }
  // alarmcode03
  if (lhs->alarmcode03 != rhs->alarmcode03) {
    return false;
  }
  // alarmcode04
  if (lhs->alarmcode04 != rhs->alarmcode04) {
    return false;
  }
  // alarmcode05
  if (lhs->alarmcode05 != rhs->alarmcode05) {
    return false;
  }
  // alarmcode06
  if (lhs->alarmcode06 != rhs->alarmcode06) {
    return false;
  }
  // alarmcode07
  if (lhs->alarmcode07 != rhs->alarmcode07) {
    return false;
  }
  // alarmcode08
  if (lhs->alarmcode08 != rhs->alarmcode08) {
    return false;
  }
  // alarmcode09
  if (lhs->alarmcode09 != rhs->alarmcode09) {
    return false;
  }
  // alarmcode10
  if (lhs->alarmcode10 != rhs->alarmcode10) {
    return false;
  }
  // alarmcode11
  if (lhs->alarmcode11 != rhs->alarmcode11) {
    return false;
  }
  // alarmcode12
  if (lhs->alarmcode12 != rhs->alarmcode12) {
    return false;
  }
  // alarmcode13
  if (lhs->alarmcode13 != rhs->alarmcode13) {
    return false;
  }
  // alarmcode14
  if (lhs->alarmcode14 != rhs->alarmcode14) {
    return false;
  }
  // alarmcode15
  if (lhs->alarmcode15 != rhs->alarmcode15) {
    return false;
  }
  // alarmcode16
  if (lhs->alarmcode16 != rhs->alarmcode16) {
    return false;
  }
  // alarmcode17
  if (lhs->alarmcode17 != rhs->alarmcode17) {
    return false;
  }
  // alarmcode18
  if (lhs->alarmcode18 != rhs->alarmcode18) {
    return false;
  }
  // alarmcode19
  if (lhs->alarmcode19 != rhs->alarmcode19) {
    return false;
  }
  // alarmcode20
  if (lhs->alarmcode20 != rhs->alarmcode20) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__AlarmStatus__copy(
  const radar_msgs__msg__AlarmStatus * input,
  radar_msgs__msg__AlarmStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // radarid
  output->radarid = input->radarid;
  // framecnt
  output->framecnt = input->framecnt;
  // alarmnum
  output->alarmnum = input->alarmnum;
  // alarmcode01
  output->alarmcode01 = input->alarmcode01;
  // alarmcode02
  output->alarmcode02 = input->alarmcode02;
  // alarmcode03
  output->alarmcode03 = input->alarmcode03;
  // alarmcode04
  output->alarmcode04 = input->alarmcode04;
  // alarmcode05
  output->alarmcode05 = input->alarmcode05;
  // alarmcode06
  output->alarmcode06 = input->alarmcode06;
  // alarmcode07
  output->alarmcode07 = input->alarmcode07;
  // alarmcode08
  output->alarmcode08 = input->alarmcode08;
  // alarmcode09
  output->alarmcode09 = input->alarmcode09;
  // alarmcode10
  output->alarmcode10 = input->alarmcode10;
  // alarmcode11
  output->alarmcode11 = input->alarmcode11;
  // alarmcode12
  output->alarmcode12 = input->alarmcode12;
  // alarmcode13
  output->alarmcode13 = input->alarmcode13;
  // alarmcode14
  output->alarmcode14 = input->alarmcode14;
  // alarmcode15
  output->alarmcode15 = input->alarmcode15;
  // alarmcode16
  output->alarmcode16 = input->alarmcode16;
  // alarmcode17
  output->alarmcode17 = input->alarmcode17;
  // alarmcode18
  output->alarmcode18 = input->alarmcode18;
  // alarmcode19
  output->alarmcode19 = input->alarmcode19;
  // alarmcode20
  output->alarmcode20 = input->alarmcode20;
  return true;
}

radar_msgs__msg__AlarmStatus *
radar_msgs__msg__AlarmStatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__AlarmStatus * msg = (radar_msgs__msg__AlarmStatus *)allocator.allocate(sizeof(radar_msgs__msg__AlarmStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__AlarmStatus));
  bool success = radar_msgs__msg__AlarmStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__AlarmStatus__destroy(radar_msgs__msg__AlarmStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__AlarmStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__AlarmStatus__Sequence__init(radar_msgs__msg__AlarmStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__AlarmStatus * data = NULL;

  if (size) {
    data = (radar_msgs__msg__AlarmStatus *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__AlarmStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__AlarmStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__AlarmStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__AlarmStatus__Sequence__fini(radar_msgs__msg__AlarmStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__AlarmStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__AlarmStatus__Sequence *
radar_msgs__msg__AlarmStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__AlarmStatus__Sequence * array = (radar_msgs__msg__AlarmStatus__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__AlarmStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__AlarmStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__AlarmStatus__Sequence__destroy(radar_msgs__msg__AlarmStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__AlarmStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__AlarmStatus__Sequence__are_equal(const radar_msgs__msg__AlarmStatus__Sequence * lhs, const radar_msgs__msg__AlarmStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__AlarmStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__AlarmStatus__Sequence__copy(
  const radar_msgs__msg__AlarmStatus__Sequence * input,
  radar_msgs__msg__AlarmStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__AlarmStatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__AlarmStatus * data =
      (radar_msgs__msg__AlarmStatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__AlarmStatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__AlarmStatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__AlarmStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
