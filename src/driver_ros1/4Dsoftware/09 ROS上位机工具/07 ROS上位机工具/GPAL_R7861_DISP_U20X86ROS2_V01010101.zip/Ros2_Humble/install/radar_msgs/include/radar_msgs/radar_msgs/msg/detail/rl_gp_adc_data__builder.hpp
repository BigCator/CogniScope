// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlGpAdcData.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_GP_ADC_DATA__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_GP_ADC_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_gp_adc_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlGpAdcData_avg
{
public:
  explicit Init_RlGpAdcData_avg(::radar_msgs::msg::RlGpAdcData & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlGpAdcData avg(::radar_msgs::msg::RlGpAdcData::_avg_type arg)
  {
    msg_.avg = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlGpAdcData msg_;
};

class Init_RlGpAdcData_max
{
public:
  explicit Init_RlGpAdcData_max(::radar_msgs::msg::RlGpAdcData & msg)
  : msg_(msg)
  {}
  Init_RlGpAdcData_avg max(::radar_msgs::msg::RlGpAdcData::_max_type arg)
  {
    msg_.max = std::move(arg);
    return Init_RlGpAdcData_avg(msg_);
  }

private:
  ::radar_msgs::msg::RlGpAdcData msg_;
};

class Init_RlGpAdcData_min
{
public:
  Init_RlGpAdcData_min()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlGpAdcData_max min(::radar_msgs::msg::RlGpAdcData::_min_type arg)
  {
    msg_.min = std::move(arg);
    return Init_RlGpAdcData_max(msg_);
  }

private:
  ::radar_msgs::msg::RlGpAdcData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlGpAdcData>()
{
  return radar_msgs::msg::builder::Init_RlGpAdcData_min();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_GP_ADC_DATA__BUILDER_HPP_
