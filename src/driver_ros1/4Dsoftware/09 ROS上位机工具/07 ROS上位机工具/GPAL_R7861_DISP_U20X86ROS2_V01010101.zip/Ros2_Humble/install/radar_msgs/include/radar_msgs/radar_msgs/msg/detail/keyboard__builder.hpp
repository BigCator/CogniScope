// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/Keyboard.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__KEYBOARD__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__KEYBOARD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/keyboard__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_Keyboard_key
{
public:
  explicit Init_Keyboard_key(::radar_msgs::msg::Keyboard & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::Keyboard key(::radar_msgs::msg::Keyboard::_key_type arg)
  {
    msg_.key = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::Keyboard msg_;
};

class Init_Keyboard_header
{
public:
  Init_Keyboard_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Keyboard_key header(::radar_msgs::msg::Keyboard::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Keyboard_key(msg_);
  }

private:
  ::radar_msgs::msg::Keyboard msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::Keyboard>()
{
  return radar_msgs::msg::builder::Init_Keyboard_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__KEYBOARD__BUILDER_HPP_
