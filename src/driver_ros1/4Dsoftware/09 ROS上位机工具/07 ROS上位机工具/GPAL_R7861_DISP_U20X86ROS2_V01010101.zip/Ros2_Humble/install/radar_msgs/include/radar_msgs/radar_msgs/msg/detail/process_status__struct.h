// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/ProcessStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/ProcessStatus in the package radar_msgs.
typedef struct radar_msgs__msg__ProcessStatus
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  /// radar ID
  uint32_t radar_id;
  /// frame cnt in radar
  uint32_t frame_cnt;
  /// LSB=ms
  float capture_time;
  uint32_t framelost_cnt;
  uint32_t adcerrcnt;
  uint32_t reserved_a;
  uint32_t reserved_b;
  /// LSB=ms
  float time1dfft;
  uint32_t reserved_c;
  uint32_t reserved_d;
  uint32_t reserved_e;
  uint32_t reserved_f;
  /// LSB=ms
  float time2dfft;
  uint32_t reserved_g;
  uint32_t reserved_h;
  uint32_t reserved_i;
  uint32_t reserved_j;
  /// LSB=ms
  float timerdmap;
  uint32_t reserved_k;
  uint32_t reserved_l;
  uint32_t reserved_m;
  uint32_t reserved_n;
  /// LSB=ms
  float timecfar;
  uint32_t reserved_o;
  uint32_t reserved_p;
  uint32_t reserved_q;
  uint32_t reserved_r;
  /// LSB=ms
  float timedoa;
  uint32_t reserved_s;
  uint32_t reserved_t;
  uint32_t reserved_u;
  uint32_t reserved_v;
  /// LSB=ms
  float timepcl;
  uint32_t reserved_w;
  uint32_t reserved_x;
  uint32_t reserved_y;
  uint32_t reserved_z;
  /// LSB=ms
  float timeod;
  uint32_t odtimeoutcnt;
  /// 0: cali fails; 1: pre-cali; 1~99: calibrating(in process); 100: cali success
  int32_t selfcalistatus;
  uint32_t reserved_aa;
  uint32_t reserved_ab;
  uint32_t reserved_ac;
  uint32_t reserved_ad;
} radar_msgs__msg__ProcessStatus;

// Struct for a sequence of radar_msgs__msg__ProcessStatus.
typedef struct radar_msgs__msg__ProcessStatus__Sequence
{
  radar_msgs__msg__ProcessStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__ProcessStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__STRUCT_H_
