// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RadarFeature.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RADAR_FEATURE__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RADAR_FEATURE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/radar_feature__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RadarFeature_azimuth
{
public:
  explicit Init_RadarFeature_azimuth(::radar_msgs::msg::RadarFeature & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RadarFeature azimuth(::radar_msgs::msg::RadarFeature::_azimuth_type arg)
  {
    msg_.azimuth = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RadarFeature msg_;
};

class Init_RadarFeature_v
{
public:
  explicit Init_RadarFeature_v(::radar_msgs::msg::RadarFeature & msg)
  : msg_(msg)
  {}
  Init_RadarFeature_azimuth v(::radar_msgs::msg::RadarFeature::_v_type arg)
  {
    msg_.v = std::move(arg);
    return Init_RadarFeature_azimuth(msg_);
  }

private:
  ::radar_msgs::msg::RadarFeature msg_;
};

class Init_RadarFeature_d
{
public:
  explicit Init_RadarFeature_d(::radar_msgs::msg::RadarFeature & msg)
  : msg_(msg)
  {}
  Init_RadarFeature_v d(::radar_msgs::msg::RadarFeature::_d_type arg)
  {
    msg_.d = std::move(arg);
    return Init_RadarFeature_v(msg_);
  }

private:
  ::radar_msgs::msg::RadarFeature msg_;
};

class Init_RadarFeature_target_num
{
public:
  explicit Init_RadarFeature_target_num(::radar_msgs::msg::RadarFeature & msg)
  : msg_(msg)
  {}
  Init_RadarFeature_d target_num(::radar_msgs::msg::RadarFeature::_target_num_type arg)
  {
    msg_.target_num = std::move(arg);
    return Init_RadarFeature_d(msg_);
  }

private:
  ::radar_msgs::msg::RadarFeature msg_;
};

class Init_RadarFeature_header
{
public:
  Init_RadarFeature_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RadarFeature_target_num header(::radar_msgs::msg::RadarFeature::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_RadarFeature_target_num(msg_);
  }

private:
  ::radar_msgs::msg::RadarFeature msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RadarFeature>()
{
  return radar_msgs::msg::builder::Init_RadarFeature_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RADAR_FEATURE__BUILDER_HPP_
