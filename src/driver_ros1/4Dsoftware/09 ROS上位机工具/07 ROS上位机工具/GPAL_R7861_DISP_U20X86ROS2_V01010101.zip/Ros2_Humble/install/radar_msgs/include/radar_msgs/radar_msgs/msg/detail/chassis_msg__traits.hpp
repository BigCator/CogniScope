// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/ChassisMsg.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/chassis_msg__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ChassisMsg & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: islessinfo
  {
    out << "islessinfo: ";
    rosidl_generator_traits::value_to_yaml(msg.islessinfo, out);
    out << ", ";
  }

  // member: reserved
  {
    out << "reserved: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved, out);
    out << ", ";
  }

  // member: vehdynyawratehsc2
  {
    out << "vehdynyawratehsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehdynyawratehsc2, out);
    out << ", ";
  }

  // member: vehdynyawratevhsc2
  {
    out << "vehdynyawratevhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehdynyawratevhsc2, out);
    out << ", ";
  }

  // member: trshftlvrpos_h1hsc2
  {
    out << "trshftlvrpos_h1hsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.trshftlvrpos_h1hsc2, out);
    out << ", ";
  }

  // member: trshftlvrposv_h1hsc2
  {
    out << "trshftlvrposv_h1hsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.trshftlvrposv_h1hsc2, out);
    out << ", ";
  }

  // member: vehspdavgdrvnhsc2
  {
    out << "vehspdavgdrvnhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehspdavgdrvnhsc2, out);
    out << ", ";
  }

  // member: vehspdavgdrvnvhsc2
  {
    out << "vehspdavgdrvnvhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehspdavgdrvnvhsc2, out);
    out << ", ";
  }

  // member: vehspdavgnondrvnhsc2
  {
    out << "vehspdavgnondrvnhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehspdavgnondrvnhsc2, out);
    out << ", ";
  }

  // member: vehspdavgnondrvnvhsc2
  {
    out << "vehspdavgnondrvnvhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehspdavgnondrvnvhsc2, out);
    out << ", ";
  }

  // member: strgwhlanghsc2
  {
    out << "strgwhlanghsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.strgwhlanghsc2, out);
    out << ", ";
  }

  // member: strgwhlangvhsc2
  {
    out << "strgwhlangvhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.strgwhlangvhsc2, out);
    out << ", ";
  }

  // member: ncounter
  {
    out << "ncounter: ";
    rosidl_generator_traits::value_to_yaml(msg.ncounter, out);
    out << ", ";
  }

  // member: itimestamp
  {
    out << "itimestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.itimestamp, out);
    out << ", ";
  }

  // member: flatitude
  {
    out << "flatitude: ";
    rosidl_generator_traits::value_to_yaml(msg.flatitude, out);
    out << ", ";
  }

  // member: flongitude
  {
    out << "flongitude: ";
    rosidl_generator_traits::value_to_yaml(msg.flongitude, out);
    out << ", ";
  }

  // member: faltitude
  {
    out << "faltitude: ";
    rosidl_generator_traits::value_to_yaml(msg.faltitude, out);
    out << ", ";
  }

  // member: faccx
  {
    out << "faccx: ";
    rosidl_generator_traits::value_to_yaml(msg.faccx, out);
    out << ", ";
  }

  // member: faccy
  {
    out << "faccy: ";
    rosidl_generator_traits::value_to_yaml(msg.faccy, out);
    out << ", ";
  }

  // member: faccz
  {
    out << "faccz: ";
    rosidl_generator_traits::value_to_yaml(msg.faccz, out);
    out << ", ";
  }

  // member: fangratex
  {
    out << "fangratex: ";
    rosidl_generator_traits::value_to_yaml(msg.fangratex, out);
    out << ", ";
  }

  // member: fangratey
  {
    out << "fangratey: ";
    rosidl_generator_traits::value_to_yaml(msg.fangratey, out);
    out << ", ";
  }

  // member: fangratez
  {
    out << "fangratez: ";
    rosidl_generator_traits::value_to_yaml(msg.fangratez, out);
    out << ", ";
  }

  // member: fvelnorth
  {
    out << "fvelnorth: ";
    rosidl_generator_traits::value_to_yaml(msg.fvelnorth, out);
    out << ", ";
  }

  // member: fvelwest
  {
    out << "fvelwest: ";
    rosidl_generator_traits::value_to_yaml(msg.fvelwest, out);
    out << ", ";
  }

  // member: fvelup
  {
    out << "fvelup: ";
    rosidl_generator_traits::value_to_yaml(msg.fvelup, out);
    out << ", ";
  }

  // member: fheading
  {
    out << "fheading: ";
    rosidl_generator_traits::value_to_yaml(msg.fheading, out);
    out << ", ";
  }

  // member: fpitch
  {
    out << "fpitch: ";
    rosidl_generator_traits::value_to_yaml(msg.fpitch, out);
    out << ", ";
  }

  // member: froll
  {
    out << "froll: ";
    rosidl_generator_traits::value_to_yaml(msg.froll, out);
    out << ", ";
  }

  // member: nnavstatus
  {
    out << "nnavstatus: ";
    rosidl_generator_traits::value_to_yaml(msg.nnavstatus, out);
    out << ", ";
  }

  // member: vtimestamp
  {
    out << "vtimestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.vtimestamp, out);
    out << ", ";
  }

  // member: fsteeringangle
  {
    out << "fsteeringangle: ";
    rosidl_generator_traits::value_to_yaml(msg.fsteeringangle, out);
    out << ", ";
  }

  // member: fspeed
  {
    out << "fspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.fspeed, out);
    out << ", ";
  }

  // member: fyawrate
  {
    out << "fyawrate: ";
    rosidl_generator_traits::value_to_yaml(msg.fyawrate, out);
    out << ", ";
  }

  // member: ffrontleftwheelspeed
  {
    out << "ffrontleftwheelspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.ffrontleftwheelspeed, out);
    out << ", ";
  }

  // member: ffrontrightwheelspeed
  {
    out << "ffrontrightwheelspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.ffrontrightwheelspeed, out);
    out << ", ";
  }

  // member: frearleftwheelspeed
  {
    out << "frearleftwheelspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.frearleftwheelspeed, out);
    out << ", ";
  }

  // member: frearrightwheelspeed
  {
    out << "frearrightwheelspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.frearrightwheelspeed, out);
    out << ", ";
  }

  // member: nshifterposition
  {
    out << "nshifterposition: ";
    rosidl_generator_traits::value_to_yaml(msg.nshifterposition, out);
    out << ", ";
  }

  // member: nleftdirectionlamp
  {
    out << "nleftdirectionlamp: ";
    rosidl_generator_traits::value_to_yaml(msg.nleftdirectionlamp, out);
    out << ", ";
  }

  // member: nrightdirectionlamp
  {
    out << "nrightdirectionlamp: ";
    rosidl_generator_traits::value_to_yaml(msg.nrightdirectionlamp, out);
    out << ", ";
  }

  // member: nmainbeamlamp
  {
    out << "nmainbeamlamp: ";
    rosidl_generator_traits::value_to_yaml(msg.nmainbeamlamp, out);
    out << ", ";
  }

  // member: ndippedbeamlamp
  {
    out << "ndippedbeamlamp: ";
    rosidl_generator_traits::value_to_yaml(msg.ndippedbeamlamp, out);
    out << ", ";
  }

  // member: nwiperstate
  {
    out << "nwiperstate: ";
    rosidl_generator_traits::value_to_yaml(msg.nwiperstate, out);
    out << ", ";
  }

  // member: flateralaccel
  {
    out << "flateralaccel: ";
    rosidl_generator_traits::value_to_yaml(msg.flateralaccel, out);
    out << ", ";
  }

  // member: flongituaccel
  {
    out << "flongituaccel: ";
    rosidl_generator_traits::value_to_yaml(msg.flongituaccel, out);
    out << ", ";
  }

  // member: nleftdrivenwheelpulsecounters
  {
    out << "nleftdrivenwheelpulsecounters: ";
    rosidl_generator_traits::value_to_yaml(msg.nleftdrivenwheelpulsecounters, out);
    out << ", ";
  }

  // member: nrightdrivenwheelpulsecounters
  {
    out << "nrightdrivenwheelpulsecounters: ";
    rosidl_generator_traits::value_to_yaml(msg.nrightdrivenwheelpulsecounters, out);
    out << ", ";
  }

  // member: nleftnondrivenwheelpulsecounters
  {
    out << "nleftnondrivenwheelpulsecounters: ";
    rosidl_generator_traits::value_to_yaml(msg.nleftnondrivenwheelpulsecounters, out);
    out << ", ";
  }

  // member: nrightnondrivenwheelpulsecounters
  {
    out << "nrightnondrivenwheelpulsecounters: ";
    rosidl_generator_traits::value_to_yaml(msg.nrightnondrivenwheelpulsecounters, out);
    out << ", ";
  }

  // member: ndrivemode
  {
    out << "ndrivemode: ";
    rosidl_generator_traits::value_to_yaml(msg.ndrivemode, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ChassisMsg & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: islessinfo
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "islessinfo: ";
    rosidl_generator_traits::value_to_yaml(msg.islessinfo, out);
    out << "\n";
  }

  // member: reserved
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved, out);
    out << "\n";
  }

  // member: vehdynyawratehsc2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vehdynyawratehsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehdynyawratehsc2, out);
    out << "\n";
  }

  // member: vehdynyawratevhsc2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vehdynyawratevhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehdynyawratevhsc2, out);
    out << "\n";
  }

  // member: trshftlvrpos_h1hsc2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "trshftlvrpos_h1hsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.trshftlvrpos_h1hsc2, out);
    out << "\n";
  }

  // member: trshftlvrposv_h1hsc2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "trshftlvrposv_h1hsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.trshftlvrposv_h1hsc2, out);
    out << "\n";
  }

  // member: vehspdavgdrvnhsc2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vehspdavgdrvnhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehspdavgdrvnhsc2, out);
    out << "\n";
  }

  // member: vehspdavgdrvnvhsc2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vehspdavgdrvnvhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehspdavgdrvnvhsc2, out);
    out << "\n";
  }

  // member: vehspdavgnondrvnhsc2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vehspdavgnondrvnhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehspdavgnondrvnhsc2, out);
    out << "\n";
  }

  // member: vehspdavgnondrvnvhsc2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vehspdavgnondrvnvhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.vehspdavgnondrvnvhsc2, out);
    out << "\n";
  }

  // member: strgwhlanghsc2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "strgwhlanghsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.strgwhlanghsc2, out);
    out << "\n";
  }

  // member: strgwhlangvhsc2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "strgwhlangvhsc2: ";
    rosidl_generator_traits::value_to_yaml(msg.strgwhlangvhsc2, out);
    out << "\n";
  }

  // member: ncounter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ncounter: ";
    rosidl_generator_traits::value_to_yaml(msg.ncounter, out);
    out << "\n";
  }

  // member: itimestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "itimestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.itimestamp, out);
    out << "\n";
  }

  // member: flatitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "flatitude: ";
    rosidl_generator_traits::value_to_yaml(msg.flatitude, out);
    out << "\n";
  }

  // member: flongitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "flongitude: ";
    rosidl_generator_traits::value_to_yaml(msg.flongitude, out);
    out << "\n";
  }

  // member: faltitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "faltitude: ";
    rosidl_generator_traits::value_to_yaml(msg.faltitude, out);
    out << "\n";
  }

  // member: faccx
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "faccx: ";
    rosidl_generator_traits::value_to_yaml(msg.faccx, out);
    out << "\n";
  }

  // member: faccy
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "faccy: ";
    rosidl_generator_traits::value_to_yaml(msg.faccy, out);
    out << "\n";
  }

  // member: faccz
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "faccz: ";
    rosidl_generator_traits::value_to_yaml(msg.faccz, out);
    out << "\n";
  }

  // member: fangratex
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fangratex: ";
    rosidl_generator_traits::value_to_yaml(msg.fangratex, out);
    out << "\n";
  }

  // member: fangratey
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fangratey: ";
    rosidl_generator_traits::value_to_yaml(msg.fangratey, out);
    out << "\n";
  }

  // member: fangratez
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fangratez: ";
    rosidl_generator_traits::value_to_yaml(msg.fangratez, out);
    out << "\n";
  }

  // member: fvelnorth
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fvelnorth: ";
    rosidl_generator_traits::value_to_yaml(msg.fvelnorth, out);
    out << "\n";
  }

  // member: fvelwest
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fvelwest: ";
    rosidl_generator_traits::value_to_yaml(msg.fvelwest, out);
    out << "\n";
  }

  // member: fvelup
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fvelup: ";
    rosidl_generator_traits::value_to_yaml(msg.fvelup, out);
    out << "\n";
  }

  // member: fheading
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fheading: ";
    rosidl_generator_traits::value_to_yaml(msg.fheading, out);
    out << "\n";
  }

  // member: fpitch
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fpitch: ";
    rosidl_generator_traits::value_to_yaml(msg.fpitch, out);
    out << "\n";
  }

  // member: froll
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "froll: ";
    rosidl_generator_traits::value_to_yaml(msg.froll, out);
    out << "\n";
  }

  // member: nnavstatus
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nnavstatus: ";
    rosidl_generator_traits::value_to_yaml(msg.nnavstatus, out);
    out << "\n";
  }

  // member: vtimestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vtimestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.vtimestamp, out);
    out << "\n";
  }

  // member: fsteeringangle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fsteeringangle: ";
    rosidl_generator_traits::value_to_yaml(msg.fsteeringangle, out);
    out << "\n";
  }

  // member: fspeed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.fspeed, out);
    out << "\n";
  }

  // member: fyawrate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fyawrate: ";
    rosidl_generator_traits::value_to_yaml(msg.fyawrate, out);
    out << "\n";
  }

  // member: ffrontleftwheelspeed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ffrontleftwheelspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.ffrontleftwheelspeed, out);
    out << "\n";
  }

  // member: ffrontrightwheelspeed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ffrontrightwheelspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.ffrontrightwheelspeed, out);
    out << "\n";
  }

  // member: frearleftwheelspeed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frearleftwheelspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.frearleftwheelspeed, out);
    out << "\n";
  }

  // member: frearrightwheelspeed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frearrightwheelspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.frearrightwheelspeed, out);
    out << "\n";
  }

  // member: nshifterposition
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nshifterposition: ";
    rosidl_generator_traits::value_to_yaml(msg.nshifterposition, out);
    out << "\n";
  }

  // member: nleftdirectionlamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nleftdirectionlamp: ";
    rosidl_generator_traits::value_to_yaml(msg.nleftdirectionlamp, out);
    out << "\n";
  }

  // member: nrightdirectionlamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nrightdirectionlamp: ";
    rosidl_generator_traits::value_to_yaml(msg.nrightdirectionlamp, out);
    out << "\n";
  }

  // member: nmainbeamlamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nmainbeamlamp: ";
    rosidl_generator_traits::value_to_yaml(msg.nmainbeamlamp, out);
    out << "\n";
  }

  // member: ndippedbeamlamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ndippedbeamlamp: ";
    rosidl_generator_traits::value_to_yaml(msg.ndippedbeamlamp, out);
    out << "\n";
  }

  // member: nwiperstate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nwiperstate: ";
    rosidl_generator_traits::value_to_yaml(msg.nwiperstate, out);
    out << "\n";
  }

  // member: flateralaccel
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "flateralaccel: ";
    rosidl_generator_traits::value_to_yaml(msg.flateralaccel, out);
    out << "\n";
  }

  // member: flongituaccel
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "flongituaccel: ";
    rosidl_generator_traits::value_to_yaml(msg.flongituaccel, out);
    out << "\n";
  }

  // member: nleftdrivenwheelpulsecounters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nleftdrivenwheelpulsecounters: ";
    rosidl_generator_traits::value_to_yaml(msg.nleftdrivenwheelpulsecounters, out);
    out << "\n";
  }

  // member: nrightdrivenwheelpulsecounters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nrightdrivenwheelpulsecounters: ";
    rosidl_generator_traits::value_to_yaml(msg.nrightdrivenwheelpulsecounters, out);
    out << "\n";
  }

  // member: nleftnondrivenwheelpulsecounters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nleftnondrivenwheelpulsecounters: ";
    rosidl_generator_traits::value_to_yaml(msg.nleftnondrivenwheelpulsecounters, out);
    out << "\n";
  }

  // member: nrightnondrivenwheelpulsecounters
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nrightnondrivenwheelpulsecounters: ";
    rosidl_generator_traits::value_to_yaml(msg.nrightnondrivenwheelpulsecounters, out);
    out << "\n";
  }

  // member: ndrivemode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ndrivemode: ";
    rosidl_generator_traits::value_to_yaml(msg.ndrivemode, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ChassisMsg & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::ChassisMsg & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::ChassisMsg & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::ChassisMsg>()
{
  return "radar_msgs::msg::ChassisMsg";
}

template<>
inline const char * name<radar_msgs::msg::ChassisMsg>()
{
  return "radar_msgs/msg/ChassisMsg";
}

template<>
struct has_fixed_size<radar_msgs::msg::ChassisMsg>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<radar_msgs::msg::ChassisMsg>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<radar_msgs::msg::ChassisMsg>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__CHASSIS_MSG__TRAITS_HPP_
