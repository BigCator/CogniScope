// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__RL_MON_GPADC_INT_ANA_SIG_REP_HPP_
#define RADAR_MSGS__MSG__RL_MON_GPADC_INT_ANA_SIG_REP_HPP_

#include "radar_msgs/msg/detail/rl_mon_gpadc_int_ana_sig_rep__struct.hpp"
#include "radar_msgs/msg/detail/rl_mon_gpadc_int_ana_sig_rep__builder.hpp"
#include "radar_msgs/msg/detail/rl_mon_gpadc_int_ana_sig_rep__traits.hpp"

#endif  // RADAR_MSGS__MSG__RL_MON_GPADC_INT_ANA_SIG_REP_HPP_
