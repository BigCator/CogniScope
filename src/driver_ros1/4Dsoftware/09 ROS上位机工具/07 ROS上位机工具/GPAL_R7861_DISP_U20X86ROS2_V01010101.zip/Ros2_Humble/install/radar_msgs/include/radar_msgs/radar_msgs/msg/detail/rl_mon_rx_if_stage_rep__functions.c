// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/RlMonRxIfStageRep.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/rl_mon_rx_if_stage_rep__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
radar_msgs__msg__RlMonRxIfStageRep__init(radar_msgs__msg__RlMonRxIfStageRep * msg)
{
  if (!msg) {
    return false;
  }
  // statusflags
  // errorcode
  // profindex
  // reserved0
  // lpfcutoffbandedgedroopvalrx0
  // hpfcutofffreqer
  // lpfcutoffstopbandatten
  // rxifagainerval
  // ifgainexp
  // reserved2
  // lpfcutoffbandedgedroopvalrx
  // timestamp
  return true;
}

void
radar_msgs__msg__RlMonRxIfStageRep__fini(radar_msgs__msg__RlMonRxIfStageRep * msg)
{
  if (!msg) {
    return;
  }
  // statusflags
  // errorcode
  // profindex
  // reserved0
  // lpfcutoffbandedgedroopvalrx0
  // hpfcutofffreqer
  // lpfcutoffstopbandatten
  // rxifagainerval
  // ifgainexp
  // reserved2
  // lpfcutoffbandedgedroopvalrx
  // timestamp
}

bool
radar_msgs__msg__RlMonRxIfStageRep__are_equal(const radar_msgs__msg__RlMonRxIfStageRep * lhs, const radar_msgs__msg__RlMonRxIfStageRep * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // statusflags
  if (lhs->statusflags != rhs->statusflags) {
    return false;
  }
  // errorcode
  if (lhs->errorcode != rhs->errorcode) {
    return false;
  }
  // profindex
  if (lhs->profindex != rhs->profindex) {
    return false;
  }
  // reserved0
  if (lhs->reserved0 != rhs->reserved0) {
    return false;
  }
  // lpfcutoffbandedgedroopvalrx0
  if (lhs->lpfcutoffbandedgedroopvalrx0 != rhs->lpfcutoffbandedgedroopvalrx0) {
    return false;
  }
  // hpfcutofffreqer
  for (size_t i = 0; i < 8; ++i) {
    if (lhs->hpfcutofffreqer[i] != rhs->hpfcutofffreqer[i]) {
      return false;
    }
  }
  // lpfcutoffstopbandatten
  for (size_t i = 0; i < 8; ++i) {
    if (lhs->lpfcutoffstopbandatten[i] != rhs->lpfcutoffstopbandatten[i]) {
      return false;
    }
  }
  // rxifagainerval
  for (size_t i = 0; i < 8; ++i) {
    if (lhs->rxifagainerval[i] != rhs->rxifagainerval[i]) {
      return false;
    }
  }
  // ifgainexp
  if (lhs->ifgainexp != rhs->ifgainexp) {
    return false;
  }
  // reserved2
  if (lhs->reserved2 != rhs->reserved2) {
    return false;
  }
  // lpfcutoffbandedgedroopvalrx
  for (size_t i = 0; i < 6; ++i) {
    if (lhs->lpfcutoffbandedgedroopvalrx[i] != rhs->lpfcutoffbandedgedroopvalrx[i]) {
      return false;
    }
  }
  // timestamp
  if (lhs->timestamp != rhs->timestamp) {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__RlMonRxIfStageRep__copy(
  const radar_msgs__msg__RlMonRxIfStageRep * input,
  radar_msgs__msg__RlMonRxIfStageRep * output)
{
  if (!input || !output) {
    return false;
  }
  // statusflags
  output->statusflags = input->statusflags;
  // errorcode
  output->errorcode = input->errorcode;
  // profindex
  output->profindex = input->profindex;
  // reserved0
  output->reserved0 = input->reserved0;
  // lpfcutoffbandedgedroopvalrx0
  output->lpfcutoffbandedgedroopvalrx0 = input->lpfcutoffbandedgedroopvalrx0;
  // hpfcutofffreqer
  for (size_t i = 0; i < 8; ++i) {
    output->hpfcutofffreqer[i] = input->hpfcutofffreqer[i];
  }
  // lpfcutoffstopbandatten
  for (size_t i = 0; i < 8; ++i) {
    output->lpfcutoffstopbandatten[i] = input->lpfcutoffstopbandatten[i];
  }
  // rxifagainerval
  for (size_t i = 0; i < 8; ++i) {
    output->rxifagainerval[i] = input->rxifagainerval[i];
  }
  // ifgainexp
  output->ifgainexp = input->ifgainexp;
  // reserved2
  output->reserved2 = input->reserved2;
  // lpfcutoffbandedgedroopvalrx
  for (size_t i = 0; i < 6; ++i) {
    output->lpfcutoffbandedgedroopvalrx[i] = input->lpfcutoffbandedgedroopvalrx[i];
  }
  // timestamp
  output->timestamp = input->timestamp;
  return true;
}

radar_msgs__msg__RlMonRxIfStageRep *
radar_msgs__msg__RlMonRxIfStageRep__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RlMonRxIfStageRep * msg = (radar_msgs__msg__RlMonRxIfStageRep *)allocator.allocate(sizeof(radar_msgs__msg__RlMonRxIfStageRep), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__RlMonRxIfStageRep));
  bool success = radar_msgs__msg__RlMonRxIfStageRep__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__RlMonRxIfStageRep__destroy(radar_msgs__msg__RlMonRxIfStageRep * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__RlMonRxIfStageRep__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__RlMonRxIfStageRep__Sequence__init(radar_msgs__msg__RlMonRxIfStageRep__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RlMonRxIfStageRep * data = NULL;

  if (size) {
    data = (radar_msgs__msg__RlMonRxIfStageRep *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__RlMonRxIfStageRep), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__RlMonRxIfStageRep__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__RlMonRxIfStageRep__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__RlMonRxIfStageRep__Sequence__fini(radar_msgs__msg__RlMonRxIfStageRep__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__RlMonRxIfStageRep__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__RlMonRxIfStageRep__Sequence *
radar_msgs__msg__RlMonRxIfStageRep__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__RlMonRxIfStageRep__Sequence * array = (radar_msgs__msg__RlMonRxIfStageRep__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__RlMonRxIfStageRep__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__RlMonRxIfStageRep__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__RlMonRxIfStageRep__Sequence__destroy(radar_msgs__msg__RlMonRxIfStageRep__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__RlMonRxIfStageRep__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__RlMonRxIfStageRep__Sequence__are_equal(const radar_msgs__msg__RlMonRxIfStageRep__Sequence * lhs, const radar_msgs__msg__RlMonRxIfStageRep__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__RlMonRxIfStageRep__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__RlMonRxIfStageRep__Sequence__copy(
  const radar_msgs__msg__RlMonRxIfStageRep__Sequence * input,
  radar_msgs__msg__RlMonRxIfStageRep__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__RlMonRxIfStageRep);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__RlMonRxIfStageRep * data =
      (radar_msgs__msg__RlMonRxIfStageRep *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__RlMonRxIfStageRep__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__RlMonRxIfStageRep__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__RlMonRxIfStageRep__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
