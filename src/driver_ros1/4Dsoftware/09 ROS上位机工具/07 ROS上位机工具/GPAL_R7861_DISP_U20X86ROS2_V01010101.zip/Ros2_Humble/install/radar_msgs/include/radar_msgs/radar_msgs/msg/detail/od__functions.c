// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from radar_msgs:msg/Od.idl
// generated code does not contain a copyright notice
#include "radar_msgs/msg/detail/od__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `pose`
// Member `pose_nearest`
#include "geometry_msgs/msg/detail/pose__functions.h"
// Member `dimensions`
#include "geometry_msgs/msg/detail/vector3__functions.h"
// Member `velocity`
// Member `acceleration`
// Member `v2ground`
#include "geometry_msgs/msg/detail/twist__functions.h"
// Member `reserved_o`
// Member `reserved_p`
#include "rosidl_runtime_c/string_functions.h"

bool
radar_msgs__msg__Od__init(radar_msgs__msg__Od * msg)
{
  if (!msg) {
    return false;
  }
  // object_id
  // age
  // measurement_status
  // motion_state
  // existance_confidence
  // pose
  if (!geometry_msgs__msg__Pose__init(&msg->pose)) {
    radar_msgs__msg__Od__fini(msg);
    return false;
  }
  // dimensions
  if (!geometry_msgs__msg__Vector3__init(&msg->dimensions)) {
    radar_msgs__msg__Od__fini(msg);
    return false;
  }
  // velocity
  if (!geometry_msgs__msg__Twist__init(&msg->velocity)) {
    radar_msgs__msg__Od__fini(msg);
    return false;
  }
  // acceleration
  if (!geometry_msgs__msg__Twist__init(&msg->acceleration)) {
    radar_msgs__msg__Od__fini(msg);
    return false;
  }
  // v2ground
  if (!geometry_msgs__msg__Twist__init(&msg->v2ground)) {
    radar_msgs__msg__Od__fini(msg);
    return false;
  }
  // pose_nearest
  if (!geometry_msgs__msg__Pose__init(&msg->pose_nearest)) {
    radar_msgs__msg__Od__fini(msg);
    return false;
  }
  // type
  // car_confidence
  // bike_confidence
  // ped_confidence
  // truck_confidence
  // signboard_confidence
  // ground_confidence
  // obstacle_confidence
  // enrollptsnum
  // nearestptsx
  // nearestptsy
  // nearestptsz
  // reserved_d
  // reserved_e
  // reserved_f
  // reserved_g
  // reserved_h
  // reserved_i
  // reserved_j
  // reserved_k
  // reserved_l
  // reserved_m
  // reserved_n
  // reserved_o
  if (!rosidl_runtime_c__String__init(&msg->reserved_o)) {
    radar_msgs__msg__Od__fini(msg);
    return false;
  }
  // reserved_p
  if (!rosidl_runtime_c__String__init(&msg->reserved_p)) {
    radar_msgs__msg__Od__fini(msg);
    return false;
  }
  return true;
}

void
radar_msgs__msg__Od__fini(radar_msgs__msg__Od * msg)
{
  if (!msg) {
    return;
  }
  // object_id
  // age
  // measurement_status
  // motion_state
  // existance_confidence
  // pose
  geometry_msgs__msg__Pose__fini(&msg->pose);
  // dimensions
  geometry_msgs__msg__Vector3__fini(&msg->dimensions);
  // velocity
  geometry_msgs__msg__Twist__fini(&msg->velocity);
  // acceleration
  geometry_msgs__msg__Twist__fini(&msg->acceleration);
  // v2ground
  geometry_msgs__msg__Twist__fini(&msg->v2ground);
  // pose_nearest
  geometry_msgs__msg__Pose__fini(&msg->pose_nearest);
  // type
  // car_confidence
  // bike_confidence
  // ped_confidence
  // truck_confidence
  // signboard_confidence
  // ground_confidence
  // obstacle_confidence
  // enrollptsnum
  // nearestptsx
  // nearestptsy
  // nearestptsz
  // reserved_d
  // reserved_e
  // reserved_f
  // reserved_g
  // reserved_h
  // reserved_i
  // reserved_j
  // reserved_k
  // reserved_l
  // reserved_m
  // reserved_n
  // reserved_o
  rosidl_runtime_c__String__fini(&msg->reserved_o);
  // reserved_p
  rosidl_runtime_c__String__fini(&msg->reserved_p);
}

bool
radar_msgs__msg__Od__are_equal(const radar_msgs__msg__Od * lhs, const radar_msgs__msg__Od * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // object_id
  if (lhs->object_id != rhs->object_id) {
    return false;
  }
  // age
  if (lhs->age != rhs->age) {
    return false;
  }
  // measurement_status
  if (lhs->measurement_status != rhs->measurement_status) {
    return false;
  }
  // motion_state
  if (lhs->motion_state != rhs->motion_state) {
    return false;
  }
  // existance_confidence
  if (lhs->existance_confidence != rhs->existance_confidence) {
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__are_equal(
      &(lhs->pose), &(rhs->pose)))
  {
    return false;
  }
  // dimensions
  if (!geometry_msgs__msg__Vector3__are_equal(
      &(lhs->dimensions), &(rhs->dimensions)))
  {
    return false;
  }
  // velocity
  if (!geometry_msgs__msg__Twist__are_equal(
      &(lhs->velocity), &(rhs->velocity)))
  {
    return false;
  }
  // acceleration
  if (!geometry_msgs__msg__Twist__are_equal(
      &(lhs->acceleration), &(rhs->acceleration)))
  {
    return false;
  }
  // v2ground
  if (!geometry_msgs__msg__Twist__are_equal(
      &(lhs->v2ground), &(rhs->v2ground)))
  {
    return false;
  }
  // pose_nearest
  if (!geometry_msgs__msg__Pose__are_equal(
      &(lhs->pose_nearest), &(rhs->pose_nearest)))
  {
    return false;
  }
  // type
  if (lhs->type != rhs->type) {
    return false;
  }
  // car_confidence
  if (lhs->car_confidence != rhs->car_confidence) {
    return false;
  }
  // bike_confidence
  if (lhs->bike_confidence != rhs->bike_confidence) {
    return false;
  }
  // ped_confidence
  if (lhs->ped_confidence != rhs->ped_confidence) {
    return false;
  }
  // truck_confidence
  if (lhs->truck_confidence != rhs->truck_confidence) {
    return false;
  }
  // signboard_confidence
  if (lhs->signboard_confidence != rhs->signboard_confidence) {
    return false;
  }
  // ground_confidence
  if (lhs->ground_confidence != rhs->ground_confidence) {
    return false;
  }
  // obstacle_confidence
  if (lhs->obstacle_confidence != rhs->obstacle_confidence) {
    return false;
  }
  // enrollptsnum
  if (lhs->enrollptsnum != rhs->enrollptsnum) {
    return false;
  }
  // nearestptsx
  if (lhs->nearestptsx != rhs->nearestptsx) {
    return false;
  }
  // nearestptsy
  if (lhs->nearestptsy != rhs->nearestptsy) {
    return false;
  }
  // nearestptsz
  if (lhs->nearestptsz != rhs->nearestptsz) {
    return false;
  }
  // reserved_d
  if (lhs->reserved_d != rhs->reserved_d) {
    return false;
  }
  // reserved_e
  if (lhs->reserved_e != rhs->reserved_e) {
    return false;
  }
  // reserved_f
  if (lhs->reserved_f != rhs->reserved_f) {
    return false;
  }
  // reserved_g
  if (lhs->reserved_g != rhs->reserved_g) {
    return false;
  }
  // reserved_h
  if (lhs->reserved_h != rhs->reserved_h) {
    return false;
  }
  // reserved_i
  if (lhs->reserved_i != rhs->reserved_i) {
    return false;
  }
  // reserved_j
  if (lhs->reserved_j != rhs->reserved_j) {
    return false;
  }
  // reserved_k
  if (lhs->reserved_k != rhs->reserved_k) {
    return false;
  }
  // reserved_l
  if (lhs->reserved_l != rhs->reserved_l) {
    return false;
  }
  // reserved_m
  if (lhs->reserved_m != rhs->reserved_m) {
    return false;
  }
  // reserved_n
  if (lhs->reserved_n != rhs->reserved_n) {
    return false;
  }
  // reserved_o
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->reserved_o), &(rhs->reserved_o)))
  {
    return false;
  }
  // reserved_p
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->reserved_p), &(rhs->reserved_p)))
  {
    return false;
  }
  return true;
}

bool
radar_msgs__msg__Od__copy(
  const radar_msgs__msg__Od * input,
  radar_msgs__msg__Od * output)
{
  if (!input || !output) {
    return false;
  }
  // object_id
  output->object_id = input->object_id;
  // age
  output->age = input->age;
  // measurement_status
  output->measurement_status = input->measurement_status;
  // motion_state
  output->motion_state = input->motion_state;
  // existance_confidence
  output->existance_confidence = input->existance_confidence;
  // pose
  if (!geometry_msgs__msg__Pose__copy(
      &(input->pose), &(output->pose)))
  {
    return false;
  }
  // dimensions
  if (!geometry_msgs__msg__Vector3__copy(
      &(input->dimensions), &(output->dimensions)))
  {
    return false;
  }
  // velocity
  if (!geometry_msgs__msg__Twist__copy(
      &(input->velocity), &(output->velocity)))
  {
    return false;
  }
  // acceleration
  if (!geometry_msgs__msg__Twist__copy(
      &(input->acceleration), &(output->acceleration)))
  {
    return false;
  }
  // v2ground
  if (!geometry_msgs__msg__Twist__copy(
      &(input->v2ground), &(output->v2ground)))
  {
    return false;
  }
  // pose_nearest
  if (!geometry_msgs__msg__Pose__copy(
      &(input->pose_nearest), &(output->pose_nearest)))
  {
    return false;
  }
  // type
  output->type = input->type;
  // car_confidence
  output->car_confidence = input->car_confidence;
  // bike_confidence
  output->bike_confidence = input->bike_confidence;
  // ped_confidence
  output->ped_confidence = input->ped_confidence;
  // truck_confidence
  output->truck_confidence = input->truck_confidence;
  // signboard_confidence
  output->signboard_confidence = input->signboard_confidence;
  // ground_confidence
  output->ground_confidence = input->ground_confidence;
  // obstacle_confidence
  output->obstacle_confidence = input->obstacle_confidence;
  // enrollptsnum
  output->enrollptsnum = input->enrollptsnum;
  // nearestptsx
  output->nearestptsx = input->nearestptsx;
  // nearestptsy
  output->nearestptsy = input->nearestptsy;
  // nearestptsz
  output->nearestptsz = input->nearestptsz;
  // reserved_d
  output->reserved_d = input->reserved_d;
  // reserved_e
  output->reserved_e = input->reserved_e;
  // reserved_f
  output->reserved_f = input->reserved_f;
  // reserved_g
  output->reserved_g = input->reserved_g;
  // reserved_h
  output->reserved_h = input->reserved_h;
  // reserved_i
  output->reserved_i = input->reserved_i;
  // reserved_j
  output->reserved_j = input->reserved_j;
  // reserved_k
  output->reserved_k = input->reserved_k;
  // reserved_l
  output->reserved_l = input->reserved_l;
  // reserved_m
  output->reserved_m = input->reserved_m;
  // reserved_n
  output->reserved_n = input->reserved_n;
  // reserved_o
  if (!rosidl_runtime_c__String__copy(
      &(input->reserved_o), &(output->reserved_o)))
  {
    return false;
  }
  // reserved_p
  if (!rosidl_runtime_c__String__copy(
      &(input->reserved_p), &(output->reserved_p)))
  {
    return false;
  }
  return true;
}

radar_msgs__msg__Od *
radar_msgs__msg__Od__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__Od * msg = (radar_msgs__msg__Od *)allocator.allocate(sizeof(radar_msgs__msg__Od), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(radar_msgs__msg__Od));
  bool success = radar_msgs__msg__Od__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
radar_msgs__msg__Od__destroy(radar_msgs__msg__Od * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    radar_msgs__msg__Od__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
radar_msgs__msg__Od__Sequence__init(radar_msgs__msg__Od__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__Od * data = NULL;

  if (size) {
    data = (radar_msgs__msg__Od *)allocator.zero_allocate(size, sizeof(radar_msgs__msg__Od), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = radar_msgs__msg__Od__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        radar_msgs__msg__Od__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
radar_msgs__msg__Od__Sequence__fini(radar_msgs__msg__Od__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      radar_msgs__msg__Od__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

radar_msgs__msg__Od__Sequence *
radar_msgs__msg__Od__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  radar_msgs__msg__Od__Sequence * array = (radar_msgs__msg__Od__Sequence *)allocator.allocate(sizeof(radar_msgs__msg__Od__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = radar_msgs__msg__Od__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
radar_msgs__msg__Od__Sequence__destroy(radar_msgs__msg__Od__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    radar_msgs__msg__Od__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
radar_msgs__msg__Od__Sequence__are_equal(const radar_msgs__msg__Od__Sequence * lhs, const radar_msgs__msg__Od__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!radar_msgs__msg__Od__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
radar_msgs__msg__Od__Sequence__copy(
  const radar_msgs__msg__Od__Sequence * input,
  radar_msgs__msg__Od__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(radar_msgs__msg__Od);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    radar_msgs__msg__Od * data =
      (radar_msgs__msg__Od *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!radar_msgs__msg__Od__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          radar_msgs__msg__Od__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!radar_msgs__msg__Od__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
