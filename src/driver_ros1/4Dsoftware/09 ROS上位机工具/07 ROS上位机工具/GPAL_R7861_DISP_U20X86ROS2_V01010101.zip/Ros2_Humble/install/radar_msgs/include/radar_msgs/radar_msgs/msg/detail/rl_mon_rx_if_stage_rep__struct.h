// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/RlMonRxIfStageRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_RX_IF_STAGE_REP__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_RX_IF_STAGE_REP__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/RlMonRxIfStageRep in the package radar_msgs.
typedef struct radar_msgs__msg__RlMonRxIfStageRep
{
  uint16_t statusflags;
  uint16_t errorcode;
  uint8_t profindex;
  uint8_t reserved0;
  int16_t lpfcutoffbandedgedroopvalrx0;
  int8_t hpfcutofffreqer[8];
  int8_t lpfcutoffstopbandatten[8];
  int8_t rxifagainerval[8];
  int8_t ifgainexp;
  uint8_t reserved2;
  int8_t lpfcutoffbandedgedroopvalrx[6];
  uint32_t timestamp;
} radar_msgs__msg__RlMonRxIfStageRep;

// Struct for a sequence of radar_msgs__msg__RlMonRxIfStageRep.
typedef struct radar_msgs__msg__RlMonRxIfStageRep__Sequence
{
  radar_msgs__msg__RlMonRxIfStageRep * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__RlMonRxIfStageRep__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_RX_IF_STAGE_REP__STRUCT_H_
