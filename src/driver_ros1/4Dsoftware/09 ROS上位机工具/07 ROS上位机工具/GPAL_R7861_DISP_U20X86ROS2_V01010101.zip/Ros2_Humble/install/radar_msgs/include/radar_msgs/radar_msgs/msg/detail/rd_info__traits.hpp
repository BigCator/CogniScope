// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/RdInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RD_INFO__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__RD_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/rd_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const RdInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: frameid
  {
    out << "frameid: ";
    rosidl_generator_traits::value_to_yaml(msg.frameid, out);
    out << ", ";
  }

  // member: cfarcount
  {
    out << "cfarcount: ";
    rosidl_generator_traits::value_to_yaml(msg.cfarcount, out);
    out << ", ";
  }

  // member: targetnum
  {
    out << "targetnum: ";
    rosidl_generator_traits::value_to_yaml(msg.targetnum, out);
    out << ", ";
  }

  // member: resetcnt
  {
    out << "resetcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.resetcnt, out);
    out << ", ";
  }

  // member: objnum
  {
    out << "objnum: ";
    rosidl_generator_traits::value_to_yaml(msg.objnum, out);
    out << ", ";
  }

  // member: carspeed
  {
    out << "carspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.carspeed, out);
    out << ", ";
  }

  // member: caryawrate
  {
    out << "caryawrate: ";
    rosidl_generator_traits::value_to_yaml(msg.caryawrate, out);
    out << ", ";
  }

  // member: gearstate
  {
    out << "gearstate: ";
    rosidl_generator_traits::value_to_yaml(msg.gearstate, out);
    out << ", ";
  }

  // member: odtimeoutcnt
  {
    out << "odtimeoutcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.odtimeoutcnt, out);
    out << ", ";
  }

  // member: comprotv_i
  {
    out << "comprotv_i: ";
    rosidl_generator_traits::value_to_yaml(msg.comprotv_i, out);
    out << ", ";
  }

  // member: comprotv_ii
  {
    out << "comprotv_ii: ";
    rosidl_generator_traits::value_to_yaml(msg.comprotv_ii, out);
    out << ", ";
  }

  // member: framelostcnt
  {
    out << "framelostcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.framelostcnt, out);
    out << ", ";
  }

  // member: beforeadcerrcnt
  {
    out << "beforeadcerrcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.beforeadcerrcnt, out);
    out << ", ";
  }

  // member: afteradcerrcnt
  {
    out << "afteradcerrcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.afteradcerrcnt, out);
    out << ", ";
  }

  // member: udpframelostcnt
  {
    out << "udpframelostcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.udpframelostcnt, out);
    out << ", ";
  }

  // member: udpfreq
  {
    out << "udpfreq: ";
    rosidl_generator_traits::value_to_yaml(msg.udpfreq, out);
    out << ", ";
  }

  // member: timesyncstatus
  {
    out << "timesyncstatus: ";
    rosidl_generator_traits::value_to_yaml(msg.timesyncstatus, out);
    out << ", ";
  }

  // member: velestimate
  {
    out << "velestimate: ";
    rosidl_generator_traits::value_to_yaml(msg.velestimate, out);
    out << ", ";
  }

  // member: gndk
  {
    out << "gndk: ";
    rosidl_generator_traits::value_to_yaml(msg.gndk, out);
    out << ", ";
  }

  // member: gndb
  {
    out << "gndb: ";
    rosidl_generator_traits::value_to_yaml(msg.gndb, out);
    out << ", ";
  }

  // member: pcl_time
  {
    out << "pcl_time: ";
    rosidl_generator_traits::value_to_yaml(msg.pcl_time, out);
    out << ", ";
  }

  // member: od_time
  {
    out << "od_time: ";
    rosidl_generator_traits::value_to_yaml(msg.od_time, out);
    out << ", ";
  }

  // member: rdframelostcnt
  {
    out << "rdframelostcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.rdframelostcnt, out);
    out << ", ";
  }

  // member: jamstatusprofile0
  {
    out << "jamstatusprofile0: ";
    rosidl_generator_traits::value_to_yaml(msg.jamstatusprofile0, out);
    out << ", ";
  }

  // member: jamstatusprofile1
  {
    out << "jamstatusprofile1: ";
    rosidl_generator_traits::value_to_yaml(msg.jamstatusprofile1, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RdInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: frameid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frameid: ";
    rosidl_generator_traits::value_to_yaml(msg.frameid, out);
    out << "\n";
  }

  // member: cfarcount
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cfarcount: ";
    rosidl_generator_traits::value_to_yaml(msg.cfarcount, out);
    out << "\n";
  }

  // member: targetnum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "targetnum: ";
    rosidl_generator_traits::value_to_yaml(msg.targetnum, out);
    out << "\n";
  }

  // member: resetcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "resetcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.resetcnt, out);
    out << "\n";
  }

  // member: objnum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "objnum: ";
    rosidl_generator_traits::value_to_yaml(msg.objnum, out);
    out << "\n";
  }

  // member: carspeed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "carspeed: ";
    rosidl_generator_traits::value_to_yaml(msg.carspeed, out);
    out << "\n";
  }

  // member: caryawrate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "caryawrate: ";
    rosidl_generator_traits::value_to_yaml(msg.caryawrate, out);
    out << "\n";
  }

  // member: gearstate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gearstate: ";
    rosidl_generator_traits::value_to_yaml(msg.gearstate, out);
    out << "\n";
  }

  // member: odtimeoutcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "odtimeoutcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.odtimeoutcnt, out);
    out << "\n";
  }

  // member: comprotv_i
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "comprotv_i: ";
    rosidl_generator_traits::value_to_yaml(msg.comprotv_i, out);
    out << "\n";
  }

  // member: comprotv_ii
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "comprotv_ii: ";
    rosidl_generator_traits::value_to_yaml(msg.comprotv_ii, out);
    out << "\n";
  }

  // member: framelostcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "framelostcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.framelostcnt, out);
    out << "\n";
  }

  // member: beforeadcerrcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "beforeadcerrcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.beforeadcerrcnt, out);
    out << "\n";
  }

  // member: afteradcerrcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "afteradcerrcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.afteradcerrcnt, out);
    out << "\n";
  }

  // member: udpframelostcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udpframelostcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.udpframelostcnt, out);
    out << "\n";
  }

  // member: udpfreq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "udpfreq: ";
    rosidl_generator_traits::value_to_yaml(msg.udpfreq, out);
    out << "\n";
  }

  // member: timesyncstatus
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timesyncstatus: ";
    rosidl_generator_traits::value_to_yaml(msg.timesyncstatus, out);
    out << "\n";
  }

  // member: velestimate
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "velestimate: ";
    rosidl_generator_traits::value_to_yaml(msg.velestimate, out);
    out << "\n";
  }

  // member: gndk
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gndk: ";
    rosidl_generator_traits::value_to_yaml(msg.gndk, out);
    out << "\n";
  }

  // member: gndb
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gndb: ";
    rosidl_generator_traits::value_to_yaml(msg.gndb, out);
    out << "\n";
  }

  // member: pcl_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pcl_time: ";
    rosidl_generator_traits::value_to_yaml(msg.pcl_time, out);
    out << "\n";
  }

  // member: od_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "od_time: ";
    rosidl_generator_traits::value_to_yaml(msg.od_time, out);
    out << "\n";
  }

  // member: rdframelostcnt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rdframelostcnt: ";
    rosidl_generator_traits::value_to_yaml(msg.rdframelostcnt, out);
    out << "\n";
  }

  // member: jamstatusprofile0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "jamstatusprofile0: ";
    rosidl_generator_traits::value_to_yaml(msg.jamstatusprofile0, out);
    out << "\n";
  }

  // member: jamstatusprofile1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "jamstatusprofile1: ";
    rosidl_generator_traits::value_to_yaml(msg.jamstatusprofile1, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RdInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::RdInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::RdInfo & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::RdInfo>()
{
  return "radar_msgs::msg::RdInfo";
}

template<>
inline const char * name<radar_msgs::msg::RdInfo>()
{
  return "radar_msgs/msg/RdInfo";
}

template<>
struct has_fixed_size<radar_msgs::msg::RdInfo>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<radar_msgs::msg::RdInfo>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<radar_msgs::msg::RdInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__RD_INFO__TRAITS_HPP_
