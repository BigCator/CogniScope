// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/InstallInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/install_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_InstallInfo_elevation_correction
{
public:
  explicit Init_InstallInfo_elevation_correction(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::InstallInfo elevation_correction(::radar_msgs::msg::InstallInfo::_elevation_correction_type arg)
  {
    msg_.elevation_correction = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_azimuth_correction
{
public:
  explicit Init_InstallInfo_azimuth_correction(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  Init_InstallInfo_elevation_correction azimuth_correction(::radar_msgs::msg::InstallInfo::_azimuth_correction_type arg)
  {
    msg_.azimuth_correction = std::move(arg);
    return Init_InstallInfo_elevation_correction(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_sensor_yawangle
{
public:
  explicit Init_InstallInfo_sensor_yawangle(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  Init_InstallInfo_azimuth_correction sensor_yawangle(::radar_msgs::msg::InstallInfo::_sensor_yawangle_type arg)
  {
    msg_.sensor_yawangle = std::move(arg);
    return Init_InstallInfo_azimuth_correction(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_sensor_pitchangle
{
public:
  explicit Init_InstallInfo_sensor_pitchangle(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  Init_InstallInfo_sensor_yawangle sensor_pitchangle(::radar_msgs::msg::InstallInfo::_sensor_pitchangle_type arg)
  {
    msg_.sensor_pitchangle = std::move(arg);
    return Init_InstallInfo_sensor_yawangle(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_sensor_rollangle
{
public:
  explicit Init_InstallInfo_sensor_rollangle(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  Init_InstallInfo_sensor_pitchangle sensor_rollangle(::radar_msgs::msg::InstallInfo::_sensor_rollangle_type arg)
  {
    msg_.sensor_rollangle = std::move(arg);
    return Init_InstallInfo_sensor_pitchangle(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_sensor_zposition
{
public:
  explicit Init_InstallInfo_sensor_zposition(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  Init_InstallInfo_sensor_rollangle sensor_zposition(::radar_msgs::msg::InstallInfo::_sensor_zposition_type arg)
  {
    msg_.sensor_zposition = std::move(arg);
    return Init_InstallInfo_sensor_rollangle(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_sensor_yposition
{
public:
  explicit Init_InstallInfo_sensor_yposition(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  Init_InstallInfo_sensor_zposition sensor_yposition(::radar_msgs::msg::InstallInfo::_sensor_yposition_type arg)
  {
    msg_.sensor_yposition = std::move(arg);
    return Init_InstallInfo_sensor_zposition(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_sensor_xposition
{
public:
  explicit Init_InstallInfo_sensor_xposition(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  Init_InstallInfo_sensor_yposition sensor_xposition(::radar_msgs::msg::InstallInfo::_sensor_xposition_type arg)
  {
    msg_.sensor_xposition = std::move(arg);
    return Init_InstallInfo_sensor_yposition(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_sensor_positioninvalid_flags
{
public:
  explicit Init_InstallInfo_sensor_positioninvalid_flags(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  Init_InstallInfo_sensor_xposition sensor_positioninvalid_flags(::radar_msgs::msg::InstallInfo::_sensor_positioninvalid_flags_type arg)
  {
    msg_.sensor_positioninvalid_flags = std::move(arg);
    return Init_InstallInfo_sensor_xposition(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_frame_cnt
{
public:
  explicit Init_InstallInfo_frame_cnt(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  Init_InstallInfo_sensor_positioninvalid_flags frame_cnt(::radar_msgs::msg::InstallInfo::_frame_cnt_type arg)
  {
    msg_.frame_cnt = std::move(arg);
    return Init_InstallInfo_sensor_positioninvalid_flags(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_radar_id
{
public:
  explicit Init_InstallInfo_radar_id(::radar_msgs::msg::InstallInfo & msg)
  : msg_(msg)
  {}
  Init_InstallInfo_frame_cnt radar_id(::radar_msgs::msg::InstallInfo::_radar_id_type arg)
  {
    msg_.radar_id = std::move(arg);
    return Init_InstallInfo_frame_cnt(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

class Init_InstallInfo_header
{
public:
  Init_InstallInfo_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_InstallInfo_radar_id header(::radar_msgs::msg::InstallInfo::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_InstallInfo_radar_id(msg_);
  }

private:
  ::radar_msgs::msg::InstallInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::InstallInfo>()
{
  return radar_msgs::msg::builder::Init_InstallInfo_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__BUILDER_HPP_
