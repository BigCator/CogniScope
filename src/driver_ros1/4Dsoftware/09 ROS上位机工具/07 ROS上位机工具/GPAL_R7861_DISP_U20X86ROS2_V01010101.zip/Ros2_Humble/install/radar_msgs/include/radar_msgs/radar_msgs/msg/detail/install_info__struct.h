// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/InstallInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/InstallInfo in the package radar_msgs.
typedef struct radar_msgs__msg__InstallInfo
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  /// radar ID
  uint32_t radar_id;
  /// frame cnt in radar
  uint32_t frame_cnt;
  uint16_t sensor_positioninvalid_flags;
  /// unit: m
  float sensor_xposition;
  /// unit: m
  float sensor_yposition;
  /// unit: m
  float sensor_zposition;
  /// unit: degree
  float sensor_rollangle;
  /// unit: degree
  float sensor_pitchangle;
  /// unit: degree
  float sensor_yawangle;
  /// unit: degree
  float azimuth_correction;
  /// unit: degree
  float elevation_correction;
} radar_msgs__msg__InstallInfo;

// Struct for a sequence of radar_msgs__msg__InstallInfo.
typedef struct radar_msgs__msg__InstallInfo__Sequence
{
  radar_msgs__msg__InstallInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__InstallInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__INSTALL_INFO__STRUCT_H_
