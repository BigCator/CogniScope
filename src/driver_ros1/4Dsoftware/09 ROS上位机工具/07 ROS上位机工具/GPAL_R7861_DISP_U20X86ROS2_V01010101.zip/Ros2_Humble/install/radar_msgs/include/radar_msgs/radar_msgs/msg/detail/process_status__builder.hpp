// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/ProcessStatus.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/process_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_ProcessStatus_reserved_ad
{
public:
  explicit Init_ProcessStatus_reserved_ad(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::ProcessStatus reserved_ad(::radar_msgs::msg::ProcessStatus::_reserved_ad_type arg)
  {
    msg_.reserved_ad = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_ac
{
public:
  explicit Init_ProcessStatus_reserved_ac(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_ad reserved_ac(::radar_msgs::msg::ProcessStatus::_reserved_ac_type arg)
  {
    msg_.reserved_ac = std::move(arg);
    return Init_ProcessStatus_reserved_ad(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_ab
{
public:
  explicit Init_ProcessStatus_reserved_ab(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_ac reserved_ab(::radar_msgs::msg::ProcessStatus::_reserved_ab_type arg)
  {
    msg_.reserved_ab = std::move(arg);
    return Init_ProcessStatus_reserved_ac(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_aa
{
public:
  explicit Init_ProcessStatus_reserved_aa(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_ab reserved_aa(::radar_msgs::msg::ProcessStatus::_reserved_aa_type arg)
  {
    msg_.reserved_aa = std::move(arg);
    return Init_ProcessStatus_reserved_ab(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_selfcalistatus
{
public:
  explicit Init_ProcessStatus_selfcalistatus(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_aa selfcalistatus(::radar_msgs::msg::ProcessStatus::_selfcalistatus_type arg)
  {
    msg_.selfcalistatus = std::move(arg);
    return Init_ProcessStatus_reserved_aa(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_odtimeoutcnt
{
public:
  explicit Init_ProcessStatus_odtimeoutcnt(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_selfcalistatus odtimeoutcnt(::radar_msgs::msg::ProcessStatus::_odtimeoutcnt_type arg)
  {
    msg_.odtimeoutcnt = std::move(arg);
    return Init_ProcessStatus_selfcalistatus(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_timeod
{
public:
  explicit Init_ProcessStatus_timeod(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_odtimeoutcnt timeod(::radar_msgs::msg::ProcessStatus::_timeod_type arg)
  {
    msg_.timeod = std::move(arg);
    return Init_ProcessStatus_odtimeoutcnt(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_z
{
public:
  explicit Init_ProcessStatus_reserved_z(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_timeod reserved_z(::radar_msgs::msg::ProcessStatus::_reserved_z_type arg)
  {
    msg_.reserved_z = std::move(arg);
    return Init_ProcessStatus_timeod(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_y
{
public:
  explicit Init_ProcessStatus_reserved_y(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_z reserved_y(::radar_msgs::msg::ProcessStatus::_reserved_y_type arg)
  {
    msg_.reserved_y = std::move(arg);
    return Init_ProcessStatus_reserved_z(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_x
{
public:
  explicit Init_ProcessStatus_reserved_x(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_y reserved_x(::radar_msgs::msg::ProcessStatus::_reserved_x_type arg)
  {
    msg_.reserved_x = std::move(arg);
    return Init_ProcessStatus_reserved_y(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_w
{
public:
  explicit Init_ProcessStatus_reserved_w(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_x reserved_w(::radar_msgs::msg::ProcessStatus::_reserved_w_type arg)
  {
    msg_.reserved_w = std::move(arg);
    return Init_ProcessStatus_reserved_x(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_timepcl
{
public:
  explicit Init_ProcessStatus_timepcl(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_w timepcl(::radar_msgs::msg::ProcessStatus::_timepcl_type arg)
  {
    msg_.timepcl = std::move(arg);
    return Init_ProcessStatus_reserved_w(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_v
{
public:
  explicit Init_ProcessStatus_reserved_v(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_timepcl reserved_v(::radar_msgs::msg::ProcessStatus::_reserved_v_type arg)
  {
    msg_.reserved_v = std::move(arg);
    return Init_ProcessStatus_timepcl(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_u
{
public:
  explicit Init_ProcessStatus_reserved_u(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_v reserved_u(::radar_msgs::msg::ProcessStatus::_reserved_u_type arg)
  {
    msg_.reserved_u = std::move(arg);
    return Init_ProcessStatus_reserved_v(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_t
{
public:
  explicit Init_ProcessStatus_reserved_t(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_u reserved_t(::radar_msgs::msg::ProcessStatus::_reserved_t_type arg)
  {
    msg_.reserved_t = std::move(arg);
    return Init_ProcessStatus_reserved_u(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_s
{
public:
  explicit Init_ProcessStatus_reserved_s(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_t reserved_s(::radar_msgs::msg::ProcessStatus::_reserved_s_type arg)
  {
    msg_.reserved_s = std::move(arg);
    return Init_ProcessStatus_reserved_t(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_timedoa
{
public:
  explicit Init_ProcessStatus_timedoa(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_s timedoa(::radar_msgs::msg::ProcessStatus::_timedoa_type arg)
  {
    msg_.timedoa = std::move(arg);
    return Init_ProcessStatus_reserved_s(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_r
{
public:
  explicit Init_ProcessStatus_reserved_r(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_timedoa reserved_r(::radar_msgs::msg::ProcessStatus::_reserved_r_type arg)
  {
    msg_.reserved_r = std::move(arg);
    return Init_ProcessStatus_timedoa(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_q
{
public:
  explicit Init_ProcessStatus_reserved_q(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_r reserved_q(::radar_msgs::msg::ProcessStatus::_reserved_q_type arg)
  {
    msg_.reserved_q = std::move(arg);
    return Init_ProcessStatus_reserved_r(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_p
{
public:
  explicit Init_ProcessStatus_reserved_p(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_q reserved_p(::radar_msgs::msg::ProcessStatus::_reserved_p_type arg)
  {
    msg_.reserved_p = std::move(arg);
    return Init_ProcessStatus_reserved_q(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_o
{
public:
  explicit Init_ProcessStatus_reserved_o(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_p reserved_o(::radar_msgs::msg::ProcessStatus::_reserved_o_type arg)
  {
    msg_.reserved_o = std::move(arg);
    return Init_ProcessStatus_reserved_p(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_timecfar
{
public:
  explicit Init_ProcessStatus_timecfar(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_o timecfar(::radar_msgs::msg::ProcessStatus::_timecfar_type arg)
  {
    msg_.timecfar = std::move(arg);
    return Init_ProcessStatus_reserved_o(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_n
{
public:
  explicit Init_ProcessStatus_reserved_n(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_timecfar reserved_n(::radar_msgs::msg::ProcessStatus::_reserved_n_type arg)
  {
    msg_.reserved_n = std::move(arg);
    return Init_ProcessStatus_timecfar(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_m
{
public:
  explicit Init_ProcessStatus_reserved_m(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_n reserved_m(::radar_msgs::msg::ProcessStatus::_reserved_m_type arg)
  {
    msg_.reserved_m = std::move(arg);
    return Init_ProcessStatus_reserved_n(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_l
{
public:
  explicit Init_ProcessStatus_reserved_l(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_m reserved_l(::radar_msgs::msg::ProcessStatus::_reserved_l_type arg)
  {
    msg_.reserved_l = std::move(arg);
    return Init_ProcessStatus_reserved_m(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_k
{
public:
  explicit Init_ProcessStatus_reserved_k(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_l reserved_k(::radar_msgs::msg::ProcessStatus::_reserved_k_type arg)
  {
    msg_.reserved_k = std::move(arg);
    return Init_ProcessStatus_reserved_l(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_timerdmap
{
public:
  explicit Init_ProcessStatus_timerdmap(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_k timerdmap(::radar_msgs::msg::ProcessStatus::_timerdmap_type arg)
  {
    msg_.timerdmap = std::move(arg);
    return Init_ProcessStatus_reserved_k(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_j
{
public:
  explicit Init_ProcessStatus_reserved_j(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_timerdmap reserved_j(::radar_msgs::msg::ProcessStatus::_reserved_j_type arg)
  {
    msg_.reserved_j = std::move(arg);
    return Init_ProcessStatus_timerdmap(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_i
{
public:
  explicit Init_ProcessStatus_reserved_i(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_j reserved_i(::radar_msgs::msg::ProcessStatus::_reserved_i_type arg)
  {
    msg_.reserved_i = std::move(arg);
    return Init_ProcessStatus_reserved_j(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_h
{
public:
  explicit Init_ProcessStatus_reserved_h(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_i reserved_h(::radar_msgs::msg::ProcessStatus::_reserved_h_type arg)
  {
    msg_.reserved_h = std::move(arg);
    return Init_ProcessStatus_reserved_i(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_g
{
public:
  explicit Init_ProcessStatus_reserved_g(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_h reserved_g(::radar_msgs::msg::ProcessStatus::_reserved_g_type arg)
  {
    msg_.reserved_g = std::move(arg);
    return Init_ProcessStatus_reserved_h(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_time2dfft
{
public:
  explicit Init_ProcessStatus_time2dfft(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_g time2dfft(::radar_msgs::msg::ProcessStatus::_time2dfft_type arg)
  {
    msg_.time2dfft = std::move(arg);
    return Init_ProcessStatus_reserved_g(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_f
{
public:
  explicit Init_ProcessStatus_reserved_f(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_time2dfft reserved_f(::radar_msgs::msg::ProcessStatus::_reserved_f_type arg)
  {
    msg_.reserved_f = std::move(arg);
    return Init_ProcessStatus_time2dfft(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_e
{
public:
  explicit Init_ProcessStatus_reserved_e(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_f reserved_e(::radar_msgs::msg::ProcessStatus::_reserved_e_type arg)
  {
    msg_.reserved_e = std::move(arg);
    return Init_ProcessStatus_reserved_f(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_d
{
public:
  explicit Init_ProcessStatus_reserved_d(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_e reserved_d(::radar_msgs::msg::ProcessStatus::_reserved_d_type arg)
  {
    msg_.reserved_d = std::move(arg);
    return Init_ProcessStatus_reserved_e(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_c
{
public:
  explicit Init_ProcessStatus_reserved_c(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_d reserved_c(::radar_msgs::msg::ProcessStatus::_reserved_c_type arg)
  {
    msg_.reserved_c = std::move(arg);
    return Init_ProcessStatus_reserved_d(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_time1dfft
{
public:
  explicit Init_ProcessStatus_time1dfft(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_c time1dfft(::radar_msgs::msg::ProcessStatus::_time1dfft_type arg)
  {
    msg_.time1dfft = std::move(arg);
    return Init_ProcessStatus_reserved_c(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_b
{
public:
  explicit Init_ProcessStatus_reserved_b(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_time1dfft reserved_b(::radar_msgs::msg::ProcessStatus::_reserved_b_type arg)
  {
    msg_.reserved_b = std::move(arg);
    return Init_ProcessStatus_time1dfft(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_reserved_a
{
public:
  explicit Init_ProcessStatus_reserved_a(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_b reserved_a(::radar_msgs::msg::ProcessStatus::_reserved_a_type arg)
  {
    msg_.reserved_a = std::move(arg);
    return Init_ProcessStatus_reserved_b(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_adcerrcnt
{
public:
  explicit Init_ProcessStatus_adcerrcnt(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_reserved_a adcerrcnt(::radar_msgs::msg::ProcessStatus::_adcerrcnt_type arg)
  {
    msg_.adcerrcnt = std::move(arg);
    return Init_ProcessStatus_reserved_a(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_framelost_cnt
{
public:
  explicit Init_ProcessStatus_framelost_cnt(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_adcerrcnt framelost_cnt(::radar_msgs::msg::ProcessStatus::_framelost_cnt_type arg)
  {
    msg_.framelost_cnt = std::move(arg);
    return Init_ProcessStatus_adcerrcnt(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_capture_time
{
public:
  explicit Init_ProcessStatus_capture_time(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_framelost_cnt capture_time(::radar_msgs::msg::ProcessStatus::_capture_time_type arg)
  {
    msg_.capture_time = std::move(arg);
    return Init_ProcessStatus_framelost_cnt(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_frame_cnt
{
public:
  explicit Init_ProcessStatus_frame_cnt(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_capture_time frame_cnt(::radar_msgs::msg::ProcessStatus::_frame_cnt_type arg)
  {
    msg_.frame_cnt = std::move(arg);
    return Init_ProcessStatus_capture_time(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_radar_id
{
public:
  explicit Init_ProcessStatus_radar_id(::radar_msgs::msg::ProcessStatus & msg)
  : msg_(msg)
  {}
  Init_ProcessStatus_frame_cnt radar_id(::radar_msgs::msg::ProcessStatus::_radar_id_type arg)
  {
    msg_.radar_id = std::move(arg);
    return Init_ProcessStatus_frame_cnt(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

class Init_ProcessStatus_header
{
public:
  Init_ProcessStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ProcessStatus_radar_id header(::radar_msgs::msg::ProcessStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ProcessStatus_radar_id(msg_);
  }

private:
  ::radar_msgs::msg::ProcessStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::ProcessStatus>()
{
  return radar_msgs::msg::builder::Init_ProcessStatus_header();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__PROCESS_STATUS__BUILDER_HPP_
