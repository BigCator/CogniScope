// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__UDP_PACKET_HPP_
#define RADAR_MSGS__MSG__UDP_PACKET_HPP_

#include "radar_msgs/msg/detail/udp_packet__struct.hpp"
#include "radar_msgs/msg/detail/udp_packet__builder.hpp"
#include "radar_msgs/msg/detail/udp_packet__traits.hpp"

#endif  // RADAR_MSGS__MSG__UDP_PACKET_HPP_
