// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from radar_msgs:msg/RlMonPllConVoltRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_PLL_CON_VOLT_REP__TRAITS_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_PLL_CON_VOLT_REP__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "radar_msgs/msg/detail/rl_mon_pll_con_volt_rep__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace radar_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const RlMonPllConVoltRep & msg,
  std::ostream & out)
{
  out << "{";
  // member: statusflags
  {
    out << "statusflags: ";
    rosidl_generator_traits::value_to_yaml(msg.statusflags, out);
    out << ", ";
  }

  // member: errorcode
  {
    out << "errorcode: ";
    rosidl_generator_traits::value_to_yaml(msg.errorcode, out);
    out << ", ";
  }

  // member: pllcontvoltval
  {
    if (msg.pllcontvoltval.size() == 0) {
      out << "pllcontvoltval: []";
    } else {
      out << "pllcontvoltval: [";
      size_t pending_items = msg.pllcontvoltval.size();
      for (auto item : msg.pllcontvoltval) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved
  {
    out << "reserved: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved, out);
    out << ", ";
  }

  // member: timestamp
  {
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RlMonPllConVoltRep & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: statusflags
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "statusflags: ";
    rosidl_generator_traits::value_to_yaml(msg.statusflags, out);
    out << "\n";
  }

  // member: errorcode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "errorcode: ";
    rosidl_generator_traits::value_to_yaml(msg.errorcode, out);
    out << "\n";
  }

  // member: pllcontvoltval
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.pllcontvoltval.size() == 0) {
      out << "pllcontvoltval: []\n";
    } else {
      out << "pllcontvoltval:\n";
      for (auto item : msg.pllcontvoltval) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reserved: ";
    rosidl_generator_traits::value_to_yaml(msg.reserved, out);
    out << "\n";
  }

  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RlMonPllConVoltRep & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace radar_msgs

namespace rosidl_generator_traits
{

[[deprecated("use radar_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const radar_msgs::msg::RlMonPllConVoltRep & msg,
  std::ostream & out, size_t indentation = 0)
{
  radar_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use radar_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const radar_msgs::msg::RlMonPllConVoltRep & msg)
{
  return radar_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<radar_msgs::msg::RlMonPllConVoltRep>()
{
  return "radar_msgs::msg::RlMonPllConVoltRep";
}

template<>
inline const char * name<radar_msgs::msg::RlMonPllConVoltRep>()
{
  return "radar_msgs/msg/RlMonPllConVoltRep";
}

template<>
struct has_fixed_size<radar_msgs::msg::RlMonPllConVoltRep>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<radar_msgs::msg::RlMonPllConVoltRep>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<radar_msgs::msg::RlMonPllConVoltRep>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_PLL_CON_VOLT_REP__TRAITS_HPP_
