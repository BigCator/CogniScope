// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from radar_msgs:msg/RdInfo.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RD_INFO__STRUCT_H_
#define RADAR_MSGS__MSG__DETAIL__RD_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/RdInfo in the package radar_msgs.
typedef struct radar_msgs__msg__RdInfo
{
  /// Includes measurement timestamp and coordinate frame.
  std_msgs__msg__Header header;
  uint32_t frameid;
  /// cfar count
  uint32_t cfarcount;
  /// targets Num
  uint32_t targetnum;
  /// reset count
  int16_t resetcnt;
  /// object number of this frame
  uint32_t objnum;
  /// ego car speed
  float carspeed;
  /// ego car yaw rate
  float caryawrate;
  /// ego car gear state
  uint16_t gearstate;
  int16_t odtimeoutcnt;
  uint16_t comprotv_i;
  uint16_t comprotv_ii;
  /// frame lost count checked by ROS sw
  uint16_t framelostcnt;
  uint16_t beforeadcerrcnt;
  uint16_t afteradcerrcnt;
  /// counter of lost frames
  uint32_t udpframelostcnt;
  /// frames frequency in Hz
  float udpfreq;
  /// status of time synchronization
  uint16_t timesyncstatus;
  /// estimated car speed, m/s
  float velestimate;
  float gndk;
  float gndb;
  /// duration of od process (ms)
  float pcl_time;
  /// duration of od process (ms)
  float od_time;
  /// frame lost count in radar
  uint32_t rdframelostcnt;
  /// 16 bytes of LSB of reserved_k, 0 ~ 100
  uint16_t jamstatusprofile0;
  /// 16 bytes of MSB of reserved_k, 0 ~ 100
  uint16_t jamstatusprofile1;
} radar_msgs__msg__RdInfo;

// Struct for a sequence of radar_msgs__msg__RdInfo.
typedef struct radar_msgs__msg__RdInfo__Sequence
{
  radar_msgs__msg__RdInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} radar_msgs__msg__RdInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // RADAR_MSGS__MSG__DETAIL__RD_INFO__STRUCT_H_
