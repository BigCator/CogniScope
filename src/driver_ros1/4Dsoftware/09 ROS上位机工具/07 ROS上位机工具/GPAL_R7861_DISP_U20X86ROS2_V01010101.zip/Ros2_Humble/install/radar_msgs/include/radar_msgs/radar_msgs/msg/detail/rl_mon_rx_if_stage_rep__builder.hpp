// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from radar_msgs:msg/RlMonRxIfStageRep.idl
// generated code does not contain a copyright notice

#ifndef RADAR_MSGS__MSG__DETAIL__RL_MON_RX_IF_STAGE_REP__BUILDER_HPP_
#define RADAR_MSGS__MSG__DETAIL__RL_MON_RX_IF_STAGE_REP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "radar_msgs/msg/detail/rl_mon_rx_if_stage_rep__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace radar_msgs
{

namespace msg
{

namespace builder
{

class Init_RlMonRxIfStageRep_timestamp
{
public:
  explicit Init_RlMonRxIfStageRep_timestamp(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  ::radar_msgs::msg::RlMonRxIfStageRep timestamp(::radar_msgs::msg::RlMonRxIfStageRep::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_lpfcutoffbandedgedroopvalrx
{
public:
  explicit Init_RlMonRxIfStageRep_lpfcutoffbandedgedroopvalrx(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIfStageRep_timestamp lpfcutoffbandedgedroopvalrx(::radar_msgs::msg::RlMonRxIfStageRep::_lpfcutoffbandedgedroopvalrx_type arg)
  {
    msg_.lpfcutoffbandedgedroopvalrx = std::move(arg);
    return Init_RlMonRxIfStageRep_timestamp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_reserved2
{
public:
  explicit Init_RlMonRxIfStageRep_reserved2(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIfStageRep_lpfcutoffbandedgedroopvalrx reserved2(::radar_msgs::msg::RlMonRxIfStageRep::_reserved2_type arg)
  {
    msg_.reserved2 = std::move(arg);
    return Init_RlMonRxIfStageRep_lpfcutoffbandedgedroopvalrx(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_ifgainexp
{
public:
  explicit Init_RlMonRxIfStageRep_ifgainexp(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIfStageRep_reserved2 ifgainexp(::radar_msgs::msg::RlMonRxIfStageRep::_ifgainexp_type arg)
  {
    msg_.ifgainexp = std::move(arg);
    return Init_RlMonRxIfStageRep_reserved2(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_rxifagainerval
{
public:
  explicit Init_RlMonRxIfStageRep_rxifagainerval(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIfStageRep_ifgainexp rxifagainerval(::radar_msgs::msg::RlMonRxIfStageRep::_rxifagainerval_type arg)
  {
    msg_.rxifagainerval = std::move(arg);
    return Init_RlMonRxIfStageRep_ifgainexp(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_lpfcutoffstopbandatten
{
public:
  explicit Init_RlMonRxIfStageRep_lpfcutoffstopbandatten(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIfStageRep_rxifagainerval lpfcutoffstopbandatten(::radar_msgs::msg::RlMonRxIfStageRep::_lpfcutoffstopbandatten_type arg)
  {
    msg_.lpfcutoffstopbandatten = std::move(arg);
    return Init_RlMonRxIfStageRep_rxifagainerval(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_hpfcutofffreqer
{
public:
  explicit Init_RlMonRxIfStageRep_hpfcutofffreqer(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIfStageRep_lpfcutoffstopbandatten hpfcutofffreqer(::radar_msgs::msg::RlMonRxIfStageRep::_hpfcutofffreqer_type arg)
  {
    msg_.hpfcutofffreqer = std::move(arg);
    return Init_RlMonRxIfStageRep_lpfcutoffstopbandatten(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_lpfcutoffbandedgedroopvalrx0
{
public:
  explicit Init_RlMonRxIfStageRep_lpfcutoffbandedgedroopvalrx0(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIfStageRep_hpfcutofffreqer lpfcutoffbandedgedroopvalrx0(::radar_msgs::msg::RlMonRxIfStageRep::_lpfcutoffbandedgedroopvalrx0_type arg)
  {
    msg_.lpfcutoffbandedgedroopvalrx0 = std::move(arg);
    return Init_RlMonRxIfStageRep_hpfcutofffreqer(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_reserved0
{
public:
  explicit Init_RlMonRxIfStageRep_reserved0(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIfStageRep_lpfcutoffbandedgedroopvalrx0 reserved0(::radar_msgs::msg::RlMonRxIfStageRep::_reserved0_type arg)
  {
    msg_.reserved0 = std::move(arg);
    return Init_RlMonRxIfStageRep_lpfcutoffbandedgedroopvalrx0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_profindex
{
public:
  explicit Init_RlMonRxIfStageRep_profindex(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIfStageRep_reserved0 profindex(::radar_msgs::msg::RlMonRxIfStageRep::_profindex_type arg)
  {
    msg_.profindex = std::move(arg);
    return Init_RlMonRxIfStageRep_reserved0(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_errorcode
{
public:
  explicit Init_RlMonRxIfStageRep_errorcode(::radar_msgs::msg::RlMonRxIfStageRep & msg)
  : msg_(msg)
  {}
  Init_RlMonRxIfStageRep_profindex errorcode(::radar_msgs::msg::RlMonRxIfStageRep::_errorcode_type arg)
  {
    msg_.errorcode = std::move(arg);
    return Init_RlMonRxIfStageRep_profindex(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

class Init_RlMonRxIfStageRep_statusflags
{
public:
  Init_RlMonRxIfStageRep_statusflags()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RlMonRxIfStageRep_errorcode statusflags(::radar_msgs::msg::RlMonRxIfStageRep::_statusflags_type arg)
  {
    msg_.statusflags = std::move(arg);
    return Init_RlMonRxIfStageRep_errorcode(msg_);
  }

private:
  ::radar_msgs::msg::RlMonRxIfStageRep msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::radar_msgs::msg::RlMonRxIfStageRep>()
{
  return radar_msgs::msg::builder::Init_RlMonRxIfStageRep_statusflags();
}

}  // namespace radar_msgs

#endif  // RADAR_MSGS__MSG__DETAIL__RL_MON_RX_IF_STAGE_REP__BUILDER_HPP_
