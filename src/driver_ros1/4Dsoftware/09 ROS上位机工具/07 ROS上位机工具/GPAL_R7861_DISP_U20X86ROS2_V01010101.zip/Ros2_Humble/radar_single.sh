#!/bin/bash


source /opt/ros/humble/setup.bash
source install/setup.bash
sleep 0.5
ros2 launch radar_show gpal_rd_single.xml


